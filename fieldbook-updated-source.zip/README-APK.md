# FieldBook - Android APK & Installation Guide / ऐप डाउनलोड और APK गाइड

## 1. क्या इंस्टॉल करने के बाद ऐप का UI और फीचर्स इस प्रिव्यू जैसे ही रहेंगे?
**हाँ, 100% बिल्कुल समान (Identical)!**
- वही हरा-भरा किसान अनुकूल थीम (Emerald Theme)
- वही फसल खाता (Crop Ledger), मंडी कैलकुलेटर (Mandi Calculator), मौसम अलर्ट (Mandi & Weather)
- वही कैलकुलेटर और नोट्स/सामान लिस्ट (Notes & Shopping Checklist)
- आपके फोन में ऐप बिना ब्राउज़र बार (Full-Screen Native UI) के साथ खुलेगा और बिना इंटरनेट के भी पूरा डेटा फोन में सुरक्षित चलेगा।

---

## 2. डायरेक्ट APK डाउनलोड करने के 3 आसान तरीके:

### तरीका A: 1-क्लिक में आधिकारिक APK (PWABuilder - अनुशंसित)
यह Microsoft का आधिकारिक फ्री टूल है जो किसी भी PWA को 1 मिनट में असली `.apk` फाइल में बदल देता है:
1. नीचे दिए गए डायरेक्ट लिंक पर जाएं:
   👉 **https://www.pwabuilder.com/reportcard?site=https://ais-pre-r2stqjpopqjqnvs5err4lv-603898960151.asia-east1.run.app**
2. **"Package for Android"** बटन पर क्लिक करें।
3. **"Generate APK / Package"** चुनें।
4. आपकी रेडीमेड `.apk` फाइल तुरंत डाउनलोड हो जाएगी! इसे फोन में सामान्य रूप से इंस्टॉल करें।

---

### तरीका B: बिना किसी फाइल को डाउनलोड किए सीधे फोन में ऐप लगाना (WebAPK)
Android और Google का आधुनिक नियम WebAPK है:
1. अपने Android फोन में Chrome से ऐप खोलें।
2. ऊपर दाईं ओर **3 बिंदी (⋮)** पर टच करें।
3. **"Install app"** या **"होम स्क्रीन में जोड़ें"** चुनें।
4. Android खुद-ब-खुद आपके फोन में इसका असली ऐप आइकन बना देगा।

---

### तरीका C: GitHub से डायरेक्ट APK बनाना (GitHub Actions)
इस प्रोजेक्ट में `.github/workflows/build-apk.yml` पहले से शामिल है:
1. इस प्रोजेक्ट की ZIP फाइल को अपने GitHub अकाउंट पर एक नई रिपॉजिटरी में अपलोड (Push) करें।
2. GitHub पर **Actions** टैब में जाएं।
3. **"Build Android APK"** अपने आप चल जाएगा और 2-3 मिनट में **"FieldBook-Android-APK"** नाम से डाउनलोड करने के लिए तैयार `.apk` फाइल Artifacts में मिल जाएगी!
