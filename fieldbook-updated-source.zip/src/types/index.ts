export type Language = 'hi' | 'en';
export type Theme = 'dark' | 'light';

export type AreaUnit = 'acre' | 'bigha' | 'hectare' | 'marla' | 'kanal' | 'guntha';

export type CropSeason = 'kharif' | 'rabi' | 'zaid' | 'annual';

export type CropAccountingType = 'one_time' | 'recurring';

export type CropCategory = 'grain' | 'vegetable' | 'fruit' | 'pulse' | 'oilseed' | 'other';

export interface CropCycle {
  id: string;
  name: string;
  hindiName: string;
  variety?: string;
  cropCategory?: CropCategory;
  landArea: number;
  areaUnit: AreaUnit;
  season: CropSeason;
  sowingDate: string; // YYYY-MM-DD
  expectedHarvestDate?: string;
  status: 'active' | 'harvested' | 'archived';
  accountingType?: CropAccountingType;
  targetYieldQuintal?: number;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type ExpenseCategory =
  | 'fertilizer' // खाद और गोबर खाद (Fertilizers & Manure)
  | 'seeds' // बीज और पौध (Seeds & Seedlings)
  | 'pesticide' // कीटनाशक / दवाई / स्प्रे (Sprays & Pesticides)
  | 'irrigation' // पानी / सिंचाई / डीजल (Irrigation)
  | 'labour' // मजदूरी / लेबर (Labour)
  | 'machinery' // ट्रैक्टर / जुताई / कटाई (Machinery)
  | 'transport' // ढुलाई / मंडी किराया (Transport)
  | 'other'; // अन्य खर्च (Other Expenses)

export type IncomeCategory =
  | 'mandi_sale' // मंडी बिक्री
  | 'local_sale' // स्थानीय / गांव में बिक्री
  | 'subsidy' // सरकारी अनुदान / सब्सिडी
  | 'byproduct'; // भूसा / पराली बिक्री

export interface MandiDetails {
  grossWeightKg?: number;
  tareWeightKg?: number;
  netWeightQuintal: number;
  ratePerQuintal: number;
  palledariPerQuintal?: number;
  totalPalledari?: number;
  mandiCess?: number;
  buyerName?: string;
  receiptNumber?: string;
}

export interface ReceiptAttachment {
  id: string;
  transactionId: string;
  transactionType: 'expense' | 'income';
  cropId: string;
  category: ExpenseCategory | IncomeCategory;
  title: string;
  date: string; // YYYY-MM-DD (Transaction date is source of truth)
  amount: number; // Rupees (Transaction amount is source of truth)
  fileName: string;
  mimeType: string;
  fileSize: number;
  storageRef: string; // Key in IndexedDB / persistent receipt store
  createdAt: string;
  updatedAt: string;
}

export interface Transaction {
  id: string;
  cropId: string;
  type: 'expense' | 'income';
  category: ExpenseCategory | IncomeCategory;
  title: string;
  amount: number;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  quantity?: number;
  unit?: string; // kg, liter, bag, hours, days
  ratePerUnit?: number;
  vendorOrBuyer?: string;
  notes?: string;
  paymentStatus: 'paid' | 'pending';
  mandiDetails?: MandiDetails;
  receiptAttachment?: ReceiptAttachment;
  createdAt: string;
}

export interface HarvestEntry {
  id: string;
  cropId: string;
  date: string;
  time: string;
  quantityQuintal: number;
  quantityValue?: number;
  quantityUnit?: 'quintal' | 'kg';
  moisturePercentage?: number;
  grade?: string; // A, B, C
  storageLocation?: string; // Mandi direct, Home godown, Warehouse
  notes?: string;
}

export interface DiaryEntry {
  id: string;
  cropId: string;
  date: string;
  time: string;
  activityType: 'sowing' | 'irrigation' | 'fertilizer' | 'spray' | 'inspection' | 'harvest' | 'weeding' | 'other';
  notes: string;
  weatherNote?: string;
}

export interface FarmReportSummary {
  totalLagat: number;
  totalKamai: number;
  netProfit: number;
  profitMarginPercent: number;
  totalLandAreaAcre: number;
  costPerAcre: number;
  profitPerAcre: number;
  totalYieldQuintal: number;
  expenseByCategory: Record<string, number>;
}

export interface FarmNote {
  id: string;
  title: string;
  content: string;
  category: 'general' | 'reminder' | 'field_work' | 'payment' | 'spray';
  isPinned: boolean;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  color?: string; // emerald, amber, sky, purple, rose
  createdAt: string;
  updatedAt: string;
}

export interface ShoppingItem {
  id: string;
  name: string;
  category: 'fertilizer' | 'seeds' | 'pesticide' | 'machinery_tools' | 'irrigation' | 'general';
  quantity: number;
  unit: string; // बोरी (Bags), पैकेट (Packets), लीटर (Liters), किलो (Kg), नग (Pcs)
  estimatedCost?: number;
  actualCost?: number;
  isPurchased: boolean;
  notes?: string;
  date: string; // YYYY-MM-DD
  createdAt: string;
}

export interface MonthlyCropEntry {
  monthKey: string; // 'YYYY-MM'
  year: number;
  month: number; // 1-12
  salesTotal: number;
  expensesTotal: number;
  netProfit: number; // salesTotal - expensesTotal
  isProfit: boolean;
  salesCount: number;
  expensesCount: number;
  harvestQuintal: number;
  harvestCount: number;
  salesTransactions: Transaction[];
  expenseTransactions: Transaction[];
  harvestEntries: HarvestEntry[];
  expensesByCategory: Record<ExpenseCategory, number>;
  hasSalesWithoutRecordedExpenses: boolean;
  hasExpensesOnly: boolean;
  isEmpty: boolean;
  cumulativeSales: number;
  cumulativeExpenses: number;
  cumulativeNetProfit: number;
}

export interface CropMonthlyAccountingSummary {
  cropId: string;
  accountingType: CropAccountingType;
  months: MonthlyCropEntry[];
  monthsMap: Record<string, MonthlyCropEntry>;
  availableMonthKeys: string[]; // Sorted ascending ('YYYY-MM')
  totalSales: number;
  totalExpenses: number;
  overallNetProfit: number;
  isOverallProfit: boolean;
  totalHarvestQuintal: number;
  totalSalesCount: number;
  totalExpensesCount: number;
  totalHarvestCount: number;
}

export interface FarmMonthlyCropSummary {
  crop: CropCycle;
  monthKey: string;
  expensesTotal: number;
  salesTotal: number;
  netProfit: number;
  isProfit: boolean;
  expensesCount: number;
  salesCount: number;
  harvestQuintal: number;
  harvestCount: number;
  expenseTransactions: Transaction[];
  salesTransactions: Transaction[];
  harvestEntries: HarvestEntry[];
  expensesByCategory: Record<ExpenseCategory, number>;
}

export interface FarmMonthlyAccountingSummary {
  monthKey: string;
  year: number;
  month: number;
  availableMonthKeys: string[];
  totalExpenses: number;
  totalSales: number;
  netProfit: number;
  isProfit: boolean;
  totalExpensesCount: number;
  totalSalesCount: number;
  cropSummaries: FarmMonthlyCropSummary[];
}


