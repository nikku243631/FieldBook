import React from 'react';
import { CropCycle, Transaction, HarvestEntry, Language, Theme } from '../types';
import { formatCurrency, getTranslation } from '../utils/translations';
import {
  calculateCropFinancials,
  calculateCropTimeline,
  getCropCategoryLabel,
  getEffectiveCropAccountingType,
  getEffectiveCropCategory
} from '../utils/calculations';
import {
  Sprout,
  TrendingUp,
  TrendingDown,
  Calendar,
  ArrowRight,
  Trash2,
  Coins,
  Clock
} from 'lucide-react';

interface CropCardProps {
  crop: CropCycle;
  transactions: Transaction[];
  harvests: HarvestEntry[];
  lang: Language;
  theme: Theme;
  onSelect: (cropId: string) => void;
  onDelete?: (cropId: string, cropName: string) => void;
}

export const CropCard: React.FC<CropCardProps> = ({
  crop,
  transactions,
  harvests,
  lang,
  onSelect,
  onDelete
}) => {
  const financials = calculateCropFinancials(crop, transactions, harvests);
  const timeline = calculateCropTimeline(crop);
  const category = getEffectiveCropCategory(crop);
  const harvestType = getEffectiveCropAccountingType(crop);

  const totalLagat = financials.totalExpenses;
  const totalKamai = financials.totalIncome;
  const netProfit = financials.netProfit;
  const isProfit = financials.isProfit;
  const totalYield = financials.totalHarvestQuintal;
  const profitPerUnit = financials.profitPerUnit;
  const areaUnitLabel = getTranslation(lang, crop.areaUnit);

  return (
    <article
      onClick={() => onSelect(crop.id)}
      className="liquid-glass-card group relative rounded-[28px] p-4 sm:p-5 transition-all duration-200 cursor-pointer overflow-hidden hover:-translate-y-0.5"
    >
      {/* Top Row: Season + Area on Left | Frosted Status Pill + Red Glass Delete Button on Right */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="inline-flex flex-wrap items-center gap-1.5 text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100">
          <Sprout className="w-4 h-4 shrink-0 text-emerald-700 dark:text-emerald-400" />
          <span>
            {crop.season === 'rabi'
              ? 'रबी (Rabi)'
              : crop.season === 'kharif'
              ? 'खरीफ (Kharif)'
              : crop.season === 'zaid'
              ? 'जायद (Zaid)'
              : 'वार्षिक (Annual)'}
          </span>
          <span>·</span>
          <span className="font-extrabold">
            {crop.landArea} {areaUnitLabel}
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span
            className={`px-3 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 ${
              crop.status === 'active'
                ? 'liquid-glass-income text-emerald-950 dark:text-emerald-200'
                : 'liquid-glass-pill text-slate-900 dark:text-slate-200'
            }`}
          >
            <Sprout className="w-3 h-3 text-emerald-700 dark:text-emerald-400 shrink-0" />
            <span>
              {crop.status === 'active'
                ? getTranslation(lang, 'active')
                : crop.status === 'harvested'
                ? getTranslation(lang, 'harvested')
                : getTranslation(lang, 'archived')}
            </span>
          </span>

          {onDelete && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onDelete(crop.id, crop.hindiName || crop.name);
              }}
              title={lang === 'hi' ? 'फसल हटाएं' : 'Delete Crop'}
              aria-label={lang === 'hi' ? 'फसल हटाएं' : 'Delete Crop'}
              className="liquid-glass-danger w-9 h-9 rounded-2xl flex items-center justify-center cursor-pointer shrink-0"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Crop Title, Category & Harvest Type */}
      <div className="mb-3">
        <h3 className="text-xl sm:text-2xl font-black tracking-tight text-slate-950 dark:text-white leading-tight">
          {lang === 'hi' ? crop.hindiName || crop.name : crop.name}
        </h3>
        <div className="flex flex-wrap items-center gap-1.5 mt-1 text-[11px] font-bold text-slate-800 dark:text-slate-200">
          <span className="px-2 py-0.5 rounded-md bg-white/75 dark:bg-slate-800/80 border border-slate-300/80 dark:border-slate-700">
            {getCropCategoryLabel(category, lang)}
          </span>
          <span className="px-2 py-0.5 rounded-md bg-blue-50/85 dark:bg-blue-950/60 text-blue-900 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
            {harvestType === 'recurring'
              ? lang === 'hi'
                ? 'बार-बार तुड़ाई (Repeated Harvest)'
                : 'Repeated Harvest'
              : lang === 'hi'
              ? 'एक बार कटाई (Single Harvest)'
              : 'Single Harvest'}
          </span>
          {crop.variety && (
            <span className="text-slate-700 dark:text-slate-300">
              · {lang === 'hi' ? 'किस्म:' : 'Variety:'} <strong>{crop.variety}</strong>
            </span>
          )}
        </div>
      </div>

      {/* 3 Translucent 3D Glass Financial Sub-Cards matching Reference Image */}
      <div className="grid grid-cols-3 gap-2 sm:gap-2.5 mb-3">
        {/* 1. Expenses (Lagat) */}
        <div className="liquid-glass-expense p-2.5 sm:p-3 rounded-2xl">
          <div className="flex items-center gap-1">
            <Coins className="w-3.5 h-3.5 text-rose-700 dark:text-rose-300 shrink-0" />
            <span className="text-[10px] sm:text-[11px] font-bold truncate text-rose-950 dark:text-rose-200">
              {lang === 'hi' ? 'लागत (Lagat)' : 'Expenses (Lagat)'}
            </span>
          </div>
          <span className="text-sm sm:text-base font-black block tabular-nums text-rose-800 dark:text-rose-300 mt-1 truncate">
            {formatCurrency(totalLagat)}
          </span>
        </div>

        {/* 2. Income (Kamai) */}
        <div className="liquid-glass-income p-2.5 sm:p-3 rounded-2xl">
          <div className="flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-800 dark:text-emerald-300 shrink-0" />
            <span className="text-[10px] sm:text-[11px] font-bold truncate text-emerald-950 dark:text-emerald-200">
              {lang === 'hi' ? 'कमाई (Kamai)' : 'Income (Kamai)'}
            </span>
          </div>
          <span className="text-sm sm:text-base font-black block tabular-nums text-emerald-900 dark:text-emerald-300 mt-1 truncate">
            {formatCurrency(totalKamai)}
          </span>
        </div>

        {/* 3. Net Profit / Net Loss */}
        <div
          className={`p-2.5 sm:p-3 rounded-2xl ${
            isProfit ? 'liquid-glass-profit' : 'liquid-glass-expense'
          }`}
        >
          <div className="flex items-center gap-1">
            {isProfit ? (
              <TrendingUp className="w-3.5 h-3.5 shrink-0 text-blue-800 dark:text-blue-300" />
            ) : (
              <TrendingDown className="w-3.5 h-3.5 shrink-0 text-rose-700 dark:text-rose-300" />
            )}
            <span
              className={`text-[10px] sm:text-[11px] font-bold truncate ${
                isProfit
                  ? 'text-blue-950 dark:text-blue-200'
                  : 'text-rose-950 dark:text-rose-200'
              }`}
            >
              {isProfit ? getTranslation(lang, 'netProfit') : getTranslation(lang, 'netLoss')}
            </span>
          </div>
          <span
            className={`text-sm sm:text-base font-black block tabular-nums mt-0.5 truncate ${
              isProfit
                ? 'text-blue-800 dark:text-blue-300'
                : 'text-rose-800 dark:text-rose-300'
            }`}
          >
            {isProfit ? '+' : ''}
            {formatCurrency(netProfit)}
          </span>
          <span className="text-[10px] font-bold block truncate text-rose-900/90 dark:text-slate-300">
            {profitPerUnit >= 0 ? '+' : ''}
            {formatCurrency(profitPerUnit)} / {areaUnitLabel}
          </span>
        </div>
      </div>

      {/* Crop Age & Harvest Date Info Strip */}
      <div className="flex flex-wrap items-center justify-between gap-1.5 text-[11px] font-bold text-slate-800 dark:text-slate-200 mb-2.5 px-1">
        <span className="inline-flex items-center gap-1">
          <Clock className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400 shrink-0" />
          <span>
            {lang === 'hi' ? 'फसल उम्र:' : 'Crop Age:'}{' '}
            <strong className="font-mono">{timeline.cropAgeDays}</strong>{' '}
            {lang === 'hi' ? 'दिन' : 'days'}
          </span>
        </span>
        {timeline.expectedHarvestDate && (
          <span className="text-slate-700 dark:text-slate-300">
            {timeline.isHarvestDatePassed
              ? lang === 'hi'
                ? 'अनुमानित कटाई तारीख निकल चुकी है'
                : 'Expected harvest date has passed.'
              : timeline.isHarvestDateToday
              ? lang === 'hi'
                ? 'आज अनुमानित कटाई तारीख'
                : 'Expected harvest today'
              : lang === 'hi'
              ? `कटाई में ~${timeline.daysRemainingUntilHarvest} दिन बाकी`
              : `~${timeline.daysRemainingUntilHarvest} days to harvest`}
          </span>
        )}
      </div>

      {/* Bottom Row: Sowing Date on Left | 3D Emerald Glass "Open Ledger →" Pill on Right */}
      <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/50 dark:border-slate-700/60 text-xs font-bold text-slate-900 dark:text-slate-100">
        <div className="flex items-center gap-1.5 truncate">
          <Calendar className="w-4 h-4 shrink-0 text-slate-800 dark:text-emerald-400" />
          <span>
            {lang === 'hi' ? 'बुवाई:' : 'Sown:'} {crop.sowingDate}
          </span>
          {totalYield > 0 && (
            <>
              <span>·</span>
              <span className="font-extrabold text-emerald-800 dark:text-emerald-300">
                {totalYield} {getTranslation(lang, 'quintal')}
              </span>
            </>
          )}
        </div>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onSelect(crop.id);
          }}
          className="liquid-glass-emerald px-4 py-1.5 rounded-full text-white flex items-center gap-1.5 text-xs font-extrabold shrink-0 cursor-pointer"
        >
          <span>{lang === 'hi' ? 'खाता खोलें' : 'Open Ledger'}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </article>
  );
};

