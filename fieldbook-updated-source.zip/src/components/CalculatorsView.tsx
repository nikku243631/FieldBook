import React, { useState } from 'react';
import {
  Calculator,
  Droplets,
  Sprout,
  Scale,
  Landmark,
  Share2,
  RotateCcw,
  CheckCircle2,
  Info,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Tractor
} from 'lucide-react';
import { Language, Theme } from '../types';
import { formatCurrency } from '../utils/translations';
import { shareViaWhatsApp } from '../utils/export';

interface CalculatorsViewProps {
  lang: Language;
  theme?: Theme;
}

type CalcTab = 'fertilizer' | 'pesticide' | 'seed' | 'kcc' | 'land' | 'yield';

const CROP_PRESETS: Record<
  string,
  {
    nameHi: string;
    nameEn: string;
    n: number;
    p: number;
    k: number;
    seedRateKgPerAcre: number;
    germination: number;
  }
> = {
  wheat: { nameHi: 'गेहूं (Wheat)', nameEn: 'Wheat', n: 50, p: 25, k: 15, seedRateKgPerAcre: 45, germination: 85 },
  paddy: { nameHi: 'धान (Paddy)', nameEn: 'Paddy / Rice', n: 50, p: 25, k: 25, seedRateKgPerAcre: 12, germination: 85 },
  mustard: { nameHi: 'सरसों (Mustard)', nameEn: 'Mustard', n: 35, p: 20, k: 10, seedRateKgPerAcre: 2, germination: 90 },
  potato: { nameHi: 'आलू (Potato)', nameEn: 'Potato', n: 60, p: 35, k: 40, seedRateKgPerAcre: 1000, germination: 95 },
  cotton: { nameHi: 'कपास (Cotton)', nameEn: 'Cotton', n: 45, p: 25, k: 20, seedRateKgPerAcre: 1.5, germination: 80 },
  sugarcane: { nameHi: 'गन्ना (Sugarcane)', nameEn: 'Sugarcane', n: 80, p: 35, k: 35, seedRateKgPerAcre: 2800, germination: 85 },
  soybean: { nameHi: 'सोयाबीन (Soybean)', nameEn: 'Soybean', n: 12, p: 32, k: 16, seedRateKgPerAcre: 30, germination: 80 },
  maize: { nameHi: 'मक्का (Maize)', nameEn: 'Maize / Corn', n: 50, p: 25, k: 15, seedRateKgPerAcre: 8, germination: 90 }
};

export const CalculatorsView: React.FC<CalculatorsViewProps> = ({ lang, theme = 'light' }) => {
  const [activeTab, setActiveTab] = useState<CalcTab>('fertilizer');
  const [showGuide, setShowGuide] = useState<boolean>(false);
  const [phoneInput, setPhoneInput] = useState<string>('');
  const isDark = theme === 'dark';

  // 1. Fertilizer (NPK -> Urea, DAP, MOP) State
  const [selectedPreset, setSelectedPreset] = useState<string>('wheat');
  const [fertArea, setFertArea] = useState<string>('2');
  const [fertUnit, setFertUnit] = useState<'Acre' | 'Hectare' | 'Bigha'>('Acre');
  const [targetN, setTargetN] = useState<string>('50');
  const [targetP, setTargetP] = useState<string>('25');
  const [targetK, setTargetK] = useState<string>('15');

  // 2. Pesticide Spray Tank Calculator State
  const [sprayArea, setSprayArea] = useState<string>('2');
  const [waterPerAcre, setWaterPerAcre] = useState<string>('150');
  const [tankCapacity, setTankCapacity] = useState<string>('16');
  const [doseMlPerLiter, setDoseMlPerLiter] = useState<string>('2');

  // 3. Seed Rate Calculator State
  const [seedArea, setSeedArea] = useState<string>('3');
  const [seedRatePerAcre, setSeedRatePerAcre] = useState<string>('45');
  const [germinationPct, setGerminationPct] = useState<string>('85');
  const [seedPricePerKg, setSeedPricePerKg] = useState<string>('38');

  // 4. KCC / Farm Loan Interest Calculator State
  const [loanPrincipal, setLoanPrincipal] = useState<string>('100000');
  const [loanRateYear, setLoanRateYear] = useState<string>('4');
  const [loanMonths, setLoanMonths] = useState<string>('6');

  // 5. Land Area Unit Converter State
  const [landValue, setLandValue] = useState<string>('5');
  const [landFromUnit, setLandFromUnit] = useState<'Bigha' | 'Acre' | 'Hectare' | 'Kanal'>('Bigha');
  const [bighaPerAcreRatio, setBighaPerAcreRatio] = useState<string>('1.6');

  // 6. Mandi Moisture & Net Realization State
  const [grossWeightQtl, setGrossWeightQtl] = useState<string>('50');
  const [mandiRatePerQtl, setMandiRatePerQtl] = useState<string>('2425');
  const [actualMoisture, setActualMoisture] = useState<string>('15.5');
  const [standardMoisture, setStandardMoisture] = useState<string>('14.0');
  const [hamaliAndTulaiCost, setHamaliAndTulaiCost] = useState<string>('650');

  const handleApplyPreset = (key: string) => {
    setSelectedPreset(key);
    const p = CROP_PRESETS[key];
    if (p) {
      setTargetN(String(p.n));
      setTargetP(String(p.p));
      setTargetK(String(p.k));
      setSeedRatePerAcre(String(p.seedRateKgPerAcre));
      setGerminationPct(String(p.germination));
    }
  };

  // --- Fertilizer Calculations ---
  const areaVal = Math.max(0, parseFloat(fertArea) || 0);
  const areaInAcres =
    fertUnit === 'Acre' ? areaVal : fertUnit === 'Hectare' ? areaVal * 2.47105 : areaVal / 1.6;
  const nPerAcre = Math.max(0, parseFloat(targetN) || 0);
  const pPerAcre = Math.max(0, parseFloat(targetP) || 0);
  const kPerAcre = Math.max(0, parseFloat(targetK) || 0);

  const totalNRequired = nPerAcre * areaInAcres;
  const totalPRequired = pPerAcre * areaInAcres;
  const totalKRequired = kPerAcre * areaInAcres;

  const dapKg = totalPRequired / 0.46;
  const nSuppliedByDap = dapKg * 0.18;
  const remainingN = Math.max(0, totalNRequired - nSuppliedByDap);
  const ureaKg = remainingN / 0.46;
  const mopKg = totalKRequired / 0.6;

  const dapBags = dapKg / 50;
  const ureaBags = ureaKg / 45;
  const mopBags = mopKg / 50;

  // --- Spray Calculations ---
  const spArea = Math.max(0, parseFloat(sprayArea) || 0);
  const spWaterPerAcre = Math.max(1, parseFloat(waterPerAcre) || 150);
  const spTankCap = Math.max(1, parseFloat(tankCapacity) || 16);
  const spDose = Math.max(0, parseFloat(doseMlPerLiter) || 0);

  const totalWaterLiters = spArea * spWaterPerAcre;
  const totalTanks = totalWaterLiters / spTankCap;
  const medicinePerTankMl = spTankCap * spDose;
  const totalMedicineMl = totalWaterLiters * spDose;

  // --- Seed Calculations ---
  const sArea = Math.max(0, parseFloat(seedArea) || 0);
  const sRate = Math.max(0, parseFloat(seedRatePerAcre) || 0);
  const sGerm = Math.min(100, Math.max(10, parseFloat(germinationPct) || 85));
  const sPrice = Math.max(0, parseFloat(seedPricePerKg) || 0);

  const adjustedSeedPerAcre = (sRate * 85) / sGerm;
  const totalSeedKg = adjustedSeedPerAcre * sArea;
  const totalSeedCost = totalSeedKg * sPrice;

  // --- KCC Loan Calculations ---
  const principal = Math.max(0, parseFloat(loanPrincipal) || 0);
  const annualRate = Math.max(0, parseFloat(loanRateYear) || 0);
  const months = Math.max(0, parseFloat(loanMonths) || 0);
  const simpleInterest = (principal * annualRate * (months / 12)) / 100;
  const totalPayable = principal + simpleInterest;

  // --- Land Converter Calculations ---
  const lVal = Math.max(0, parseFloat(landValue) || 0);
  const bighaRatio = Math.max(0.5, parseFloat(bighaPerAcreRatio) || 1.6);
  const baseAcres =
    landFromUnit === 'Acre'
      ? lVal
      : landFromUnit === 'Hectare'
      ? lVal * 2.47105
      : landFromUnit === 'Kanal'
      ? lVal / 8
      : lVal / bighaRatio;

  const convAcres = baseAcres;
  const convHectares = baseAcres / 2.47105;
  const convBigha = baseAcres * bighaRatio;
  const convKanal = baseAcres * 8;
  const convSqFt = baseAcres * 43560;

  // --- Mandi Moisture & Realization Calculations ---
  const grossQtl = Math.max(0, parseFloat(grossWeightQtl) || 0);
  const rateQtl = Math.max(0, parseFloat(mandiRatePerQtl) || 0);
  const actMoist = Math.max(0, parseFloat(actualMoisture) || 0);
  const stdMoist = Math.max(0, parseFloat(standardMoisture) || 14);
  const mandiExpenses = Math.max(0, parseFloat(hamaliAndTulaiCost) || 0);

  const excessMoisturePct = Math.max(0, actMoist - stdMoist);
  const moistureWeightCutQtl = (grossQtl * excessMoisturePct) / 100;
  const netBillableWeightQtl = Math.max(0, grossQtl - moistureWeightCutQtl);
  const grossMandiAmount = netBillableWeightQtl * rateQtl;
  const netMandiHandAmount = Math.max(0, grossMandiAmount - mandiExpenses);

  const shareCurrentCalculationOnWhatsApp = () => {
    let text = '';
    if (activeTab === 'fertilizer') {
      text =
        `🌱 *FieldBook उर्वरक (NPK) हिसाब*\n` +
        `क्षेत्रफल: ${fertArea} ${fertUnit}\n` +
        `• DAP खाद: *${dapKg.toFixed(1)} Kg* (${dapBags.toFixed(1)} बोरी)\n` +
        `• यूरिया (Urea): *${ureaKg.toFixed(1)} Kg* (${ureaBags.toFixed(1)} बोरी)\n` +
        `• पोटाश (MOP): *${mopKg.toFixed(1)} Kg* (${mopBags.toFixed(1)} बोरी)`;
    } else if (activeTab === 'pesticide') {
      text =
        `💧 *FieldBook स्प्रे पंप और दवाई हिसाब*\n` +
        `क्षेत्रफल: ${sprayArea} एकड़ | टंकी: ${tankCapacity} लीटर\n` +
        `• कुल पानी: *${totalWaterLiters.toFixed(0)} लीटर* (${totalTanks.toFixed(1)} टंकी)\n` +
        `• प्रति टंकी दवाई: *${medicinePerTankMl.toFixed(0)} ml*\n` +
        `• कुल दवाई: *${totalMedicineMl.toFixed(0)} ml* (${(totalMedicineMl / 1000).toFixed(2)} L)`;
    } else if (activeTab === 'seed') {
      text =
        `🌾 *FieldBook बीज मात्रा (Seed Rate) हिसाब*\n` +
        `क्षेत्रफल: ${seedArea} एकड़\n` +
        `• कुल आवश्यक बीज: *${totalSeedKg.toFixed(1)} Kg*\n` +
        `• अनुमानित बीज खर्च: *${formatCurrency(totalSeedCost)}*`;
    } else if (activeTab === 'kcc') {
      text =
        `🏦 *FieldBook किसान क्रेडिट कार्ड (KCC) ब्याज हिसाब*\n` +
        `मूलधन: ${formatCurrency(principal)} | दर: ${annualRate}% | समय: ${months} माह\n` +
        `• कुल ब्याज: *${formatCurrency(simpleInterest)}*\n` +
        `• कुल देय राशि: *${formatCurrency(totalPayable)}*`;
    } else if (activeTab === 'land') {
      text =
        `📐 *FieldBook खेत नाप कन्वर्टर*\n` +
        `${landValue} ${landFromUnit} बराबर है:\n` +
        `• एकड़ (Acre): *${convAcres.toFixed(2)}*\n` +
        `• बीघा (Bigha): *${convBigha.toFixed(2)}*\n` +
        `• हेक्टेयर (Hectare): *${convHectares.toFixed(2)}*\n` +
        `• कनाल (Kanal): *${convKanal.toFixed(2)}*`;
    } else {
      text =
        `⚖️ *FieldBook मंडी नमी और तौल हिसाब*\n` +
        `कुल वजन: ${grossQtl} क्विंटल | भाव: ₹${rateQtl}/क्विंटल\n` +
        `• नमी कटौती (${excessMoisturePct.toFixed(1)}%): *-${moistureWeightCutQtl.toFixed(2)} क्विंटल*\n` +
        `• शुद्ध वजन: *${netBillableWeightQtl.toFixed(2)} क्विंटल*\n` +
        `• हाथ में शुद्ध रकम: *${formatCurrency(netMandiHandAmount)}*`;
    }

    shareViaWhatsApp(text, phoneInput);
  };

  const tabs: { id: CalcTab; labelHi: string; labelEn: string; icon: React.ReactNode }[] = [
    { id: 'fertilizer', labelHi: 'खाद / NPK', labelEn: 'Fertilizer (NPK)', icon: <Sprout className="w-4 h-4" /> },
    { id: 'pesticide', labelHi: 'स्प्रे टंकी', labelEn: 'Spray Tank', icon: <Droplets className="w-4 h-4" /> },
    { id: 'seed', labelHi: 'बीज मात्रा', labelEn: 'Seed Rate', icon: <Tractor className="w-4 h-4" /> },
    { id: 'yield', labelHi: 'मंडी व नमी', labelEn: 'Mandi & Moisture', icon: <Scale className="w-4 h-4" /> },
    { id: 'kcc', labelHi: 'KCC ब्याज', labelEn: 'KCC Loan', icon: <Landmark className="w-4 h-4" /> },
    { id: 'land', labelHi: 'खेत नाप', labelEn: 'Land Unit', icon: <Calculator className="w-4 h-4" /> }
  ];

  const inputClass =
    'w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500';
  const labelClass = 'block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1';

  return (
    <div className="max-w-5xl mx-auto pb-20 space-y-4">
      {/* Header Banner */}
      <div
        className={`liquid-glass-card rounded-2xl p-4 sm:p-5 ${
          isDark ? 'text-slate-100' : 'text-slate-900'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1 text-[11px] font-extrabold text-emerald-800 dark:text-emerald-400 mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? '6-इन-1 स्मार्ट कृषि कैलकुलेटर' : '6-in-1 Smart Farm Calculators'}</span>
            </div>
            <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
              {lang === 'hi' ? 'खाद, स्प्रे, बीज, मंडी और ब्याज कैलकुलेटर' : 'Fertilizer, Spray, Seed, Mandi & KCC Calculators'}
            </h2>
          </div>

          <button
            type="button"
            onClick={() => setShowGuide(!showGuide)}
            className="liquid-glass-amber self-start sm:self-auto inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-amber-900 dark:text-amber-200 text-xs font-extrabold transition-all cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5 text-amber-700 dark:text-amber-300" />
            <span>{lang === 'hi' ? 'कैसे इस्तेमाल करें?' : 'How to use?'}</span>
            {showGuide ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {showGuide && (
          <div className="liquid-glass-income mt-3 p-3 rounded-xl text-xs text-slate-800 dark:text-slate-200 space-y-1 leading-relaxed">
            <p className="font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
              <Info className="w-3.5 h-3.5 shrink-0" />
              {lang === 'hi' ? 'आसान निर्देश (Quick Guide):' : 'Quick Instructions:'}
            </p>
            <p>
              {lang === 'hi'
                ? '1. नीचे दिए गए 6 बटन में से अपनी जरूरत का कैलकुलेटर चुनें (जैसे खाद/NPK या स्प्रे टंकी)।'
                : '1. Pick any of the 6 specialized farm tools from the tabs below.'}
            </p>
            <p>
              {lang === 'hi'
                ? '2. अपने खेत का क्षेत्रफल (एकड़/बीघा) भरें — नीचे तुरंत बोरी और खर्च का सटीक हिसाब आ जाएगा।'
                : '2. Enter your plot size or weight — exact bag counts and net payouts appear automatically.'}
            </p>
          </div>
        )}

        {/* 6 Tool Selector Tabs — Unclipped & Liquid Glass */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mt-3.5 pt-3.5 border-t border-slate-200/70 dark:border-slate-700/70">
          {tabs.map(t => {
            const active = activeTab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveTab(t.id)}
                className={`flex items-center justify-center gap-1.5 px-2.5 py-2.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                  active
                    ? 'btn-3d-primary text-white'
                    : 'liquid-glass-pill text-slate-800 dark:text-slate-100'
                }`}
              >
                {t.icon}
                <span className="leading-tight text-center">{lang === 'hi' ? t.labelHi : t.labelEn}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Active Calculator Body */}
      <div
        className={`liquid-glass-card rounded-2xl p-4 sm:p-5 space-y-4 ${
          isDark ? 'text-slate-100' : 'text-slate-900'
        }`}
      >
        {/* 1. FERTILIZER CALCULATOR */}
        {activeTab === 'fertilizer' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200/70 dark:border-slate-700/70">
              <div>
                <h3 className="text-sm sm:text-base font-extrabold">
                  {lang === 'hi' ? 'उर्वरक (यूरिया, डीएपी, पोटाश) कैलकुलेटर' : 'Fertilizer (Urea, DAP, MOP) Calculator'}
                </h3>
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {lang === 'hi'
                    ? 'फसल चुनें या प्रति एकड़ N-P-K की मात्रा लिखकर जानें कितनी बोरी खाद लगेगी'
                    : 'Select crop preset or enter N-P-K dose per acre to calculate exact fertilizer bags'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleApplyPreset('wheat')}
                className="liquid-glass-amber self-start sm:self-auto inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-amber-900 dark:text-amber-200 text-xs font-extrabold cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                {lang === 'hi' ? 'रीसेट' : 'Reset'}
              </button>
            </div>

            {/* Crop Quick Presets */}
            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1.5">
                {lang === 'hi' ? 'फसल चुनें (ऑटोमैटिक अनुशंसित NPK मात्रा):' : 'Select Crop Preset (Auto-fills recommended NPK/acre):'}
              </label>
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(CROP_PRESETS).map(([key, item]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => handleApplyPreset(key)}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                      selectedPreset === key
                        ? 'btn-3d-primary text-white'
                        : 'liquid-glass-pill text-slate-800 dark:text-slate-100'
                    }`}
                  >
                    {lang === 'hi' ? item.nameHi : item.nameEn}
                  </button>
                ))}
              </div>
            </div>

            {/* Inputs Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'खेत का क्षेत्रफल (Area)' : 'Land Area'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.1"
                  value={fertArea}
                  onChange={e => setFertArea(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'इकाई (Unit)' : 'Area Unit'}
                </label>
                <select
                  value={fertUnit}
                  onChange={e => setFertUnit(e.target.value as 'Acre' | 'Hectare' | 'Bigha')}
                  className={inputClass}
                >
                  <option value="Acre">{lang === 'hi' ? 'एकड़ (Acre)' : 'Acre'}</option>
                  <option value="Bigha">{lang === 'hi' ? 'बीघा (Bigha)' : 'Bigha'}</option>
                  <option value="Hectare">{lang === 'hi' ? 'हेक्टेयर (Hectare)' : 'Hectare'}</option>
                </select>
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'नाइट्रोजन (N kg/एकड़)' : 'Nitrogen (N kg/acre)'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={targetN}
                  onChange={e => setTargetN(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'फॉस्फोरस (P kg/एकड़)' : 'Phosphorus (P kg/acre)'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={targetP}
                  onChange={e => setTargetP(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'पोटाश (K kg/एकड़)' : 'Potash (K kg/acre)'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={targetK}
                  onChange={e => setTargetK(e.target.value)}
                  className={inputClass}
                />
              </div>
            </div>

            {/* Fertilizer Output Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="p-3.5 rounded-xl bg-amber-50/80 dark:bg-amber-950/35 border border-amber-200 dark:border-amber-800/70">
                <div className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                  {lang === 'hi' ? 'डीएपी खाद (DAP 18:46)' : 'DAP Fertilizer (18:46)'}
                </div>
                <div className="text-lg sm:text-xl font-bold mt-1 font-mono">
                  {dapKg.toFixed(1)} <span className="text-xs font-semibold">Kg</span>
                </div>
                <div className="mt-1.5 inline-block px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-900/50 text-amber-900 dark:text-amber-200 text-xs font-semibold">
                  ≈ {dapBags.toFixed(2)} {lang === 'hi' ? 'बोरी (50 Kg)' : 'Bags (50 Kg)'}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/35 border border-emerald-200 dark:border-emerald-800/70">
                <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                  {lang === 'hi' ? 'यूरिया खाद (Urea 46% N)' : 'Urea Fertilizer (46% N)'}
                </div>
                <div className="text-lg sm:text-xl font-bold mt-1 font-mono">
                  {ureaKg.toFixed(1)} <span className="text-xs font-semibold">Kg</span>
                </div>
                <div className="mt-1.5 inline-block px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-900/50 text-emerald-900 dark:text-emerald-200 text-xs font-semibold">
                  ≈ {ureaBags.toFixed(2)} {lang === 'hi' ? 'बोरी (45 Kg)' : 'Bags (45 Kg)'}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-rose-50/80 dark:bg-rose-950/35 border border-rose-200 dark:border-rose-800/70">
                <div className="text-xs font-semibold text-rose-800 dark:text-rose-300">
                  {lang === 'hi' ? 'पोटाश खाद (MOP 60% K)' : 'MOP Potash (60% K)'}
                </div>
                <div className="text-lg sm:text-xl font-bold mt-1 font-mono">
                  {mopKg.toFixed(1)} <span className="text-xs font-semibold">Kg</span>
                </div>
                <div className="mt-1.5 inline-block px-2 py-0.5 rounded-md bg-rose-100 dark:bg-rose-900/50 text-rose-900 dark:text-rose-200 text-xs font-semibold">
                  ≈ {mopBags.toFixed(2)} {lang === 'hi' ? 'बोरी (50 Kg)' : 'Bags (50 Kg)'}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 2. PESTICIDE SPRAY CALCULATOR */}
        {activeTab === 'pesticide' && (
          <div className="space-y-4">
            <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm sm:text-base font-bold">
                {lang === 'hi' ? 'कीटनाशक स्प्रे पंप और दवाई कैलकुलेटर' : 'Pesticide Spray Tank & Dose Calculator'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {lang === 'hi'
                  ? 'जानें पूरे खेत में कितनी टंकी पानी लगेगा और हर टंकी में कितनी दवाई (ml) डालनी है'
                  : 'Calculate total spray tanks needed and exact chemical dose per tank'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'खेत का क्षेत्रफल (एकड़)' : 'Area to Spray (Acres)'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.5"
                  value={sprayArea}
                  onChange={e => setSprayArea(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'प्रति एकड़ पानी (लीटर)' : 'Water per Acre (Liters)'}
                </label>
                <input
                  type="number"
                  min="10"
                  value={waterPerAcre}
                  onChange={e => setWaterPerAcre(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'स्प्रे पंप टंकी साइज (लीटर)' : 'Spray Tank Capacity (L)'}
                </label>
                <select
                  value={tankCapacity}
                  onChange={e => setTankCapacity(e.target.value)}
                  className={inputClass}
                >
                  <option value="15">15 Liters</option>
                  <option value="16">16 Liters (Standard)</option>
                  <option value="20">20 Liters</option>
                  <option value="25">25 Liters (Power Sprayer)</option>
                  <option value="500">500 Liters (Tractor Boom)</option>
                </select>
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'दवाई की मात्रा (ml प्रति लीटर)' : 'Chemical Dose (ml / Liter)'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.25"
                  value={doseMlPerLiter}
                  onChange={e => setDoseMlPerLiter(e.target.value)}
                  className={inputClass}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="p-3.5 rounded-xl bg-blue-50/80 dark:bg-blue-950/35 border border-blue-200 dark:border-blue-800/70">
                <div className="text-xs font-semibold text-blue-800 dark:text-blue-300">
                  {lang === 'hi' ? 'कुल स्प्रे पंप (टंकी)' : 'Total Spray Tanks'}
                </div>
                <div className="text-lg sm:text-xl font-bold mt-1 font-mono">
                  {totalTanks.toFixed(1)} <span className="text-xs font-semibold">{lang === 'hi' ? 'टंकी' : 'Tanks'}</span>
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                  {lang === 'hi' ? `कुल पानी: ${totalWaterLiters.toFixed(0)} लीटर` : `Total Water: ${totalWaterLiters.toFixed(0)} L`}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/35 border border-emerald-200 dark:border-emerald-800/70">
                <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                  {lang === 'hi' ? '1 टंकी में दवाई डालें' : 'Dose per 1 Tank'}
                </div>
                <div className="text-lg sm:text-xl font-bold mt-1 font-mono">
                  {medicinePerTankMl.toFixed(0)} <span className="text-xs font-semibold">ml / g</span>
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                  {lang === 'hi' ? `प्रति ${tankCapacity}L पंप में` : `Per ${tankCapacity}L sprayer tank`}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-amber-50/80 dark:bg-amber-950/35 border border-amber-200 dark:border-amber-800/70">
                <div className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                  {lang === 'hi' ? 'कुल दवाई खरीदी' : 'Total Chemical Needed'}
                </div>
                <div className="text-lg sm:text-xl font-bold mt-1 font-mono">
                  {totalMedicineMl.toFixed(0)} <span className="text-xs font-semibold">ml</span>
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                  ≈ {(totalMedicineMl / 1000).toFixed(2)} {lang === 'hi' ? 'लीटर / किलो' : 'Liters / Kg'}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 3. SEED RATE CALCULATOR */}
        {activeTab === 'seed' && (
          <div className="space-y-4">
            <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm sm:text-base font-bold">
                {lang === 'hi' ? 'बीज मात्रा (Seed Rate) और खर्च कैलकुलेटर' : 'Seed Quantity & Cost Calculator'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {lang === 'hi'
                  ? 'अंकुरण क्षमता (Germination %) के अनुसार बुवाई के लिए सही बीज मात्रा निकालें'
                  : 'Calculate exact seed weight adjusted for germination percentage'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'बुवाई क्षेत्रफल (एकड़)' : 'Sowing Area (Acres)'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.5"
                  value={seedArea}
                  onChange={e => setSeedArea(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'बीज दर (Kg प्रति एकड़)' : 'Standard Seed Rate (Kg/Acre)'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={seedRatePerAcre}
                  onChange={e => setSeedRatePerAcre(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'अंकुरण क्षमता (Germination %)' : 'Germination %'}
                </label>
                <input
                  type="number"
                  min="20"
                  max="100"
                  value={germinationPct}
                  onChange={e => setGerminationPct(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'बीज का भाव (₹ प्रति किलो)' : 'Seed Price (₹ per Kg)'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={seedPricePerKg}
                  onChange={e => setSeedPricePerKg(e.target.value)}
                  className={inputClass}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="p-3.5 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/35 border border-emerald-200 dark:border-emerald-800/70">
                <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                  {lang === 'hi' ? 'प्रति एकड़ आवश्यक बीज' : 'Adjusted Seed / Acre'}
                </div>
                <div className="text-lg sm:text-xl font-bold mt-1 font-mono">
                  {adjustedSeedPerAcre.toFixed(1)} <span className="text-xs font-semibold">Kg</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-amber-50/80 dark:bg-amber-950/35 border border-amber-200 dark:border-amber-800/70">
                <div className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                  {lang === 'hi' ? 'कुल बीज वजन' : 'Total Seed Quantity'}
                </div>
                <div className="text-lg sm:text-xl font-bold mt-1 font-mono">
                  {totalSeedKg.toFixed(1)} <span className="text-xs font-semibold">Kg</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-blue-50/80 dark:bg-blue-950/35 border border-blue-200 dark:border-blue-800/70">
                <div className="text-xs font-semibold text-blue-800 dark:text-blue-300">
                  {lang === 'hi' ? 'अनुमानित बीज खर्च' : 'Estimated Seed Cost'}
                </div>
                <div className="text-lg sm:text-xl font-bold mt-1 font-mono">
                  {formatCurrency(totalSeedCost)}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 4. MANDI MOISTURE & REALIZATION */}
        {activeTab === 'yield' && (
          <div className="space-y-4">
            <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm sm:text-base font-bold">
                {lang === 'hi' ? 'मंडी नमी कटौती और शुद्ध भुगतान कैलकुलेटर' : 'Mandi Moisture Cut & Net Payout Calculator'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {lang === 'hi'
                  ? 'अनाज में नमी (Moisture) और हमाली/तुलाई खर्च घटाने के बाद हाथ में आने वाली शुद्ध रकम जानें'
                  : 'Calculate net billable weight after moisture deduction and unloading charges'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'कुल तौल (क्विंटल)' : 'Gross Weight (Qtl)'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={grossWeightQtl}
                  onChange={e => setGrossWeightQtl(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'मंडी भाव (₹/क्विंटल)' : 'Mandi Rate (₹/Qtl)'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={mandiRatePerQtl}
                  onChange={e => setMandiRatePerQtl(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'फसल में नमी (%)' : 'Actual Moisture (%)'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.1"
                  value={actualMoisture}
                  onChange={e => setActualMoisture(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'मानक नमी छूट (%)' : 'Standard Moisture (%)'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.1"
                  value={standardMoisture}
                  onChange={e => setStandardMoisture(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'हमाली/तुलाई खर्च (₹)' : 'Hamali / Labor (₹)'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={hamaliAndTulaiCost}
                  onChange={e => setHamaliAndTulaiCost(e.target.value)}
                  className={inputClass}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="p-3.5 rounded-xl bg-rose-50/80 dark:bg-rose-950/35 border border-rose-200 dark:border-rose-800/70">
                <div className="text-xs font-semibold text-rose-800 dark:text-rose-300">
                  {lang === 'hi' ? 'नमी कटौती वजन' : 'Moisture Weight Cut'}
                </div>
                <div className="text-lg sm:text-xl font-bold text-rose-700 dark:text-rose-400 mt-1 font-mono">
                  -{moistureWeightCutQtl.toFixed(2)} <span className="text-xs font-semibold">Qtl</span>
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                  ({excessMoisturePct.toFixed(1)}% {lang === 'hi' ? 'अतिरिक्त नमी' : 'excess moisture'})
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-amber-50/80 dark:bg-amber-950/35 border border-amber-200 dark:border-amber-800/70">
                <div className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                  {lang === 'hi' ? 'शुद्ध बिल वजन' : 'Net Billable Weight'}
                </div>
                <div className="text-lg sm:text-xl font-bold mt-1 font-mono">
                  {netBillableWeightQtl.toFixed(2)} <span className="text-xs font-semibold">Qtl</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/35 border border-emerald-200 dark:border-emerald-800/70">
                <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                  {lang === 'hi' ? 'हाथ में शुद्ध रकम' : 'Net Hand Payout'}
                </div>
                <div className="text-lg sm:text-xl font-bold text-emerald-700 dark:text-emerald-400 mt-1 font-mono">
                  {formatCurrency(netMandiHandAmount)}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 5. KCC LOAN INTEREST CALCULATOR */}
        {activeTab === 'kcc' && (
          <div className="space-y-4">
            <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm sm:text-base font-bold">
                {lang === 'hi' ? 'किसान क्रेडिट कार्ड (KCC) और कृषि ऋण ब्याज' : 'KCC & Farm Loan Interest Calculator'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {lang === 'hi'
                  ? 'समय पर भुगतान करने पर KCC में 4% वार्षिक ब्याज लगता है — अपना सटीक ब्याज निकालें'
                  : 'Calculate exact simple interest for KCC (4% p.a. with timely repayment subsidy) or private loans'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'ऋण राशि / मूलधन (₹)' : 'Loan Amount (₹)'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="5000"
                  value={loanPrincipal}
                  onChange={e => setLoanPrincipal(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'वार्षिक ब्याज दर (% प्रति वर्ष)' : 'Annual Interest Rate (% p.a.)'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.5"
                  value={loanRateYear}
                  onChange={e => setLoanRateYear(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'समय अवधि (महीने)' : 'Duration (Months)'}
                </label>
                <input
                  type="number"
                  min="1"
                  max="60"
                  value={loanMonths}
                  onChange={e => setLoanMonths(e.target.value)}
                  className={inputClass}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="p-3.5 rounded-xl bg-amber-50/80 dark:bg-amber-950/35 border border-amber-200 dark:border-amber-800/70">
                <div className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                  {lang === 'hi' ? 'कुल ब्याज राशि' : 'Total Interest Payable'}
                </div>
                <div className="text-lg sm:text-xl font-bold mt-1 font-mono">
                  {formatCurrency(simpleInterest)}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/35 border border-emerald-200 dark:border-emerald-800/70">
                <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                  {lang === 'hi' ? 'कुल लौटाने योग्य राशि (मूलधन + ब्याज)' : 'Total Repayment (Principal + Interest)'}
                </div>
                <div className="text-lg sm:text-xl font-bold text-emerald-700 dark:text-emerald-400 mt-1 font-mono">
                  {formatCurrency(totalPayable)}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 6. LAND AREA CONVERTER */}
        {activeTab === 'land' && (
          <div className="space-y-4">
            <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm sm:text-base font-bold">
                {lang === 'hi' ? 'खेत जमीन नाप कन्वर्टर (बीघा, एकड़, हेक्टेयर, कनाल)' : 'Land Area Unit Converter (Bigha, Acre, Hectare, Kanal)'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {lang === 'hi'
                  ? 'अपने राज्य के बीघा अनुपात के अनुसार जमीन की सभी इकाइयों में तुरंत गणना करें'
                  : 'Convert farm plot measurements across Acre, Bigha, Hectare, Kanal, and Sq.Ft.'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'जमीन का मान (Value)' : 'Land Area Value'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.25"
                  value={landValue}
                  onChange={e => setLandValue(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'किस इकाई से? (From Unit)' : 'From Unit'}
                </label>
                <select
                  value={landFromUnit}
                  onChange={e => setLandFromUnit(e.target.value as 'Bigha' | 'Acre' | 'Hectare' | 'Kanal')}
                  className={inputClass}
                >
                  <option value="Bigha">{lang === 'hi' ? 'बीघा (Bigha)' : 'Bigha'}</option>
                  <option value="Acre">{lang === 'hi' ? 'एकड़ (Acre)' : 'Acre'}</option>
                  <option value="Hectare">{lang === 'hi' ? 'हेक्टेयर (Hectare)' : 'Hectare'}</option>
                  <option value="Kanal">{lang === 'hi' ? 'कनाल (Kanal)' : 'Kanal'}</option>
                </select>
              </div>

              <div>
                <label className={labelClass}>
                  {lang === 'hi' ? 'क्षेत्रीय अनुपात (1 एकड़ में कितने बीघा?)' : 'Regional Ratio (Bighas per 1 Acre)'}
                </label>
                <select
                  value={bighaPerAcreRatio}
                  onChange={e => setBighaPerAcreRatio(e.target.value)}
                  className={inputClass}
                >
                  <option value="1.6">{lang === 'hi' ? '1.6 बीघा = 1 एकड़ (UP/Raj पक्का बीघा)' : '1.6 Bigha = 1 Acre (Standard Puqqa)'}</option>
                  <option value="2.5">{lang === 'hi' ? '2.5 बीघा = 1 एकड़ (MP/गुजरात/बिहार)' : '2.5 Bigha = 1 Acre (MP / Gujarat)'}</option>
                  <option value="3.0">{lang === 'hi' ? '3.0 बीघा = 1 एकड़ (बंगाल/असम)' : '3.0 Bigha = 1 Acre (East India)'}</option>
                  <option value="4.8">{lang === 'hi' ? '4.8 बीघा = 1 एकड़ (कच्चा बीघा)' : '4.8 Bigha = 1 Acre (Kachha Bigha)'}</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 pt-1">
              <div className="p-3 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/35 border border-emerald-200 dark:border-emerald-800/70">
                <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                  {lang === 'hi' ? 'एकड़ (Acres)' : 'Acres'}
                </div>
                <div className="text-base sm:text-lg font-bold mt-0.5 font-mono">{convAcres.toFixed(2)}</div>
              </div>
              <div className="p-3 rounded-xl bg-amber-50/80 dark:bg-amber-950/35 border border-amber-200 dark:border-amber-800/70">
                <div className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                  {lang === 'hi' ? 'बीघा (Bigha)' : 'Bigha'}
                </div>
                <div className="text-base sm:text-lg font-bold mt-0.5 font-mono">{convBigha.toFixed(2)}</div>
              </div>
              <div className="p-3 rounded-xl bg-blue-50/80 dark:bg-blue-950/35 border border-blue-200 dark:border-blue-800/70">
                <div className="text-xs font-semibold text-blue-800 dark:text-blue-300">
                  {lang === 'hi' ? 'हेक्टेयर (Ha)' : 'Hectares'}
                </div>
                <div className="text-base sm:text-lg font-bold mt-0.5 font-mono">{convHectares.toFixed(2)}</div>
              </div>
              <div className="p-3 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/35 border border-emerald-200 dark:border-emerald-800/70">
                <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                  {lang === 'hi' ? 'कनाल (Kanal)' : 'Kanal'}
                </div>
                <div className="text-base sm:text-lg font-bold mt-0.5 font-mono">{convKanal.toFixed(2)}</div>
              </div>
              <div className="p-3 rounded-xl bg-amber-50/80 dark:bg-amber-950/35 border border-amber-200 dark:border-amber-800/70 col-span-2 sm:col-span-1">
                <div className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                  {lang === 'hi' ? 'वर्ग फुट (Sq.Ft)' : 'Sq. Ft.'}
                </div>
                <div className="text-base sm:text-lg font-bold mt-0.5 font-mono">
                  {Math.round(convSqFt).toLocaleString('en-IN')}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Bottom WhatsApp Share Bar */}
        <div className="pt-3.5 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              {lang === 'hi'
                ? 'इस गणना को अपने परिवार या किसान मित्र को व्हाट्सएप पर भेजें:'
                : 'Share this calculation result directly on WhatsApp:'}
            </span>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="tel"
              value={phoneInput}
              onChange={e => setPhoneInput(e.target.value)}
              placeholder={lang === 'hi' ? 'व्हाट्सएप नंबर (वैकल्पिक)' : 'WhatsApp number (optional)'}
              className="px-3 py-2 rounded-xl text-xs font-medium"
            />
            <button
              type="button"
              onClick={shareCurrentCalculationOnWhatsApp}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-xs transition-all cursor-pointer active:scale-95"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'व्हाट्सएप पर शेयर करें' : 'Share on WhatsApp'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
