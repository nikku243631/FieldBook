import React, { useState, useEffect } from 'react';
import {
  Calculator as CalcIcon,
  RotateCcw,
  Copy,
  Check,
  Share2,
  FileText,
  Clock,
  Trash2,
  Sparkles,
  Volume2,
  VolumeX
} from 'lucide-react';
import { Language, Theme } from '../types';
import { Storage } from '../utils/storage';
import { shareViaWhatsApp } from '../utils/export';

interface SimpleCalculatorProps {
  lang: Language;
  theme: Theme;
  onSendToNotes?: (calcText: string) => void;
  isModal?: boolean;
  onClose?: () => void;
}

export const SimpleCalculator: React.FC<SimpleCalculatorProps> = ({
  lang,
  theme,
  onSendToNotes,
  isModal = false,
  onClose
}) => {
  const isHindi = lang === 'hi';
  const isDark = theme === 'dark';

  const [expression, setExpression] = useState<string>('');
  const [currentVal, setCurrentVal] = useState<string>('0');
  const [isNewNumber, setIsNewNumber] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(false);
  const [history, setHistory] = useState<{ id: string; expression: string; result: string; timestamp: string }[]>(
    () => Storage.getCalcHistory()
  );

  const playClick = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.05);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.05);
    } catch {}
  };

  const safeEvaluate = (expr: string): number | null => {
    try {
      const sanitized = expr
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/[^0-9+\-*/.()%]/g, '');

      if (!sanitized) return null;

      const processed = sanitized.replace(/([0-9.]+)%/g, '($1/100)');

      // Deterministic recursive-descent math parser (zero eval / Function constructor)
      let pos = 0;
      const str = processed;

      const parseExpression = (): number => {
        let val = parseTerm();
        while (pos < str.length && (str[pos] === '+' || str[pos] === '-')) {
          const op = str[pos++];
          const right = parseTerm();
          val = op === '+' ? val + right : val - right;
        }
        return val;
      };

      const parseTerm = (): number => {
        let val = parseFactor();
        while (pos < str.length && (str[pos] === '*' || str[pos] === '/')) {
          const op = str[pos++];
          const right = parseFactor();
          val = op === '*' ? val * right : val / right;
        }
        return val;
      };

      const parseFactor = (): number => {
        if (str[pos] === '+') {
          pos++;
          return parseFactor();
        }
        if (str[pos] === '-') {
          pos++;
          return -parseFactor();
        }
        if (str[pos] === '(') {
          pos++; // consume '('
          const val = parseExpression();
          if (str[pos] === ')') pos++;
          return val;
        }
        const start = pos;
        let dotCount = 0;
        while (pos < str.length && ((str[pos] >= '0' && str[pos] <= '9') || str[pos] === '.')) {
          if (str[pos] === '.') dotCount++;
          pos++;
        }
        if (start === pos || dotCount > 1) return NaN;
        return Number(str.slice(start, pos));
      };

      const result = parseExpression();
      if (pos === str.length && typeof result === 'number' && !isNaN(result) && isFinite(result)) {
        return result;
      }
      return null;
    } catch {
      return null;
    }
  };

  const handleDigit = (digit: string) => {
    playClick();
    if (isNewNumber) {
      if (digit === '.') {
        setCurrentVal('0.');
      } else {
        setCurrentVal(digit);
      }
      setIsNewNumber(false);
    } else {
      if (digit === '.' && currentVal.includes('.')) return;
      if (currentVal === '0' && digit !== '.') {
        setCurrentVal(digit);
      } else {
        setCurrentVal(currentVal + digit);
      }
    }
  };

  const handleDoubleZero = () => {
    playClick();
    if (isNewNumber || currentVal === '0') {
      setCurrentVal('0');
      setIsNewNumber(false);
    } else {
      setCurrentVal(currentVal + '00');
    }
  };

  const handleOperator = (op: string) => {
    playClick();
    const symbol = op === '*' ? '×' : op === '/' ? '÷' : op;

    if (expression && !isNewNumber) {
      const full = `${expression} ${currentVal}`;
      const res = safeEvaluate(full);
      if (res !== null) {
        const rounded = Number(res.toFixed(4));
        setExpression(`${rounded} ${symbol}`);
        setCurrentVal(String(rounded));
        setIsNewNumber(true);
        return;
      }
    }

    setExpression(`${currentVal} ${symbol}`);
    setIsNewNumber(true);
  };

  const handleEquals = () => {
    playClick();
    if (!expression) return;
    const fullExpr = `${expression} ${currentVal}`;
    const result = safeEvaluate(fullExpr);

    if (result !== null) {
      const rounded = Number(result.toFixed(4));
      const formattedResult = rounded.toLocaleString('en-IN');
      const now = new Date();
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      const dateStr = now.toLocaleDateString(isHindi ? 'hi-IN' : 'en-IN', { day: 'numeric', month: 'short' });

      const newHistoryItem = {
        id: `calc-${Date.now()}`,
        expression: fullExpr,
        result: formattedResult,
        timestamp: `${dateStr}, ${timeStr}`
      };

      const updatedHistory = [newHistoryItem, ...history.slice(0, 49)];
      setHistory(updatedHistory);
      Storage.saveCalcHistory(updatedHistory);

      setExpression(`${fullExpr} =`);
      setCurrentVal(String(rounded));
      setIsNewNumber(true);
    } else {
      setCurrentVal('Error');
      setIsNewNumber(true);
    }
  };

  const handleClear = () => {
    playClick();
    setCurrentVal('0');
    setExpression('');
    setIsNewNumber(true);
  };

  const handleBackspace = () => {
    playClick();
    if (isNewNumber) {
      setCurrentVal('0');
      return;
    }
    if (currentVal.length <= 1) {
      setCurrentVal('0');
      setIsNewNumber(true);
    } else {
      setCurrentVal(currentVal.slice(0, -1));
    }
  };

  const handleToggleSign = () => {
    playClick();
    if (currentVal === '0') return;
    if (currentVal.startsWith('-')) {
      setCurrentVal(currentVal.substring(1));
    } else {
      setCurrentVal('-' + currentVal);
    }
  };

  const handlePercentage = () => {
    playClick();
    const val = parseFloat(currentVal);
    if (!isNaN(val)) {
      const res = val / 100;
      setCurrentVal(String(res));
      setIsNewNumber(true);
    }
  };

  const applyFarmShortcut = (type: 'addGst' | 'subGst' | 'toQuintal' | 'toKg' | 'toMann' | 'fromMann') => {
    playClick();
    const val = parseFloat(currentVal);
    if (isNaN(val)) return;

    let res = val;
    let label = '';

    switch (type) {
      case 'addGst':
        res = val * 1.18;
        label = `${val} + 18% GST`;
        break;
      case 'subGst':
        res = val / 1.18;
        label = `${val} - 18% GST`;
        break;
      case 'toQuintal':
        res = val / 100;
        label = `${val} kg ÷ 100 = क्विंटल`;
        break;
      case 'toKg':
        res = val * 100;
        label = `${val} क्विंटल × 100 = kg`;
        break;
      case 'toMann':
        res = val / 40;
        label = `${val} kg ÷ 40 = मन (Mann)`;
        break;
      case 'fromMann':
        res = val * 40;
        label = `${val} मन × 40 = kg`;
        break;
    }

    const rounded = Number(res.toFixed(3));
    setExpression(label);
    setCurrentVal(String(rounded));
    setIsNewNumber(true);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(currentVal);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareWhatsApp = () => {
    const text = `*FieldBook हिसाब गणना*\n${expression ? expression + '\n' : ''}कुल रकम: ₹${currentVal}\n(तैयार: FieldBook - Mr Nikhil)`;
    shareViaWhatsApp(text);
  };

  const handleSaveToNotesAction = () => {
    const noteText = `कैलकुलेटर हिसाब:\n${expression ? expression + ' = ' : ''}₹${currentVal}\nतारीख: ${new Date().toLocaleString()}`;
    if (onSendToNotes) {
      onSendToNotes(noteText);
    } else {
      const existing = Storage.getNotes();
      const newNote = {
        id: `note-${Date.now()}`,
        title: `हिसाब: ₹${currentVal}`,
        content: noteText,
        category: 'payment' as const,
        isPinned: false,
        date: new Date().toISOString().split('T')[0],
        time: new Date().toTimeString().slice(0, 5),
        color: 'emerald',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      Storage.saveNotes([newNote, ...existing]);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleClearHistory = () => {
    setHistory([]);
    Storage.saveCalcHistory([]);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(e.key)) {
        handleDigit(e.key);
      } else if (e.key === '.') {
        handleDigit('.');
      } else if (e.key === '+') {
        handleOperator('+');
      } else if (e.key === '-') {
        handleOperator('-');
      } else if (e.key === '*' || e.key === 'x') {
        handleOperator('*');
      } else if (e.key === '/') {
        e.preventDefault();
        handleOperator('/');
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (e.key === 'Backspace') {
        handleBackspace();
      } else if (e.key === 'Escape') {
        if (isModal && onClose) onClose();
        else handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentVal, expression, isNewNumber]);

  return (
    <div
      className={`calc-glass-shell relative w-full max-w-md mx-auto rounded-[30px] overflow-hidden transition-all ${
        isDark ? 'text-slate-100' : 'text-slate-950'
      }`}
    >
      {/* Top Translucent Glass Header */}
      <div
        className={`flex items-center justify-between px-4 py-3 border-b ${
          isDark ? 'border-emerald-500/25 bg-slate-900/55' : 'border-emerald-500/25 bg-white/55'
        }`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-2xl calc-snakeskin-op flex items-center justify-center text-white shrink-0">
            <CalcIcon className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm font-black tracking-tight truncate">
              {isHindi ? 'डिजिटल हिसाब कैलकुलेटर' : 'Field Digital Calculator'}
            </h3>
            <p className="text-[11px] font-bold text-slate-700 dark:text-slate-300 truncate">
              {isHindi ? 'साधारण व सटीक जोड़-घटाव' : 'Simple & accurate arithmetic'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              soundEnabled
                ? 'calc-snakeskin-op text-white'
                : 'liquid-glass-pill text-slate-900 dark:text-slate-100'
            }`}
            title={soundEnabled ? 'Click sound on' : 'Click sound off'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          <button
            type="button"
            onClick={() => setShowHistory(!showHistory)}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
              showHistory
                ? 'calc-snakeskin-op text-white'
                : 'liquid-glass-pill text-slate-900 dark:text-slate-100'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{isHindi ? 'इतिहास' : 'History'}</span>
          </button>

          {isModal && onClose && (
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full calc-snakeskin-rose flex items-center justify-center text-xs font-black cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* History Tape Drawer */}
      {showHistory ? (
        <div className="p-4 max-h-[380px] overflow-y-auto space-y-2.5">
          <div className="flex items-center justify-between pb-2 border-b border-slate-300/70 dark:border-slate-700">
            <span className="text-xs font-extrabold">
              {isHindi ? 'पिछली गणनाएं (Calculation Tape)' : 'Past Calculations'}
            </span>
            {history.length > 0 && (
              <button
                type="button"
                onClick={handleClearHistory}
                className="text-[11px] font-bold calc-snakeskin-rose px-2.5 py-1 rounded-xl flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
                <span>{isHindi ? 'मिटाएं' : 'Clear'}</span>
              </button>
            )}
          </div>

          {history.length === 0 ? (
            <div className="text-center py-8 text-slate-600 dark:text-slate-400 text-xs font-semibold">
              {isHindi ? 'कोई पुराना हिसाब नहीं है' : 'No previous calculations yet'}
            </div>
          ) : (
            history.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  setCurrentVal(item.result.replace(/,/g, ''));
                  setExpression(item.expression);
                  setShowHistory(false);
                }}
                className="p-3 rounded-2xl liquid-glass-subcard text-left cursor-pointer transition-all hover:border-emerald-500"
              >
                <div className="flex justify-between items-center text-[11px] text-slate-600 dark:text-slate-400 mb-0.5">
                  <span className="font-mono font-semibold">{item.timestamp}</span>
                  <span className="text-emerald-700 dark:text-emerald-400 font-bold">
                    {isHindi ? 'टैप कर लोड करें' : 'Tap to load'}
                  </span>
                </div>
                <div className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 truncate">
                  {item.expression}
                </div>
                <div className="text-base font-black text-emerald-800 dark:text-emerald-300 font-mono">
                  ₹ {item.result}
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="p-3.5 sm:p-4 space-y-3">
          {/* Premium 3D Glass Display Box */}
          <div className="calc-glass-display rounded-[22px] p-3.5 sm:p-4 relative">
            <div className="h-5 flex items-center justify-end text-xs sm:text-sm font-mono font-extrabold text-emerald-950/85 dark:text-emerald-300/90 overflow-x-auto whitespace-nowrap">
              {expression || <span className="opacity-0">0</span>}
            </div>

            <div className="flex items-baseline justify-between gap-2 mt-1">
              <span className="text-xl sm:text-2xl font-black text-emerald-800 dark:text-emerald-400 select-none">
                ₹
              </span>
              <div
                className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-slate-950 dark:text-white text-right overflow-x-auto scrollbar-none select-all w-full leading-none py-0.5"
                style={{ direction: 'ltr' }}
              >
                {currentVal}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-1.5 pt-2.5 mt-2.5 border-t border-emerald-600/25 dark:border-emerald-400/25 text-[11px]">
              <span className="text-slate-800 dark:text-slate-200 font-extrabold">
                {isHindi ? 'शेयर / सेव:' : 'Save/Share:'}
              </span>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleCopy}
                  className="px-2.5 py-1 rounded-xl calc-snakeskin-btn text-[11px] font-extrabold flex items-center gap-1 cursor-pointer"
                  title="Copy result"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-700" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? (isHindi ? 'कॉपी हुआ' : 'Copied') : (isHindi ? 'कॉपी' : 'Copy')}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveToNotesAction}
                  className="px-2.5 py-1 rounded-xl calc-snakeskin-amber text-[11px] font-extrabold flex items-center gap-1 cursor-pointer"
                  title="Save to Farm Notes"
                >
                  <FileText className="w-3 h-3" />
                  <span>{isHindi ? 'नोट्स' : 'Note'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleShareWhatsApp}
                  className="px-2.5 py-1 rounded-xl calc-snakeskin-op text-white text-[11px] font-extrabold flex items-center gap-1 cursor-pointer"
                  title="Share on WhatsApp"
                >
                  <Share2 className="w-3 h-3" />
                  <span>WhatsApp</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick Agricultural Conversions Strip */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1 text-[11px] font-extrabold text-slate-800 dark:text-slate-200">
              <Sparkles className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
              <span>{isHindi ? 'कृषि व मंडी शॉर्टकट' : 'Agri Quick Math'}:</span>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
              <button
                type="button"
                onClick={() => applyFarmShortcut('addGst')}
                className="px-1.5 py-1.5 rounded-xl text-[11px] font-extrabold liquid-glass-income text-emerald-950 dark:text-emerald-200 cursor-pointer truncate"
              >
                +18% GST
              </button>
              <button
                type="button"
                onClick={() => applyFarmShortcut('subGst')}
                className="px-1.5 py-1.5 rounded-xl text-[11px] font-extrabold liquid-glass-income text-emerald-950 dark:text-emerald-200 cursor-pointer truncate"
              >
                -18% GST
              </button>
              <button
                type="button"
                onClick={() => applyFarmShortcut('toQuintal')}
                className="px-1.5 py-1.5 rounded-xl text-[11px] font-extrabold calc-snakeskin-amber cursor-pointer truncate"
              >
                ÷100 (क्विं.)
              </button>
              <button
                type="button"
                onClick={() => applyFarmShortcut('toKg')}
                className="px-1.5 py-1.5 rounded-xl text-[11px] font-extrabold calc-snakeskin-amber cursor-pointer truncate"
              >
                ×100 (kg)
              </button>
              <button
                type="button"
                onClick={() => applyFarmShortcut('toMann')}
                className="px-1.5 py-1.5 rounded-xl text-[11px] font-extrabold calc-snakeskin-btn cursor-pointer truncate"
              >
                ÷40 (मन)
              </button>
              <button
                type="button"
                onClick={() => applyFarmShortcut('fromMann')}
                className="px-1.5 py-1.5 rounded-xl text-[11px] font-extrabold calc-snakeskin-btn cursor-pointer truncate"
              >
                ×40 (मन→kg)
              </button>
            </div>
          </div>

          {/* Calculator Keypad Grid — Bold Rounded 3D Glass Buttons with Crosshatch Snake-Skin Texture */}
          <div className="grid grid-cols-4 gap-2 sm:gap-2.5 text-lg sm:text-xl font-black font-mono">
            <button
              type="button"
              onClick={handleClear}
              className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-rose active:scale-95 transition-all cursor-pointer flex items-center justify-center tracking-tight"
            >
              AC
            </button>
            <button
              type="button"
              onClick={handleBackspace}
              className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-amber active:scale-95 transition-all cursor-pointer flex items-center justify-center"
            >
              <RotateCcw className="w-5 h-5 stroke-[2.75]" />
            </button>
            <button
              type="button"
              onClick={handlePercentage}
              className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-amber active:scale-95 transition-all cursor-pointer flex items-center justify-center"
            >
              %
            </button>
            <button
              type="button"
              onClick={() => handleOperator('/')}
              className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-op active:scale-95 transition-all cursor-pointer flex items-center justify-center text-2xl"
            >
              ÷
            </button>

            {['7', '8', '9'].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => handleDigit(d)}
                className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-btn active:scale-95 transition-all cursor-pointer flex items-center justify-center text-xl sm:text-2xl"
              >
                {d}
              </button>
            ))}
            <button
              type="button"
              onClick={() => handleOperator('*')}
              className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-op active:scale-95 transition-all cursor-pointer flex items-center justify-center text-2xl"
            >
              ×
            </button>

            {['4', '5', '6'].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => handleDigit(d)}
                className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-btn active:scale-95 transition-all cursor-pointer flex items-center justify-center text-xl sm:text-2xl"
              >
                {d}
              </button>
            ))}
            <button
              type="button"
              onClick={() => handleOperator('-')}
              className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-op active:scale-95 transition-all cursor-pointer flex items-center justify-center text-2xl"
            >
              −
            </button>

            {['1', '2', '3'].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => handleDigit(d)}
                className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-btn active:scale-95 transition-all cursor-pointer flex items-center justify-center text-xl sm:text-2xl"
              >
                {d}
              </button>
            ))}
            <button
              type="button"
              onClick={() => handleOperator('+')}
              className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-op active:scale-95 transition-all cursor-pointer flex items-center justify-center text-2xl"
            >
              +
            </button>

            <button
              type="button"
              onClick={handleToggleSign}
              className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-btn active:scale-95 transition-all cursor-pointer flex items-center justify-center text-sm sm:text-base font-black"
            >
              +/−
            </button>
            <button
              type="button"
              onClick={() => handleDigit('0')}
              className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-btn active:scale-95 transition-all cursor-pointer flex items-center justify-center text-xl sm:text-2xl"
            >
              0
            </button>
            <button
              type="button"
              onClick={handleDoubleZero}
              className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-btn active:scale-95 transition-all cursor-pointer flex items-center justify-center text-base sm:text-lg font-black"
            >
              00
            </button>
            <button
              type="button"
              onClick={() => handleDigit('.')}
              className="min-h-[54px] sm:min-h-[58px] px-2 rounded-[20px] calc-snakeskin-btn active:scale-95 transition-all cursor-pointer flex items-center justify-center text-2xl"
            >
              .
            </button>

            <button
              type="button"
              onClick={handleEquals}
              className="col-span-4 min-h-[52px] py-3 px-4 rounded-[20px] calc-snakeskin-op text-white font-black text-base sm:text-lg transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <span className="text-xl leading-none">=</span>
              <span className="font-sans">
                {isHindi ? 'जोड़ें / परिणाम निकालें' : 'Calculate'}
              </span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
