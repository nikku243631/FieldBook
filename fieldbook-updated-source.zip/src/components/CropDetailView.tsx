import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  CropCycle,
  Transaction,
  HarvestEntry,
  DiaryEntry,
  Language,
  Theme
} from '../types';
import { formatCurrency, getTranslation } from '../utils/translations';
import {
  generateWhatsAppSummary,
  printCropReportPDF,
  shareViaWhatsApp
} from '../utils/export';
import {
  calculateCropFinancials,
  calculateCropTimeline,
  getEffectiveCropAccountingType,
  getEffectiveCropCategory,
  getCropCategoryLabel
} from '../utils/calculations';
import { ConfirmModal } from './ConfirmModal';
import { ReceiptViewerModal } from './ReceiptViewerModal';
import {
  ArrowLeft,
  Share2,
  Printer,
  Trash2,
  Edit,
  Plus,
  TrendingUp,
  TrendingDown,
  Scale,
  Calendar,
  Clock,
  Sparkles,
  PieChart,
  BookOpen,
  Paperclip,
  Layers,
  Repeat,
  CheckCircle2,
  Tag,
  X
} from 'lucide-react';

interface CropDetailViewProps {
  crop: CropCycle;
  transactions: Transaction[];
  harvests: HarvestEntry[];
  diary: DiaryEntry[];
  lang: Language;
  theme: Theme;
  farmerName?: string;
  onBack: () => void;
  onEditCrop: (crop: CropCycle) => void;
  onUpdateCrop?: (updates: Partial<CropCycle>) => void;
  onDeleteCrop: (cropId: string) => void;
  onAddTransaction: (type: 'expense' | 'income') => void;
  onEditTransaction?: (tx: Transaction) => void;
  onDeleteTransaction: (txId: string) => void;
  onAddHarvest: () => void;
  onEditHarvest?: (harvest: HarvestEntry) => void;
  onDeleteHarvest: (harvestId: string) => void;
  onAddDiary: () => void;
  onEditDiary?: (entry: DiaryEntry) => void;
  onDeleteDiary: (diaryId: string) => void;
}

export const CropDetailView: React.FC<CropDetailViewProps> = ({
  crop,
  transactions,
  harvests,
  diary,
  lang,
  theme,
  farmerName = 'Kisan Bhai',
  onBack,
  onEditCrop,
  onUpdateCrop,
  onDeleteCrop,
  onAddTransaction,
  onEditTransaction,
  onDeleteTransaction,
  onAddHarvest,
  onEditHarvest,
  onDeleteHarvest,
  onAddDiary,
  onEditDiary,
  onDeleteDiary
}) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'expenses' | 'income' | 'harvest' | 'diary'>('dashboard');
  const [expenseFilter, setExpenseFilter] = useState<string>('all');
  const [isDeleteCropModalOpen, setIsDeleteCropModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{
    type: 'tx' | 'harvest' | 'diary';
    id: string;
    name: string;
  } | null>(null);
  const [viewingReceiptTx, setViewingReceiptTx] = useState<Transaction | null>(null);
  const [selectedTxDetail, setSelectedTxDetail] = useState<Transaction | null>(null);
  const isDark = theme === 'dark';

  const cropTx = transactions.filter((t) => t.cropId === crop.id);
  const expenses = cropTx.filter((t) => t.type === 'expense');
  const incomes = cropTx.filter((t) => t.type === 'income');
  const cropHarvests = harvests.filter((h) => h.cropId === crop.id);
  const cropDiary = diary.filter((d) => d.cropId === crop.id);

  const financials = calculateCropFinancials(crop, transactions, harvests);
  const effectiveAccountingType = getEffectiveCropAccountingType(crop);
  const effectiveCategory = getEffectiveCropCategory(crop);
  const timeline = calculateCropTimeline(crop);

  const totalLagat = financials.totalExpenses;
  const totalKamai = financials.totalIncome;
  const netProfit = financials.netProfit;
  const isProfit = financials.isProfit;
  const profitMarginPercent = financials.profitMarginPercent.toFixed(1);

  const totalYieldQuintal = financials.totalHarvestQuintal;
  const yieldPerUnit = financials.yieldPerUnit;
  const costPerAreaUnit = financials.costPerUnit;
  const profitPerAreaUnit = financials.profitPerUnit;
  const costPerQuintal = financials.costPerQuintal;
  const roiPercent = financials.roiPercent.toFixed(1);
  const areaUnitLabel = getTranslation(lang, crop.areaUnit);
  const expenseByCategory = financials.expenseByCategory;

  const categoryIcons: Record<string, string> = {
    fertilizer: '🌱',
    seeds: '🌾',
    pesticide: '🧪',
    irrigation: '💧',
    labour: '👥',
    transport: '🚚',
    machinery: '🚜',
    other: '📦'
  };

  const handleConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  const handleShareWhatsApp = () => {
    const encoded = generateWhatsAppSummary(crop, transactions, harvests, lang);
    shareViaWhatsApp(decodeURIComponent(encoded), `${crop.hindiName || crop.name} - FieldBook Report`);
  };

  const handlePrintPDF = () => {
    printCropReportPDF(crop, transactions, harvests, farmerName, lang);
  };

  const filteredExpenses = expenses.filter((e) => {
    if (expenseFilter === 'all') return true;
    return e.category === expenseFilter;
  });

  return (
    <div className="space-y-4 pb-20">
      {/* Top Navigation & Action Strip */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button
          type="button"
          onClick={onBack}
          className="liquid-glass-pill flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-extrabold cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4 text-emerald-600" />
          <span>{getTranslation(lang, 'allCrops')}</span>
        </button>

        <div className="flex flex-wrap items-center gap-1.5">
          {/* WhatsApp Share */}
          <button
            type="button"
            onClick={handleShareWhatsApp}
            title="Share on WhatsApp"
            className="liquid-glass-emerald flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-extrabold text-white cursor-pointer active:scale-95 transition-all"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>WhatsApp</span>
          </button>

          {/* Print PDF Statement */}
          <button
            type="button"
            onClick={handlePrintPDF}
            title="Print / Save PDF Statement"
            className="btn-3d-blue flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-extrabold text-white cursor-pointer active:scale-95 transition-all"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>PDF / Print</span>
          </button>

          {/* Edit Crop */}
          <button
            type="button"
            onClick={() => onEditCrop(crop)}
            title="Edit Crop"
            className="liquid-glass-pill p-1.5 rounded-xl text-amber-800 dark:text-amber-300 cursor-pointer transition-colors"
          >
            <Edit className="w-4 h-4" />
          </button>

          {/* Delete Crop */}
          <button
            type="button"
            onClick={() => setIsDeleteCropModalOpen(true)}
            title={lang === 'hi' ? 'पूरी फसल का खाता हटाएं' : 'Delete Crop Record'}
            className="liquid-glass-danger p-1.5 rounded-xl cursor-pointer transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Crop Header Card */}
      <div className="liquid-glass-card relative rounded-2xl p-4 sm:p-5 overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4">
          <div>
            <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
              <span className="px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 font-semibold">
                {crop.season === 'rabi'
                  ? 'रबी (Rabi)'
                  : crop.season === 'kharif'
                  ? 'खरीफ (Kharif)'
                  : crop.season === 'zaid'
                  ? 'जायद (Zaid)'
                  : 'वार्षिक (Annual)'}
              </span>
              <span>•</span>
              <span className="font-semibold text-slate-700 dark:text-slate-200">
                {crop.landArea} {areaUnitLabel}
              </span>
              <span>•</span>
              <span>
                {lang === 'hi' ? 'बुवाई:' : 'Sown:'} {crop.sowingDate}
              </span>
            </div>

            <h1 className="text-lg sm:text-xl font-bold tracking-tight">
              {lang === 'hi' ? crop.hindiName || crop.name : crop.name}
            </h1>

            {crop.variety && (
              <p className="text-xs mt-0.5 text-slate-500 dark:text-slate-400">
                {lang === 'hi' ? 'किस्म:' : 'Variety:'}{' '}
                <span className="text-slate-800 dark:text-slate-200 font-semibold">{crop.variety}</span>
                {crop.targetYieldQuintal && (
                  <span className="ml-2.5 text-slate-600 dark:text-slate-300 font-medium">
                    • {lang === 'hi' ? 'लक्ष्य:' : 'Target:'} {crop.targetYieldQuintal}{' '}
                    {getTranslation(lang, 'quintal')}
                  </span>
                )}
              </p>
            )}
          </div>

          {/* Crop Category Badge, Harvest Type Badge & Status Badge / Cycle Completion Control */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg text-xs font-semibold border bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800 inline-flex items-center gap-1">
              <Tag className="w-3.5 h-3.5 shrink-0" />
              <span>{getCropCategoryLabel(effectiveCategory, lang)}</span>
            </span>

            <span
              className="px-2.5 py-1 rounded-lg text-xs font-semibold border bg-blue-50 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-800 inline-flex items-center gap-1"
              title={
                effectiveAccountingType === 'recurring'
                  ? lang === 'hi'
                    ? 'बार-बार तुड़ाई और साप्ताहिक मंडी बिक्री वाली फसल'
                    : 'Repeated harvests and weekly/monthly sales crop'
                  : lang === 'hi'
                  ? 'एक बार / मौसमी कटाई वाली फसल'
                  : 'Single harvest crop'
              }
            >
              {effectiveAccountingType === 'recurring' ? (
                <Repeat className="w-3.5 h-3.5 shrink-0" />
              ) : (
                <Layers className="w-3.5 h-3.5 shrink-0" />
              )}
              <span>
                {effectiveAccountingType === 'recurring'
                  ? lang === 'hi'
                    ? 'बार-बार तुड़ाई (Repeated Harvest)'
                    : 'Repeated Harvest'
                  : lang === 'hi'
                  ? 'एक बार कटाई (Single Harvest)'
                  : 'Single Harvest'}
              </span>
            </span>

            <span
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold border ${
                crop.status === 'active'
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                  : 'bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800'
              }`}
            >
              {crop.status === 'active'
                ? getTranslation(lang, 'active')
                : getTranslation(lang, 'harvested')}
            </span>

            {onUpdateCrop && (
              <button
                type="button"
                onClick={() =>
                  onUpdateCrop({
                    status: crop.status === 'active' ? 'harvested' : 'active'
                  })
                }
                className="liquid-glass-pill px-2.5 py-1 rounded-xl text-xs font-extrabold cursor-pointer inline-flex items-center gap-1 transition-all"
                title={
                  crop.status === 'active'
                    ? lang === 'hi'
                      ? 'सभी तुड़ाई पूरी होने पर फसल चक्र पूर्ण चिह्नित करें'
                      : 'Mark crop cycle as completed/harvested'
                    : lang === 'hi'
                    ? 'फसल चक्र को पुनः चालू (Active) करें'
                    : 'Re-open crop cycle as active'
                }
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>
                  {crop.status === 'active'
                    ? lang === 'hi'
                      ? 'फसल पूर्ण करें'
                      : 'Mark Completed'
                    : lang === 'hi'
                    ? 'चालू करें'
                    : 'Mark Active'}
                </span>
              </button>
            )}
          </div>
        </div>

        {/* 4-KPI Financial Grid — Distinct Translucent 3D Liquid Glass Sub-Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
          {/* Total Lagat */}
          <div className="liquid-glass-expense p-3 rounded-2xl">
            <span className="text-[11px] font-extrabold block text-rose-900 dark:text-rose-200">
              {getTranslation(lang, 'totalLagat')}
            </span>
            <span className="text-base sm:text-lg font-black font-mono tabular-nums block mt-0.5 text-rose-800 dark:text-rose-300">
              {formatCurrency(totalLagat)}
            </span>
            <span className="text-[10px] font-semibold text-slate-700 dark:text-slate-300 block mt-0.5">
              {costPerAreaUnit > 0 ? `${formatCurrency(costPerAreaUnit)}/${areaUnitLabel}` : 'शून्य लागत'}
            </span>
          </div>

          {/* Total Kamai */}
          <div className="liquid-glass-income p-3 rounded-2xl">
            <span className="text-[11px] font-extrabold block text-emerald-950 dark:text-emerald-200">
              {getTranslation(lang, 'totalKamai')}
            </span>
            <span className="text-base sm:text-lg font-black font-mono tabular-nums block mt-0.5 text-emerald-900 dark:text-emerald-300">
              {formatCurrency(totalKamai)}
            </span>
            <span className="text-[10px] font-semibold text-slate-700 dark:text-slate-300 block mt-0.5">
              {incomes.length} {lang === 'hi' ? 'मंडी/स्थानीय बिक्री' : 'Sales Recorded'}
            </span>
          </div>

          {/* Net Profit / Loss */}
          <div
            onClick={isProfit ? handleConfetti : undefined}
            className={`p-3 rounded-2xl transition-all ${
              isProfit
                ? 'liquid-glass-profit cursor-pointer'
                : 'liquid-glass-expense'
            }`}
          >
            <div className="flex items-center justify-between">
              <span
                className={`text-[11px] font-extrabold block ${
                  isProfit ? 'text-blue-950 dark:text-blue-200' : 'text-rose-900 dark:text-rose-200'
                }`}
              >
                {isProfit ? getTranslation(lang, 'netProfit') : getTranslation(lang, 'netLoss')}
              </span>
              {isProfit && <Sparkles className="w-3.5 h-3.5 text-amber-500" />}
            </div>
            <div className="flex items-center gap-1 mt-0.5">
              {isProfit ? (
                <TrendingUp className="w-4 h-4 shrink-0 text-blue-700 dark:text-blue-300" />
              ) : (
                <TrendingDown className="w-4 h-4 shrink-0 text-rose-700 dark:text-rose-300" />
              )}
              <span
                className={`text-base sm:text-lg font-black font-mono tabular-nums truncate ${
                  isProfit ? 'text-blue-900 dark:text-blue-300' : 'text-rose-800 dark:text-rose-300'
                }`}
              >
                {isProfit ? '+' : ''}
                {formatCurrency(netProfit)}
              </span>
            </div>
            <span className="text-[10px] font-semibold text-slate-700 dark:text-slate-300 block mt-0.5 truncate">
              {lang === 'hi' ? 'मुनाफा दर:' : 'Margin:'} {profitMarginPercent}%
            </span>
          </div>

          {/* Total Yield Harvest */}
          <div className="liquid-glass-amber p-3 rounded-2xl">
            <span className="text-[11px] font-extrabold block text-amber-950 dark:text-amber-200">
              {getTranslation(lang, 'totalHarvest')}
            </span>
            <span className="text-base sm:text-lg font-black font-mono tabular-nums block mt-0.5 text-amber-900 dark:text-amber-300">
              {totalYieldQuintal} <span className="text-xs font-extrabold">{getTranslation(lang, 'quintal')}</span>
            </span>
            <span className="text-[10px] font-semibold text-slate-700 dark:text-slate-300 block mt-0.5">
              {cropHarvests.length} {lang === 'hi' ? 'कटाई सत्र दर्ज' : 'Harvest Logs'}
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs — Unclipped Responsive Liquid Glass Pills */}
      <div className="liquid-glass-card flex flex-wrap items-center gap-1.5 p-2 rounded-2xl">
        <button
          type="button"
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'dashboard'
              ? 'liquid-glass-emerald text-white'
              : 'liquid-glass-pill text-slate-900 dark:text-slate-100'
          }`}
        >
          <PieChart className="w-3.5 h-3.5 shrink-0" />
          <span>{getTranslation(lang, 'dashboard')}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('expenses')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'expenses'
              ? 'btn-3d-rose text-white'
              : 'liquid-glass-pill text-rose-900 dark:text-rose-200'
          }`}
        >
          <span>🔴 {getTranslation(lang, 'expenses')}</span>
          <span
            className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono font-black ${
              activeTab === 'expenses'
                ? 'bg-black/25 text-white'
                : 'bg-rose-100 dark:bg-rose-950 text-rose-900 dark:text-rose-200'
            }`}
          >
            {expenses.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('income')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'income'
              ? 'liquid-glass-emerald text-white'
              : 'liquid-glass-pill text-emerald-950 dark:text-emerald-200'
          }`}
        >
          <span>🟢 {getTranslation(lang, 'income')}</span>
          <span
            className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono font-black ${
              activeTab === 'income'
                ? 'bg-black/25 text-white'
                : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-900 dark:text-emerald-200'
            }`}
          >
            {incomes.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('harvest')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'harvest'
              ? 'btn-3d-amber text-white'
              : 'liquid-glass-pill text-amber-950 dark:text-amber-200'
          }`}
        >
          <Scale className="w-3.5 h-3.5 shrink-0" />
          <span>{getTranslation(lang, 'harvest')}</span>
          <span
            className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono font-black ${
              activeTab === 'harvest'
                ? 'bg-black/25 text-white'
                : 'bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200'
            }`}
          >
            {cropHarvests.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('diary')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'diary'
              ? 'btn-3d-blue text-white'
              : 'liquid-glass-pill text-blue-950 dark:text-blue-200'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 shrink-0" />
          <span>{getTranslation(lang, 'diary')}</span>
          <span
            className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono font-black ${
              activeTab === 'diary'
                ? 'bg-black/25 text-white'
                : 'bg-blue-100 dark:bg-blue-950 text-blue-900 dark:text-blue-200'
            }`}
          >
            {cropDiary.length}
          </span>
        </button>
      </div>

      {/* ==================== TAB 1: DASHBOARD & P&L ANALYSIS ==================== */}
      {activeTab === 'dashboard' && (
        <div className="space-y-4">
          {/* Simple & Useful Crop Information & Harvest Timeline Card */}
          <div className="liquid-glass-card rounded-2xl p-4 sm:p-5 space-y-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-emerald-500/20 dark:border-slate-700/80">
              <div>
                <h3 className="text-sm sm:text-base font-extrabold flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-emerald-600" />
                  <span>
                    {lang === 'hi'
                      ? 'फसल जानकारी और कटाई समय-सीमा (Crop & Harvest Info)'
                      : 'Crop Information & Harvest Timeline'}
                  </span>
                </h3>
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {lang === 'hi'
                    ? 'बुवाई से अब तक के दिन और पहली कटाई / तुड़ाई का अनुमानित समय'
                    : 'Days since sowing and estimated first harvest date'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onEditCrop(crop)}
                className="liquid-glass-pill px-3 py-1.5 rounded-xl text-xs font-extrabold text-emerald-900 dark:text-emerald-300 inline-flex items-center gap-1 cursor-pointer"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? 'फसल विवरण बदलें' : 'Edit Details'}</span>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 text-xs">
              {/* 1. Crop Name */}
              <div className="liquid-glass-subcard p-3 rounded-xl">
                <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400 block">
                  {lang === 'hi' ? 'फसल का नाम' : 'Crop Name'}
                </span>
                <span className="font-extrabold text-slate-950 dark:text-slate-100 block mt-0.5 truncate">
                  {lang === 'hi' ? crop.hindiName || crop.name : crop.name}
                </span>
              </div>

              {/* 2. Crop Category */}
              <div className="liquid-glass-subcard p-3 rounded-xl">
                <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400 block">
                  {lang === 'hi' ? 'फसल श्रेणी (Category)' : 'Crop Category'}
                </span>
                <span className="font-extrabold text-emerald-800 dark:text-emerald-400 block mt-0.5">
                  {getCropCategoryLabel(effectiveCategory, lang)}
                </span>
              </div>

              {/* 3. Harvest Type */}
              <div className="liquid-glass-subcard p-3 rounded-xl">
                <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400 block">
                  {lang === 'hi' ? 'कटाई का प्रकार' : 'Harvest Type'}
                </span>
                <span className="font-extrabold text-blue-800 dark:text-blue-400 block mt-0.5">
                  {effectiveAccountingType === 'recurring'
                    ? lang === 'hi'
                      ? 'बार-बार तुड़ाई (Repeated)'
                      : 'Repeated Harvest'
                    : lang === 'hi'
                    ? 'एक बार कटाई (Single)'
                    : 'Single Harvest'}
                </span>
              </div>

              {/* 4. Sowing / Transplantation Date */}
              <div className="liquid-glass-subcard p-3 rounded-xl">
                <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400 block">
                  {lang === 'hi' ? 'बुवाई / रोपाई तारीख' : 'Sowing / Planting Date'}
                </span>
                <span className="font-mono font-extrabold text-slate-950 dark:text-slate-100 block mt-0.5">
                  {crop.sowingDate}
                </span>
              </div>

              {/* 5. Current Crop Age in Days */}
              <div className="liquid-glass-income p-3 rounded-xl">
                <span className="text-[10px] font-extrabold text-emerald-950 dark:text-emerald-200 block">
                  {lang === 'hi' ? 'फसल की वर्तमान उम्र' : 'Current Crop Age'}
                </span>
                <span className="font-mono font-black text-sm text-emerald-900 dark:text-emerald-300 block mt-0.5">
                  {timeline.cropAgeDays} {lang === 'hi' ? 'दिन (days)' : 'days'}
                </span>
              </div>

              {/* 6. Expected First Harvest Date & Approximate Days Remaining */}
              <div className="liquid-glass-amber p-3 rounded-xl">
                <span className="text-[10px] font-extrabold text-amber-950 dark:text-amber-200 block">
                  {lang === 'hi' ? 'अनुमानित पहली कटाई' : 'Expected First Harvest'}
                </span>
                {onUpdateCrop ? (
                  <input
                    type="date"
                    aria-label={lang === 'hi' ? 'अनुमानित पहली कटाई की तारीख' : 'Expected First Harvest Date'}
                    value={crop.expectedHarvestDate || ''}
                    onChange={(e) =>
                      onUpdateCrop({
                        expectedHarvestDate: e.target.value || undefined
                      })
                    }
                    className="mt-0.5 w-full px-1.5 py-0.5 rounded-lg font-mono font-bold text-xs text-slate-950 dark:text-slate-100"
                  />
                ) : (
                  <span className="font-mono font-bold text-slate-950 dark:text-slate-100 block mt-0.5">
                    {crop.expectedHarvestDate || (lang === 'hi' ? 'तय नहीं' : 'Not set')}
                  </span>
                )}
                {timeline.expectedHarvestDate && (
                  <span
                    className={`text-[10px] font-extrabold block mt-1 ${
                      timeline.isHarvestDatePassed
                        ? 'text-amber-950 dark:text-amber-200'
                        : 'text-blue-900 dark:text-blue-300'
                    }`}
                  >
                    {timeline.isHarvestDatePassed
                      ? lang === 'hi'
                        ? 'अनुमानित कटाई की तारीख बीत चुकी है।'
                        : 'Expected harvest date has passed.'
                      : timeline.isHarvestDateToday
                      ? lang === 'hi'
                        ? 'आज अनुमानित कटाई की तारीख है।'
                        : 'Expected harvest date is today.'
                      : lang === 'hi'
                      ? `लगभग ${timeline.daysRemainingUntilHarvest} दिन शेष`
                      : `Approx. ${timeline.daysRemainingUntilHarvest} days remaining`}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Expense Category Breakdown Card */}
          <div className="liquid-glass-card rounded-2xl p-4 sm:p-5">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3.5">
              <div>
                <h3 className="text-sm sm:text-base font-extrabold">
                  {lang === 'hi' ? 'लागत वर्गीकरण (Expense Breakdown)' : 'Expense Breakdown'}
                </h3>
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {lang === 'hi'
                    ? 'किस मद में कितना रुपया खर्च हुआ (खाद, बीज, दवाई, डीजल, मजदूरी)'
                    : 'Rupees spent across each farming input'}
                </p>
              </div>
              <span className="text-xs sm:text-sm font-mono font-black text-rose-800 dark:text-rose-300 liquid-glass-expense px-3 py-1 rounded-xl">
                {lang === 'hi' ? 'कुल लागत:' : 'Total:'} {formatCurrency(totalLagat)}
              </span>
            </div>

            {totalLagat > 0 ? (
              <div className="space-y-2.5">
                {Object.entries(expenseByCategory).map(([cat, amt]) => {
                  const percent = Math.round((amt / totalLagat) * 100);
                  return (
                    <div key={cat} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-extrabold">
                        <span className="flex items-center gap-1.5">
                          <span>{categoryIcons[cat] || '📦'}</span>
                          <span>{getTranslation(lang, cat as any)}</span>
                        </span>
                        <div className="flex items-center gap-1.5 font-mono">
                          <span className="font-black">{formatCurrency(amt)}</span>
                          <span className="text-slate-600 dark:text-slate-300">({percent}%)</span>
                        </div>
                      </div>
                      <div className="w-full h-2.5 rounded-full overflow-hidden bg-slate-200/80 dark:bg-slate-800">
                        <div
                          className="h-full bg-emerald-600 rounded-full transition-all duration-300"
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs font-semibold py-5 text-center text-slate-600 dark:text-slate-300">
                {lang === 'hi'
                  ? 'अभी तक कोई खर्च दर्ज नहीं किया गया है। "लागत (खर्च)" टैब में जाकर खर्च जोड़ें।'
                  : 'No expenses logged yet. Tap Add Expense to begin.'}
              </p>
            )}
          </div>

          {/* Mandi Profitability Insight */}
          <div className="liquid-glass-card rounded-2xl p-4 sm:p-5">
            <h3 className="text-sm sm:text-base font-extrabold mb-3">
              {lang === 'hi' ? 'मंडी व आर्थिक विश्लेषण' : 'Crop Economics Summary'}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="liquid-glass-income p-3 rounded-xl">
                <span className="text-xs font-extrabold block text-emerald-950 dark:text-emerald-200">
                  {lang === 'hi' ? 'कुल पैदावार' : 'Total Yield'}
                </span>
                <span className="text-base sm:text-lg font-black font-mono block mt-0.5">
                  {totalYieldQuintal} {getTranslation(lang, 'quintal')}
                </span>
                <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block mt-0.5">
                  {crop.landArea > 0
                    ? `${yieldPerUnit} ${getTranslation(lang, 'quintal')}/${areaUnitLabel}`
                    : ''}
                </span>
              </div>

              <div className="liquid-glass-amber p-3 rounded-xl">
                <span className="text-xs font-extrabold block text-amber-950 dark:text-amber-200">
                  {lang === 'hi' ? 'प्रति क्विंटल औसत लागत' : 'Cost Per Quintal'}
                </span>
                <span className="text-base sm:text-lg font-black font-mono block mt-0.5">
                  {costPerQuintal > 0 ? formatCurrency(costPerQuintal) : '₹0'}
                </span>
                <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block mt-0.5">
                  {lang === 'hi' ? '1 क्विंटल तैयार करने का खर्च' : 'Production cost per quintal'}
                </span>
              </div>

              <div className="liquid-glass-profit p-3 rounded-xl">
                <span className="text-xs font-extrabold block text-blue-950 dark:text-blue-200">
                  {lang === 'hi' ? 'शुद्ध रिटर्न (ROI)' : 'Return on Investment (ROI)'}
                </span>
                <span
                  className={`text-base sm:text-lg font-black font-mono block mt-0.5 ${
                    isProfit ? 'text-emerald-800 dark:text-emerald-300' : 'text-rose-800 dark:text-rose-300'
                  }`}
                >
                  {totalLagat > 0 ? `${roiPercent}%` : '0%'}
                </span>
                <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block mt-0.5">
                  {lang === 'hi' ? 'लागत पर शुद्ध मुनाफा प्रतिशत' : 'Net return on total expenses'}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== TAB 2: LAGAT (EXPENSES) ==================== */}
      {activeTab === 'expenses' && (
        <div className="space-y-3.5">
          <div className="liquid-glass-card rounded-2xl p-3 sm:p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-slate-100">
                {lang === 'hi' ? 'मद के अनुसार खर्च छाँटें (Filter by Category):' : 'Filter Expenses by Category:'}
              </span>

              <button
                type="button"
                onClick={() => onAddTransaction('expense')}
                className="btn-3d-rose flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-white font-extrabold text-xs whitespace-nowrap cursor-pointer"
              >
                <Plus className="w-4 h-4 shrink-0" />
                <span>{getTranslation(lang, 'addExpense')}</span>
              </button>
            </div>

            {/* Unclipped Wrapping Liquid Glass Expense Category Buttons */}
            <div className="flex flex-wrap items-center gap-1.5">
              {['all', 'seeds', 'fertilizer', 'pesticide', 'labour', 'irrigation', 'transport', 'machinery', 'other'].map(
                (cat) => (
                  <button
                    type="button"
                    key={cat}
                    onClick={() => setExpenseFilter(cat)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer inline-flex items-center gap-1 ${
                      expenseFilter === cat
                        ? 'btn-3d-rose text-white'
                        : 'liquid-glass-pill text-slate-900 dark:text-slate-100'
                    }`}
                  >
                    {cat !== 'all' && <span>{categoryIcons[cat] || '📦'}</span>}
                    <span>
                      {cat === 'all' ? (lang === 'hi' ? 'सभी खर्च' : 'All Expenses') : getTranslation(lang, cat as any)}
                    </span>
                  </button>
                )
              )}
            </div>
          </div>

          {filteredExpenses.length > 0 ? (
            <div className="space-y-2.5">
              {filteredExpenses.map((tx) => (
                <div
                  key={tx.id}
                  onClick={() => setSelectedTxDetail(tx)}
                  className={`liquid-glass-card p-3.5 rounded-xl transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 cursor-pointer hover:border-rose-400 ${
                    isDark ? 'text-slate-100' : 'text-slate-900'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 flex items-center justify-center shrink-0 text-base">
                      {categoryIcons[tx.category] || '📦'}
                    </div>

                    <div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <h4 className="text-xs sm:text-sm font-bold">
                          {tx.title}
                        </h4>
                        <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                          {getTranslation(lang, tx.category as any)}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5 text-[11px] mt-0.5 font-mono text-slate-500 dark:text-slate-400">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-rose-500" />
                          <span>{tx.date}</span>
                        </span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-rose-500" />
                          <span>{tx.time}</span>
                        </span>
                        {tx.quantity && (
                          <>
                            <span>•</span>
                            <span className="font-semibold text-slate-700 dark:text-slate-200">
                              {tx.quantity} {tx.unit || ''}
                            </span>
                          </>
                        )}
                        {tx.vendorOrBuyer && (
                          <>
                            <span>•</span>
                            <span className="font-semibold text-slate-700 dark:text-slate-200">{tx.vendorOrBuyer}</span>
                          </>
                        )}
                      </div>

                      {tx.notes && (
                        <p className="text-xs mt-1 text-slate-600 dark:text-slate-300">
                          {tx.notes}
                        </p>
                      )}

                      {tx.receiptAttachment && (
                        <div className="mt-1.5">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setViewingReceiptTx(tx);
                            }}
                            className="liquid-glass-pill px-2.5 py-1 rounded-lg text-[11px] font-extrabold text-emerald-900 dark:text-emerald-300 inline-flex items-center gap-1.5 cursor-pointer border border-emerald-400/60"
                          >
                            <Paperclip className="w-3 h-3 text-emerald-700 dark:text-emerald-400 shrink-0" />
                            <span className="truncate max-w-[180px]">
                              {lang === 'hi'
                                ? `बिल देखें: ${tx.receiptAttachment.fileName}`
                                : `View Bill: ${tx.receiptAttachment.fileName}`}
                            </span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-1.5 self-end sm:self-center">
                    <span className="text-sm sm:text-base font-bold font-mono tabular-nums mr-1 text-rose-700 dark:text-rose-400">
                      -{formatCurrency(tx.amount)}
                    </span>
                    {tx.receiptAttachment && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setViewingReceiptTx(tx);
                        }}
                        title={lang === 'hi' ? 'बिल / रसीद देखें' : 'View Attached Bill / Receipt'}
                        className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 cursor-pointer"
                      >
                        <Paperclip className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {onEditTransaction && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onEditTransaction(tx);
                        }}
                        title={lang === 'hi' ? 'खर्च सुधारें' : 'Edit Expense'}
                        className="p-1.5 rounded-lg liquid-glass-pill text-slate-800 dark:text-slate-100 cursor-pointer"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setItemToDelete({ type: 'tx', id: tx.id, name: tx.title });
                      }}
                      title={lang === 'hi' ? 'खर्च हटाएं' : 'Delete Expense'}
                      className="p-1.5 rounded-lg liquid-glass-danger cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div
              className={`liquid-glass-card text-center py-8 border border-dashed rounded-2xl ${
                isDark ? 'text-slate-100' : 'text-slate-900'
              }`}
            >
              <p className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-3">
                {lang === 'hi' ? 'इस श्रेणी में कोई खर्च दर्ज नहीं है' : 'No expenses in this category'}
              </p>
              <button
                type="button"
                onClick={() => onAddTransaction('expense')}
                className="btn-3d-rose inline-flex items-center gap-1 px-4 py-2 rounded-xl text-white font-semibold text-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{getTranslation(lang, 'addExpense')}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB 3: KAMAI (INCOME & MANDI SALES) ==================== */}
      {activeTab === 'income' && (
        <div className="space-y-3.5">
          <div className="liquid-glass-card p-3.5 rounded-2xl flex flex-wrap items-center justify-between gap-2.5">
            <h3 className="text-sm sm:text-base font-extrabold">
              {lang === 'hi' ? 'मंडी बिक्री व आमदनी खाते' : 'Mandi Sales & Realization'}
            </h3>

            <button
              type="button"
              onClick={() => onAddTransaction('income')}
              className="btn-3d-primary flex items-center gap-1 px-3.5 py-2 rounded-xl text-white font-semibold text-xs cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{getTranslation(lang, 'addIncome')}</span>
            </button>
          </div>

          {incomes.length > 0 ? (
            <div className="space-y-2.5">
              {incomes.map((tx) => (
                <div
                  key={tx.id}
                  onClick={() => setSelectedTxDetail(tx)}
                  className={`liquid-glass-card p-3.5 rounded-xl cursor-pointer transition-all hover:border-emerald-400 ${
                    isDark ? 'text-slate-100' : 'text-slate-900'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2.5 border-b border-slate-200/70 dark:border-slate-700/70">
                    <div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-xs sm:text-sm font-bold">
                          {tx.title}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                          {getTranslation(lang, tx.category as any)}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5 text-[11px] mt-0.5 font-mono text-slate-600 dark:text-slate-300">
                        <span>{tx.date}</span>
                        <span>•</span>
                        <span>{tx.time}</span>
                        {tx.vendorOrBuyer && (
                          <>
                            <span>•</span>
                            <span className="font-semibold text-emerald-700 dark:text-emerald-400">
                              {tx.vendorOrBuyer}
                            </span>
                          </>
                        )}
                      </div>

                      {tx.notes && (
                        <p className="text-xs mt-1 text-slate-700 dark:text-slate-300">
                          {tx.notes}
                        </p>
                      )}

                      {tx.receiptAttachment && (
                        <div className="mt-1.5">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setViewingReceiptTx(tx);
                            }}
                            className="liquid-glass-pill px-2.5 py-1 rounded-lg text-[11px] font-extrabold text-emerald-900 dark:text-emerald-300 inline-flex items-center gap-1.5 cursor-pointer border border-emerald-400/60"
                          >
                            <Paperclip className="w-3 h-3 text-emerald-700 dark:text-emerald-400 shrink-0" />
                            <span className="truncate max-w-[180px]">
                              {lang === 'hi'
                                ? `रसीद देखें: ${tx.receiptAttachment.fileName}`
                                : `View Receipt: ${tx.receiptAttachment.fileName}`}
                            </span>
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className="text-sm sm:text-base font-bold font-mono tabular-nums mr-1 text-emerald-700 dark:text-emerald-400">
                        +{formatCurrency(tx.amount)}
                      </span>
                      {tx.receiptAttachment && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setViewingReceiptTx(tx);
                          }}
                          title={lang === 'hi' ? 'रसीद / बिल देखें' : 'View Attached Receipt'}
                          className="p-1.5 rounded-lg liquid-glass-emerald cursor-pointer"
                        >
                          <Paperclip className="w-3.5 h-3.5" />
                        </button>
                      )}
                      {onEditTransaction && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onEditTransaction(tx);
                          }}
                          title={lang === 'hi' ? 'कमाई सुधारें' : 'Edit Income'}
                          className="p-1.5 rounded-lg liquid-glass-pill text-slate-800 dark:text-slate-100 cursor-pointer"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setItemToDelete({ type: 'tx', id: tx.id, name: tx.title });
                        }}
                        title={lang === 'hi' ? 'कमाई हटाएं' : 'Delete Income'}
                        className="p-1.5 rounded-lg liquid-glass-danger cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Mandi Slip Breakdown Card if present */}
                  {tx.mandiDetails && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2.5 text-xs">
                      <div className="liquid-glass-income p-2 rounded-lg">
                        <span className="text-[10px] font-bold block text-emerald-900 dark:text-emerald-300">
                          शुद्ध वजन (Net Qtl)
                        </span>
                        <span className="text-xs sm:text-sm font-extrabold font-mono">
                          {tx.mandiDetails.netWeightQuintal} {getTranslation(lang, 'quintal')}
                        </span>
                      </div>

                      <div className="liquid-glass-amber p-2 rounded-lg">
                        <span className="text-[10px] font-bold block text-amber-900 dark:text-amber-300">
                          मंडी भाव (Rate/Qtl)
                        </span>
                        <span className="text-xs sm:text-sm font-extrabold font-mono">
                          ₹{tx.mandiDetails.ratePerQuintal}
                        </span>
                      </div>

                      <div className="liquid-glass-expense p-2 rounded-lg">
                        <span className="text-[10px] font-bold block text-rose-900 dark:text-rose-300">
                          पल्लेदारी कटौती
                        </span>
                        <span className="text-xs sm:text-sm font-extrabold font-mono text-rose-700 dark:text-rose-400">
                          ₹{tx.mandiDetails.totalPalledari || 0}
                        </span>
                      </div>

                      <div className="liquid-glass-profit p-2 rounded-lg">
                        <span className="text-[10px] font-bold block text-blue-900 dark:text-blue-300">
                          पर्ची नंबर (Slip)
                        </span>
                        <span className="text-xs sm:text-sm font-mono font-extrabold">
                          {tx.mandiDetails.receiptNumber || 'N/A'}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div
              className={`liquid-glass-card text-center py-8 border border-dashed rounded-2xl ${
                isDark ? 'text-slate-100' : 'text-slate-900'
              }`}
            >
              <p className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-3">
                {lang === 'hi' ? 'अभी कोई बिक्री दर्ज नहीं हुई है' : 'No sales or income logged yet'}
              </p>
              <button
                type="button"
                onClick={() => onAddTransaction('income')}
                className="btn-3d-primary inline-flex items-center gap-1 px-4 py-2 rounded-xl text-white font-semibold text-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{getTranslation(lang, 'addIncome')}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB 4: TUDAI (HARVEST WEIGHT LOGS) ==================== */}
      {activeTab === 'harvest' && (
        <div className="space-y-3.5">
          <div className="liquid-glass-card p-3.5 rounded-2xl flex flex-wrap items-center justify-between gap-2.5">
            <div>
              <h3 className="text-sm sm:text-base font-extrabold">
                {lang === 'hi' ? 'कटाई व तुड़ाई वजन हिसाब' : 'Harvest Weight Logging'}
              </h3>
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                {lang === 'hi' ? 'कुल दर्ज पैदावार:' : 'Total Recorded Yield:'}{' '}
                <span className="font-bold font-mono text-amber-700 dark:text-amber-400">
                  {totalYieldQuintal} {getTranslation(lang, 'quintal')}
                </span>
              </p>
            </div>

            <button
              type="button"
              onClick={onAddHarvest}
              className="btn-3d-amber flex items-center gap-1 px-3.5 py-2 rounded-xl text-white font-semibold text-xs cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{getTranslation(lang, 'addHarvest')}</span>
            </button>
          </div>

          {cropHarvests.length > 0 ? (
            <div className="space-y-2.5">
              {cropHarvests.map((hrv) => (
                <div
                  key={hrv.id}
                  className={`liquid-glass-card p-3.5 rounded-xl flex items-center justify-between gap-2 ${
                    isDark ? 'text-slate-100' : 'text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0">
                      <Scale className="w-4 h-4" />
                    </div>

                    <div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-sm sm:text-base font-bold font-mono">
                          {hrv.quantityUnit === 'kg'
                            ? `${hrv.quantityValue ?? Number((hrv.quantityQuintal * 100).toFixed(2))} ${
                                lang === 'hi' ? 'किलो (Kg)' : 'Kg'
                              } (${hrv.quantityQuintal} ${getTranslation(lang, 'quintal')})`
                            : `${hrv.quantityQuintal} ${getTranslation(lang, 'quintal')}`}
                        </span>
                        {hrv.grade && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                            {hrv.grade}
                          </span>
                        )}
                        {hrv.moisturePercentage !== undefined && (
                          <span className="text-xs font-mono font-semibold text-emerald-700 dark:text-emerald-400">
                            {lang === 'hi' ? 'नमी:' : 'Moisture:'} {hrv.moisturePercentage}%
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5 text-[11px] mt-0.5 font-mono text-slate-600 dark:text-slate-300">
                        <span>{hrv.date}</span>
                        <span>•</span>
                        <span>{hrv.time}</span>
                        {hrv.storageLocation && (
                          <>
                            <span>•</span>
                            <span className="font-semibold text-slate-800 dark:text-slate-200">{hrv.storageLocation}</span>
                          </>
                        )}
                      </div>

                      {hrv.notes && (
                        <p className="text-xs mt-1 text-slate-700 dark:text-slate-300">
                          {hrv.notes}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {onEditHarvest && (
                      <button
                        type="button"
                        onClick={() => onEditHarvest(hrv)}
                        title={lang === 'hi' ? 'कटाई वजन सुधारें' : 'Edit Harvest Entry'}
                        className="p-1.5 rounded-lg liquid-glass-pill text-slate-800 dark:text-slate-100 cursor-pointer"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() =>
                        setItemToDelete({
                          type: 'harvest',
                          id: hrv.id,
                          name: `${hrv.quantityQuintal} क्विंटल कटाई`
                        })
                      }
                      title={lang === 'hi' ? 'कटाई वजन हटाएं' : 'Delete Harvest Entry'}
                      className="p-1.5 rounded-lg liquid-glass-danger cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div
              className={`liquid-glass-card text-center py-8 border border-dashed rounded-2xl ${
                isDark ? 'text-slate-100' : 'text-slate-900'
              }`}
            >
              <p className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-3">
                {lang === 'hi' ? 'कटाई का वजन दर्ज करने के लिए बटन दबाएं' : 'Log your first harvest session'}
              </p>
              <button
                type="button"
                onClick={onAddHarvest}
                className="btn-3d-amber inline-flex items-center gap-1 px-4 py-2 rounded-xl text-white font-semibold text-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{getTranslation(lang, 'addHarvest')}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB 5: KHET DIARY ==================== */}
      {activeTab === 'diary' && (
        <div className="space-y-3.5">
          <div className="liquid-glass-card p-3.5 rounded-2xl flex flex-wrap items-center justify-between gap-2.5">
            <div>
              <h3 className="text-sm sm:text-base font-extrabold">
                {lang === 'hi' ? 'खेत डायरी व गतिविधि टाइमलाइन' : 'Farm Activity Diary'}
              </h3>
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                {lang === 'hi'
                  ? 'सिंचाई, छिड़काव व खाद डालने की तारीख व टिप्पणियां'
                  : 'Timestamps of irrigation, sprays, and fertilizer'}
              </p>
            </div>

            <button
              type="button"
              onClick={onAddDiary}
              className="btn-3d-blue flex items-center gap-1 px-3.5 py-2 rounded-xl text-white font-semibold text-xs cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{getTranslation(lang, 'addDiary')}</span>
            </button>
          </div>

          {cropDiary.length > 0 ? (
            <div className="relative pl-5 space-y-3 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-emerald-500">
              {cropDiary.map((item) => (
                <div key={item.id} className="relative">
                  <div className="absolute -left-5 top-2.5 w-3 h-3 rounded-full bg-emerald-600 border-2 border-white dark:border-slate-900" />

                  <div
                    className={`liquid-glass-card p-3.5 rounded-xl ${
                      isDark ? 'text-slate-100' : 'text-slate-900'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-[11px] font-semibold text-blue-800 dark:text-blue-300">
                          {item.activityType === 'irrigation'
                            ? '💧 सिंचाई'
                            : item.activityType === 'spray'
                            ? '🧪 स्प्रे छिड़काव'
                            : item.activityType === 'fertilizer'
                            ? '🌱 खाद'
                            : item.activityType === 'sowing'
                            ? '🌾 बुवाई'
                            : item.activityType === 'inspection'
                            ? '🔍 निरीक्षण'
                            : item.activityType === 'harvest'
                            ? '🌾 कटाई'
                            : item.activityType === 'weeding'
                            ? '🌿 निराई-गुड़ाई'
                            : '📋 अन्य कार्य'}
                        </span>
                        <span className="text-[11px] font-mono font-semibold text-slate-600 dark:text-slate-300">
                          {item.date} • {item.time}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        {onEditDiary && (
                          <button
                            type="button"
                            onClick={() => onEditDiary(item)}
                            title={lang === 'hi' ? 'डायरी नोट सुधारें' : 'Edit Diary Note'}
                            className="p-1.5 rounded-lg liquid-glass-pill text-slate-800 dark:text-slate-100 cursor-pointer"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setItemToDelete({ type: 'diary', id: item.id, name: 'खेत डायरी नोट' })}
                          title={lang === 'hi' ? 'डायरी नोट हटाएं' : 'Delete Diary Note'}
                          className="p-1.5 rounded-lg liquid-glass-danger cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <p className="text-xs sm:text-sm font-semibold leading-relaxed">
                      {item.notes}
                    </p>

                    {item.weatherNote && (
                      <p className="text-[11px] mt-1.5 flex items-center gap-1 font-bold text-amber-800 dark:text-amber-300 liquid-glass-amber px-2 py-0.5 rounded w-fit">
                        <span>☀️</span> {item.weatherNote}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div
              className={`liquid-glass-card text-center py-8 border border-dashed rounded-2xl ${
                isDark ? 'text-slate-100' : 'text-slate-900'
              }`}
            >
              <p className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-3">
                {lang === 'hi' ? 'खेत डायरी में कोई प्रविष्टि नहीं है' : 'No diary entries yet'}
              </p>
              <button
                type="button"
                onClick={onAddDiary}
                className="btn-3d-blue inline-flex items-center gap-1 px-4 py-2 rounded-xl text-white font-semibold text-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{getTranslation(lang, 'addDiary')}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Delete Crop Confirmation Modal */}
      <ConfirmModal
        isOpen={isDeleteCropModalOpen}
        title={lang === 'hi' ? 'पूरी फसल का खाता हटाएं?' : 'Delete Entire Crop?'}
        message={
          lang === 'hi'
            ? `क्या आप सचमुच "${crop.hindiName || crop.name}" फसल और इसके अंदर दर्ज सभी खर्च, मंडी बिक्री, तुड़ाई व डायरी के हिसाब को हमेशा के लिए हटाना चाहते हैं?`
            : `Are you sure you want to permanently delete "${crop.name}" and all its recorded expenses, mandi sales, and logs?`
        }
        confirmLabel={lang === 'hi' ? 'हाँ, पूरा खाता हटाएं' : 'Yes, Delete All'}
        cancelLabel={lang === 'hi' ? 'रद्द करें' : 'Cancel'}
        isDestructive={true}
        theme={theme}
        onConfirm={() => {
          setIsDeleteCropModalOpen(false);
          onDeleteCrop(crop.id);
        }}
        onCancel={() => setIsDeleteCropModalOpen(false)}
      />

      {/* Delete Single Entry Confirmation Modal */}
      <ConfirmModal
        isOpen={!!itemToDelete}
        title={lang === 'hi' ? 'प्रविष्टि हटाएं?' : 'Delete Entry?'}
        message={
          lang === 'hi'
            ? `क्या आप "${itemToDelete?.name}" का रिकॉर्ड हटाना चाहते हैं?`
            : `Are you sure you want to delete "${itemToDelete?.name}"?`
        }
        confirmLabel={lang === 'hi' ? 'हाँ, हटाएं' : 'Yes, Delete'}
        cancelLabel={lang === 'hi' ? 'रद्द करें' : 'Cancel'}
        isDestructive={true}
        theme={theme}
        onConfirm={() => {
          if (!itemToDelete) return;
          if (itemToDelete.type === 'tx') onDeleteTransaction(itemToDelete.id);
          else if (itemToDelete.type === 'harvest') onDeleteHarvest(itemToDelete.id);
          else if (itemToDelete.type === 'diary') onDeleteDiary(itemToDelete.id);
          setItemToDelete(null);
        }}
        onCancel={() => setItemToDelete(null)}
      />

      {/* Transaction Detail Modal (Opened when tapping any Expense or Income row) */}
      {selectedTxDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-sm">
          <div className="liquid-glass-modal w-full max-w-md rounded-3xl p-5 space-y-4">
            <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <span
                  className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-extrabold mb-1 ${
                    selectedTxDetail.type === 'expense'
                      ? 'bg-rose-100 dark:bg-rose-950/80 text-rose-800 dark:text-rose-300'
                      : 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300'
                  }`}
                >
                  {selectedTxDetail.type === 'expense'
                    ? lang === 'hi'
                      ? '🔴 खर्च प्रविष्टि (Expense)'
                      : '🔴 Expense Entry'
                    : lang === 'hi'
                    ? '🟢 बिक्री / कमाई (Income)'
                    : '🟢 Sale / Income Entry'}
                </span>
                <h3 className="text-base font-black text-slate-950 dark:text-white">
                  {selectedTxDetail.title}
                </h3>
                <p className="text-xs font-bold text-emerald-800 dark:text-emerald-300">
                  {lang === 'hi' ? crop.hindiName || crop.name : crop.name}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTxDetail(null)}
                className="w-8 h-8 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-100/80 dark:bg-slate-800/70">
                <span className="font-bold text-slate-600 dark:text-slate-300">
                  {lang === 'hi' ? 'कुल राशि (Amount):' : 'Total Amount:'}
                </span>
                <span
                  className={`text-base font-black font-mono ${
                    selectedTxDetail.type === 'expense'
                      ? 'text-rose-700 dark:text-rose-400'
                      : 'text-emerald-700 dark:text-emerald-400'
                  }`}
                >
                  {selectedTxDetail.type === 'expense' ? '-' : '+'}
                  {formatCurrency(selectedTxDetail.amount)}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] font-bold text-slate-500 block">
                    {lang === 'hi' ? 'तारीख और समय' : 'Date & Time'}
                  </span>
                  <span className="font-mono font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1 mt-0.5">
                    <Clock className="w-3 h-3 text-emerald-600" />
                    {selectedTxDetail.date} {selectedTxDetail.time}
                  </span>
                </div>

                <div className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] font-bold text-slate-500 block">
                    {lang === 'hi' ? 'श्रेणी (Category)' : 'Category'}
                  </span>
                  <span className="font-bold text-slate-900 dark:text-slate-100 block mt-0.5">
                    {getTranslation(lang, selectedTxDetail.category as any)}
                  </span>
                </div>
              </div>

              {(selectedTxDetail.quantity || selectedTxDetail.vendorOrBuyer) && (
                <div className="grid grid-cols-2 gap-2">
                  {selectedTxDetail.quantity && (
                    <div className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                      <span className="text-[10px] font-bold text-slate-500 block">
                        {lang === 'hi' ? 'मात्रा (Quantity)' : 'Quantity'}
                      </span>
                      <span className="font-mono font-bold text-slate-900 dark:text-slate-100 block mt-0.5">
                        {selectedTxDetail.quantity} {selectedTxDetail.unit || ''}
                      </span>
                    </div>
                  )}
                  {selectedTxDetail.vendorOrBuyer && (
                    <div className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                      <span className="text-[10px] font-bold text-slate-500 block">
                        {selectedTxDetail.type === 'expense'
                          ? lang === 'hi'
                            ? 'दुकानदार / विक्रेता'
                            : 'Vendor / Shop'
                          : lang === 'hi'
                          ? 'खरीदार / आढ़ती'
                          : 'Buyer / Mandi'}
                      </span>
                      <span className="font-bold text-slate-900 dark:text-slate-100 block mt-0.5">
                        {selectedTxDetail.vendorOrBuyer}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {selectedTxDetail.notes && (
                <div className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] font-bold text-slate-500 block">
                    {lang === 'hi' ? 'नोट्स / विवरण' : 'Notes'}
                  </span>
                  <p className="text-slate-800 dark:text-slate-200 mt-0.5">
                    {selectedTxDetail.notes}
                  </p>
                </div>
              )}

              {selectedTxDetail.receiptAttachment && (
                <button
                  type="button"
                  onClick={() => {
                    const tx = selectedTxDetail;
                    setSelectedTxDetail(null);
                    setViewingReceiptTx(tx);
                  }}
                  className="liquid-glass-pill w-full py-2.5 px-3 rounded-xl font-extrabold text-emerald-900 dark:text-emerald-300 flex items-center justify-center gap-1.5 cursor-pointer border border-emerald-400/60"
                >
                  <Paperclip className="w-3.5 h-3.5" />
                  <span>
                    {lang === 'hi'
                      ? `संलग्न बिल / रसीद देखें (${selectedTxDetail.receiptAttachment.fileName})`
                      : `View Attached Bill / Receipt (${selectedTxDetail.receiptAttachment.fileName})`}
                  </span>
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              {onEditTransaction && (
                <button
                  type="button"
                  onClick={() => {
                    const tx = selectedTxDetail;
                    setSelectedTxDetail(null);
                    onEditTransaction(tx);
                  }}
                  className="liquid-glass-pill px-3.5 py-2 rounded-xl text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span>{lang === 'hi' ? 'प्रविष्टि सुधारें' : 'Edit Entry'}</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => setSelectedTxDetail(null)}
                className="liquid-glass-emerald px-4 py-2 rounded-xl text-xs font-extrabold text-white cursor-pointer"
              >
                {lang === 'hi' ? 'बंद करें' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Linked Bill / Receipt Viewer Modal */}
      <ReceiptViewerModal
        isOpen={!!viewingReceiptTx}
        onClose={() => setViewingReceiptTx(null)}
        transaction={viewingReceiptTx}
        cropName={lang === 'hi' ? crop.hindiName || crop.name : crop.name}
        lang={lang}
      />
    </div>
  );
};
