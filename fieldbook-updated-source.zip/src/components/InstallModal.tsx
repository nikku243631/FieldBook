import React from 'react';
import {
  Download,
  Smartphone,
  X,
  ShieldCheck,
  MoreVertical,
  PlusSquare,
  PackageCheck,
  User
} from 'lucide-react';
import { Language, Theme } from '../types';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  theme: Theme;
  onGoToAccountReports?: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({
  isOpen,
  onClose,
  lang,
  onGoToAccountReports
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();

  if (!isOpen) return null;

  const isHindi = lang === 'hi';

  const handleDirectInstall = async () => {
    const success = await install();
    if (success) {
      setTimeout(() => {
        onClose();
      }, 1000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-950/65 backdrop-blur-md">
      <div className="liquid-glass-modal relative w-full max-w-xl rounded-3xl overflow-hidden z-10 my-6 animate-in fade-in zoom-in-95 duration-200">
        {/* Header Ribbon */}
        <div className="px-5 py-4 border-b border-white/60 dark:border-slate-700/70 bg-gradient-to-r from-emerald-500/25 via-teal-500/20 to-sky-500/25">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-emerald-950 border-2 border-white/80 flex items-center justify-center overflow-hidden shadow-md shrink-0">
                <img
                  src="/logo.png"
                  alt="FieldBook Logo"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-extrabold tracking-tight text-slate-950 dark:text-white">
                    {isHindi ? 'किसान खाता व ऐप इंस्टॉल' : 'Farmer Account & App Install'}
                  </h2>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-700 text-white uppercase">
                    v2.4
                  </span>
                </div>
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                  {isHindi
                    ? 'किसान प्रोफाइल, डेटा बैकअप और फोन में ऐप इंस्टॉल सुविधा'
                    : 'Farmer profile, farm data backup & device installation'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="liquid-glass-pill w-9 h-9 rounded-full flex items-center justify-center text-slate-950 dark:text-white cursor-pointer shrink-0"
              title={isHindi ? 'बंद करें' : 'Close'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Actions */}
          <div className="flex gap-2 mt-3.5 p-1 rounded-2xl bg-white/50 dark:bg-slate-900/60 border border-white/70 dark:border-slate-700 text-xs font-extrabold">
            <div className="flex-1 py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 liquid-glass-emerald text-white shadow-sm">
              <Smartphone className="w-4 h-4 shrink-0" />
              <span>{isHindi ? '📱 ऐप इंस्टॉल' : '📱 Direct Install'}</span>
            </div>

            {onGoToAccountReports && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onGoToAccountReports();
                }}
                className="flex-1 py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 text-slate-900 dark:text-slate-200 hover:bg-white/60 transition cursor-pointer"
              >
                <User className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>{isHindi ? '👤 किसान खाता / बैकअप' : '👤 Account / Backup'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 space-y-4 max-h-[72vh] overflow-y-auto">
          {isInstalled && (
            <div className="p-3 rounded-2xl liquid-glass-income flex items-center gap-2.5 text-xs font-extrabold text-emerald-950 dark:text-emerald-200">
              <PackageCheck className="w-5 h-5 shrink-0 text-emerald-700" />
              <span>{isHindi ? 'FieldBook आपके फोन में इंस्टॉल है!' : 'FieldBook is installed!'}</span>
            </div>
          )}

          <div className="space-y-4">
            {isInstallable ? (
              <div className="p-4 rounded-2xl liquid-glass-income text-center space-y-3">
                <button
                  type="button"
                  onClick={handleDirectInstall}
                  className="w-full py-3.5 px-6 rounded-2xl liquid-glass-emerald text-white font-extrabold text-sm shadow-lg cursor-pointer flex items-center justify-center gap-2"
                >
                  <Download className="w-5 h-5" />
                  <span>{isHindi ? '📱 अभी फोन में इंस्टॉल करें' : '📱 Install App on Device'}</span>
                </button>
              </div>
            ) : null}

            <div className="space-y-2.5">
              <div className="p-3.5 rounded-2xl liquid-glass-subcard flex items-center gap-3">
                <div className="w-7 h-7 rounded-xl liquid-glass-emerald text-white flex items-center justify-center font-extrabold text-xs shrink-0">
                  1
                </div>
                <p className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5">
                  <span>{isHindi ? 'Chrome ब्राउज़र में ऊपर 3 बिंदी दबाएं' : 'Open Chrome 3-dot Menu'}</span>
                  <MoreVertical className="w-4 h-4 inline" />
                </p>
              </div>

              <div className="p-3.5 rounded-2xl liquid-glass-subcard flex items-center gap-3">
                <div className="w-7 h-7 rounded-xl liquid-glass-emerald text-white flex items-center justify-center font-extrabold text-xs shrink-0">
                  2
                </div>
                <p className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5">
                  <span>{isHindi ? '"Install app" या "Add to Home screen" चुनें' : 'Select "Install app"'}</span>
                  <PlusSquare className="w-4 h-4 inline" />
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3.5 border-t border-white/60 dark:border-slate-700/70 bg-white/45 dark:bg-slate-900/75 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5 text-slate-950 dark:text-slate-200 font-extrabold">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>{isHindi ? '100% सुरक्षित • By Mr Nikhil' : '100% Secure • By Mr Nikhil'}</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="liquid-glass-pill px-4 py-2 rounded-xl text-slate-950 dark:text-white font-extrabold cursor-pointer"
          >
            {isHindi ? 'बंद करें (Close)' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};

