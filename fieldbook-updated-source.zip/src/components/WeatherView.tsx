import React, { useState, useEffect } from 'react';
import {
  Wind,
  Droplets,
  MapPin,
  Search,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Sprout,
  ThermometerSun,
  CloudRain,
  Navigation,
  ShieldAlert,
  Calendar
} from 'lucide-react';
import { Language, Theme } from '../types';
import { Storage, SavedLocation, DEFAULT_USER_LOCATION } from '../utils/storage';

interface WeatherViewProps {
  lang: Language;
  theme: Theme;
}

interface CurrentWeather {
  temperature: number;
  apparentTemperature: number;
  humidity: number;
  windSpeed: number;
  weatherCode: number;
  precipitation: number;
}

interface DailyForecast {
  date: string;
  tempMax: number;
  tempMin: number;
  precipProb: number;
  precipSum: number;
  windMax: number;
  weatherCode: number;
}

const POPULAR_LOCATIONS: SavedLocation[] = [
  DEFAULT_USER_LOCATION,
  {
    name: 'बदायूं शहर (Budaun City)',
    district: 'बदायूं (Budaun)',
    state: 'उत्तर प्रदेश',
    pincode: '243601',
    lat: 28.0342,
    lon: 79.1243
  },
  {
    name: 'बिल्सी, बदायूं (Bilsi)',
    district: 'बदायूं',
    state: 'उत्तर प्रदेश',
    pincode: '243633',
    lat: 28.1317,
    lon: 78.9114
  },
  {
    name: 'सहसवान, बदायूं (Sahaswan)',
    district: 'बदायूं',
    state: 'उत्तर प्रदेश',
    pincode: '243638',
    lat: 28.0715,
    lon: 78.7429
  },
  {
    name: 'उझानी, बदायूं (Ujhani)',
    district: 'बदायूं',
    state: 'उत्तर प्रदेश',
    pincode: '243639',
    lat: 28.0044,
    lon: 79.0085
  },
  {
    name: 'बरेली (Bareilly)',
    district: 'बरेली',
    state: 'उत्तर प्रदेश',
    pincode: '243001',
    lat: 28.367,
    lon: 79.4304
  }
];

export const WeatherView: React.FC<WeatherViewProps> = ({ lang, theme }) => {
  const isHindi = lang === 'hi';
  const isDark = theme === 'dark';

  const [savedLoc, setSavedLoc] = useState<SavedLocation>(() => Storage.getWeatherLocation());
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [searchResults, setSearchResults] = useState<SavedLocation[]>([]);
  const [isSearching, setIsSearching] = useState<boolean>(false);

  const [current, setCurrent] = useState<CurrentWeather | null>(null);
  const [daily, setDaily] = useState<DailyForecast[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const [isOfflineData, setIsOfflineData] = useState<boolean>(false);
  const [gpsStatus, setGpsStatus] = useState<string>('');

  const getWeatherLabel = (code: number): { hi: string; en: string; icon: string } => {
    if (code === 0) return { hi: 'तेज खिली धूप (साफ आसमान)', en: 'Clear Sunny Sky', icon: '☀️' };
    if (code >= 1 && code <= 3) return { hi: 'हल्के बादल व धूप', en: 'Partly Cloudy', icon: '⛅' };
    if (code === 45 || code === 48) return { hi: 'कोहरा / धुंध', en: 'Foggy / Hazy', icon: '🌫️' };
    if (code >= 51 && code <= 67) return { hi: 'हल्की से मध्यम बारिश', en: 'Light to Moderate Rain', icon: '🌧️' };
    if (code >= 80 && code <= 82) return { hi: 'तेज बौछारें / बारिश', en: 'Rain Showers', icon: '🌦️' };
    if (code >= 95) return { hi: 'आंधी-तूफान व बारिश की चेतावनी', en: 'Thunderstorm Alert', icon: '⛈️' };
    return { hi: 'सामान्य मौसम', en: 'Normal Weather', icon: '🌤️' };
  };

  const fetchWeather = async (loc: SavedLocation) => {
    setLoading(true);
    setIsOfflineData(false);
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${loc.lat}&longitude=${loc.lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max&timezone=auto`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('Network error');
      const data = await res.json();

      const curr: CurrentWeather = {
        temperature: Math.round(data.current.temperature_2m),
        apparentTemperature: Math.round(data.current.apparent_temperature),
        humidity: Math.round(data.current.relative_humidity_2m),
        windSpeed: Math.round(data.current.wind_speed_10m),
        weatherCode: data.current.weather_code,
        precipitation: data.current.precipitation || 0
      };

      const days: DailyForecast[] = (data.daily.time || []).slice(0, 7).map((d: string, idx: number) => ({
        date: d,
        tempMax: Math.round(data.daily.temperature_2m_max[idx]),
        tempMin: Math.round(data.daily.temperature_2m_min[idx]),
        precipProb: Math.round(data.daily.precipitation_probability_max?.[idx] || 0),
        precipSum: Number((data.daily.precipitation_sum?.[idx] || 0).toFixed(1)),
        windMax: Math.round(data.daily.wind_speed_10m_max?.[idx] || 0),
        weatherCode: data.daily.weather_code?.[idx] || 0
      }));

      const nowStr = new Date().toLocaleTimeString(isHindi ? 'hi-IN' : 'en-IN', {
        hour: '2-digit',
        minute: '2-digit'
      });

      setCurrent(curr);
      setDaily(days);
      setLastUpdated(nowStr);
      Storage.saveCachedWeather(loc.lat, loc.lon, { current: curr, daily: days, updatedAt: nowStr });
    } catch {
      const cached = Storage.getCachedWeather(loc.lat, loc.lon);
      if (cached && cached.current && cached.daily) {
        setCurrent(cached.current);
        setDaily(cached.daily);
        setLastUpdated(cached.updatedAt || '');
        setIsOfflineData(true);
      } else {
        setCurrent({
          temperature: 29,
          apparentTemperature: 30,
          humidity: 52,
          windSpeed: 11,
          weatherCode: 1,
          precipitation: 0
        });
        setDaily([
          { date: new Date().toISOString().split('T')[0], tempMax: 31, tempMin: 18, precipProb: 10, precipSum: 0, windMax: 12, weatherCode: 1 },
          { date: new Date(Date.now() + 86400000).toISOString().split('T')[0], tempMax: 32, tempMin: 19, precipProb: 5, precipSum: 0, windMax: 10, weatherCode: 0 },
          { date: new Date(Date.now() + 172800000).toISOString().split('T')[0], tempMax: 30, tempMin: 17, precipProb: 20, precipSum: 0, windMax: 14, weatherCode: 2 }
        ]);
        setIsOfflineData(true);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeather(savedLoc);
  }, [savedLoc]);

  const handleSelectLocation = (loc: SavedLocation) => {
    setSavedLoc(loc);
    Storage.saveWeatherLocation(loc);
    setSearchResults([]);
    setSearchQuery('');
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchQuery.trim();
    if (!q) return;
    setIsSearching(true);
    try {
      const res = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=5&language=hi&format=json`
      );
      const data = await res.json();
      if (data.results && Array.isArray(data.results)) {
        const mapped: SavedLocation[] = data.results.map((item: any) => ({
          name: `${item.name}${item.admin2 ? `, ${item.admin2}` : ''}`,
          district: item.admin2 || item.admin1 || '',
          state: item.admin1 || item.country || '',
          lat: item.latitude,
          lon: item.longitude
        }));
        setSearchResults(mapped);
      } else {
        setSearchResults([]);
      }
    } catch {
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleUseGPS = () => {
    if (!navigator.geolocation) {
      setGpsStatus(isHindi ? 'जीपीएस उपलब्ध नहीं है' : 'GPS not supported');
      return;
    }
    setGpsStatus(isHindi ? 'लोकेशन खोजी जा रही है...' : 'Detecting GPS...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const newLoc: SavedLocation = {
          name: isHindi ? 'मेरा खेत (GPS लोकेशन)' : 'My Farm (GPS Location)',
          lat: pos.coords.latitude,
          lon: pos.coords.longitude
        };
        handleSelectLocation(newLoc);
        setGpsStatus('');
      },
      () => {
        setGpsStatus(isHindi ? 'GPS अनुमति नहीं मिली, नीचे से गांव चुनें' : 'GPS permission denied');
        setTimeout(() => setGpsStatus(''), 4000);
      }
    );
  };

  const spraySafe =
    current && current.windSpeed <= 15 && current.precipitation === 0 && (daily[0]?.precipProb || 0) < 40;

  return (
    <div className="max-w-5xl mx-auto pb-20 space-y-4">
      {/* Location & Search Card */}
      <div
        className={`liquid-glass-card rounded-2xl p-4 sm:p-5 space-y-3.5 ${
          isDark ? 'text-slate-100' : 'text-slate-900'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] font-extrabold text-emerald-800 dark:text-emerald-400">
                  {isHindi ? 'किसान मौसम केंद्र' : 'Farm Weather Station'}
                </span>
                {isOfflineData && (
                  <span className="px-2 py-0.5 rounded-md liquid-glass-amber text-amber-800 dark:text-amber-300 text-[10px] font-bold">
                    {isHindi ? 'ऑफलाइन सेव डेटा' : 'Offline Cached'}
                  </span>
                )}
              </div>
              <h2 className="text-base sm:text-lg font-extrabold mt-0.5">
                {savedLoc.name}
              </h2>
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                {savedLoc.district ? `${savedLoc.district}, ` : ''}
                {savedLoc.state || 'भारत'} {lastUpdated ? `• अपडेट: ${lastUpdated}` : ''}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleUseGPS}
              className="liquid-glass-profit px-3 py-1.5 rounded-xl text-blue-900 dark:text-blue-200 font-extrabold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Navigation className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400" />
              <span>{isHindi ? 'GPS लोकेशन' : 'Use GPS'}</span>
            </button>
            <button
              type="button"
              onClick={() => fetchWeather(savedLoc)}
              disabled={loading}
              className="btn-3d-primary px-3 py-1.5 rounded-xl text-white font-semibold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>{isHindi ? 'ताज़ा करें' : 'Refresh'}</span>
            </button>
          </div>
        </div>

        {gpsStatus && (
          <div className="liquid-glass-amber p-2.5 rounded-xl text-amber-900 dark:text-amber-200 text-xs font-bold">
            {gpsStatus}
          </div>
        )}

        {/* Quick Village/District Buttons */}
        <div className="space-y-1.5">
          <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300">
            {isHindi ? 'त्वरित क्षेत्र चुनें (Quick Select):' : 'Quick Select Area:'}
          </span>
          <div className="flex flex-wrap gap-1.5">
            {POPULAR_LOCATIONS.map((loc) => {
              const active = loc.name === savedLoc.name;
              return (
                <button
                  key={loc.name}
                  type="button"
                  onClick={() => handleSelectLocation(loc)}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                    active
                      ? 'btn-3d-primary text-white'
                      : 'liquid-glass-pill text-slate-800 dark:text-slate-100'
                  }`}
                >
                  {loc.name}
                </button>
              );
            })}
          </div>
        </div>

        {/* Search any city/village */}
        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                isHindi
                  ? 'अपना गांव, तहसील या जिला खोजें (जैसे Budaun, Bareilly)...'
                  : 'Search village, tehsil or district...'
              }
              className="w-full pl-9 pr-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
            />
          </div>
          <button
            type="submit"
            disabled={isSearching}
            className="btn-3d-primary px-4 py-2 rounded-xl text-white font-semibold text-xs sm:text-sm cursor-pointer shrink-0"
          >
            {isSearching ? (isHindi ? 'खोज...' : '...') : isHindi ? 'खोजें' : 'Search'}
          </button>
        </form>

        {searchResults.length > 0 && (
          <div className="liquid-glass-income p-3 rounded-xl space-y-2">
            <div className="text-xs font-bold text-emerald-900 dark:text-emerald-300">
              {isHindi ? 'नीचे से अपना स्थान चुनें:' : 'Select your location:'}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {searchResults.map((r, i) => (
                <button
                  key={`${r.lat}-${r.lon}-${i}`}
                  type="button"
                  onClick={() => handleSelectLocation(r)}
                  className="liquid-glass-subcard p-2.5 rounded-xl text-left flex items-center justify-between cursor-pointer"
                >
                  <div>
                    <div className="text-xs font-bold">{r.name}</div>
                    <div className="text-[11px] font-medium text-slate-600 dark:text-slate-300">{r.state}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[11px] font-semibold">
                    {isHindi ? 'चुनें' : 'Select'}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Current Weather + Spray & Irrigation Advisory */}
      {current && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Current Weather Card */}
          <div
            className={`liquid-glass-card lg:col-span-7 rounded-2xl p-4 sm:p-5 flex flex-col justify-between space-y-4 ${
              isDark ? 'text-slate-100' : 'text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between gap-3">
              <div>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md liquid-glass-amber text-amber-900 dark:text-amber-300 text-[11px] font-bold">
                  <ThermometerSun className="w-3.5 h-3.5 text-amber-600" />
                  {isHindi ? 'अभी का लाइव मौसम' : 'Current Live Weather'}
                </span>
                <div className="flex items-baseline gap-2.5 mt-2">
                  <span className="text-3xl sm:text-4xl font-extrabold font-mono">
                    {current.temperature}°C
                  </span>
                  <span className="text-xl">{getWeatherLabel(current.weatherCode).icon}</span>
                </div>
                <p className="text-xs sm:text-sm font-extrabold text-emerald-800 dark:text-emerald-400 mt-1">
                  {isHindi
                    ? getWeatherLabel(current.weatherCode).hi
                    : getWeatherLabel(current.weatherCode).en}
                </p>
                <p className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 mt-0.5">
                  {isHindi
                    ? `महसूस तापमान: ${current.apparentTemperature}°C`
                    : `Feels like: ${current.apparentTemperature}°C`}
                </p>
              </div>

              <div className="w-16 h-16 rounded-2xl liquid-glass-amber flex items-center justify-center text-3xl shrink-0">
                {getWeatherLabel(current.weatherCode).icon}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2.5 pt-3 border-t border-slate-200/70 dark:border-slate-700/70">
              <div className="liquid-glass-profit p-2.5 rounded-xl">
                <div className="flex items-center gap-1 text-[10px] font-bold text-blue-900 dark:text-blue-300">
                  <Wind className="w-3.5 h-3.5" />
                  <span>{isHindi ? 'हवा की गति' : 'Wind'}</span>
                </div>
                <div className="text-sm sm:text-base font-extrabold mt-0.5 font-mono">
                  {current.windSpeed} km/h
                </div>
              </div>

              <div className="liquid-glass-income p-2.5 rounded-xl">
                <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-900 dark:text-emerald-300">
                  <Droplets className="w-3.5 h-3.5" />
                  <span>{isHindi ? 'नमी' : 'Humidity'}</span>
                </div>
                <div className="text-sm sm:text-base font-extrabold mt-0.5 font-mono">
                  {current.humidity}%
                </div>
              </div>

              <div className="liquid-glass-amber p-2.5 rounded-xl">
                <div className="flex items-center gap-1 text-[10px] font-bold text-amber-900 dark:text-amber-300">
                  <CloudRain className="w-3.5 h-3.5" />
                  <span>{isHindi ? 'बारिश' : 'Rain'}</span>
                </div>
                <div className="text-sm sm:text-base font-extrabold mt-0.5 font-mono">
                  {daily[0]?.precipProb || 0}%
                </div>
              </div>
            </div>
          </div>

          {/* Spray & Farming Decision Advisory Card */}
          <div
            className={`liquid-glass-card lg:col-span-5 rounded-2xl p-4 sm:p-5 flex flex-col justify-between space-y-3 ${
              isDark ? 'text-slate-100' : 'text-slate-900'
            }`}
          >
            <div className="space-y-2.5">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl liquid-glass-income flex items-center justify-center text-emerald-800 dark:text-emerald-300">
                  <Sprout className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold">
                    {isHindi ? 'दवा स्प्रे और सिंचाई सलाह' : 'Spray & Irrigation Advisory'}
                  </h3>
                  <p className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">
                    {isHindi ? 'हवा व बारिश के अनुसार खेती का फैसला' : 'Based on live wind & rain'}
                  </p>
                </div>
              </div>

              <div
                className={`p-3 rounded-xl ${
                  spraySafe
                    ? 'liquid-glass-income text-emerald-950 dark:text-emerald-200'
                    : 'liquid-glass-expense text-rose-950 dark:text-rose-200'
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs sm:text-sm font-extrabold">
                  {spraySafe ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  <span>
                    {spraySafe
                      ? isHindi
                        ? 'स्प्रे के लिए मौसम अनुकूल है'
                        : 'Good Conditions for Spraying'
                      : isHindi
                      ? 'अभी दवा स्प्रे से बचें!'
                      : 'Avoid Spraying Right Now!'}
                  </span>
                </div>
                <p className="text-xs font-medium mt-1 leading-relaxed">
                  {spraySafe
                    ? isHindi
                      ? `हवा की गति सामान्य (${current.windSpeed} km/h) है और तेज बारिश का खतरा कम है। कीटनाशक या खाद का छिड़काव सुबह/शाम किया जा सकता है।`
                      : `Wind speed (${current.windSpeed} km/h) is calm and rain risk is low. Safe for foliar spray.`
                    : isHindi
                    ? `हवा तेज (${current.windSpeed} km/h) या बारिश की संभावना (${daily[0]?.precipProb || 0}%) होने से दवा उड़ या धुल सकती है।`
                    : `High wind (${current.windSpeed} km/h) or rain risk (${daily[0]?.precipProb || 0}%) may waste spray chemicals.`}
                </p>
              </div>

              <div className="liquid-glass-amber p-3 rounded-xl text-amber-950 dark:text-amber-200 space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-extrabold">
                  <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>{isHindi ? 'सिंचाई व कटाई सुझाव:' : 'Irrigation & Harvest Tip:'}</span>
                </div>
                <p className="text-xs font-medium leading-relaxed">
                  {(daily[0]?.precipProb || 0) > 50
                    ? isHindi
                      ? 'आज बारिश की संभावना अधिक है, इसलिए सिंचाई रोक दें और कटी हुई फसल को सुरक्षित रखें।'
                      : 'High chance of rain today. Delay irrigation and cover harvested grain.'
                    : isHindi
                    ? 'आने वाले दिनों में मौसम साफ रहने का अनुमान है। खेत की नमी जांचकर आवश्यकतानुसार सिंचाई या गुड़ाई करें।'
                    : 'Weather looks clear ahead. Proceed with scheduled irrigation or harvesting.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 7-Day Forecast Cards */}
      {daily.length > 0 && (
        <div
          className={`liquid-glass-card rounded-2xl p-4 sm:p-5 space-y-3 ${
            isDark ? 'text-slate-100' : 'text-slate-900'
          }`}
        >
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm sm:text-base font-extrabold">
              {isHindi ? 'आने वाले 7 दिनों का मौसम पूर्वानुमान' : '7-Day Farm Weather Forecast'}
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-2.5">
            {daily.map((day, idx) => {
              const dateObj = new Date(day.date);
              const dayName =
                idx === 0
                  ? isHindi
                    ? 'आज (Today)'
                    : 'Today'
                  : idx === 1
                  ? isHindi
                    ? 'कल (Tomorrow)'
                    : 'Tomorrow'
                  : dateObj.toLocaleDateString(isHindi ? 'hi-IN' : 'en-IN', {
                      weekday: 'short',
                      day: 'numeric',
                      month: 'short'
                    });
              const info = getWeatherLabel(day.weatherCode);

              return (
                <div
                  key={day.date}
                  className={`p-3 rounded-xl flex sm:flex-col justify-between items-center sm:items-start gap-1.5 ${
                    idx === 0 ? 'liquid-glass-income' : 'liquid-glass-subcard'
                  }`}
                >
                  <div>
                    <div className="text-xs font-extrabold">{dayName}</div>
                    <div className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">{info.hi}</div>
                  </div>

                  <div className="text-2xl my-0.5">{info.icon}</div>

                  <div className="text-right sm:text-left w-full">
                    <div className="text-xs sm:text-sm font-extrabold font-mono">
                      {day.tempMax}° <span className="text-slate-600 dark:text-slate-300 text-[11px]">/ {day.tempMin}°C</span>
                    </div>
                    <div className="flex items-center justify-end sm:justify-start gap-1.5 mt-1 text-[10px] font-bold">
                      <span className="px-1.5 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                        💧 {day.precipProb}%
                      </span>
                      <span className="text-slate-700 dark:text-slate-300">💨 {day.windMax}km/h</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
