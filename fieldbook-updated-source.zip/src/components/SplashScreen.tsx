import React, { useEffect, useState } from 'react';
import { ArrowRight, ShieldCheck, Sparkles, UserCheck } from 'lucide-react';
import { Language } from '../types';

interface SplashScreenProps {
  onDismiss: () => void;
  lang: Language;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onDismiss, lang }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [progress, setProgress] = useState(15);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => (prev < 100 ? prev + 17 : 100));
    }, 300);

    const timer = setTimeout(() => {
      handleClose();
    }, 2400);

    return () => {
      clearInterval(interval);
      clearTimeout(timer);
    };
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(onDismiss, 250);
  };

  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-between px-5 overflow-hidden transition-all duration-300 ${
        isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-105 pointer-events-none'
      }`}
      style={{
        background: 'linear-gradient(145deg, #011d16 0%, #022c22 45%, #064e3b 85%, #047857 100%)',
        paddingTop: 'calc(env(safe-area-inset-top, 16px) + 1.5rem)',
        paddingBottom: 'calc(env(safe-area-inset-bottom, 16px) + 1.5rem)'
      }}
    >
      {/* Ambient Background Glow */}
      <div className="absolute -top-28 -left-28 w-72 h-72 rounded-full bg-emerald-400/20 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-28 -right-28 w-72 h-72 rounded-full bg-amber-400/20 blur-3xl pointer-events-none" />

      {/* Top Tag */}
      <div className="relative z-10 flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/15 border border-white/25 backdrop-blur-xl shadow-md">
        <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" style={{ animationDuration: '5s' }} />
        <span className="text-xs font-bold tracking-wider uppercase text-white">
          {lang === 'hi' ? 'डिजिटल किसान डायरी और हिसाब' : 'Smart Digital Farm Ledger'}
        </span>
      </div>

      {/* Center Hero Logo & Branding */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-sm my-auto py-4">
        <div className="relative mb-5">
          <div className="absolute inset-0 rounded-3xl bg-emerald-400/35 blur-2xl animate-pulse" />
          <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-white/10 p-1.5 flex items-center justify-center shadow-2xl border border-white/30 backdrop-blur-xl overflow-hidden">
            <img
              src="/logo.png"
              alt="FieldBook By Mr Nikhil"
              className="w-full h-full object-contain rounded-2xl drop-shadow-md"
            />
          </div>
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-1.5 drop-shadow">
          Field<span className="text-amber-300">Book</span>
        </h1>

        <p className="text-xs sm:text-sm font-medium text-emerald-50 max-w-xs leading-relaxed mb-5">
          {lang === 'hi'
            ? 'खेत का पूरा हिसाब, मंडी भाव, मौसम अलर्ट और कृषि कैलकुलेटर — आपके अपने फोन में'
            : 'Complete crop accounting, mandi calculator, weather alerts & farm notes'}
        </p>

        {/* Creator Attribution Card */}
        <div className="w-full rounded-2xl bg-white/12 border border-white/25 backdrop-blur-xl px-5 py-3.5 shadow-xl mb-5">
          <div className="flex items-center justify-center gap-1.5 text-amber-300 text-[11px] font-bold uppercase tracking-widest mb-1">
            <UserCheck className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'निर्माता व डेवलपर' : 'Designed & Created By'}</span>
          </div>
          <p className="text-lg sm:text-xl font-extrabold text-white tracking-wide">
            By Mr. Nikhil
          </p>
          <div className="mt-2 pt-2 border-t border-white/15 flex items-center justify-center gap-1.5 text-xs font-medium text-emerald-100">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
            <span>{lang === 'hi' ? '100% सुरक्षित ऑफलाइन डेटा स्टोरेज' : '100% Safe Offline Data Storage'}</span>
          </div>
        </div>

        {/* Loading Progress Bar */}
        <div className="w-48 h-1.5 bg-black/40 rounded-full overflow-hidden border border-white/20">
          <div
            className="h-full bg-amber-400 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Bottom Enter Button */}
      <div className="relative z-10 w-full max-w-xs">
        <button
          type="button"
          onClick={handleClose}
          className="w-full py-3 px-5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer border border-amber-200"
        >
          <span>{lang === 'hi' ? 'ऐप खोलें (Enter App)' : 'Continue to FieldBook'}</span>
          <ArrowRight className="w-4 h-4 stroke-[2.5]" />
        </button>
      </div>
    </div>
  );
};
