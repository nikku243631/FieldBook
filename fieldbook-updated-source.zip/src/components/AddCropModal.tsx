import React, { useState, useEffect } from 'react';
import { X, Sprout, Calendar, MapPin, Tag, Sparkles, FileText, Layers, Repeat, Clock } from 'lucide-react';
import {
  CropCycle,
  CropSeason,
  CropAccountingType,
  CropCategory,
  AreaUnit,
  Language,
  Theme
} from '../types';
import { getTranslation } from '../utils/translations';
import {
  calculateCropTimeline,
  getCropCategoryLabel,
  getEffectiveCropAccountingType,
  getEffectiveCropCategory,
  suggestCropClassification
} from '../utils/calculations';

interface AddCropModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveCrop: (cropData: Partial<CropCycle>) => void;
  lang: Language;
  theme: Theme;
  cropToEdit?: CropCycle | null;
}

const COMMON_CROPS: {
  name: string;
  hindiName: string;
  season: CropSeason;
  icon: string;
  cropCategory: CropCategory;
  accountingType: CropAccountingType;
}[] = [
  { name: 'Wheat (गेहूं)', hindiName: 'गेहूं (Wheat)', season: 'rabi', icon: '🌾', cropCategory: 'grain', accountingType: 'one_time' },
  { name: 'Paddy / Rice (धान)', hindiName: 'धान (Paddy)', season: 'kharif', icon: '🌱', cropCategory: 'grain', accountingType: 'one_time' },
  { name: 'Mustard (सरसों)', hindiName: 'सरसों (Mustard)', season: 'rabi', icon: '🌼', cropCategory: 'oilseed', accountingType: 'one_time' },
  { name: 'Cotton (कपास)', hindiName: 'कपास (Cotton)', season: 'kharif', icon: '☁️', cropCategory: 'other', accountingType: 'one_time' },
  { name: 'Sugarcane (गन्ना)', hindiName: 'गन्ना (Sugarcane)', season: 'annual', icon: '🎋', cropCategory: 'other', accountingType: 'one_time' },
  { name: 'Potato (आलू)', hindiName: 'आलू (Potato)', season: 'rabi', icon: '🥔', cropCategory: 'vegetable', accountingType: 'one_time' },
  { name: 'Maize (मक्का)', hindiName: 'मक्का (Maize)', season: 'kharif', icon: '🌽', cropCategory: 'grain', accountingType: 'one_time' },
  { name: 'Gram / Chana (चना)', hindiName: 'चना (Gram)', season: 'rabi', icon: '🫘', cropCategory: 'pulse', accountingType: 'one_time' },
  { name: 'Soybean (सोयाबीन)', hindiName: 'सोयाबीन (Soybean)', season: 'kharif', icon: '🌿', cropCategory: 'oilseed', accountingType: 'one_time' },
  { name: 'Chilli (मिर्च)', hindiName: 'मिर्च (Chilli)', season: 'kharif', icon: '🌶️', cropCategory: 'vegetable', accountingType: 'recurring' },
  { name: 'Brinjal (बैंगन)', hindiName: 'बैंगन (Brinjal)', season: 'kharif', icon: '🍆', cropCategory: 'vegetable', accountingType: 'recurring' },
  { name: 'Vegetables (सब्जियां)', hindiName: 'सब्जियां (Vegetables)', season: 'zaid', icon: '🥬', cropCategory: 'vegetable', accountingType: 'recurring' }
];

const CROP_CATEGORIES: CropCategory[] = ['grain', 'vegetable', 'fruit', 'pulse', 'oilseed', 'other'];

export const AddCropModal: React.FC<AddCropModalProps> = ({
  isOpen,
  onClose,
  onSaveCrop,
  lang,
  cropToEdit
}) => {
  const [name, setName] = useState(cropToEdit?.name || '');
  const [hindiName, setHindiName] = useState(cropToEdit?.hindiName || '');
  const [variety, setVariety] = useState(cropToEdit?.variety || '');
  const [cropCategory, setCropCategory] = useState<CropCategory>(
    getEffectiveCropCategory(cropToEdit)
  );
  const [accountingType, setAccountingType] = useState<CropAccountingType>(
    getEffectiveCropAccountingType(cropToEdit)
  );
  const [manualCategorySelected, setManualCategorySelected] = useState<boolean>(Boolean(cropToEdit));
  const [manualHarvestTypeSelected, setManualHarvestTypeSelected] = useState<boolean>(
    Boolean(cropToEdit)
  );
  const [landArea, setLandArea] = useState<number | ''>(cropToEdit?.landArea ?? 2);
  const [areaUnit, setAreaUnit] = useState<AreaUnit>(cropToEdit?.areaUnit || 'acre');
  const [season, setSeason] = useState<CropSeason>(cropToEdit?.season || 'rabi');
  const [sowingDate, setSowingDate] = useState(
    cropToEdit?.sowingDate || new Date().toISOString().split('T')[0]
  );
  const [expectedHarvestDate, setExpectedHarvestDate] = useState(
    cropToEdit?.expectedHarvestDate || ''
  );
  const [targetYieldQuintal, setTargetYieldQuintal] = useState<number | ''>(
    cropToEdit?.targetYieldQuintal ?? ''
  );
  const [status, setStatus] = useState<CropCycle['status']>(cropToEdit?.status || 'active');
  const [notes, setNotes] = useState(cropToEdit?.notes || '');

  useEffect(() => {
    if (!isOpen) return;
    if (cropToEdit) {
      setName(cropToEdit.name || '');
      setHindiName(cropToEdit.hindiName || '');
      setVariety(cropToEdit.variety || '');
      setCropCategory(getEffectiveCropCategory(cropToEdit));
      setAccountingType(getEffectiveCropAccountingType(cropToEdit));
      setManualCategorySelected(true);
      setManualHarvestTypeSelected(true);
      setLandArea(cropToEdit.landArea ?? 2);
      setAreaUnit(cropToEdit.areaUnit || 'acre');
      setSeason(cropToEdit.season || 'rabi');
      setSowingDate(cropToEdit.sowingDate || new Date().toISOString().split('T')[0]);
      setExpectedHarvestDate(cropToEdit.expectedHarvestDate || '');
      setTargetYieldQuintal(cropToEdit.targetYieldQuintal ?? '');
      setStatus(cropToEdit.status || 'active');
      setNotes(cropToEdit.notes || '');
    } else {
      setName('');
      setHindiName('');
      setVariety('');
      setCropCategory('grain');
      setAccountingType('one_time');
      setManualCategorySelected(false);
      setManualHarvestTypeSelected(false);
      setLandArea(2);
      setAreaUnit('acre');
      setSeason('rabi');
      setSowingDate(new Date().toISOString().split('T')[0]);
      setExpectedHarvestDate('');
      setTargetYieldQuintal('');
      setStatus('active');
      setNotes('');
    }
  }, [isOpen, cropToEdit]);

  if (!isOpen) return null;

  const handleQuickCropSelect = (crop: (typeof COMMON_CROPS)[0]) => {
    setName(crop.name);
    setHindiName(crop.hindiName);
    setSeason(crop.season);
    setCropCategory(crop.cropCategory);
    setAccountingType(crop.accountingType);
    setManualCategorySelected(false);
    setManualHarvestTypeSelected(false);
  };

  const timelinePreview = calculateCropTimeline({
    sowingDate,
    expectedHarvestDate: expectedHarvestDate || undefined
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const cleanArea = Number(landArea);
    if (!Number.isFinite(cleanArea) || cleanArea <= 0) return;

    onSaveCrop({
      id: cropToEdit?.id,
      name: name.trim(),
      hindiName: hindiName.trim() || name.trim(),
      variety: variety.trim(),
      cropCategory,
      landArea: Number(cleanArea.toFixed(2)),
      areaUnit,
      season,
      accountingType,
      sowingDate,
      expectedHarvestDate: expectedHarvestDate || undefined,
      targetYieldQuintal:
        targetYieldQuintal && Number(targetYieldQuintal) > 0
          ? Number(targetYieldQuintal)
          : undefined,
      notes: notes.trim(),
      status
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/60 backdrop-blur-md overflow-y-auto">
      <div className="liquid-glass-modal w-full max-w-lg rounded-3xl p-4 sm:p-5 my-4 max-h-[92vh] overflow-y-auto">
        {/* 3D Liquid Glass Header Banner */}
        <div className="flex items-center justify-between pb-3.5 mb-3.5 border-b-2 border-emerald-500/30">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl liquid-glass-emerald flex items-center justify-center text-white shrink-0">
              <Sprout className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-950 dark:text-white leading-tight">
                {cropToEdit ? getTranslation(lang, 'editCrop') : getTranslation(lang, 'addCrop')}
              </h2>
              <p className="text-xs font-bold text-emerald-900 dark:text-emerald-300">
                {lang === 'hi'
                  ? '✍️ नीचे दिए गए रंगीन बॉक्स में फसल का विवरण भरें'
                  : '✍️ Fill crop details in the boxes below'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* Quick Pick Suggestions */}
          {!cropToEdit && (
            <div className="liquid-glass-income rounded-2xl p-3">
              <label className="text-xs font-extrabold text-emerald-950 dark:text-emerald-200 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-300" />
                <span>
                  {lang === 'hi'
                    ? 'जल्दी चुनें (1 टैप में फसल चुनें):'
                    : 'Quick Pick Common Crop (1-Tap):'}
                </span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {COMMON_CROPS.map((crop) => {
                  const isSelected = name === crop.name;
                  return (
                    <button
                      key={crop.name}
                      type="button"
                      onClick={() => handleQuickCropSelect(crop)}
                      className={`px-3 py-1.5 rounded-full text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1 ${
                        isSelected
                          ? 'liquid-glass-emerald text-white scale-105'
                          : 'bg-white/90 dark:bg-slate-900/90 border-2 border-emerald-500/70 text-slate-950 dark:text-white shadow-xs hover:bg-emerald-50'
                      }`}
                    >
                      <span>{crop.icon}</span>
                      <span>{lang === 'hi' ? crop.hindiName : crop.name.split(' (')[0]}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Section 1: Crop Name, Variety, Category & Harvest Type */}
          <div className="liquid-glass-profit rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5 mb-1.5">
                  <Sprout className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                  <span>{getTranslation(lang, 'cropName')} *</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => {
                    const val = e.target.value;
                    setName(val);
                    if (!hindiName || !cropToEdit) setHindiName(val);
                    if (!cropToEdit) {
                      const suggestion = suggestCropClassification(val);
                      if (suggestion.category && !manualCategorySelected) {
                        setCropCategory(suggestion.category);
                      }
                      if (suggestion.accountingType && !manualHarvestTypeSelected) {
                        setAccountingType(suggestion.accountingType);
                      }
                    }
                  }}
                  placeholder={lang === 'hi' ? 'जैसे: गेहूं, धान, मिर्च, बैंगन' : 'Type crop name (e.g. Wheat, Chilli)'}
                  className="liquid-glass-input w-full px-3.5 py-2.5 rounded-xl text-sm font-bold text-slate-950 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5 mb-1.5">
                  <Tag className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400" />
                  <span>{getTranslation(lang, 'cropVariety')}</span>
                </label>
                <input
                  type="text"
                  value={variety}
                  onChange={(e) => setVariety(e.target.value)}
                  placeholder={lang === 'hi' ? 'किस्म लिखें (जैसे: HD 2967)' : 'Type variety (e.g. HD 2967)'}
                  className="input-3d-sky w-full px-3.5 py-2.5 rounded-xl text-sm font-bold text-slate-950 dark:text-white"
                />
              </div>
            </div>

            {/* Crop Category Selector (Separate from Harvest Type) */}
            <div>
              <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                🌿 {lang === 'hi' ? 'फसल की श्रेणी (Crop Category)' : 'Crop Category'}
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                {CROP_CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => {
                      setCropCategory(cat);
                      setManualCategorySelected(true);
                    }}
                    className={`px-2 py-2 rounded-xl text-xs font-extrabold text-center transition-all cursor-pointer border ${
                      cropCategory === cat
                        ? 'liquid-glass-emerald text-white border-emerald-400 shadow-2xs'
                        : 'bg-white/85 dark:bg-slate-900/85 text-slate-900 dark:text-slate-100 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    {getCropCategoryLabel(cat, lang)}
                  </button>
                ))}
              </div>
            </div>

            {/* Harvest Type: Single Harvest vs Repeated Harvest */}
            <div className="pt-1">
              <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5 mb-1.5">
                <Repeat className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400" />
                <span>
                  {lang === 'hi'
                    ? 'कटाई / तुड़ाई का प्रकार (Harvest Type)'
                    : 'Harvest Type'}
                </span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setAccountingType('one_time');
                    setManualHarvestTypeSelected(true);
                  }}
                  className={`p-2.5 rounded-xl text-left transition-all cursor-pointer border ${
                    accountingType === 'one_time'
                      ? 'liquid-glass-emerald text-white border-emerald-400 shadow-xs'
                      : 'bg-white/85 dark:bg-slate-900/85 text-slate-900 dark:text-slate-100 border-slate-300 dark:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-extrabold flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 shrink-0" />
                    <span>
                      {lang === 'hi'
                        ? '1. एक बार कटाई (Single Harvest)'
                        : '1. Single Harvest'}
                    </span>
                  </div>
                  <p
                    className={`text-[11px] font-semibold mt-0.5 leading-snug ${
                      accountingType === 'one_time'
                        ? 'text-emerald-50'
                        : 'text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {lang === 'hi'
                      ? 'जैसे: गेहूं, धान, सरसों, चना, आलू'
                      : 'Examples: Wheat, Paddy, Mustard, Gram, Potato'}
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setAccountingType('recurring');
                    setManualHarvestTypeSelected(true);
                  }}
                  className={`p-2.5 rounded-xl text-left transition-all cursor-pointer border ${
                    accountingType === 'recurring'
                      ? 'liquid-glass-emerald text-white border-emerald-400 shadow-xs'
                      : 'bg-white/85 dark:bg-slate-900/85 text-slate-900 dark:text-slate-100 border-slate-300 dark:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-extrabold flex items-center gap-1.5">
                    <Repeat className="w-3.5 h-3.5 shrink-0" />
                    <span>
                      {lang === 'hi'
                        ? '2. बार-बार तुड़ाई (Repeated Harvest)'
                        : '2. Repeated Harvest'}
                    </span>
                  </div>
                  <p
                    className={`text-[11px] font-semibold mt-0.5 leading-snug ${
                      accountingType === 'recurring'
                        ? 'text-emerald-50'
                        : 'text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {lang === 'hi'
                      ? 'जैसे: बैंगन, मिर्च, टमाटर, भिंडी व अन्य सब्जियां'
                      : 'Examples: Brinjal, Chilli, Tomato & Vegetables'}
                  </p>
                </button>
              </div>
            </div>

            {/* Land Area & Area Unit */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-amber-950 dark:text-amber-300 flex items-center gap-1 mb-1.5">
                  <MapPin className="w-3.5 h-3.5 text-amber-700 dark:text-amber-400" />
                  <span>{getTranslation(lang, 'landArea')} *</span>
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  required
                  value={landArea}
                  onChange={(e) =>
                    setLandArea(e.target.value === '' ? '' : parseFloat(e.target.value))
                  }
                  placeholder="2.5"
                  className="input-3d-amber w-full px-3.5 py-2.5 rounded-xl text-sm font-mono font-extrabold tabular-nums text-slate-950 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-amber-950 dark:text-amber-300 block mb-1.5">
                  📐 {getTranslation(lang, 'areaUnit')}
                </label>
                <select
                  value={areaUnit}
                  onChange={(e) => setAreaUnit(e.target.value as AreaUnit)}
                  className="input-3d-amber w-full px-3 py-2.5 rounded-xl text-sm font-extrabold text-slate-950 dark:text-white"
                >
                  <option value="acre">{getTranslation(lang, 'acre')}</option>
                  <option value="bigha">{getTranslation(lang, 'bigha')}</option>
                  <option value="hectare">{getTranslation(lang, 'hectare')}</option>
                  <option value="kanal">{getTranslation(lang, 'kanal')}</option>
                  <option value="marla">{getTranslation(lang, 'marla')}</option>
                  <option value="guntha">{getTranslation(lang, 'guntha')}</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 2: Season, Sowing/Transplanting Date, Expected First Harvest Date & Crop Age Preview */}
          <div className="liquid-glass-income rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-emerald-950 dark:text-emerald-200 block mb-1.5">
                  🌤️ {getTranslation(lang, 'season')}
                </label>
                <select
                  value={season}
                  onChange={(e) => setSeason(e.target.value as CropSeason)}
                  className="liquid-glass-input w-full px-3 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white"
                >
                  <option value="rabi">रबी (Rabi - गेहूं/सरसों/चना)</option>
                  <option value="kharif">खरीफ (Kharif - धान/कपास/बाजरा)</option>
                  <option value="zaid">जायद (Zaid - तरबूज/सब्जियां)</option>
                  <option value="annual">वार्षिक (Annual - गन्ना)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-extrabold text-emerald-950 dark:text-emerald-200 flex items-center gap-1 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  <span>
                    {lang === 'hi'
                      ? 'बुवाई / रोपाई की तारीख (Sowing Date) *'
                      : 'Sowing / Transplantation Date *'}
                  </span>
                </label>
                <input
                  type="date"
                  required
                  value={sowingDate}
                  onChange={(e) => setSowingDate(e.target.value)}
                  className="liquid-glass-input w-full px-3 py-2.5 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums text-slate-950 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  📅{' '}
                  {lang === 'hi'
                    ? 'अनुमानित पहली कटाई तारीख'
                    : 'Expected First Harvest Date'}
                </label>
                <input
                  type="date"
                  value={expectedHarvestDate}
                  onChange={(e) => setExpectedHarvestDate(e.target.value)}
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-bold tabular-nums text-slate-950 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  🎯 {getTranslation(lang, 'targetYield')}
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  value={targetYieldQuintal}
                  onChange={(e) =>
                    setTargetYieldQuintal(e.target.value === '' ? '' : parseFloat(e.target.value))
                  }
                  placeholder={lang === 'hi' ? 'उदा. 50 क्विंटल' : 'e.g. 50'}
                  className="input-3d-amber w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums text-slate-950 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  📌 {getTranslation(lang, 'status')}
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as CropCycle['status'])}
                  className="liquid-glass-input w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white"
                >
                  <option value="active">{getTranslation(lang, 'active')}</option>
                  <option value="harvested">{getTranslation(lang, 'harvested')}</option>
                  <option value="archived">{getTranslation(lang, 'archived')}</option>
                </select>
              </div>
            </div>

            {/* Live Crop Age & Remaining Days Summary Strip */}
            <div className="p-2.5 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-emerald-500/40 flex flex-wrap items-center justify-between gap-2 text-xs font-bold">
              <div className="flex items-center gap-1.5 text-emerald-900 dark:text-emerald-300">
                <Clock className="w-3.5 h-3.5 shrink-0" />
                <span>
                  {lang === 'hi' ? 'फसल की वर्तमान उम्र:' : 'Current Crop Age:'}{' '}
                  <strong className="font-mono font-black">
                    {timelinePreview.cropAgeDays} {lang === 'hi' ? 'दिन (days)' : 'days'}
                  </strong>
                </span>
              </div>

              {timelinePreview.expectedHarvestDate && (
                <div className="font-semibold">
                  {timelinePreview.isHarvestDatePassed ? (
                    <span className="text-amber-800 dark:text-amber-300 font-bold">
                      {lang === 'hi'
                        ? 'अनुमानित कटाई की तारीख निकल चुकी है (Expected harvest date has passed.)'
                        : 'Expected harvest date has passed.'}
                    </span>
                  ) : timelinePreview.isHarvestDateToday ? (
                    <span className="text-blue-800 dark:text-blue-300 font-bold">
                      {lang === 'hi'
                        ? 'अनुमानित कटाई आज है (0 दिन बाकी)'
                        : 'Expected harvest date is today (0 days remaining)'}
                    </span>
                  ) : (
                    <span className="text-blue-900 dark:text-blue-300 font-bold">
                      {lang === 'hi' ? 'कटाई में अनुमानित बाकी दिन:' : 'Approx. days until harvest:'}{' '}
                      <strong className="font-mono font-black">
                        {timelinePreview.daysRemainingUntilHarvest}{' '}
                        {lang === 'hi' ? 'दिन' : 'days'}
                      </strong>
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Notes */}
          <div className="liquid-glass-profit rounded-2xl p-3">
            <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5 mb-1.5">
              <FileText className="w-3.5 h-3.5 text-blue-700" />
              <span>{getTranslation(lang, 'notes')}</span>
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={
                lang === 'hi'
                  ? 'खेत का नाम/स्थान, मिट्टी की किस्म, या विशेष नोट यहां लिखें...'
                  : 'Type field location, soil details, or special notes here...'
              }
              className="input-3d-sky w-full px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold text-slate-950 dark:text-white resize-none"
            />
          </div>

          {/* Bottom 3D Liquid Glass Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="liquid-glass-pill px-5 py-2.5 rounded-full text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className="liquid-glass-emerald px-6 py-2.5 rounded-full text-white font-extrabold text-xs sm:text-sm cursor-pointer shadow-md"
            >
              ✓ {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

