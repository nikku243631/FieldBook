import { FarmNote, Language } from '../types';

const FIRED_REMINDERS_STORAGE_KEY = 'kisan_fired_reminders_v1';
const SCHEDULED_NATIVE_ALARMS_KEY = 'kisan_scheduled_native_alarms_v1';

interface AndroidReminderBridge {
  requestNotificationPermission?: () => boolean;
  scheduleReminderAlarm?: (
    noteId: string,
    title: string,
    body: string,
    triggerAtMillis: number
  ) => boolean;
  cancelReminderAlarm?: (noteId: string) => boolean;
  triggerImmediateReminderNotification?: (
    noteId: string,
    title: string,
    body: string
  ) => boolean;
}

function getAndroidBridge(): AndroidReminderBridge | null {
  if (typeof window === 'undefined') return null;
  const win = window as unknown as { AndroidBridge?: AndroidReminderBridge };
  return win.AndroidBridge || null;
}

export interface TriggeredReminderAlarm {
  note: FarmNote;
  triggeredAt: string;
}

function getFiredMap(): Record<string, string> {
  try {
    const raw = localStorage.getItem(FIRED_REMINDERS_STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Record<string, string>;
  } catch {
    return {};
  }
}

function markReminderFired(note: FarmNote): void {
  try {
    const map = getFiredMap();
    const signature = `${note.date}T${note.time}`;
    map[note.id] = signature;
    localStorage.setItem(FIRED_REMINDERS_STORAGE_KEY, JSON.stringify(map));
  } catch {
    // Ignore storage quota errors
  }
}

export function hasReminderAlreadyFired(note: FarmNote): boolean {
  const map = getFiredMap();
  const signature = `${note.date}T${note.time}`;
  return map[note.id] === signature;
}

/**
 * Request notification permission when user adds/saves a reminder (both Native Android 13+ and Web).
 */
export async function requestReminderNotificationPermission(): Promise<boolean> {
  try {
    const bridge = getAndroidBridge();
    if (bridge && typeof bridge.requestNotificationPermission === 'function') {
      bridge.requestNotificationPermission();
    }
  } catch {
    // Ignore native bridge error
  }

  try {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return false;
    }
    if (Notification.permission === 'granted') {
      return true;
    }
    if (Notification.permission !== 'denied') {
      const result = await Notification.requestPermission();
      return result === 'granted';
    }
    return false;
  } catch {
    return false;
  }
}

/**
 * Synchronize saved reminder notes with native Android AlarmManager so alarms and
 * lock-screen notifications fire reliably at the selected date & time even when the app is closed.
 */
export function syncNativeAndroidReminderAlarms(notes: FarmNote[], lang: Language): void {
  const bridge = getAndroidBridge();
  if (!bridge || typeof bridge.scheduleReminderAlarm !== 'function') {
    return;
  }

  try {
    const nowMs = Date.now();
    const prevRaw = localStorage.getItem(SCHEDULED_NATIVE_ALARMS_KEY);
    const prevMap: Record<string, string> = prevRaw ? JSON.parse(prevRaw) : {};
    const nextMap: Record<string, string> = {};

    for (const note of notes) {
      if (!note || note.category !== 'reminder' || !note.date || !note.time) {
        continue;
      }

      const scheduledMs = new Date(`${note.date}T${note.time}:00`).getTime();
      if (!Number.isFinite(scheduledMs)) {
        continue;
      }

      const signature = `${note.date}T${note.time}|${note.title}|${note.content}`;
      // Schedule future reminders (or reminders due within the next few seconds)
      if (scheduledMs > nowMs - 15000 && !hasReminderAlreadyFired(note)) {
        nextMap[note.id] = signature;
        if (prevMap[note.id] !== signature) {
          const title =
            lang === 'hi'
              ? `⏰ खेत रिमाइंडर: ${note.title}`
              : `⏰ Farm Reminder: ${note.title}`;
          const body = note.content
            ? `${note.content} (${note.date} • ${note.time})`
            : `${note.date} • ${note.time}`;
          bridge.scheduleReminderAlarm(note.id, title, body, scheduledMs);
        }
      }
    }

    // Cancel any previously scheduled native alarms that were deleted or changed
    if (typeof bridge.cancelReminderAlarm === 'function') {
      for (const oldNoteId of Object.keys(prevMap)) {
        if (!nextMap[oldNoteId]) {
          bridge.cancelReminderAlarm(oldNoteId);
        }
      }
    }

    localStorage.setItem(SCHEDULED_NATIVE_ALARMS_KEY, JSON.stringify(nextMap));
  } catch {
    // Ignore storage or bridge errors
  }
}

/**
 * Play a clear two-tone agricultural reminder alarm chime + vibration
 */
export function playReminderAlarmSound(): void {
  try {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate([300, 150, 300, 150, 500]);
    }
  } catch {
    // Ignore if vibration is unsupported
  }

  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const frequencies = [880, 1108.73, 1318.51, 880, 1318.51];
    frequencies.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      const startTime = now + idx * 0.22;
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.18, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.19);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + 0.2);
    });
  } catch {
    // Ignore audio context autoplay restrictions
  }
}

/**
 * Dispatch a high-priority system / ServiceWorker / Native Android notification
 * visible on the lock screen when Android permissions allow.
 */
export async function dispatchSystemReminderNotification(
  note: FarmNote,
  lang: Language
): Promise<void> {
  const title =
    lang === 'hi'
      ? `⏰ खेत रिमाइंडर: ${note.title}`
      : `⏰ Farm Reminder: ${note.title}`;
  const body = note.content
    ? `${note.content} (${note.date} • ${note.time})`
    : `${note.date} • ${note.time}`;

  // 1. If running inside the Android APK, also trigger the native high-priority notification channel
  try {
    const bridge = getAndroidBridge();
    if (bridge && typeof bridge.triggerImmediateReminderNotification === 'function') {
      bridge.triggerImmediateReminderNotification(note.id, title, body);
    }
  } catch {
    // Ignore native bridge error
  }

  // 2. Dispatch via ServiceWorker / Web Notification API
  try {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'default') {
        await Notification.requestPermission();
      }

      if (Notification.permission === 'granted') {
        if ('serviceWorker' in navigator) {
          const registration = await navigator.serviceWorker.getRegistration();
          if (registration && typeof registration.showNotification === 'function') {
            await registration.showNotification(title, {
              body,
              icon: '/logo.png',
              badge: '/logo.png',
              tag: `fieldbook-reminder-${note.id}-${note.date}-${note.time}`,
              requireInteraction: true,
              vibrate: [300, 150, 300, 150, 500],
              data: { noteId: note.id, date: note.date, time: note.time }
            } as NotificationOptions);
            return;
          }
        }

        // Fallback to standard Notification API
        new Notification(title, {
          body,
          icon: '/logo.png',
          tag: `fieldbook-reminder-${note.id}-${note.date}-${note.time}`,
          requireInteraction: true
        });
      }
    }
  } catch {
    // Ignore if system notifications are blocked
  }
}

/**
 * Evaluate all saved reminder notes and return any due reminders that should trigger now.
 */
export function checkDueReminders(notes: FarmNote[]): FarmNote[] {
  const now = new Date();
  const nowMs = now.getTime();
  const dueNotes: FarmNote[] = [];

  for (const note of notes) {
    if (!note || note.category !== 'reminder' || !note.date || !note.time) {
      continue;
    }

    if (hasReminderAlreadyFired(note)) {
      continue;
    }

    const scheduledMs = new Date(`${note.date}T${note.time}:00`).getTime();
    if (!Number.isFinite(scheduledMs)) {
      continue;
    }

    // Trigger when current time reaches the scheduled minute (within a 24-hour window so recent missed reminders still alert when opening app)
    const diffMs = nowMs - scheduledMs;
    if (diffMs >= 0 && diffMs <= 24 * 60 * 60 * 1000) {
      markReminderFired(note);
      dueNotes.push(note);
    }
  }

  return dueNotes;
}
