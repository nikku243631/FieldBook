# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# Preserve @JavascriptInterface methods on FieldBook's native bridge
-keepattributes *Annotation*,JavascriptInterface
-keepclassmembers class com.fieldbook.kisan.MainActivity$AndroidNativeBridge {
    @android.webkit.JavascriptInterface <methods>;
    public *;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Preserve Capacitor Bridge and Plugin classes
-keep class com.getcapacitor.** { *; }
-keep class com.fieldbook.kisan.** { *; }
-keepattributes SourceFile,LineNumberTable

