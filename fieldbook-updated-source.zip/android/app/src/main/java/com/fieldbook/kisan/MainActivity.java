package com.fieldbook.kisan;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends BridgeActivity {
    private static final int REQ_POST_NOTIFICATIONS = 1009;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestNotificationPermissionIfNeeded();

        if (this.bridge != null && this.bridge.getWebView() != null) {
            WebView webView = this.bridge.getWebView();
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);

            // Register Native Android Bridge for WhatsApp Sharing, PDF/CSV/JSON Saving & Native Alarm Reminders
            webView.addJavascriptInterface(new AndroidNativeBridge(this), "AndroidBridge");
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(
                            this,
                            new String[]{Manifest.permission.POST_NOTIFICATIONS},
                            REQ_POST_NOTIFICATIONS
                    );
                }
            }
        } catch (Exception ignored) {
        }
    }

    public class AndroidNativeBridge {
        private final MainActivity activity;

        public AndroidNativeBridge(MainActivity activity) {
            this.activity = activity;
        }

        @JavascriptInterface
        public boolean requestNotificationPermission() {
            try {
                if (Build.VERSION.SDK_INT >= 33) {
                    if (ContextCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED) {
                        activity.runOnUiThread(activity::requestNotificationPermissionIfNeeded);
                        return false;
                    }
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        /**
         * Schedule an exact native Android AlarmManager reminder that triggers ReminderAlarmReceiver
         * at the selected date & time (even if the app is minimized or on the lock screen).
         */
        @JavascriptInterface
        public boolean scheduleReminderAlarm(String noteId, String title, String body, long triggerAtMillis) {
            try {
                if (noteId == null || noteId.trim().isEmpty()) {
                    return false;
                }
                AlarmManager alarmManager = (AlarmManager) activity.getSystemService(Context.ALARM_SERVICE);
                if (alarmManager == null) {
                    return false;
                }

                Intent intent = new Intent(activity, ReminderAlarmReceiver.class);
                intent.putExtra(ReminderAlarmReceiver.EXTRA_NOTE_ID, noteId);
                intent.putExtra(ReminderAlarmReceiver.EXTRA_TITLE, title);
                intent.putExtra(ReminderAlarmReceiver.EXTRA_BODY, body);

                int requestCode = Math.abs(noteId.hashCode());
                int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    flags |= PendingIntent.FLAG_IMMUTABLE;
                }

                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                        activity,
                        requestCode,
                        intent,
                        flags
                );

                long safeTriggerMs = Math.max(triggerAtMillis, System.currentTimeMillis() + 1000L);

                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTriggerMs, pendingIntent);
                    } else {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP, safeTriggerMs, pendingIntent);
                    }
                } catch (SecurityException se) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTriggerMs, pendingIntent);
                    } else {
                        alarmManager.set(AlarmManager.RTC_WAKEUP, safeTriggerMs, pendingIntent);
                    }
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        /**
         * Cancel a previously scheduled native Android reminder alarm.
         */
        @JavascriptInterface
        public boolean cancelReminderAlarm(String noteId) {
            try {
                if (noteId == null || noteId.trim().isEmpty()) {
                    return false;
                }
                AlarmManager alarmManager = (AlarmManager) activity.getSystemService(Context.ALARM_SERVICE);
                if (alarmManager == null) {
                    return false;
                }
                Intent intent = new Intent(activity, ReminderAlarmReceiver.class);
                int requestCode = Math.abs(noteId.hashCode());
                int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    flags |= PendingIntent.FLAG_IMMUTABLE;
                }
                PendingIntent pendingIntent = PendingIntent.getBroadcast(activity, requestCode, intent, flags);
                alarmManager.cancel(pendingIntent);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        /**
         * Dispatch an immediate high-priority Android notification + alarm sound/vibration.
         */
        @JavascriptInterface
        public boolean triggerImmediateReminderNotification(String noteId, String title, String body) {
            try {
                Intent intent = new Intent(activity, ReminderAlarmReceiver.class);
                intent.putExtra(ReminderAlarmReceiver.EXTRA_NOTE_ID, noteId);
                intent.putExtra(ReminderAlarmReceiver.EXTRA_TITLE, title);
                intent.putExtra(ReminderAlarmReceiver.EXTRA_BODY, body);
                activity.sendBroadcast(intent);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        /**
         * Share text directly to WhatsApp or Android Share Sheet without WebView URL errors
         */
        @JavascriptInterface
        public boolean shareText(String text, String title) {
            try {
                Intent sendIntent = new Intent(Intent.ACTION_SEND);
                sendIntent.setType("text/plain");
                sendIntent.putExtra(Intent.EXTRA_TEXT, text);
                if (title != null && !title.isEmpty()) {
                    sendIntent.putExtra(Intent.EXTRA_SUBJECT, title);
                }
                Intent chooser = Intent.createChooser(sendIntent, title != null && !title.isEmpty() ? title : "Share FieldBook Report");
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(chooser);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        /**
         * Save text file (CSV, JSON, HTML) to Android Downloads folder and open Share/View sheet
         */
        @JavascriptInterface
        public boolean saveAndShareFile(String content, String fileName, String mimeType) {
            try {
                byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
                return saveBytesAndShareInternal(bytes, fileName, mimeType);
            } catch (Exception e) {
                activity.runOnUiThread(() ->
                    Toast.makeText(activity, "फाइल सेव करने में त्रुटि: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
                return false;
            }
        }

        /**
         * Save binary file (such as real .PDF report) encoded as Base64 to Android Downloads and open Share/View sheet
         */
        @JavascriptInterface
        public boolean saveBase64File(String base64Data, String fileName, String mimeType) {
            try {
                String cleanBase64 = base64Data;
                int commaIndex = base64Data.indexOf(',');
                if (commaIndex != -1) {
                    cleanBase64 = base64Data.substring(commaIndex + 1);
                }
                byte[] bytes = Base64.decode(cleanBase64, Base64.DEFAULT);
                return saveBytesAndShareInternal(bytes, fileName, mimeType);
            } catch (Exception e) {
                activity.runOnUiThread(() ->
                    Toast.makeText(activity, "PDF सेव करने में त्रुटि: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
                return false;
            }
        }

        private boolean saveBytesAndShareInternal(byte[] bytes, String fileName, String mimeType) {
            try {
                String resolvedMime = (mimeType != null && !mimeType.isEmpty()) ? mimeType : "application/octet-stream";

                // 1. Save a permanent copy in public Android Downloads folder (Android 10+ MediaStore)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    try {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                        values.put(MediaStore.MediaColumns.MIME_TYPE, resolvedMime);
                        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FieldBook");
                        ContentResolver resolver = activity.getContentResolver();
                        Uri downloadUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (downloadUri != null) {
                            try (OutputStream os = resolver.openOutputStream(downloadUri)) {
                                if (os != null) {
                                    os.write(bytes);
                                    os.flush();
                                }
                            }
                        }
                    } catch (Exception ignored) {
                        // Fallback to cache share below if MediaStore fails on custom ROMs
                    }
                }

                // 2. Also write to cache directory and trigger Android Share / Open sheet via FileProvider
                File exportDir = new File(activity.getCacheDir(), "exports");
                if (!exportDir.exists()) {
                    exportDir.mkdirs();
                }
                File outFile = new File(exportDir, fileName);
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(bytes);
                    fos.flush();
                }

                Uri contentUri = FileProvider.getUriForFile(
                    activity,
                    activity.getPackageName() + ".fileprovider",
                    outFile
                );

                // For JSON backup files, save directly to Downloads without forcing an external JSON viewer popup
                boolean isJsonBackup = fileName.toLowerCase().endsWith(".json");

                activity.runOnUiThread(() -> {
                    if (isJsonBackup) {
                        Toast.makeText(
                            activity,
                            "✅ बैकअप फाइल सेव हो गई: Downloads/FieldBook/" + fileName,
                            Toast.LENGTH_LONG
                        ).show();
                    } else {
                        Toast.makeText(
                            activity,
                            "✅ फाइल डाउनलोड हो गई: Downloads/FieldBook/" + fileName,
                            Toast.LENGTH_LONG
                        ).show();

                        try {
                            Intent shareIntent = new Intent(Intent.ACTION_SEND);
                            shareIntent.setType(resolvedMime);
                            shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                            shareIntent.setClipData(ClipData.newRawUri(fileName, contentUri));
                            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                            Intent chooser = Intent.createChooser(shareIntent, fileName);
                            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            activity.startActivity(chooser);
                        } catch (Exception ignored) {
                        }
                    }
                });

                return true;
            } catch (Exception e) {
                activity.runOnUiThread(() ->
                    Toast.makeText(activity, "फाइल सेव करने में त्रुटि: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
                return false;
            }
        }

        /**
         * Trigger Native Android System Print / Save as PDF Dialog
         */
        @JavascriptInterface
        public boolean printCurrentPage(String jobName) {
            activity.runOnUiThread(() -> {
                try {
                    if (activity.bridge != null && activity.bridge.getWebView() != null) {
                        android.print.PrintManager printManager =
                            (android.print.PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                        String docName = (jobName != null && !jobName.isEmpty()) ? jobName : "FieldBook_Report";
                        android.print.PrintDocumentAdapter printAdapter =
                            activity.bridge.getWebView().createPrintDocumentAdapter(docName);
                        if (printManager != null) {
                            printManager.print(docName, printAdapter, new android.print.PrintAttributes.Builder().build());
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(activity, "प्रिंट सेवा उपलब्ध नहीं है: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
            return true;
        }
    }
}
