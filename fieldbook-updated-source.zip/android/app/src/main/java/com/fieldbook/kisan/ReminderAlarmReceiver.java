package com.fieldbook.kisan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;

/**
 * Native Android BroadcastReceiver triggered by AlarmManager at the exact
 * date and time selected by the farmer in FieldBook Reminders.
 * Displays a high-priority notification with sound & vibration, visible on the lock screen.
 */
public class ReminderAlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "fieldbook_farm_reminders_v1";
    public static final String EXTRA_NOTE_ID = "noteId";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_BODY = "body";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) {
            return;
        }

        String noteId = intent.getStringExtra(EXTRA_NOTE_ID);
        String title = intent.getStringExtra(EXTRA_TITLE);
        String body = intent.getStringExtra(EXTRA_BODY);

        if (title == null || title.trim().isEmpty()) {
            title = "⏰ FieldBook खेत रिमाइंडर";
        }
        if (body == null || body.trim().isEmpty()) {
            body = "आपके खेत कार्य का समय हो गया है।";
        }

        NotificationManager notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager == null) {
            return;
        }

        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (alarmSound == null) {
            alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "FieldBook Farm Reminders & Alarms",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Scheduled farm reminders, irrigation alerts, and mandi payment alarms");
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 350, 150, 350, 150, 500});
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            if (alarmSound != null) {
                AudioAttributes audioAttributes = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();
                channel.setSound(alarmSound, audioAttributes);
            }
            notificationManager.createNotificationChannel(channel);
        }

        Intent launchIntent = new Intent(context, MainActivity.class);
        launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (noteId != null) {
            launchIntent.putExtra(EXTRA_NOTE_ID, noteId);
        }

        int requestCode = noteId != null ? Math.abs(noteId.hashCode()) : (int) (System.currentTimeMillis() & 0xfffffff);
        int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
        }

        PendingIntent contentPendingIntent = PendingIntent.getActivity(
                context,
                requestCode,
                launchIntent,
                pendingFlags
        );

        int smallIcon = context.getApplicationInfo().icon;
        if (smallIcon == 0) {
            smallIcon = android.R.drawable.ic_lock_idle_alarm;
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(smallIcon)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setVibrate(new long[]{0, 350, 150, 350, 150, 500})
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setContentIntent(contentPendingIntent);

        if (alarmSound != null) {
            builder.setSound(alarmSound);
        }

        notificationManager.notify(requestCode, builder.build());
    }
}
