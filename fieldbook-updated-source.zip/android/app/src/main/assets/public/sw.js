/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "0d1bc1c80fde4df60d85e53a233ec9a7"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e72ba9fca3cdcbe274286fa0a42cba96"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f2321851d8cc83a93a6ae9666657751f"
  }, {
    "url": "logo.png",
    "revision": "e72ba9fca3cdcbe274286fa0a42cba96"
  }, {
    "url": "index.html",
    "revision": "60a1965d6e978482db7d71cf2e26db52"
  }, {
    "url": "icon.svg",
    "revision": "9fa8396e6dfdd0e1aa84caf132014edb"
  }, {
    "url": "favicon.ico",
    "revision": "18590afee9a6cbfbad204528dacdeaf8"
  }, {
    "url": "farm-bg.jpg",
    "revision": "b6b7c3a2e030cd87630ef7d7c78e255a"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "18e597183d3bd23d8febaaa6dada9584"
  }, {
    "url": "FieldBook-Features-Guide.html",
    "revision": "db566fed49428c0d7656cea4e5450ede"
  }, {
    "url": "assets/web-CGBBIMis.js",
    "revision": null
  }, {
    "url": "assets/index-aFLzoHq6.css",
    "revision": null
  }, {
    "url": "assets/index-QvMTqBuT.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "18e597183d3bd23d8febaaa6dada9584"
  }, {
    "url": "farm-bg.jpg",
    "revision": "b6b7c3a2e030cd87630ef7d7c78e255a"
  }, {
    "url": "favicon.ico",
    "revision": "18590afee9a6cbfbad204528dacdeaf8"
  }, {
    "url": "icon.svg",
    "revision": "9fa8396e6dfdd0e1aa84caf132014edb"
  }, {
    "url": "logo.png",
    "revision": "e72ba9fca3cdcbe274286fa0a42cba96"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f2321851d8cc83a93a6ae9666657751f"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e72ba9fca3cdcbe274286fa0a42cba96"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "0d1bc1c80fde4df60d85e53a233ec9a7"
  }, {
    "url": "manifest.webmanifest",
    "revision": "b7b2eac79f0fdbd27938ba72e7819958"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
