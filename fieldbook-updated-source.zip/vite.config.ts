import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'icon.svg', 'logo.png', 'farm-bg.jpg'],
        manifest: {
          id: '/',
          name: 'FieldBook - Digital Khet Ledger By Mr Nikhil',
          short_name: 'FieldBook',
          description: 'Offline-first digital farm ledger, crop cycle profit-loss analytics, mandi calculator, agricultural advisory, and expense tracker.',
          theme_color: '#022c22',
          background_color: '#022c22',
          display: 'standalone',
          orientation: 'portrait-primary',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,jpg,svg,woff,woff2}'],
          globIgnores: ['**/assets/aistudio/**', '**/*.zip', '**/*.apk'],
          maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
        },
        devOptions: {
          enabled: false,
          type: 'module',
        },
      }),
      {
        name: 'strip-non-release-public-artifacts',
        closeBundle() {
          const distDir = path.resolve(__dirname, 'dist');
          const aistudioDir = path.join(distDir, 'assets', 'aistudio');
          if (fs.existsSync(aistudioDir)) {
            fs.rmSync(aistudioDir, { recursive: true, force: true });
          }
          if (fs.existsSync(distDir)) {
            for (const entry of fs.readdirSync(distDir)) {
              if (
                entry.endsWith('.zip') ||
                entry.endsWith('.apk') ||
                entry.endsWith('.aab') ||
                entry.endsWith('.pdf')
              ) {
                fs.rmSync(path.join(distDir, entry), { force: true });
              }
            }
          }
        },
      },
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
