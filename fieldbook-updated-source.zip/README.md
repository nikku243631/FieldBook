# FieldBook — Kisan Khet Ledger & Krishi Hisab (v2.4.0)

**FieldBook** is an offline-first agricultural accounting ledger, mandi payout calculator, crop-cycle tracker, farm diary, notes/shopping list manager, and weather advisory application designed for Indian farmers with full **Hindi (`hi`)** and **English (`en`)** support.

---

## 1. Architecture Disclosure

- **Application Stack:** React 19 + TypeScript 5.8 + Vite 6 + Tailwind CSS 4 + Progressive Web App (`vite-plugin-pwa`).
- **Android Packaging Stack:** **Capacitor 7.2.0** (`@capacitor/core@7.2.0`, `@capacitor/cli@7.2.0`, `@capacitor/android@7.2.0`, `@capacitor/app@7.0.1`).
- **Important Note on Native Architecture:** This project is a **React + Vite + Capacitor Android WebView application** (`com.fieldbook.kisan`), **not** a native Kotlin + Jetpack Compose UI application. All 18+ agricultural screens, themes, calculators, and offline storage run identically inside the full-screen Android WebView (`AppTheme.NoActionBarLaunch`) without browser navigation bars.
- **Offline Persistence:** Uses hardened browser/WebView `localStorage` with schema validation, automatic recovery from malformed entries, `QuotaExceededError` handling, and full JSON backup/restore + CSV export. Note that WebView `localStorage` is distinct from native Android Room/SQLite storage; users are encouraged to export JSON backups from the **Reports & Backup** tab before factory-resetting or switching phones.

---

## 2. Preserved & Audited Features

1. **Crop Ledger & Multiple Crop Cycles:** Create, edit, filter, and delete crop cycles across Rabi, Kharif, Zaid, and Annual seasons.
2. **Expense & Income Tracking:** Record, edit, filter, and delete farm input expenses (`seeds`, `fertilizer`, `pesticide`, `irrigation`, `labour`, `machinery`, `other`) and mandi/local income entries.
3. **Harvest Weight Logs & Farm Diary:** Record, edit, and delete harvest sessions (quintals, moisture %, grade, storage location) and timestamped farm diary activities.
4. **Crop Profit/Loss & Per-Unit Analytics:** Automatically computes total expenses, total income, net profit/loss, ROI %, profit margin %, cost per quintal, and cost/profit per land-area unit (`acre`, `bigha`, `hectare`, `kanal`, `guntha`).
5. **Mandi Calculator:** Calculates net weight (`kg`, `quintal`, `mann`), gross payout, bag-wise palledari deductions, and net payable amount with validation when tare weight exceeds gross weight.
6. **Fertilizer (NPK + Zinc) & Seed Calculators:** Computes Urea, DAP, MOP bags and Zinc sulfate (`kg`) requirements per acre or bigha, plus crop seed quantities and total seed cost.
7. **Land-Area Unit Converter:** Converts between Acre, Pucca Bigha, Standard Bigha, Kaccha Bigha, Hectare, Kanal, Marla, Guntha, and Square Feet.
8. **Diesel & Tube-Well Irrigation Calculator:** Computes total diesel consumption (`liters`), total cost (`₹`), and per-acre irrigation cost.
9. **General Quick Calculator:** Floating and tab-accessible arithmetic calculator with calculation tape history and 1-tap export to Farm Notes.
10. **Notes & Shopping Lists:** Pinned notes, colour tags, category filters, and interactive farm input shopping checklist with estimated prices.
11. **Live & Cached Weather Advisory:** Uses the live **Open-Meteo API** (`api.open-meteo.com`) with editable location presets, custom GPS/coordinate entry, spray/irrigation advisories, and explicit **LIVE vs. CACHED/OFFLINE** badges. Never fabricates temperatures or forecasts when offline.
12. **Reports, PDF Print, CSV Export & JSON Backup/Restore:** Month-by-month cashflow breakdown, WhatsApp summary sharing, printable PDF statements, Excel-compatible UTF-8 BOM CSV export, and validated JSON backup/restore.

---

## 3. Reproducible Local Build & Verification Instructions

### Prerequisites
- **Node.js:** v22.x (pinned in CI)
- **npm:** v10.x (uses `package-lock.json` via `npm ci`)
- **For Android APK Compilation:**
  - **Java JDK:** 21 (`Temurin-21`)
  - **Android SDK:** Platform 35, Build-Tools 35.0.0 (`ANDROID_HOME` configured)

### Step-by-Step Commands

```bash
# 1. Install exact pinned dependencies from package-lock.json
npm ci

# 2. Run TypeScript static type validation
npm run lint

# 3. Run automated accounting, storage, backup & import verification suite
npm run test

# 4. Build production web bundle and PWA service worker (outputs to dist/)
npm run build

# 5. Sync production web bundle and plugins into the Capacitor Android project
npx cap sync android

# 6. Build the installable Android debug APK via Gradle Wrapper
cd android
chmod +x gradlew
./gradlew assembleDebug --no-daemon --stacktrace

# 7. Copy the generated APK to project root
cp app/build/outputs/apk/debug/app-debug.apk ../FieldBook-Kisan-App.apk
```

The resulting installable APK is located at:
- `android/app/build/outputs/apk/debug/app-debug.apk`
- `FieldBook-Kisan-App.apk`

---

## 4. Automatic APK Build via GitHub Actions

This repository includes a verified workflow at `.github/workflows/build-apk.yml`.

1. Extract `FieldBook-Complete-GitHub-APK.zip` and push all files (including `.github/workflows/build-apk.yml`, `package-lock.json`, and `android/`) to a GitHub repository on the `main` or `master` branch.
2. GitHub Actions automatically runs:
   - `npm ci`
   - `npm run lint`
   - `npm run test`
   - `npm run build`
   - `npx cap sync android`
   - `npx capacitor-assets generate --android ...`
   - `./gradlew assembleDebug`
3. Download **`FieldBook-Kisan-App.apk`** from the workflow run's **Artifacts** (`FieldBook-Kisan-App-APK`) or from the repository's **Releases** (`latest-apk`).
