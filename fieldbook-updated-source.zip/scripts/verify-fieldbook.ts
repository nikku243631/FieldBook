import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  calculateCropFinancials,
  calculateMonthlyCropAccounting,
  calculateMonthlyFarmAccounting,
  calculateCropTimeline,
  suggestCropClassification,
  getEffectiveCropCategory,
  getCropCategoryLabel,
  getMonthlyEntryForMonth,
  getEffectiveCropAccountingType,
  inferCropAccountingTypeFromName,
  formatMonthLabel,
  calculateMandiPayout,
  calculateFertilizerRequirement,
  calculateSeedRequirement,
  convertLandAreaAllUnits,
  calculateDieselIrrigationCost
} from '../src/utils/calculations';
import { Storage } from '../src/utils/storage';
import {
  ReceiptStorage,
  buildSyncedReceiptAttachment,
  validateReceiptFile
} from '../src/utils/receiptStorage';
import { generateWhatsAppSummary, escapeHtml, sanitizeCsvCell } from '../src/utils/export';
import { CropCycle, Transaction, HarvestEntry, ShoppingItem } from '../src/types';

// Polyfill in-memory localStorage for Node verification
class MemoryStorage {
  private store = new Map<string, string>();
  get length() {
    return this.store.size;
  }
  clear() {
    this.store.clear();
  }
  getItem(key: string): string | null {
    return this.store.has(key) ? this.store.get(key)! : null;
  }
  key(index: number): string | null {
    return Array.from(this.store.keys())[index] ?? null;
  }
  removeItem(key: string): void {
    this.store.delete(key);
  }
  setItem(key: string, value: string): void {
    this.store.set(key, String(value));
  }
}

(globalThis as any).localStorage = new MemoryStorage();

async function runVerification() {
  console.log('=== FieldBook Automated Audit & Functional Verification Suite ===');

  // 1. Verify relative imports across all src/**/*.ts(x) files & confirm Profile Setup, Tracker, Growth Chart, and in-app ZIP/YAML UI are removed
  const srcDir = path.resolve(process.cwd(), 'src');
  assert.equal(
    fs.existsSync(path.join(srcDir, 'components', 'CropGrowthProgressChart.tsx')),
    false,
    'CropGrowthProgressChart.tsx must be completely removed'
  );
  assert.equal(
    fs.existsSync(path.join(srcDir, 'utils', 'zipExporter.ts')),
    false,
    'zipExporter.ts must be completely removed from app UI bundle'
  );
  assert.equal(
    fs.existsSync(path.join(srcDir, 'components', 'ProfileSetupModal.tsx')),
    false,
    'ProfileSetupModal.tsx must be completely removed'
  );
  assert.equal(
    fs.existsSync(path.join(srcDir, 'utils', 'tracker.ts')),
    false,
    'tracker.ts must be completely removed'
  );
  assert.equal(
    fs.existsSync(path.resolve(process.cwd(), 'BACKEND-TRACKER-CONTRACT.md')),
    false,
    'BACKEND-TRACKER-CONTRACT.md must be completely removed'
  );

  function getAllSourceFiles(dir: string): string[] {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    const files: string[] = [];
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        files.push(...getAllSourceFiles(full));
      } else if (entry.isFile() && /\.(ts|tsx)$/.test(entry.name)) {
        files.push(full);
      }
    }
    return files;
  }

  const sourceFiles = getAllSourceFiles(srcDir);
  let checkedImports = 0;
  for (const file of sourceFiles) {
    const content = fs.readFileSync(file, 'utf8');
    const relFile = path.relative(process.cwd(), file);
    assert.equal(
      content.includes('CropGrowthProgressChart'),
      false,
      `File ${relFile} must not reference CropGrowthProgressChart`
    );
    assert.equal(
      content.includes('zipExporter'),
      false,
      `File ${relFile} must not reference zipExporter`
    );
    assert.equal(
      content.includes('ProfileSetupModal'),
      false,
      `File ${relFile} must not reference ProfileSetupModal`
    );
    assert.equal(
      content.includes('TrackerService'),
      false,
      `File ${relFile} must not reference TrackerService`
    );
    assert.equal(
      content.includes('FieldBook-Complete-GitHub-APK.zip'),
      false,
      `File ${relFile} must not embed FieldBook-Complete-GitHub-APK.zip download UI`
    );
    assert.equal(
      content.includes('build-apk.yml'),
      false,
      `File ${relFile} must not embed build-apk.yml copy/download UI`
    );
    const importRegex = /from\s+['"](\.[^'"]+)['"]/g;
    let match: RegExpExecArray | null;
    while ((match = importRegex.exec(content)) !== null) {
      const relPath = match[1];
      const resolvedBase = path.resolve(path.dirname(file), relPath);
      const candidates = [
        resolvedBase,
        `${resolvedBase}.ts`,
        `${resolvedBase}.tsx`,
        path.join(resolvedBase, 'index.ts'),
        path.join(resolvedBase, 'index.tsx')
      ];
      const exists = candidates.some((c) => fs.existsSync(c) && fs.statSync(c).isFile());
      assert.ok(
        exists,
        `Missing relative import "${relPath}" in ${relFile}`
      );
      checkedImports++;
    }
  }
  console.log(`✓ [1/16] Verified ${checkedImports} relative imports across ${sourceFiles.length} TypeScript files and confirmed Profile Setup, Tracker, in-app ZIP/YAML UI & CropGrowthProgressChart are removed.`);

  // 2. Test Crop Financials: Total expenses, total income, net profit/loss, profit per land-area unit, harvest quantities
  const testCrop: CropCycle = {
    id: 'crop-test-1',
    name: 'Wheat (HD-3226)',
    hindiName: 'गेहूं (HD-3226)',
    variety: 'HD-3226',
    landArea: 4,
    areaUnit: 'acre',
    season: 'rabi',
    sowingDate: '2025-11-10',
    status: 'active',
    createdAt: '2025-11-10T00:00:00Z',
    updatedAt: '2025-11-10T00:00:00Z'
  };

  const testTx: Transaction[] = [
    {
      id: 't1',
      cropId: 'crop-test-1',
      type: 'expense',
      category: 'seeds',
      title: 'Certified Wheat Seeds',
      amount: 6400,
      date: '2025-11-10',
      time: '09:00',
      paymentStatus: 'paid',
      createdAt: '2025-11-10T09:00:00Z'
    },
    {
      id: 't2',
      cropId: 'crop-test-1',
      type: 'expense',
      category: 'fertilizer',
      title: 'DAP & Urea',
      amount: 8600,
      date: '2025-11-12',
      time: '10:00',
      paymentStatus: 'paid',
      createdAt: '2025-11-12T10:00:00Z'
    },
    {
      id: 't3',
      cropId: 'crop-test-1',
      type: 'income',
      category: 'mandi_sale',
      title: 'Karnal Mandi Sale',
      amount: 95000,
      date: '2026-04-05',
      time: '15:00',
      paymentStatus: 'paid',
      createdAt: '2026-04-05T15:00:00Z'
    }
  ];

  const testHarvests: HarvestEntry[] = [
    {
      id: 'h1',
      cropId: 'crop-test-1',
      date: '2026-04-02',
      time: '14:00',
      quantityQuintal: 38.5
    },
    {
      id: 'h2',
      cropId: 'crop-test-1',
      date: '2026-04-03',
      time: '16:00',
      quantityQuintal: 41.5
    }
  ];

  const fin = calculateCropFinancials(testCrop, testTx, testHarvests);
  assert.equal(fin.totalExpenses, 15000, 'Total expenses should be 15000');
  assert.equal(fin.totalIncome, 95000, 'Total income should be 95000');
  assert.equal(fin.netProfit, 80000, 'Net profit should be 80000');
  assert.equal(fin.isProfit, true, 'Should be profitable');
  assert.equal(fin.costPerUnit, 3750, 'Cost per acre should be 3750');
  assert.equal(fin.profitPerUnit, 20000, 'Profit per acre should be 20000');
  assert.equal(fin.totalHarvestQuintal, 80, 'Total harvest should be 80 quintals');
  assert.equal(fin.yieldPerUnit, 20, 'Yield per acre should be 20 quintals');
  assert.equal(fin.costPerQuintal, 188, 'Cost per quintal should be Math.round(15000/80) = 188');

  // Edge case: zero land area & zero harvest & net loss
  const zeroAreaCrop: CropCycle = { ...testCrop, landArea: 0, areaUnit: 'bigha' };
  const lossTx: Transaction[] = [testTx[0]]; // Only 6400 expense, 0 income
  const finZero = calculateCropFinancials(zeroAreaCrop, lossTx, []);
  assert.equal(finZero.totalExpenses, 6400);
  assert.equal(finZero.totalIncome, 0);
  assert.equal(finZero.netProfit, -6400);
  assert.equal(finZero.isProfit, false);
  assert.equal(finZero.costPerUnit, 0, 'Division by zero landArea must safely return 0');
  assert.equal(finZero.profitPerUnit, 0, 'Division by zero landArea must safely return 0');
  assert.equal(finZero.costPerQuintal, 0, 'Division by zero harvest must safely return 0');
  console.log('✓ [2/16] Verified Crop Financials (total expenses, income, net P&L, per-area-unit profit, harvest yield, division-by-zero guards).');

  // 3. Test Mandi Calculator
  const mandi1 = calculateMandiPayout({
    grossWeightKg: 3500,
    tareWeightKg: 1000,
    ratePerQuintal: 2325,
    bagsCount: 50,
    palledariPerBag: 14
  });
  assert.equal(mandi1.netWeightKg, 2500);
  assert.equal(mandi1.netWeightQuintal, 25);
  assert.equal(mandi1.netWeightMann, 62.5);
  assert.equal(mandi1.grossAmount, 58125);
  assert.equal(mandi1.totalDeductions, 700);
  assert.equal(mandi1.netPayableAmount, 57425);

  const mandiEdge = calculateMandiPayout({
    grossWeightKg: 800,
    tareWeightKg: 1000,
    ratePerQuintal: 2325,
    bagsCount: 10,
    palledariPerBag: 15
  });
  assert.equal(mandiEdge.netWeightKg, 0);
  assert.equal(mandiEdge.netPayableAmount, 0);
  console.log('✓ [3/16] Verified Mandi Calculator (gross/tare/net weight, quintals, mann, palledari deductions, net payable).');

  // 4. Test Fertilizer & Seed Calculators
  const fertWheat = calculateFertilizerRequirement('wheat', 2.5, 'acre');
  assert.equal(fertWheat.ureaBags, 6.3);
  assert.equal(fertWheat.dapBags, 2.5);
  assert.equal(fertWheat.mopBags, 1.3);
  assert.equal(fertWheat.zincKg, 12.5);

  const fertBigha = calculateFertilizerRequirement('wheat', 5, 'bigha');
  assert.equal(fertBigha.areaInAcres, 2);
  assert.equal(fertBigha.ureaBags, 5);
  assert.equal(fertBigha.dapBags, 2);

  const seedWheat = calculateSeedRequirement('wheat', 3, 40, 'acre');
  assert.equal(seedWheat.totalSeedRequiredKg, 120);
  assert.equal(seedWheat.totalSeedCost, 4800);
  console.log('✓ [4/16] Verified Fertilizer & Seed Calculators across acre and bigha units.');

  // 5. Test Land-Area Unit Converter & Diesel Calculator
  const area1Acre = convertLandAreaAllUnits(1, 'acre');
  assert.equal(area1Acre.sqFt, 43560);
  assert.equal(area1Acre.kanal, 8);
  assert.equal(area1Acre.marla, 160);
  assert.equal(area1Acre.guntha, 40);
  assert.equal(area1Acre.bighaPucca, 1.6);
  assert.equal(area1Acre.bighaKaccha, 4.8);

  const diesel = calculateDieselIrrigationCost(6, 2.5, 89, 2);
  assert.equal(diesel.totalDieselLiters, 15);
  assert.equal(diesel.totalDieselCost, 1335);
  assert.equal(diesel.costPerAcre, 668);
  console.log('✓ [5/16] Verified Land-Area Unit Converter and Diesel Irrigation Cost Calculator.');

  // 6. Test Record Creation, Editing, Deletion & Local Persistence
  const initialCrops = Storage.getCrops();
  assert.ok(initialCrops.length >= 2, 'Should initialize with seed crops');

  const addedCrop: CropCycle = {
    ...testCrop,
    id: 'crop-custom-99',
    name: 'Basmati Paddy'
  };
  Storage.saveCrops([addedCrop, ...initialCrops]);
  assert.equal(Storage.getCrops()[0].id, 'crop-custom-99');

  const editedCrops = Storage.getCrops().map((c) =>
    c.id === 'crop-custom-99' ? { ...c, landArea: 6.5 } : c
  );
  Storage.saveCrops(editedCrops);
  assert.equal(Storage.getCrops().find((c) => c.id === 'crop-custom-99')?.landArea, 6.5);

  Storage.saveCrops(Storage.getCrops().filter((c) => c.id !== 'crop-custom-99'));
  assert.equal(Storage.getCrops().some((c) => c.id === 'crop-custom-99'), false);
  console.log('✓ [6/16] Verified creating, editing, and deleting records in Storage.');

  // 7. Test JSON Backup Export, Valid Restore, and Invalid Backup Rejection
  const backupJson = Storage.exportFullBackup();
  assert.ok(backupJson.includes('FieldBook'), 'Exported JSON should include FieldBook branding');

  const cropsBeforeInvalid = Storage.getCrops().length;
  const badResult1 = Storage.importFullBackupWithDetails('{not valid json');
  assert.equal(badResult1.success, false, 'Malformed JSON must be rejected');
  assert.ok(badResult1.errorEn, 'Malformed JSON must return an understandable error message');
  assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Malformed JSON must not corrupt existing data');

  const badResult2 = Storage.importFullBackupWithDetails(JSON.stringify({ randomKey: 123 }));
  assert.equal(badResult2.success, false, 'Unrelated JSON object must be rejected');
  assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Unrelated JSON must not corrupt existing data');

  const badResult3 = Storage.importFullBackupWithDetails(
    JSON.stringify({ crops: [{ invalidCropWithoutIdOrName: true }], transactions: [] })
  );
  assert.equal(badResult3.success, false, 'JSON with invalid crop schema must be rejected');
  assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Invalid crop schema must not corrupt existing data');

  Storage.clearAllData();
  assert.equal(Storage.getCrops().length, 0, 'Crops should be empty after clearAllData');
  const goodResult = Storage.importFullBackupWithDetails(backupJson);
  assert.equal(goodResult.success, true, 'Valid backup should restore cleanly');
  assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Restored crop count should match backup');
  console.log('✓ [7/16] Verified JSON Backup Export/Restore and confirmed invalid backup files produce clear errors without corrupting data.');

  // 8. Test WhatsApp Summary Generation
  const waText = decodeURIComponent(generateWhatsAppSummary(testCrop, testTx, testHarvests, 'hi'));
  assert.ok(waText.includes('FieldBook'), 'WhatsApp summary should include FieldBook header');
  assert.ok(waText.includes('80 क्विंटल'), 'WhatsApp summary should include total harvest');
  console.log('✓ [8/16] Verified Report Summary & Export formatting.');

  // 9. Verify Malformed localStorage Recovery
  (globalThis as any).localStorage.setItem('fieldbook_crops_v1', '<<<corrupted_json>>>');
  const recoveredCrops = Storage.getCrops();
  assert.ok(Array.isArray(recoveredCrops) && recoveredCrops.length > 0, 'Storage must safely recover from corrupted localStorage entries');
  console.log('✓ [9/16] Verified automatic recovery from corrupted localStorage entries.');

  // 10. Test Expense & Income Bill/Receipt Attachments, Transaction Linking, Edits, Validation & Backup Restore
  const invalidCheck = validateReceiptFile({ name: 'malware.exe', type: 'application/x-msdownload', size: 1024 });
  assert.equal(invalidCheck.valid, false, 'Invalid file type must be rejected');
  const oversizedCheck = validateReceiptFile({ name: 'huge.pdf', type: 'application/pdf', size: 25 * 1024 * 1024 });
  assert.equal(oversizedCheck.valid, false, 'Oversized PDF must be rejected');
  const validImgCheck = validateReceiptFile({ name: 'dap_bill.jpg', type: 'image/jpeg', size: 145000 });
  assert.equal(validImgCheck.valid, true);
  assert.equal(validImgCheck.kind, 'image');
  const validPdfCheck = validateReceiptFile({ name: 'mandi_slip.pdf', type: 'application/pdf', size: 210000 });
  assert.equal(validPdfCheck.valid, true);
  assert.equal(validPdfCheck.kind, 'pdf');

  // Attach image bill to an Expense transaction
  const expenseWithBill: Transaction = {
    id: 'tx-exp-bill-1',
    cropId: 'crop-wheat-2024',
    type: 'expense',
    category: 'fertilizer',
    title: 'IFFCO DAP 3 Bags',
    amount: 4050,
    date: '2025-11-15',
    time: '11:20',
    notes: 'Cash memo #402',
    paymentStatus: 'paid',
    createdAt: '2025-11-15T11:20:00Z'
  };
  const expAttachment = buildSyncedReceiptAttachment(expenseWithBill, {
    fileName: 'iffco_dap_bill.jpg',
    mimeType: 'image/jpeg',
    fileSize: 82000
  });
  expenseWithBill.receiptAttachment = expAttachment;
  const sampleImageDataUrl = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
  const savedExpBill = await ReceiptStorage.saveReceipt(expAttachment, sampleImageDataUrl);
  assert.equal(savedExpBill, true, 'Expense receipt attachment should save cleanly');

  // Attach PDF receipt to an Income transaction
  const incomeWithBill: Transaction = {
    id: 'tx-inc-bill-2',
    cropId: 'crop-mustard-2024',
    type: 'income',
    category: 'mandi_sale',
    title: 'Mandi Sale 15 Quintal',
    amount: 84750,
    date: '2025-03-10',
    time: '14:45',
    notes: 'Slip #MND-901',
    paymentStatus: 'paid',
    createdAt: '2025-03-10T14:45:00Z'
  };
  const incAttachment = buildSyncedReceiptAttachment(incomeWithBill, {
    fileName: 'mandi_slip_901.pdf',
    mimeType: 'application/pdf',
    fileSize: 124000
  });
  incomeWithBill.receiptAttachment = incAttachment;
  const samplePdfDataUrl = 'data:application/pdf;base64,JVBERi0xLjQK';
  const savedIncBill = await ReceiptStorage.saveReceipt(incAttachment, samplePdfDataUrl);
  assert.equal(savedIncBill, true, 'Income receipt attachment should save cleanly');

  // Verify reopening both attachments and checking linked metadata
  const reopenedExp = await ReceiptStorage.getReceipt(expAttachment.storageRef);
  assert.ok(reopenedExp, 'Expense receipt should be retrievable');
  assert.equal(reopenedExp.transactionId, 'tx-exp-bill-1');
  assert.equal(reopenedExp.transactionType, 'expense');
  assert.equal(reopenedExp.cropId, 'crop-wheat-2024');
  assert.equal(reopenedExp.amount, 4050);
  assert.equal(reopenedExp.date, '2025-11-15');
  assert.equal(reopenedExp.dataUrl, sampleImageDataUrl);

  const reopenedInc = await ReceiptStorage.getReceipt(incAttachment.storageRef);
  assert.ok(reopenedInc, 'Income receipt should be retrievable');
  assert.equal(reopenedInc.transactionId, 'tx-inc-bill-2');
  assert.equal(reopenedInc.transactionType, 'income');
  assert.equal(reopenedInc.cropId, 'crop-mustard-2024');
  assert.equal(reopenedInc.amount, 84750);
  assert.equal(reopenedInc.date, '2025-03-10');
  assert.equal(reopenedInc.dataUrl, samplePdfDataUrl);

  // Edit the expense transaction (change amount, date, title, notes) and verify receipt stays linked & synced
  const editedExpense: Transaction = {
    ...expenseWithBill,
    title: 'IFFCO DAP 4 Bags (Updated)',
    amount: 5400,
    date: '2025-11-16',
    notes: 'Cash memo #402 - updated to 4 bags'
  };
  const syncedTxAfterEdit = await ReceiptStorage.syncStoredReceiptMetadata(editedExpense);
  assert.equal(syncedTxAfterEdit.receiptAttachment?.amount, 5400, 'Receipt amount must sync with edited transaction');
  assert.equal(syncedTxAfterEdit.receiptAttachment?.date, '2025-11-16', 'Receipt date must sync with edited transaction');
  assert.equal(syncedTxAfterEdit.receiptAttachment?.title, 'IFFCO DAP 4 Bags (Updated)');
  assert.equal(syncedTxAfterEdit.notes, 'Cash memo #402 - updated to 4 bags', 'Notes field must remain intact');

  const reopenedAfterEdit = await ReceiptStorage.getReceipt(expAttachment.storageRef);
  assert.equal(reopenedAfterEdit?.amount, 5400, 'Stored receipt payload amount must reflect edited transaction');
  assert.equal(reopenedAfterEdit?.date, '2025-11-16', 'Stored receipt payload date must reflect edited transaction');

  // Verify full backup export/restore preserves receipts
  Storage.saveTransactions([syncedTxAfterEdit, incomeWithBill, ...Storage.getTransactions()]);
  const fullBackupWithReceipts = Storage.exportFullBackup();
  await ReceiptStorage.clearAllReceipts();
  assert.equal(await ReceiptStorage.getReceipt(expAttachment.storageRef), null);

  const restoreRes = Storage.importFullBackupWithDetails(fullBackupWithReceipts);
  assert.equal(restoreRes.success, true);
  const restoredExpReceipt = await ReceiptStorage.getReceipt(expAttachment.storageRef);
  assert.ok(restoredExpReceipt, 'Receipt must be restored from backup');
  assert.equal(restoredExpReceipt.amount, 5400);
  assert.equal(restoredExpReceipt.dataUrl, sampleImageDataUrl);

  console.log('✓ [10/16] Verified Expense & Income Bill/Receipt Attachments, transaction linking, edits sync, validation, and backup persistence.');

  // 11. Security & Release Hardening Verification (HTML escaping, CSV formula sanitization, theme persistence, AndroidManifest & ProGuard)
  assert.equal(
    escapeHtml('<script>alert("xss")</script>&"\''),
    '&lt;script&gt;alert(&quot;xss&quot;)&lt;/script&gt;&amp;&quot;&#39;',
    'escapeHtml must neutralize script tags and quotes'
  );
  assert.equal(
    sanitizeCsvCell('=cmd|\' /C calc\'!A0'),
    '"\'=cmd|\' /C calc\'!A0"',
    'sanitizeCsvCell must prefix leading formula characters with a single quote'
  );
  assert.equal(sanitizeCsvCell('DAP खाद 50kg'), '"DAP खाद 50kg"');

  // Verify dark/light theme persistence in Storage.getSettings()
  const initialSettings = Storage.getSettings();
  Storage.saveSettings({ ...initialSettings, theme: 'dark', language: 'en' });
  const reloadedSettings = Storage.getSettings();
  assert.equal(reloadedSettings.theme, 'dark', 'Dark theme must persist across restarts');
  assert.equal(reloadedSettings.language, 'en', 'Language setting must persist across restarts');
  Storage.saveSettings({ ...reloadedSettings, theme: 'light', language: 'hi' });

  // Verify no eval() or new Function() in src/
  const simpleCalcCode = fs.readFileSync(path.resolve(process.cwd(), 'src/components/SimpleCalculator.tsx'), 'utf8');
  assert.equal(/new\s+Function\s*\(/.test(simpleCalcCode), false, 'SimpleCalculator must not use new Function()');

  // Verify AndroidManifest.xml disables cleartext traffic
  const manifestXml = fs.readFileSync(
    path.resolve(process.cwd(), 'android/app/src/main/AndroidManifest.xml'),
    'utf8'
  );
  assert.ok(
    manifestXml.includes('android:usesCleartextTraffic="false"'),
    'AndroidManifest.xml must enforce usesCleartextTraffic="false"'
  );

  // Verify ProGuard keeps @JavascriptInterface methods
  const proguardRules = fs.readFileSync(
    path.resolve(process.cwd(), 'android/app/proguard-rules.pro'),
    'utf8'
  );
  assert.ok(
    proguardRules.includes('com.fieldbook.kisan.MainActivity$AndroidNativeBridge'),
    'proguard-rules.pro must preserve MainActivity$AndroidNativeBridge'
  );

  console.log('✓ [11/16] Verified Security Hardening (XSS/HTML escaping, CSV sanitization, zero-eval calculator, theme persistence, AndroidManifest & ProGuard rules).');

  // 12. Monthly Crop Accounting Verification — Type A (One-Time / Batch Harvest Crop & Legacy Crop Compatibility)
  const legacyWheatCrop: CropCycle = {
    id: 'crop-legacy-wheat',
    name: 'Wheat (गेहूं)',
    hindiName: 'गेहूं (Wheat)',
    variety: 'HD 2967',
    landArea: 3,
    areaUnit: 'acre',
    season: 'rabi',
    sowingDate: '2025-11-05',
    status: 'active',
    createdAt: '2025-11-05T08:00:00Z',
    updatedAt: '2025-11-05T08:00:00Z'
  };
  assert.equal(
    getEffectiveCropAccountingType(legacyWheatCrop),
    'one_time',
    'Legacy saved crops without accountingType must safely default to one_time'
  );
  assert.equal(inferCropAccountingTypeFromName('Wheat (गेहूं)'), 'one_time');
  assert.equal(inferCropAccountingTypeFromName('Chilli (मिर्च)'), 'recurring');
  assert.equal(inferCropAccountingTypeFromName('Brinjal (बैंगन)'), 'recurring');

  const wheatMonthlyTx: Transaction[] = [
    {
      id: 'w-nov-1',
      cropId: 'crop-legacy-wheat',
      type: 'expense',
      category: 'seeds',
      title: 'Wheat Seeds',
      amount: 4500,
      date: '2025-11-05',
      time: '10:00',
      paymentStatus: 'paid',
      createdAt: '2025-11-05T10:00:00Z'
    },
    {
      id: 'w-nov-2',
      cropId: 'crop-legacy-wheat',
      type: 'expense',
      category: 'fertilizer',
      title: 'DAP 3 Bags',
      amount: 4050,
      date: '2025-11-06',
      time: '11:00',
      paymentStatus: 'paid',
      createdAt: '2025-11-06T11:00:00Z'
    },
    {
      id: 'w-nov-3',
      cropId: 'crop-legacy-wheat',
      type: 'expense',
      category: 'machinery',
      title: 'Rotavator & Seed Drill',
      amount: 3950,
      date: '2025-11-07',
      time: '16:00',
      paymentStatus: 'paid',
      createdAt: '2025-11-07T16:00:00Z'
    },
    {
      id: 'w-dec-1',
      cropId: 'crop-legacy-wheat',
      type: 'expense',
      category: 'irrigation',
      title: 'First Irrigation Diesel',
      amount: 2500,
      date: '2025-12-02',
      time: '09:00',
      paymentStatus: 'paid',
      createdAt: '2025-12-02T09:00:00Z'
    },
    {
      id: 'w-dec-2',
      cropId: 'crop-legacy-wheat',
      type: 'expense',
      category: 'fertilizer',
      title: 'Urea & Zinc',
      amount: 2000,
      date: '2025-12-10',
      time: '11:00',
      paymentStatus: 'paid',
      createdAt: '2025-12-10T11:00:00Z'
    },
    {
      id: 'w-mar-1',
      cropId: 'crop-legacy-wheat',
      type: 'expense',
      category: 'labour',
      title: 'Harvesting Labour',
      amount: 5000,
      date: '2026-03-28',
      time: '17:00',
      paymentStatus: 'paid',
      createdAt: '2026-03-28T17:00:00Z'
    },
    {
      id: 'w-apr-1',
      cropId: 'crop-legacy-wheat',
      type: 'income',
      category: 'mandi_sale',
      title: 'Mandi Wheat Sale 60 Quintal',
      amount: 138000,
      date: '2026-04-06',
      time: '14:00',
      paymentStatus: 'paid',
      createdAt: '2026-04-06T14:00:00Z'
    }
  ];

  const wheatHarvests: HarvestEntry[] = [
    {
      id: 'w-hrv-1',
      cropId: 'crop-legacy-wheat',
      date: '2026-03-30',
      time: '16:00',
      quantityQuintal: 60
    }
  ];

  const wheatSummary = calculateMonthlyCropAccounting(
    legacyWheatCrop,
    [...wheatMonthlyTx, wheatMonthlyTx[0]],
    [...wheatHarvests, wheatHarvests[0]]
  );

  assert.equal(wheatSummary.accountingType, 'one_time');
  assert.deepEqual(wheatSummary.availableMonthKeys, ['2025-11', '2025-12', '2026-03', '2026-04']);
  const novEntry = wheatSummary.monthsMap['2025-11'];
  assert.equal(novEntry.salesTotal, 0);
  assert.equal(novEntry.expensesTotal, 12500);
  assert.equal(novEntry.netProfit, -12500);
  assert.equal(novEntry.hasExpensesOnly, true);

  const janEmptyEntry = getMonthlyEntryForMonth(wheatSummary, '2026-01');
  assert.equal(janEmptyEntry.isEmpty, true);
  assert.equal(janEmptyEntry.cumulativeExpenses, 17000);

  const aprEntry = wheatSummary.monthsMap['2026-04'];
  assert.equal(aprEntry.salesTotal, 138000);
  assert.equal(aprEntry.expensesTotal, 0);
  assert.equal(aprEntry.netProfit, 138000);
  assert.equal(aprEntry.hasSalesWithoutRecordedExpenses, true);

  const wheatLedgerFin = calculateCropFinancials(legacyWheatCrop, wheatMonthlyTx, wheatHarvests);
  assert.equal(wheatSummary.totalSales, wheatLedgerFin.totalIncome);
  assert.equal(wheatSummary.totalExpenses, wheatLedgerFin.totalExpenses);
  assert.equal(wheatSummary.overallNetProfit, wheatLedgerFin.netProfit);
  assert.equal(formatMonthLabel('2026-04', 'en'), 'April 2026');
  console.log('✓ [12/16] Verified Monthly Crop Accounting for Type A (One-Time Harvest) & Legacy Crops.');

  // 13. Monthly Crop Accounting Verification — Type B (Multi-Harvest / Recurring Weekly Sales Crop: Chilli / Brinjal)
  const chilliCrop: CropCycle = {
    id: 'crop-chilli-recurring',
    name: 'Chilli (मिर्च)',
    hindiName: 'मिर्च (Chilli)',
    variety: 'Hybrid G-4',
    landArea: 1.5,
    areaUnit: 'acre',
    season: 'kharif',
    cropCategory: 'vegetable',
    accountingType: 'recurring',
    sowingDate: '2025-07-10',
    status: 'active',
    createdAt: '2025-07-10T08:00:00Z',
    updatedAt: '2025-07-10T08:00:00Z'
  };
  assert.equal(getEffectiveCropAccountingType(chilliCrop), 'recurring');

  const chilliTx: Transaction[] = [
    {
      id: 'ch-jul-exp-1',
      cropId: 'crop-chilli-recurring',
      type: 'expense',
      category: 'seeds',
      title: 'Hybrid Chilli Nursery Plants & Mulching',
      amount: 5500,
      date: '2025-07-10',
      time: '09:30',
      paymentStatus: 'paid',
      createdAt: '2025-07-10T09:30:00Z'
    },
    {
      id: 'ch-jul-exp-2',
      cropId: 'crop-chilli-recurring',
      type: 'expense',
      category: 'fertilizer',
      title: 'Basal Dose DAP & NPK',
      amount: 2500,
      date: '2025-07-12',
      time: '11:00',
      paymentStatus: 'paid',
      createdAt: '2025-07-12T11:00:00Z'
    },
    {
      id: 'ch-sep-sale-1',
      cropId: 'crop-chilli-recurring',
      type: 'income',
      category: 'mandi_sale',
      title: 'Week 1 Picking Mandi Sale (4 Quintal)',
      amount: 12000,
      date: '2025-09-07',
      time: '11:00',
      paymentStatus: 'paid',
      createdAt: '2025-09-07T11:00:00Z'
    },
    {
      id: 'ch-sep-exp-1',
      cropId: 'crop-chilli-recurring',
      type: 'expense',
      category: 'pesticide',
      title: 'Thrips & Mite Spray',
      amount: 1800,
      date: '2025-09-10',
      time: '16:00',
      paymentStatus: 'paid',
      createdAt: '2025-09-10T16:00:00Z'
    },
    {
      id: 'ch-sep-sale-2',
      cropId: 'crop-chilli-recurring',
      type: 'income',
      category: 'mandi_sale',
      title: 'Week 2 Picking Mandi Sale (5 Quintal)',
      amount: 15500,
      date: '2025-09-14',
      time: '11:30',
      paymentStatus: 'paid',
      createdAt: '2025-09-14T11:30:00Z'
    },
    {
      id: 'ch-sep-exp-2',
      cropId: 'crop-chilli-recurring',
      type: 'expense',
      category: 'labour',
      title: 'Chilli Picking Labour & Mandi Tempo Fare',
      amount: 3200,
      date: '2025-09-21',
      time: '18:00',
      paymentStatus: 'paid',
      createdAt: '2025-09-21T18:00:00Z'
    },
    {
      id: 'ch-sep-sale-3',
      cropId: 'crop-chilli-recurring',
      type: 'income',
      category: 'mandi_sale',
      title: 'Week 3 Picking Mandi Sale (4.5 Quintal)',
      amount: 14500,
      date: '2025-09-22',
      time: '12:00',
      paymentStatus: 'paid',
      createdAt: '2025-09-22T12:00:00Z'
    },
    {
      id: 'ch-oct-sale-1',
      cropId: 'crop-chilli-recurring',
      type: 'income',
      category: 'mandi_sale',
      title: 'October Week 1 Mandi Sale (6 Quintal)',
      amount: 18000,
      date: '2025-10-05',
      time: '11:00',
      paymentStatus: 'paid',
      createdAt: '2025-10-05T11:00:00Z'
    },
    {
      id: 'ch-oct-exp-1',
      cropId: 'crop-chilli-recurring',
      type: 'expense',
      category: 'labour',
      title: 'October Picking Labour & Micronutrient Spray',
      amount: 4000,
      date: '2025-10-12',
      time: '17:00',
      paymentStatus: 'paid',
      createdAt: '2025-10-12T17:00:00Z'
    },
    {
      id: 'ch-oct-sale-2',
      cropId: 'crop-chilli-recurring',
      type: 'income',
      category: 'mandi_sale',
      title: 'October Week 3 Mandi Sale (5 Quintal)',
      amount: 16000,
      date: '2025-10-19',
      time: '12:15',
      paymentStatus: 'paid',
      createdAt: '2025-10-19T12:15:00Z'
    }
  ];

  const chilliHarvests: HarvestEntry[] = [
    { id: 'ch-h-1', cropId: 'crop-chilli-recurring', date: '2025-09-07', time: '08:00', quantityQuintal: 4 },
    { id: 'ch-h-2', cropId: 'crop-chilli-recurring', date: '2025-09-14', time: '08:00', quantityQuintal: 5 },
    { id: 'ch-h-3', cropId: 'crop-chilli-recurring', date: '2025-09-22', time: '08:00', quantityQuintal: 4.5 },
    { id: 'ch-h-4', cropId: 'crop-chilli-recurring', date: '2025-10-05', time: '08:00', quantityQuintal: 6 },
    { id: 'ch-h-5', cropId: 'crop-chilli-recurring', date: '2025-10-19', time: '08:00', quantityQuintal: 5 }
  ];

  const chilliSummary = calculateMonthlyCropAccounting(chilliCrop, chilliTx, chilliHarvests);
  assert.equal(chilliSummary.accountingType, 'recurring');
  assert.deepEqual(chilliSummary.availableMonthKeys, ['2025-07', '2025-09', '2025-10']);
  assert.equal(chilliSummary.totalSales, 76000);
  assert.equal(chilliSummary.totalExpenses, 17000);
  assert.equal(chilliSummary.overallNetProfit, 59000);
  assert.equal(chilliSummary.totalHarvestQuintal, 24.5);
  console.log('✓ [13/16] Verified Monthly Crop Accounting for Type B (Multi-Harvest Recurring Sales Crops).');

  // 14. Shopping List Quantity Fix Verification (1, 2, 5, 10, 25, 50, 100, 1.5, edit retention, invalid fallback)
  const testShoppingQuantities = [1, 2, 5, 10, 25, 50, 100, 1.5];
  const createdItems: ShoppingItem[] = testShoppingQuantities.map((qty, idx) => ({
    id: `shop-qty-${idx}`,
    name: `Farming Input #${idx + 1}`,
    category: 'fertilizer',
    quantity: qty,
    unit: 'बोरी (Bags)',
    estimatedCost: qty * 500,
    isPurchased: false,
    date: '2026-10-20',
    createdAt: '2026-10-20T09:00:00Z'
  }));
  Storage.saveShoppingItems(createdItems);
  const loadedShopping = Storage.getShoppingItems();
  assert.equal(loadedShopping.length, testShoppingQuantities.length);
  for (let i = 0; i < testShoppingQuantities.length; i++) {
    assert.equal(
      loadedShopping[i].quantity,
      testShoppingQuantities[i],
      `Shopping list item quantity ${testShoppingQuantities[i]} must be saved and retained accurately`
    );
  }

  // Edit an existing item quantity from 2 to 25 and verify it retains 25 (never resets to 1)
  const editedShopping = loadedShopping.map((item) =>
    item.id === 'shop-qty-1' ? { ...item, quantity: 25 } : item
  );
  Storage.saveShoppingItems(editedShopping);
  assert.equal(
    Storage.getShoppingItems().find((i) => i.id === 'shop-qty-1')?.quantity,
    25,
    'Edited shopping item quantity must retain 25 without resetting to 1'
  );

  // Verify corrupted/negative/zero quantity in storage safely normalizes to default 1
  (globalThis as any).localStorage.setItem(
    'fieldbook_shopping_v1',
    JSON.stringify([
      {
        id: 'shop-bad-qty',
        name: 'Urea Bag',
        category: 'fertilizer',
        quantity: -5,
        unit: 'बोरी (Bags)',
        estimatedCost: 1000,
        isPurchased: false,
        date: '2026-10-20',
        createdAt: '2026-10-20T09:00:00Z'
      }
    ])
  );
  assert.equal(
    Storage.getShoppingItems()[0].quantity,
    1,
    'Invalid/negative stored quantity must safely normalize to 1'
  );
  console.log('✓ [14/16] Verified Shopping List Quantity fix across 1, 2, 5, 10, 25, 50, 100, and 1.5 (add, edit retention, and validation).');

  // 15. Crop Details, Category vs Harvest Type Separation, and Crop Age / Expected Harvest Timeline Verification
  // Verify known crop suggestions and unknown crop non-forced behavior
  assert.deepEqual(suggestCropClassification('Wheat (गेहूं)'), {
    category: 'grain',
    accountingType: 'one_time'
  });
  assert.deepEqual(suggestCropClassification('Brinjal (बैंगन)'), {
    category: 'vegetable',
    accountingType: 'recurring'
  });
  assert.deepEqual(suggestCropClassification('Mustard (सरसों)'), {
    category: 'oilseed',
    accountingType: 'one_time'
  });
  assert.deepEqual(suggestCropClassification('Chana (चना)'), {
    category: 'pulse',
    accountingType: 'one_time'
  });
  assert.deepEqual(suggestCropClassification('Mango (आम)'), {
    category: 'fruit',
    accountingType: 'recurring'
  });
  assert.deepEqual(
    suggestCropClassification('Custom Experimental Herb XYZ'),
    { category: null, accountingType: null },
    'Unknown crop must not force a category or harvest type'
  );
  assert.equal(getCropCategoryLabel('grain', 'en'), 'Grain');
  assert.equal(getCropCategoryLabel('vegetable', 'en'), 'Vegetable');

  // Verify exact prompt example: Planted on 1 October 2026, Today is 20 October 2026 -> Crop age = 19 days
  const oct1Crop: CropCycle = {
    id: 'crop-oct-1',
    name: 'Brinjal',
    hindiName: 'बैंगन',
    landArea: 1,
    areaUnit: 'acre',
    season: 'kharif',
    cropCategory: 'vegetable',
    accountingType: 'recurring',
    sowingDate: '2026-10-01',
    expectedHarvestDate: '2026-11-15',
    status: 'active',
    createdAt: '2026-10-01T08:00:00Z',
    updatedAt: '2026-10-01T08:00:00Z'
  };
  const timelineOct20 = calculateCropTimeline(oct1Crop, '2026-10-20');
  assert.equal(
    timelineOct20.cropAgeDays,
    19,
    'Planted 2026-10-01 on reference date 2026-10-20 must equal 19 days crop age'
  );
  assert.equal(timelineOct20.daysRemainingUntilHarvest, 26);
  assert.equal(timelineOct20.isHarvestDatePassed, false);
  assert.equal(timelineOct20.isHarvestDateToday, false);

  // Verify past expected harvest date -> isHarvestDatePassed = true ("Expected harvest date has passed.")
  const timelinePastHarvest = calculateCropTimeline(oct1Crop, '2026-11-25');
  assert.equal(timelinePastHarvest.cropAgeDays, 55);
  assert.equal(timelinePastHarvest.isHarvestDatePassed, true);
  assert.equal(timelinePastHarvest.daysRemainingUntilHarvest, -10);
  assert.equal(getEffectiveCropCategory(oct1Crop), 'vegetable');
  console.log('✓ [15/16] Verified Crop Category & Harvest Type separation, Crop Age calculation (Oct 1 to Oct 20 = 19 days), and past Expected Harvest Date handling.');

  // 16. Home Page Monthly Farm Accounting & Single/Repeated Harvest (Kg & Quintal) Verification
  const brinjalCrop: CropCycle = {
    id: 'crop-brinjal-home',
    name: 'Brinjal (बैंगन)',
    hindiName: 'बैंगन (Brinjal)',
    landArea: 1,
    areaUnit: 'acre',
    season: 'kharif',
    cropCategory: 'vegetable',
    accountingType: 'recurring',
    sowingDate: '2025-08-01',
    status: 'active',
    createdAt: '2025-08-01T08:00:00Z',
    updatedAt: '2025-08-01T08:00:00Z'
  };

  const brinjalSeptTx: Transaction[] = [
    {
      id: 'br-sep-exp-1',
      cropId: 'crop-brinjal-home',
      type: 'expense',
      category: 'fertilizer',
      title: 'NPK & Micronutrients',
      amount: 1500,
      date: '2025-09-05',
      time: '09:00',
      paymentStatus: 'paid',
      createdAt: '2025-09-05T09:00:00Z'
    },
    {
      id: 'br-sep-exp-2',
      cropId: 'crop-brinjal-home',
      type: 'expense',
      category: 'pesticide',
      title: 'Borer Spray',
      amount: 1200,
      date: '2025-09-12',
      time: '10:00',
      paymentStatus: 'paid',
      createdAt: '2025-09-12T10:00:00Z'
    },
    {
      id: 'br-sep-exp-3',
      cropId: 'crop-brinjal-home',
      type: 'expense',
      category: 'transport',
      title: 'Mandi Tempo Transport',
      amount: 1300,
      date: '2025-09-18',
      time: '14:00',
      paymentStatus: 'paid',
      createdAt: '2025-09-18T14:00:00Z'
    },
    {
      id: 'br-sep-sale-1',
      cropId: 'crop-brinjal-home',
      type: 'income',
      category: 'mandi_sale',
      title: 'Brinjal Mandi Sale #1',
      amount: 5000,
      date: '2025-09-10',
      time: '13:00',
      paymentStatus: 'paid',
      createdAt: '2025-09-10T13:00:00Z'
    },
    {
      id: 'br-sep-sale-2',
      cropId: 'crop-brinjal-home',
      type: 'income',
      category: 'mandi_sale',
      title: 'Brinjal Mandi Sale #2',
      amount: 4000,
      date: '2025-09-20',
      time: '15:00',
      paymentStatus: 'paid',
      createdAt: '2025-09-20T15:00:00Z'
    }
  ];

  // Unsold harvest in kg (e.g. 85 kg = 0.85 quintal) — must NEVER be counted as sales money!
  const brinjalHarvests: HarvestEntry[] = [
    {
      id: 'br-hrv-kg-1',
      cropId: 'crop-brinjal-home',
      date: '2025-09-25',
      time: '08:30',
      quantityValue: 85,
      quantityUnit: 'kg',
      quantityQuintal: 0.85,
      notes: 'Picked 85 kg brinjal (unsold batch)'
    }
  ];

  // Calculate Home Page Monthly Farm Accounting for September 2025 across Chilli + Brinjal + Wheat
  const homeSeptSummary = calculateMonthlyFarmAccounting(
    [legacyWheatCrop, chilliCrop, brinjalCrop],
    [...wheatMonthlyTx, ...chilliTx, ...brinjalSeptTx, brinjalSeptTx[0]], // includes duplicate to test deduplication
    [...wheatHarvests, ...chilliHarvests, ...brinjalHarvests],
    '2025-09'
  );

  assert.equal(homeSeptSummary.monthKey, '2025-09');
  // In Sept 2025: Chilli has Expenses 5,000 & Sales 42,000 (Profit +37,000); Brinjal has Expenses 4,000 & Sales 9,000 (Profit +5,000)
  assert.equal(homeSeptSummary.totalExpenses, 9000, 'Total farm Sept expenses should be 5000 + 4000 = 9000');
  assert.equal(homeSeptSummary.totalSales, 51000, 'Total farm Sept sales should be 42000 + 9000 = 51000');
  assert.equal(homeSeptSummary.netProfit, 42000, 'Total farm Sept net profit should be 51000 - 9000 = 42000');
  assert.equal(homeSeptSummary.cropSummaries.length, 2, 'Only Chilli and Brinjal had entries in Sept 2025');

  const brinjalCropMonth = homeSeptSummary.cropSummaries.find((c) => c.crop.id === 'crop-brinjal-home');
  assert.ok(brinjalCropMonth, 'Brinjal monthly summary must be present');
  assert.equal(brinjalCropMonth.expensesTotal, 4000, 'Brinjal expenses = 1500 + 1200 + 1300 = 4000');
  assert.equal(brinjalCropMonth.salesTotal, 9000, 'Brinjal sales = 5000 + 4000 = 9000 (unsold harvest never counted as sale)');
  assert.equal(brinjalCropMonth.netProfit, 5000, 'Brinjal profit = 9000 - 4000 = 5000');
  assert.equal(brinjalCropMonth.expensesByCategory.fertilizer, 1500);
  assert.equal(brinjalCropMonth.expensesByCategory.pesticide, 1200);
  assert.equal(brinjalCropMonth.expensesByCategory.transport, 1300);
  assert.equal(brinjalCropMonth.harvestQuintal, 0.85, '85 kg harvest equals 0.85 quintal');

  console.log('✓ [16/16] Verified Home Page Monthly Farm Accounting (monthly totals, crop-wise summary, category breakdown, deduplication, and unsold harvests never counted as sales).');
  console.log('=== ALL 16 AUTOMATED VERIFICATION SUITES PASSED ===');
}

runVerification().catch((err) => {
  console.error(err);
  process.exit(1);
});



