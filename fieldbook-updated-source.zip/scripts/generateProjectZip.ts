import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const ROOT_DIR = process.cwd();
const OUTPUT_UPDATED_SOURCE_ROOT = path.join(ROOT_DIR, 'FieldBook-Updated-Source.zip');
const OUTPUT_UPDATED_SOURCE_PUBLIC = path.join(
  ROOT_DIR,
  'public',
  'FieldBook-Updated-Source.zip'
);

const EXCLUDED_DIRS = new Set([
  'node_modules',
  'dist',
  '.git',
  '.gradle',
  'build',
  '.idea',
  '.aistudio',
  'artifacts'
]);

const EXCLUDED_FILES = new Set([
  'FieldBook-Updated-Source.zip',
  'FieldBook-Public-Version-APK.zip',
  'FieldBook-Release-Ready-Complete-Source.zip',
  'FieldBook-Complete-GitHub-APK.zip',
  'FieldBook-Full-Security-Audit-Report.pdf',
  'FieldBook-Kisan-App.apk',
  'FieldBook-Kisan-App-Debug.apk',
  'FieldBook-Kisan-App-Release-Signed.apk',
  'FieldBook-Kisan-App-Release-Unsigned.apk',
  '.DS_Store',
  '.env',
  '.env.local',
  '.env.production',
  'local.properties'
]);

function isExcludedByExtension(fileName: string): boolean {
  const lower = fileName.toLowerCase();
  return (
    lower.endsWith('.apk') ||
    lower.endsWith('.aab') ||
    lower.endsWith('.zip') ||
    lower.endsWith('.pdf') ||
    lower.endsWith('.jks') ||
    lower.endsWith('.keystore') ||
    lower.endsWith('.p12') ||
    lower.endsWith('.pfx')
  );
}

function addDirectoryToZip(zip: JSZip, dirPath: string, relativePrefix = ''): number {
  let count = 0;
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    if (EXCLUDED_FILES.has(entry.name) || isExcludedByExtension(entry.name)) continue;

    const fullPath = path.join(dirPath, entry.name);
    const relPath = relativePrefix ? `${relativePrefix}/${entry.name}` : entry.name;

    // Skip uploaded raw AI Studio media folder inside public/assets/aistudio or android assets to keep ZIP clean & private
    if (relPath.includes('assets/aistudio')) continue;

    if (entry.isDirectory()) {
      if (EXCLUDED_DIRS.has(entry.name)) continue;
      if (relPath.startsWith('android/app/build')) continue;
      count += addDirectoryToZip(zip, fullPath, relPath);
    } else if (entry.isFile()) {
      const data = fs.readFileSync(fullPath);
      const isExecutable = entry.name === 'gradlew' || entry.name.endsWith('.sh');
      zip.file(relPath, data, {
        unixPermissions: isExecutable ? '755' : '644'
      });
      count++;
    }
  }
  return count;
}

async function main() {
  console.log('=== Packaging FieldBook-Updated-Source.zip ===');

  // Remove old legacy duplicate zips if present
  for (const legacy of [
    path.join(ROOT_DIR, 'FieldBook-Public-Version-APK.zip'),
    path.join(ROOT_DIR, 'public', 'FieldBook-Public-Version-APK.zip'),
    path.join(ROOT_DIR, 'FieldBook-Release-Ready-Complete-Source.zip'),
    path.join(ROOT_DIR, 'public', 'FieldBook-Release-Ready-Complete-Source.zip'),
    path.join(ROOT_DIR, 'FieldBook-Complete-GitHub-APK.zip'),
    path.join(ROOT_DIR, 'public', 'FieldBook-Complete-GitHub-APK.zip')
  ]) {
    if (fs.existsSync(legacy)) {
      fs.rmSync(legacy, { force: true });
    }
  }

  const zip = new JSZip();
  const totalFiles = addDirectoryToZip(zip, ROOT_DIR);

  const requiredFiles = [
    'package.json',
    'package-lock.json',
    '.env.example',
    'index.html',
    'vite.config.ts',
    'tsconfig.json',
    'capacitor.config.json',
    'public/logo.png',
    'public/farm-bg.jpg',
    'public/pwa-192x192.png',
    'public/pwa-512x512.png',
    '.github/workflows/build-apk.yml',
    'scripts/verify-fieldbook.ts',
    'src/App.tsx',
    'src/main.tsx',
    'src/index.css',
    'src/types/index.ts',
    'src/components/CropDetailView.tsx',
    'src/components/AddCropModal.tsx',
    'src/utils/export.ts',
    'src/utils/platform.ts',
    'src/utils/storage.ts',
    'src/utils/receiptStorage.ts',
    'src/utils/calculations.ts',
    'android/gradlew',
    'android/build.gradle',
    'android/app/build.gradle',
    'android/app/proguard-rules.pro',
    'android/app/src/main/AndroidManifest.xml',
    'android/app/src/main/java/com/fieldbook/kisan/MainActivity.java',
    'android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png',
    'android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.png'
  ];

  for (const reqFile of requiredFiles) {
    if (!zip.file(reqFile)) {
      throw new Error(`CRITICAL MISSING FILE IN ZIP: ${reqFile}`);
    }
  }

  // Verify removed files are NOT present in the archive
  for (const forbidden of [
    'src/components/ProfileSetupModal.tsx',
    'src/utils/tracker.ts',
    'BACKEND-TRACKER-CONTRACT.md'
  ]) {
    if (zip.file(forbidden)) {
      throw new Error(`FORBIDDEN FILE PRESENT IN ZIP: ${forbidden}`);
    }
  }

  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
    platform: 'UNIX'
  });

  fs.mkdirSync(path.dirname(OUTPUT_UPDATED_SOURCE_PUBLIC), { recursive: true });
  fs.writeFileSync(OUTPUT_UPDATED_SOURCE_ROOT, buffer);
  fs.writeFileSync(OUTPUT_UPDATED_SOURCE_PUBLIC, buffer);

  const sizeMB = (buffer.length / (1024 * 1024)).toFixed(2);
  console.log(`✓ Packed ${totalFiles} files (${sizeMB} MB) into:`);
  console.log(`  1. ${OUTPUT_UPDATED_SOURCE_ROOT}`);
  console.log(`  2. ${OUTPUT_UPDATED_SOURCE_PUBLIC}`);
  console.log(
    `✓ Verified all ${requiredFiles.length} critical files inside FieldBook-Updated-Source.zip and confirmed Profile/Tracker files are absent.`
  );
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});

