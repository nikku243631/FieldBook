package com.fieldbook.kisan;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import java.util.Map;
import org.json.JSONObject;

/**
 * Native Android BroadcastReceiver triggered by AlarmManager at the exact
 * date and time selected by the farmer in FieldBook Reminders, AND on
 * BOOT_COMPLETED / MY_PACKAGE_REPLACED to automatically reschedule saved alarms.
 */
public class ReminderAlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "fieldbook_farm_reminders_v1";
    public static final String PREFS_NAME = "fieldbook_native_alarms_prefs_v1";
    public static final String EXTRA_NOTE_ID = "noteId";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_BODY = "body";

    public static void saveAlarmToPrefs(
            Context context,
            String noteId,
            String title,
            String body,
            long triggerAtMillis
    ) {
        if (context == null || noteId == null || noteId.trim().isEmpty()) {
            return;
        }
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            JSONObject obj = new JSONObject();
            obj.put("noteId", noteId);
            obj.put("title", title != null ? title : "");
            obj.put("body", body != null ? body : "");
            obj.put("triggerAtMillis", triggerAtMillis);
            prefs.edit().putString(noteId, obj.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static void removeAlarmFromPrefs(Context context, String noteId) {
        if (context == null || noteId == null || noteId.trim().isEmpty()) {
            return;
        }
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().remove(noteId).apply();
        } catch (Exception ignored) {
        }
    }

    public static boolean scheduleExactAlarm(
            Context context,
            String noteId,
            String title,
            String body,
            long triggerAtMillis
    ) {
        if (context == null || noteId == null || noteId.trim().isEmpty()) {
            return false;
        }
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmManager == null) {
                return false;
            }

            Intent intent = new Intent(context, ReminderAlarmReceiver.class);
            intent.putExtra(EXTRA_NOTE_ID, noteId);
            intent.putExtra(EXTRA_TITLE, title);
            intent.putExtra(EXTRA_BODY, body);

            int requestCode = Math.abs(noteId.hashCode());
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }

            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    intent,
                    flags
            );

            long safeTriggerMs = Math.max(triggerAtMillis, System.currentTimeMillis() + 1000L);

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTriggerMs, pendingIntent);
                } else {
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, safeTriggerMs, pendingIntent);
                }
            } catch (SecurityException se) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTriggerMs, pendingIntent);
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, safeTriggerMs, pendingIntent);
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void rescheduleAllSavedAlarms(Context context) {
        if (context == null) {
            return;
        }
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            Map<String, ?> allEntries = prefs.getAll();
            if (allEntries == null || allEntries.isEmpty()) {
                return;
            }
            long now = System.currentTimeMillis();
            for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
                Object rawVal = entry.getValue();
                if (!(rawVal instanceof String)) {
                    continue;
                }
                try {
                    JSONObject obj = new JSONObject((String) rawVal);
                    String noteId = obj.optString("noteId", entry.getKey());
                    String title = obj.optString("title", "⏰ FieldBook खेत रिमाइंडर");
                    String body = obj.optString("body", "आपके खेत कार्य का समय हो गया है।");
                    long triggerAtMillis = obj.optLong("triggerAtMillis", 0L);

                    if (triggerAtMillis > now - 60000L) {
                        scheduleExactAlarm(context, noteId, title, body, triggerAtMillis);
                    } else {
                        prefs.edit().remove(entry.getKey()).apply();
                    }
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) {
            return;
        }

        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || "android.intent.action.QUICKBOOT_POWERON".equals(action)
                || "com.htc.intent.action.QUICKBOOT_POWERON".equals(action)) {
            rescheduleAllSavedAlarms(context);
            return;
        }

        String noteId = intent.getStringExtra(EXTRA_NOTE_ID);
        String title = intent.getStringExtra(EXTRA_TITLE);
        String body = intent.getStringExtra(EXTRA_BODY);

        if (noteId != null && !noteId.trim().isEmpty()) {
            removeAlarmFromPrefs(context, noteId);
        }

        if (title == null || title.trim().isEmpty()) {
            title = "⏰ FieldBook खेत रिमाइंडर";
        }
        if (body == null || body.trim().isEmpty()) {
            body = "आपके खेत कार्य का समय हो गया है।";
        }

        NotificationManager notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager == null) {
            return;
        }

        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (alarmSound == null) {
            alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "FieldBook Farm Reminders & Alarms",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Scheduled farm reminders, irrigation alerts, and mandi payment alarms");
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 350, 150, 350, 150, 500});
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            if (alarmSound != null) {
                AudioAttributes audioAttributes = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();
                channel.setSound(alarmSound, audioAttributes);
            }
            notificationManager.createNotificationChannel(channel);
        }

        Intent launchIntent = new Intent(context, MainActivity.class);
        launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (noteId != null) {
            launchIntent.putExtra(EXTRA_NOTE_ID, noteId);
        }

        int requestCode = noteId != null ? Math.abs(noteId.hashCode()) : (int) (System.currentTimeMillis() & 0xfffffff);
        int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
        }

        PendingIntent contentPendingIntent = PendingIntent.getActivity(
                context,
                requestCode,
                launchIntent,
                pendingFlags
        );

        int smallIcon = context.getApplicationInfo().icon;
        if (smallIcon == 0) {
            smallIcon = android.R.drawable.ic_lock_idle_alarm;
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(smallIcon)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setVibrate(new long[]{0, 350, 150, 350, 150, 500})
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setContentIntent(contentPendingIntent);

        if (alarmSound != null) {
            builder.setSound(alarmSound);
        }

        notificationManager.notify(requestCode, builder.build());
    }
}
