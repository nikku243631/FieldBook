import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Calendar,
  Clock,
  ShoppingCart,
  IndianRupee,
  Tag,
  User,
  FileText,
  Paperclip,
  Camera,
  Image as ImageIcon,
  Eye,
  RefreshCw,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { Transaction, ReceiptAttachment, Language, Theme } from '../types';
import { getTranslation } from '../utils/translations';
import {
  ReceiptStorage,
  processSelectedReceiptFile,
  buildSyncedReceiptAttachment
} from '../utils/receiptStorage';
import { ReceiptViewerModal } from './ReceiptViewerModal';

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (tx: Partial<Transaction>) => void;
  onCreateSmartReminder?: (reminder: {
    title: string;
    content: string;
    date: string;
    time: string;
    category: 'reminder' | 'spray' | 'field_work';
  }) => void;
  cropId: string;
  cropName?: string;
  defaultType?: 'expense' | 'income';
  txToEdit?: Transaction | null;
  lang: Language;
  theme: Theme;
}

function addDaysToYMD(baseDateStr: string, days: number): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(baseDateStr);
  const d = match
    ? new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]))
    : new Date();
  d.setDate(d.getDate() + days);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onCreateSmartReminder,
  cropId,
  cropName,
  defaultType = 'expense',
  txToEdit,
  lang
}) => {
  const [type, setType] = useState<'expense' | 'income'>(defaultType);
  const [category, setCategory] = useState<string>(
    defaultType === 'expense' ? 'fertilizer' : 'mandi_sale'
  );
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState<number | ''>('');

  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const timeStr = now.toTimeString().slice(0, 5);
  const [date, setDate] = useState(todayStr);
  const [time, setTime] = useState(timeStr);

  const [quantity, setQuantity] = useState<number | ''>('');
  const [unit, setUnit] = useState('');
  const [ratePerUnit, setRatePerUnit] = useState<number | ''>('');
  const [vendorOrBuyer, setVendorOrBuyer] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<'paid' | 'pending'>('paid');

  // Smart Next Irrigation / Spray Reminder state
  const [enableSmartReminder, setEnableSmartReminder] = useState<boolean>(false);
  const [smartReminderDays, setSmartReminderDays] = useState<number>(15);
  const [smartReminderDate, setSmartReminderDate] = useState<string>(() =>
    addDaysToYMD(todayStr, 15)
  );
  const [smartReminderTime, setSmartReminderTime] = useState<string>('08:00');

  // Mandi specific fields
  const [mandiGrossWeightKg, setMandiGrossWeightKg] = useState<number | ''>('');
  const [mandiTareWeightKg, setMandiTareWeightKg] = useState<number | ''>('');
  const [mandiNetWeightQuintal, setMandiNetWeightQuintal] = useState<number | ''>('');
  const [mandiRatePerQuintal, setMandiRatePerQuintal] = useState<number | ''>('');
  const [mandiPalledariPerQuintal, setMandiPalledariPerQuintal] = useState<number | ''>('');
  const [mandiBuyerName, setMandiBuyerName] = useState('');
  const [mandiReceiptNumber, setMandiReceiptNumber] = useState('');

  // Optional Bill / Receipt Attachment states
  const [existingAttachment, setExistingAttachment] = useState<ReceiptAttachment | null>(null);
  const [pendingAttachmentMeta, setPendingAttachmentMeta] = useState<{
    fileName: string;
    mimeType: string;
    fileSize: number;
  } | null>(null);
  const [attachmentDataUrl, setAttachmentDataUrl] = useState<string | null>(null);
  const [isAttachmentRemoved, setIsAttachmentRemoved] = useState<boolean>(false);
  const [attachmentError, setAttachmentError] = useState<string | null>(null);
  const [isProcessingFile, setIsProcessingFile] = useState<boolean>(false);
  const [isSavingTx, setIsSavingTx] = useState<boolean>(false);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState<boolean>(false);

  const galleryInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const pdfInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    setAttachmentError(null);
    setIsProcessingFile(false);
    setIsSavingTx(false);
    setIsPreviewModalOpen(false);
    setEnableSmartReminder(false);
    setSmartReminderDays(15);
    setSmartReminderDate(addDaysToYMD(new Date().toISOString().split('T')[0], 15));
    setSmartReminderTime('08:00');

    if (txToEdit) {
      setType(txToEdit.type);
      setCategory(txToEdit.category);
      setTitle(txToEdit.title || '');
      setAmount(txToEdit.amount ?? '');
      setDate(txToEdit.date || new Date().toISOString().split('T')[0]);
      setTime(txToEdit.time || new Date().toTimeString().slice(0, 5));
      setQuantity(txToEdit.quantity ?? '');
      setUnit(txToEdit.unit || '');
      setRatePerUnit(txToEdit.ratePerUnit ?? '');
      setVendorOrBuyer(txToEdit.vendorOrBuyer || '');
      setNotes(txToEdit.notes || '');
      setPaymentStatus(txToEdit.paymentStatus || 'paid');
      setMandiGrossWeightKg(txToEdit.mandiDetails?.grossWeightKg ?? '');
      setMandiTareWeightKg(txToEdit.mandiDetails?.tareWeightKg ?? '');
      setMandiNetWeightQuintal(txToEdit.mandiDetails?.netWeightQuintal ?? '');
      setMandiRatePerQuintal(txToEdit.mandiDetails?.ratePerQuintal ?? '');
      setMandiPalledariPerQuintal(txToEdit.mandiDetails?.palledariPerQuintal ?? '');
      setMandiBuyerName(txToEdit.mandiDetails?.buyerName || txToEdit.vendorOrBuyer || '');
      setMandiReceiptNumber(txToEdit.mandiDetails?.receiptNumber || '');

      if (txToEdit.receiptAttachment) {
        setExistingAttachment(txToEdit.receiptAttachment);
        setPendingAttachmentMeta(null);
        setIsAttachmentRemoved(false);
        ReceiptStorage.getReceipt(txToEdit.receiptAttachment.storageRef).then((stored) => {
          setAttachmentDataUrl(stored?.dataUrl || null);
        });
      } else {
        setExistingAttachment(null);
        setPendingAttachmentMeta(null);
        setAttachmentDataUrl(null);
        setIsAttachmentRemoved(false);
      }
    } else {
      const currentNow = new Date();
      setType(defaultType);
      setCategory(defaultType === 'expense' ? 'fertilizer' : 'mandi_sale');
      setTitle('');
      setAmount('');
      setDate(currentNow.toISOString().split('T')[0]);
      setTime(currentNow.toTimeString().slice(0, 5));
      setQuantity('');
      setUnit('');
      setRatePerUnit('');
      setVendorOrBuyer('');
      setNotes('');
      setPaymentStatus('paid');
      setMandiGrossWeightKg('');
      setMandiTareWeightKg('');
      setMandiNetWeightQuintal('');
      setMandiRatePerQuintal('');
      setMandiPalledariPerQuintal('');
      setMandiBuyerName('');
      setMandiReceiptNumber('');
      setExistingAttachment(null);
      setPendingAttachmentMeta(null);
      setAttachmentDataUrl(null);
      setIsAttachmentRemoved(false);
    }
  }, [isOpen, defaultType, txToEdit]);

  if (!isOpen) return null;

  const calculateMandiTotal = (netQ: number, rateQ: number, palledariQ: number) => {
    if (!netQ || !rateQ || netQ <= 0 || rateQ <= 0) return;
    const grossVal = netQ * rateQ;
    const palledariDeduction = Math.max(0, palledariQ || 0) * netQ;
    const netPayout = Math.max(0, grossVal - palledariDeduction);
    setAmount(Math.round(netPayout));
  };

  const handleMandiWeightChange = (grossKg: number, tareKg: number) => {
    const netKg = Math.max(0, grossKg - tareKg);
    const netQ = Number((netKg / 100).toFixed(2));
    setMandiNetWeightQuintal(netQ);
    if (mandiRatePerQuintal) {
      calculateMandiTotal(netQ, Number(mandiRatePerQuintal), Number(mandiPalledariPerQuintal));
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    // Reset input value so the user can re-select the same file if needed
    e.target.value = '';
    if (!file) {
      // User cancelled selection — preserve current state gracefully
      return;
    }

    setAttachmentError(null);
    setIsProcessingFile(true);
    try {
      const processed = await processSelectedReceiptFile(file);
      if (!processed.success || !processed.dataUrl) {
        setAttachmentError(
          lang === 'hi'
            ? processed.errorHi || 'बिल फाइल जोड़ने में समस्या आई।'
            : processed.errorEn || 'Failed to attach receipt file.'
        );
        return;
      }

      setPendingAttachmentMeta({
        fileName: processed.fileName || file.name,
        mimeType: processed.mimeType || file.type || 'image/jpeg',
        fileSize: processed.fileSize || file.size
      });
      setAttachmentDataUrl(processed.dataUrl);
      setIsAttachmentRemoved(false);
    } finally {
      setIsProcessingFile(false);
    }
  };

  const handleRemoveAttachment = () => {
    setPendingAttachmentMeta(null);
    setAttachmentDataUrl(null);
    setIsAttachmentRemoved(true);
    setAttachmentError(null);
  };

  const hasActiveAttachment =
    !isAttachmentRemoved && Boolean(pendingAttachmentMeta || existingAttachment);

  const displayedAttachmentName =
    pendingAttachmentMeta?.fileName || existingAttachment?.fileName || '';
  const displayedAttachmentMime =
    pendingAttachmentMeta?.mimeType || existingAttachment?.mimeType || '';
  const displayedAttachmentSize =
    pendingAttachmentMeta?.fileSize || existingAttachment?.fileSize || 0;
  const isDisplayedPdf =
    displayedAttachmentMime === 'application/pdf' ||
    displayedAttachmentName.toLowerCase().endsWith('.pdf');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || Number(amount) <= 0 || isSavingTx) return;

    setAttachmentError(null);
    setIsSavingTx(true);

    try {
      const resolvedTxId = txToEdit?.id || `tx-${Date.now()}`;
      const resolvedAmount = Math.round(Number(amount));
      const defaultTitle =
        title.trim() ||
        (type === 'expense'
          ? getTranslation(lang, category as any)
          : getTranslation(lang, category as any));

      let finalReceiptAttachment: ReceiptAttachment | undefined = undefined;

      if (isAttachmentRemoved) {
        if (existingAttachment?.storageRef) {
          await ReceiptStorage.deleteReceipt(existingAttachment.storageRef);
        }
        finalReceiptAttachment = undefined;
      } else if (pendingAttachmentMeta && attachmentDataUrl) {
        // New or replaced attachment — link directly to this transaction
        const storageRef = existingAttachment?.storageRef || `rcpt-${resolvedTxId}`;
        const builtAttachment = buildSyncedReceiptAttachment(
          {
            id: resolvedTxId,
            cropId,
            type,
            category,
            title: defaultTitle,
            amount: resolvedAmount,
            date
          },
          {
            id: storageRef,
            storageRef,
            fileName: pendingAttachmentMeta.fileName,
            mimeType: pendingAttachmentMeta.mimeType,
            fileSize: pendingAttachmentMeta.fileSize,
            createdAt: existingAttachment?.createdAt
          }
        );

        const savedOk = await ReceiptStorage.saveReceipt(builtAttachment, attachmentDataUrl);
        if (!savedOk) {
          setAttachmentError(
            lang === 'hi'
              ? 'बिल/रसीद को स्टोरेज में सेव नहीं किया जा सका। कृपया फाइल का आकार जांचें या पुनः प्रयास करें।'
              : 'Failed to save receipt attachment to storage. Please check storage space and try again.'
          );
          setIsSavingTx(false);
          return;
        }
        finalReceiptAttachment = builtAttachment;
      } else if (existingAttachment) {
        // Keep existing attachment linked and sync its metadata with any edited transaction fields
        const syncedExisting = buildSyncedReceiptAttachment(
          {
            id: resolvedTxId,
            cropId,
            type,
            category,
            title: defaultTitle,
            amount: resolvedAmount,
            date
          },
          {
            id: existingAttachment.id,
            storageRef: existingAttachment.storageRef,
            fileName: existingAttachment.fileName,
            mimeType: existingAttachment.mimeType,
            fileSize: existingAttachment.fileSize,
            createdAt: existingAttachment.createdAt
          }
        );
        if (attachmentDataUrl) {
          const savedOk = await ReceiptStorage.saveReceipt(syncedExisting, attachmentDataUrl);
          if (!savedOk) {
            setAttachmentError(
              lang === 'hi'
                ? 'रसीद अपडेट करने में समस्या आई। कृपया पुनः प्रयास करें।'
                : 'Failed to update receipt attachment. Please try again.'
            );
            setIsSavingTx(false);
            return;
          }
        }
        finalReceiptAttachment = syncedExisting;
      }

      const txData: Partial<Transaction> = {
        id: resolvedTxId,
        cropId,
        type,
        category: category as any,
        title: defaultTitle,
        amount: resolvedAmount,
        date,
        time,
        quantity: quantity && Number(quantity) > 0 ? Number(quantity) : undefined,
        unit: unit.trim() || undefined,
        ratePerUnit: ratePerUnit && Number(ratePerUnit) > 0 ? Number(ratePerUnit) : undefined,
        vendorOrBuyer: (vendorOrBuyer || mandiBuyerName).trim() || undefined,
        notes: notes.trim() || undefined,
        paymentStatus,
        receiptAttachment: finalReceiptAttachment
      };

      if (category === 'mandi_sale') {
        const netQ = Number(mandiNetWeightQuintal) || (quantity ? Number(quantity) : 0);
        const rateQ = Number(mandiRatePerQuintal) || (ratePerUnit ? Number(ratePerUnit) : 0);
        const palledariQ = Math.max(0, Number(mandiPalledariPerQuintal) || 0);
        txData.mandiDetails = {
          grossWeightKg: mandiGrossWeightKg ? Number(mandiGrossWeightKg) : undefined,
          tareWeightKg: mandiTareWeightKg ? Number(mandiTareWeightKg) : undefined,
          netWeightQuintal: netQ,
          ratePerQuintal: rateQ,
          palledariPerQuintal: palledariQ,
          totalPalledari: Math.round(palledariQ * netQ),
          buyerName: mandiBuyerName.trim() || undefined,
          receiptNumber: mandiReceiptNumber.trim() || undefined
        };
      }

      onSave(txData);

      if (
        !txToEdit &&
        enableSmartReminder &&
        type === 'expense' &&
        (category === 'irrigation' || category === 'pesticide') &&
        onCreateSmartReminder &&
        smartReminderDate
      ) {
        const isIrr = category === 'irrigation';
        const cropLabel = cropName ? ` (${cropName})` : '';
        onCreateSmartReminder({
          title: isIrr
            ? `💧 अगली सिंचाई रिमाइंडर${cropLabel}`
            : `🧪 अगला स्प्रे / छिड़काव रिमाइंडर${cropLabel}`,
          content: isIrr
            ? `${cropName || 'फसल'} में पिछली सिंचाई ${date} को की गई थी। आज अगली सिंचाई (${smartReminderDays} दिन बाद) का समय है।`
            : `${cropName || 'फसल'} में पिछला स्प्रे (${defaultTitle}) ${date} को किया गया था। आज अगले छिड़काव (${smartReminderDays} दिन बाद) की जांच करें।`,
          date: smartReminderDate,
          time: smartReminderTime || '08:00',
          category: 'reminder'
        });
      }

      onClose();
    } finally {
      setIsSavingTx(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/60 backdrop-blur-md overflow-y-auto">
      <div className="liquid-glass-modal w-full max-w-lg rounded-3xl p-4 sm:p-5 my-4 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 mb-3 border-b-2 border-emerald-500/30">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white shrink-0 ${
                type === 'expense' ? 'btn-3d-rose' : 'liquid-glass-emerald'
              }`}
            >
              <IndianRupee className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-950 dark:text-white leading-tight">
                {txToEdit
                  ? lang === 'hi'
                    ? 'प्रविष्टि संशोधित करें (Edit Entry)'
                    : 'Edit Transaction'
                  : type === 'expense'
                  ? getTranslation(lang, 'addExpense')
                  : getTranslation(lang, 'addIncome')}
              </h2>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-300">
                {lang === 'hi'
                  ? '✍️ नीचे दिए रंगीन बॉक्स में रकम और विवरण दर्ज करें'
                  : '✍️ Enter amount and item details in the 3D boxes below'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        {/* 3D Liquid Glass Type Switcher (लागत vs कमाई) */}
        <div className="grid grid-cols-2 gap-2.5 p-1.5 mb-3.5 rounded-2xl liquid-glass-pill">
          <button
            type="button"
            onClick={() => {
              setType('expense');
              setCategory('fertilizer');
            }}
            className={`py-2.5 text-xs sm:text-sm font-extrabold rounded-xl transition-all cursor-pointer ${
              type === 'expense'
                ? 'btn-3d-rose text-white'
                : 'bg-white/85 dark:bg-slate-900/80 text-rose-900 dark:text-rose-200 border border-rose-300'
            }`}
          >
            🔴 {getTranslation(lang, 'expenses')}
          </button>
          <button
            type="button"
            onClick={() => {
              setType('income');
              setCategory('mandi_sale');
            }}
            className={`py-2.5 text-xs sm:text-sm font-extrabold rounded-xl transition-all cursor-pointer ${
              type === 'income'
                ? 'liquid-glass-emerald text-white'
                : 'bg-white/85 dark:bg-slate-900/80 text-emerald-950 dark:text-emerald-200 border border-emerald-300'
            }`}
          >
            🟢 {getTranslation(lang, 'income')}
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* Primary Section: Category, Description & Amount */}
          <div
            className={`rounded-2xl p-3.5 space-y-3 ${
              type === 'expense' ? 'liquid-glass-expense' : 'liquid-glass-income'
            }`}
          >
            {/* Category Dropdown */}
            <div>
              <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5 mb-1.5">
                <Tag className="w-3.5 h-3.5 text-rose-700 dark:text-rose-300" />
                <span>
                  {type === 'expense' ? 'खर्च की श्रेणी (Category)' : 'कमाई का जरिया (Source)'}
                </span>
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl text-sm font-extrabold text-slate-950 dark:text-white ${
                  type === 'expense' ? 'input-3d-rose' : 'liquid-glass-input'
                }`}
              >
                {type === 'expense' ? (
                  <>
                    <option value="fertilizer">{getTranslation(lang, 'fertilizer')}</option>
                    <option value="seeds">{getTranslation(lang, 'seeds')}</option>
                    <option value="pesticide">{getTranslation(lang, 'pesticide')}</option>
                    <option value="irrigation">{getTranslation(lang, 'irrigation')}</option>
                    <option value="labour">{getTranslation(lang, 'labour')}</option>
                    <option value="transport">{getTranslation(lang, 'transport')}</option>
                    <option value="machinery">{getTranslation(lang, 'machinery')}</option>
                    <option value="other">{getTranslation(lang, 'other')}</option>
                  </>
                ) : (
                  <>
                    <option value="mandi_sale">{getTranslation(lang, 'mandi_sale')}</option>
                    <option value="local_sale">{getTranslation(lang, 'local_sale')}</option>
                    <option value="subsidy">{getTranslation(lang, 'subsidy')}</option>
                    <option value="byproduct">{getTranslation(lang, 'byproduct')}</option>
                  </>
                )}
              </select>
            </div>

            {/* Description Title & Amount */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  ✍️ {getTranslation(lang, 'transactionTitle')}
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={
                    type === 'expense'
                      ? lang === 'hi'
                        ? 'जैसे: 2 बोरी DAP खाद'
                        : 'e.g. 2 Bags DAP'
                      : lang === 'hi'
                      ? 'जैसे: 20 क्विंटल बिक्री'
                      : 'e.g. 20 Quintal Sale'
                  }
                  className="liquid-glass-input w-full px-3.5 py-2.5 rounded-xl text-sm font-bold text-slate-950 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-rose-950 dark:text-rose-200 block mb-1.5">
                  💰 {getTranslation(lang, 'amount')} *
                </label>
                <input
                  type="number"
                  step="1"
                  required
                  value={amount}
                  onChange={(e) =>
                    setAmount(e.target.value === '' ? '' : parseFloat(e.target.value))
                  }
                  placeholder="₹ 2500"
                  className={`w-full px-3.5 py-2.5 rounded-xl text-base font-mono font-extrabold tabular-nums text-slate-950 dark:text-white ${
                    type === 'expense' ? 'input-3d-rose' : 'liquid-glass-input'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* Special Mandi Calculator Section */}
          {category === 'mandi_sale' && (
            <div className="p-3.5 rounded-2xl liquid-glass-income space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-extrabold text-emerald-950 dark:text-emerald-200">
                <ShoppingCart className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                <span>मंडी तौल व भाव कैलकुलेटर (Mandi Weighing & Rate)</span>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-extrabold text-slate-950 dark:text-white block mb-1">
                    कांटा कुल वजन (Gross Kg)
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="उदा. 4250"
                    value={mandiGrossWeightKg}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiGrossWeightKg(val);
                      handleMandiWeightChange(Number(val) || 0, Number(mandiTareWeightKg) || 0);
                    }}
                    className="liquid-glass-input w-full px-3 py-2 text-xs sm:text-sm rounded-xl font-mono font-bold tabular-nums"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-extrabold text-slate-950 dark:text-white block mb-1">
                    ट्रॉली/खाली वजन (Tare Kg)
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="उदा. 1250"
                    value={mandiTareWeightKg}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiTareWeightKg(val);
                      handleMandiWeightChange(Number(mandiGrossWeightKg) || 0, Number(val) || 0);
                    }}
                    className="liquid-glass-input w-full px-3 py-2 text-xs sm:text-sm rounded-xl font-mono font-bold tabular-nums"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[11px] text-slate-950 dark:text-white font-extrabold block mb-1">
                    शुद्ध वजन (क्विं.) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="30.00"
                    value={mandiNetWeightQuintal}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiNetWeightQuintal(val);
                      if (mandiRatePerQuintal) {
                        calculateMandiTotal(
                          Number(val),
                          Number(mandiRatePerQuintal),
                          Number(mandiPalledariPerQuintal)
                        );
                      }
                    }}
                    className="input-3d-amber w-full px-2.5 py-2 text-xs sm:text-sm rounded-xl font-mono font-extrabold tabular-nums"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-950 dark:text-white font-extrabold block mb-1">
                    भाव/क्विं. (₹) *
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="2275"
                    value={mandiRatePerQuintal}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiRatePerQuintal(val);
                      if (mandiNetWeightQuintal) {
                        calculateMandiTotal(
                          Number(mandiNetWeightQuintal),
                          Number(val),
                          Number(mandiPalledariPerQuintal)
                        );
                      }
                    }}
                    className="liquid-glass-input w-full px-2.5 py-2 text-xs sm:text-sm rounded-xl font-mono font-extrabold tabular-nums"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-950 dark:text-white font-extrabold block mb-1">
                    पल्लेदारी (₹)
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="15"
                    value={mandiPalledariPerQuintal}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiPalledariPerQuintal(val);
                      if (mandiNetWeightQuintal && mandiRatePerQuintal) {
                        calculateMandiTotal(
                          Number(mandiNetWeightQuintal),
                          Number(mandiRatePerQuintal),
                          Number(val)
                        );
                      }
                    }}
                    className="input-3d-rose w-full px-2.5 py-2 text-xs sm:text-sm rounded-xl font-mono font-bold tabular-nums"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] text-slate-950 dark:text-white font-extrabold block mb-1">
                    आढ़ती / फर्म नाम
                  </label>
                  <input
                    type="text"
                    placeholder="उदा. राधेश्याम ट्रेडिंग"
                    value={mandiBuyerName}
                    onChange={(e) => setMandiBuyerName(e.target.value)}
                    className="input-3d-sky w-full px-3 py-2 text-xs sm:text-sm rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-950 dark:text-white font-extrabold block mb-1">
                    पर्ची / बिल नंबर
                  </label>
                  <input
                    type="text"
                    placeholder="उदा. MND-450"
                    value={mandiReceiptNumber}
                    onChange={(e) => setMandiReceiptNumber(e.target.value)}
                    className="input-3d-sky w-full px-3 py-2 text-xs sm:text-sm rounded-xl font-mono font-bold"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Date, Time, Quantity, Unit & Rate */}
          <div className="liquid-glass-profit rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{getTranslation(lang, 'date')} *</span>
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <Clock className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{getTranslation(lang, 'time')} *</span>
                </label>
                <input
                  type="time"
                  required
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                />
              </div>
            </div>

            {category !== 'mandi_sale' && (
              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label className="text-[11px] font-extrabold text-amber-950 dark:text-amber-300 block mb-1">
                    📦 {getTranslation(lang, 'quantity')}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={quantity}
                    onChange={(e) =>
                      setQuantity(e.target.value === '' ? '' : parseFloat(e.target.value))
                    }
                    placeholder="2"
                    className="input-3d-amber w-full px-2.5 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-extrabold text-amber-950 dark:text-amber-300 block mb-1">
                    ⚖️ इकाई (Unit)
                  </label>
                  <input
                    type="text"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    placeholder="बोरी / kg"
                    className="input-3d-amber w-full px-2.5 py-2 rounded-xl text-xs sm:text-sm font-bold"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-extrabold text-amber-950 dark:text-amber-300 block mb-1">
                    🏷️ दर (Rate)
                  </label>
                  <input
                    type="number"
                    step="1"
                    value={ratePerUnit}
                    onChange={(e) =>
                      setRatePerUnit(e.target.value === '' ? '' : parseFloat(e.target.value))
                    }
                    placeholder="₹1350"
                    className="input-3d-amber w-full px-2.5 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Vendor / Buyer & Payment Status & Notes */}
          <div className="liquid-glass-income rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {category !== 'mandi_sale' && (
                <div>
                  <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                    <User className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{getTranslation(lang, 'vendorOrBuyer')}</span>
                  </label>
                  <input
                    type="text"
                    value={vendorOrBuyer}
                    onChange={(e) => setVendorOrBuyer(e.target.value)}
                    placeholder={lang === 'hi' ? 'दुकानदार या मजदूर का नाम' : 'Vendor/Labour name'}
                    className="liquid-glass-input w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-bold"
                  />
                </div>
              )}

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  💳 {getTranslation(lang, 'paymentStatus')}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentStatus('paid')}
                    className={`py-2 text-xs font-extrabold rounded-xl transition-all cursor-pointer ${
                      paymentStatus === 'paid'
                        ? 'liquid-glass-emerald text-white'
                        : 'bg-white/90 dark:bg-slate-900/90 text-slate-950 dark:text-white border-2 border-emerald-500/60'
                    }`}
                  >
                    ✓ {getTranslation(lang, 'paid')}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentStatus('pending')}
                    className={`py-2 text-xs font-extrabold rounded-xl transition-all cursor-pointer ${
                      paymentStatus === 'pending'
                        ? 'btn-3d-amber text-white'
                        : 'bg-white/90 dark:bg-slate-900/90 text-slate-950 dark:text-white border-2 border-amber-500/60'
                    }`}
                  >
                    ⏳ {getTranslation(lang, 'pending')}
                  </button>
                </div>
              </div>
            </div>

            <div>
              <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                <FileText className="w-3.5 h-3.5 text-blue-700" />
                <span>{getTranslation(lang, 'notes')}</span>
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={
                  lang === 'hi' ? 'कोई विशेष बात या बिल नंबर यहां लिखें...' : 'Bill number, notes...'
                }
                className="input-3d-sky w-full px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold"
              />
            </div>

            {/* Optional 📎 Attach Bill / Receipt Section (Immediately below Notes / Remarks) */}
            <div className="pt-2 border-t border-emerald-500/25 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5">
                  <Paperclip className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                  <span>
                    {lang === 'hi'
                      ? '📎 बिल / रसीद जोड़ें (Attach Bill / Receipt — वैकल्पिक)'
                      : '📎 Attach Bill / Receipt (Optional)'}
                  </span>
                </label>
                {hasActiveAttachment && (
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-900 dark:text-emerald-300 border border-emerald-400/60">
                    {lang === 'hi' ? '✓ बिल संलग्न है' : '✓ Bill Attached'}
                  </span>
                )}
              </div>

              {/* Hidden File Inputs for Gallery Image, Camera Photo, and PDF Bill */}
              <input
                ref={galleryInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleFileSelect}
                className="hidden"
              />
              <input
                ref={pdfInputRef}
                type="file"
                accept="application/pdf,.pdf"
                onChange={handleFileSelect}
                className="hidden"
              />

              {/* Error Alert if Invalid File, Oversized File, or Storage Error */}
              {attachmentError && (
                <div className="liquid-glass-expense rounded-xl px-3 py-2 flex items-start gap-2 border border-rose-400">
                  <AlertTriangle className="w-4 h-4 text-rose-700 dark:text-rose-300 shrink-0 mt-0.5" />
                  <p className="text-xs font-extrabold text-rose-950 dark:text-rose-200 leading-snug">
                    {attachmentError}
                  </p>
                </div>
              )}

              {/* Selection Controls when no attachment is present */}
              {!hasActiveAttachment ? (
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    disabled={isProcessingFile}
                    onClick={() => galleryInputRef.current?.click()}
                    className="liquid-glass-pill py-2.5 px-2 rounded-xl flex flex-col items-center justify-center gap-1 text-[11px] font-extrabold text-slate-950 dark:text-white cursor-pointer"
                  >
                    <ImageIcon className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                    <span className="truncate max-w-full">
                      {lang === 'hi' ? 'गैलरी फोटो' : 'Gallery Image'}
                    </span>
                  </button>

                  <button
                    type="button"
                    disabled={isProcessingFile}
                    onClick={() => cameraInputRef.current?.click()}
                    className="liquid-glass-pill py-2.5 px-2 rounded-xl flex flex-col items-center justify-center gap-1 text-[11px] font-extrabold text-slate-950 dark:text-white cursor-pointer"
                  >
                    <Camera className="w-4 h-4 text-blue-700 dark:text-blue-400" />
                    <span className="truncate max-w-full">
                      {lang === 'hi' ? 'कैमरा फोटो' : 'Take Photo'}
                    </span>
                  </button>

                  <button
                    type="button"
                    disabled={isProcessingFile}
                    onClick={() => pdfInputRef.current?.click()}
                    className="liquid-glass-pill py-2.5 px-2 rounded-xl flex flex-col items-center justify-center gap-1 text-[11px] font-extrabold text-slate-950 dark:text-white cursor-pointer"
                  >
                    <FileText className="w-4 h-4 text-amber-700 dark:text-amber-400" />
                    <span className="truncate max-w-full">
                      {lang === 'hi' ? 'PDF बिल' : 'PDF Bill'}
                    </span>
                  </button>
                </div>
              ) : (
                /* Attached Bill / Receipt Preview & Actions Card */
                <div className="liquid-glass-pill rounded-2xl p-3 space-y-2.5 border border-emerald-500/40">
                  <div className="flex items-center gap-3">
                    {/* Thumbnail Preview for Images or PDF Badge */}
                    {isDisplayedPdf ? (
                      <div className="w-14 h-14 rounded-xl liquid-glass-profit flex flex-col items-center justify-center shrink-0 text-blue-800 dark:text-blue-300 border border-blue-400/50">
                        <FileText className="w-6 h-6" />
                        <span className="text-[9px] font-black mt-0.5">PDF</span>
                      </div>
                    ) : attachmentDataUrl ? (
                      <div
                        onClick={() => setIsPreviewModalOpen(true)}
                        className="w-14 h-14 rounded-xl overflow-hidden border-2 border-emerald-500/60 bg-slate-900/10 shrink-0 cursor-pointer"
                      >
                        <img
                          src={attachmentDataUrl}
                          alt={displayedAttachmentName}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="w-14 h-14 rounded-xl liquid-glass-income flex items-center justify-center shrink-0 text-emerald-800 dark:text-emerald-300">
                        <ImageIcon className="w-6 h-6" />
                      </div>
                    )}

                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white truncate">
                        {displayedAttachmentName}
                      </p>
                      <p className="text-[11px] font-bold text-slate-700 dark:text-slate-300 mt-0.5">
                        {isDisplayedPdf
                          ? lang === 'hi'
                            ? 'PDF बिल दस्तावेज़'
                            : 'PDF Bill Document'
                          : lang === 'hi'
                          ? 'बिल / रसीद फोटो'
                          : 'Bill / Receipt Photo'}
                        {displayedAttachmentSize > 0
                          ? ` • ${Math.max(1, Math.round(displayedAttachmentSize / 1024))} KB`
                          : ''}
                      </p>
                      <p className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 truncate mt-0.5">
                        {lang === 'hi'
                          ? `इस प्रविष्टि से जुड़ा: ₹${amount || 0} • ${date}`
                          : `Linked to entry: ₹${amount || 0} • ${date}`}
                      </p>
                    </div>
                  </div>

                  {/* Open/View, Replace, and Remove Controls */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-300/60 dark:border-slate-700/60">
                    <button
                      type="button"
                      onClick={() => setIsPreviewModalOpen(true)}
                      className="liquid-glass-emerald px-3 py-1.5 rounded-xl text-[11px] font-extrabold text-white inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{lang === 'hi' ? 'देखें (View)' : 'View'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => galleryInputRef.current?.click()}
                      className="liquid-glass-sky px-2.5 py-1.5 rounded-xl text-[11px] font-extrabold text-slate-950 dark:text-white inline-flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>{lang === 'hi' ? 'फोटो बदलें' : 'Replace Image'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => pdfInputRef.current?.click()}
                      className="liquid-glass-sky px-2.5 py-1.5 rounded-xl text-[11px] font-extrabold text-slate-950 dark:text-white inline-flex items-center gap-1 cursor-pointer"
                    >
                      <FileText className="w-3 h-3" />
                      <span>{lang === 'hi' ? 'PDF बदलें' : 'Replace PDF'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleRemoveAttachment}
                      className="liquid-glass-danger px-2.5 py-1.5 rounded-xl text-[11px] font-extrabold inline-flex items-center gap-1 cursor-pointer ml-auto"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{lang === 'hi' ? 'हटाएं' : 'Remove'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Smart Next Irrigation / Spray Reminder Box (Only for new Irrigation or Pesticide/Spray expenses) */}
            {!txToEdit &&
              type === 'expense' &&
              (category === 'irrigation' || category === 'pesticide') &&
              onCreateSmartReminder && (
                <div className="liquid-glass-amber rounded-2xl p-3 space-y-2.5 border border-amber-400/70">
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={enableSmartReminder}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setEnableSmartReminder(checked);
                        if (checked) {
                          const defaultDays = category === 'irrigation' ? 15 : 10;
                          setSmartReminderDays(defaultDays);
                          setSmartReminderDate(addDaysToYMD(date, defaultDays));
                        }
                      }}
                      className="mt-0.5 w-4 h-4 rounded accent-emerald-600 cursor-pointer shrink-0"
                    />
                    <div className="text-xs">
                      <span className="font-black text-slate-950 dark:text-white block">
                        🔔{' '}
                        {category === 'irrigation'
                          ? lang === 'hi'
                            ? 'अगली सिंचाई का ऑटो रिमाइंडर सेट करें (Smart Irrigation Reminder)'
                            : 'Set Next Irrigation Smart Reminder'
                          : lang === 'hi'
                          ? 'अगले स्प्रे / छिड़काव का ऑटो रिमाइंडर सेट करें (Smart Spray Reminder)'
                          : 'Set Next Spray Smart Reminder'}
                      </span>
                      <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                        {lang === 'hi'
                          ? 'तय तारीख को फोन पर अपने-आप अलार्म व नोटिफिकेशन बजेगा'
                          : 'Automatically triggers phone alarm & notification on the chosen date'}
                      </span>
                    </div>
                  </label>

                  {enableSmartReminder && (
                    <div className="space-y-2 pt-1.5 border-t border-amber-400/40">
                      <div className="flex flex-wrap items-center gap-1.5">
                        {[7, 10, 15, 21].map((d) => (
                          <button
                            key={d}
                            type="button"
                            onClick={() => {
                              setSmartReminderDays(d);
                              setSmartReminderDate(addDaysToYMD(date, d));
                            }}
                            className={`px-2.5 py-1 rounded-xl text-[11px] font-black cursor-pointer ${
                              smartReminderDays === d
                                ? 'liquid-glass-emerald text-white'
                                : 'liquid-glass-pill text-slate-900 dark:text-slate-100'
                            }`}
                          >
                            +{d} {lang === 'hi' ? 'दिन बाद' : 'Days'}
                          </button>
                        ))}
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <span className="text-[10px] font-extrabold text-slate-800 dark:text-slate-200 block mb-0.5">
                            📅 {lang === 'hi' ? 'रिमाइंडर तारीख' : 'Reminder Date'}
                          </span>
                          <input
                            type="date"
                            value={smartReminderDate}
                            onChange={(e) => setSmartReminderDate(e.target.value)}
                            className="liquid-glass-input w-full px-2.5 py-1.5 rounded-xl text-xs font-mono font-bold"
                          />
                        </div>
                        <div>
                          <span className="text-[10px] font-extrabold text-slate-800 dark:text-slate-200 block mb-0.5">
                            ⏰ {lang === 'hi' ? 'अलार्म समय' : 'Alarm Time'}
                          </span>
                          <input
                            type="time"
                            value={smartReminderTime}
                            onChange={(e) => setSmartReminderTime(e.target.value)}
                            className="liquid-glass-input w-full px-2.5 py-1.5 rounded-xl text-xs font-mono font-bold"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="liquid-glass-pill px-5 py-2.5 rounded-full text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              disabled={isSavingTx || isProcessingFile}
              className={`${
                type === 'expense' ? 'btn-3d-rose' : 'liquid-glass-emerald'
              } px-6 py-2.5 rounded-full text-white font-extrabold text-xs sm:text-sm cursor-pointer shadow-md`}
            >
              ✓ {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>

      {/* In-Form Receipt Preview Modal */}
      <ReceiptViewerModal
        isOpen={isPreviewModalOpen}
        onClose={() => setIsPreviewModalOpen(false)}
        attachment={
          hasActiveAttachment
            ? {
                id: existingAttachment?.id || 'preview',
                transactionId: txToEdit?.id || 'draft',
                transactionType: type,
                cropId,
                category: category as any,
                title:
                  title.trim() ||
                  getTranslation(lang, category as any),
                date,
                amount: Number(amount) || 0,
                fileName: displayedAttachmentName,
                mimeType: displayedAttachmentMime,
                fileSize: displayedAttachmentSize,
                storageRef: existingAttachment?.storageRef || '',
                createdAt: existingAttachment?.createdAt || new Date().toISOString(),
                updatedAt: new Date().toISOString()
              }
            : null
        }
        previewDataUrl={attachmentDataUrl}
        lang={lang}
      />
    </div>
  );
};
