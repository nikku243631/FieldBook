import React, { useState, useEffect } from 'react';
import {
  FileText,
  ShoppingBag,
  Plus,
  Search,
  Pin,
  Trash2,
  Edit2,
  Share2,
  CheckCircle2,
  Circle,
  Calendar,
  Clock,
  Sparkles,
  BellRing,
  Sprout
} from 'lucide-react';
import { Language, Theme, FarmNote, ShoppingItem, CropCycle } from '../types';
import { Storage } from '../utils/storage';
import { ConfirmModal } from './ConfirmModal';
import { shareViaWhatsApp } from '../utils/export';
import { requestReminderNotificationPermission } from '../utils/reminderScheduler';

interface NotesAndListsViewProps {
  lang: Language;
  theme: Theme;
  notes: FarmNote[];
  shoppingItems: ShoppingItem[];
  crops?: CropCycle[];
  onUpdateNotes: (notes: FarmNote[]) => void;
  onUpdateShoppingItems: (items: ShoppingItem[]) => void;
  onAddShoppingItemToExpense?: (
    item: ShoppingItem,
    cropId: string,
    cost: number,
    paymentStatus: 'paid' | 'pending'
  ) => void;
  onOpenSimpleCalc?: () => void;
}

export const NotesAndListsView: React.FC<NotesAndListsViewProps> = ({
  lang,
  theme,
  notes,
  shoppingItems,
  crops = [],
  onUpdateNotes,
  onUpdateShoppingItems,
  onAddShoppingItemToExpense,
  onOpenSimpleCalc
}) => {
  const isHindi = lang === 'hi';
  const isDark = theme === 'dark';

  const [activeSubTab, setActiveSubTab] = useState<'notes' | 'shopping'>('notes');

  // Notes state
  const [noteSearch, setNoteSearch] = useState('');
  const [selectedNoteCategory, setSelectedNoteCategory] = useState<string>('all');
  const [isAddNoteOpen, setIsAddNoteOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<FarmNote | null>(null);
  const [noteToDelete, setNoteToDelete] = useState<FarmNote | null>(null);

  // New/Edit Note Form
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [noteCategory, setNoteCategory] = useState<FarmNote['category']>('reminder');
  const [noteColor, setNoteColor] = useState<string>('emerald');
  const [noteIsPinned, setNoteIsPinned] = useState(false);
  const [noteDate, setNoteDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [noteTime, setNoteTime] = useState(() => new Date().toTimeString().slice(0, 5));

  // Shopping state
  const [shoppingFilter, setShoppingFilter] = useState<'all' | 'pending' | 'purchased'>('all');
  const [shoppingCategoryFilter] = useState<string>('all');
  const [isAddShoppingOpen, setIsAddShoppingOpen] = useState(false);
  const [editingShoppingItem, setEditingShoppingItem] = useState<ShoppingItem | null>(null);
  const [itemToDelete, setItemToDelete] = useState<ShoppingItem | null>(null);

  // 1-Click Shopping -> Crop Expense Modal state
  const [shoppingToExpenseItem, setShoppingToExpenseItem] = useState<ShoppingItem | null>(null);
  const [selectedExpenseCropId, setSelectedExpenseCropId] = useState<string>(crops[0]?.id || '');
  const [shoppingExpenseAmount, setShoppingExpenseAmount] = useState<string>('');
  const [shoppingExpensePaymentStatus, setShoppingExpensePaymentStatus] = useState<'paid' | 'pending'>('paid');
  const [convertedItemBanner, setConvertedItemBanner] = useState<string | null>(null);

  // Listen for Android hardware back button to close open popups or switch from shopping back to notes
  useEffect(() => {
    const handleHardwareBack = (e: Event) => {
      if (shoppingToExpenseItem) {
        e.preventDefault();
        setShoppingToExpenseItem(null);
        return;
      }
      if (isAddNoteOpen) {
        e.preventDefault();
        setIsAddNoteOpen(false);
        return;
      }
      if (isAddShoppingOpen) {
        e.preventDefault();
        setIsAddShoppingOpen(false);
        return;
      }
      if (noteToDelete) {
        e.preventDefault();
        setNoteToDelete(null);
        return;
      }
      if (itemToDelete) {
        e.preventDefault();
        setItemToDelete(null);
        return;
      }
      if (activeSubTab === 'shopping') {
        e.preventDefault();
        setActiveSubTab('notes');
      }
    };
    window.addEventListener('fieldbook:hardware-back', handleHardwareBack);
    return () => window.removeEventListener('fieldbook:hardware-back', handleHardwareBack);
  }, [
    shoppingToExpenseItem,
    isAddNoteOpen,
    isAddShoppingOpen,
    noteToDelete,
    itemToDelete,
    activeSubTab
  ]);

  // New/Edit Shopping Form
  const [itemName, setItemName] = useState('');
  const [itemCategory, setItemCategory] = useState<ShoppingItem['category']>('fertilizer');
  const [itemQuantityInput, setItemQuantityInput] = useState<string>('1');
  const [quantityError, setQuantityError] = useState<string>('');
  const [itemUnit, setItemUnit] = useState('बोरी');
  const [itemEstimatedCost, setItemEstimatedCost] = useState<string>('');
  const [itemActualCost, setItemActualCost] = useState<string>('');
  const [itemNotes, setItemNotes] = useState('');

  // ---------------- NOTE HANDLERS ----------------
  const handleOpenAddNote = (noteToEdit?: FarmNote) => {
    if (noteToEdit) {
      setEditingNote(noteToEdit);
      setNoteTitle(noteToEdit.title);
      setNoteContent(noteToEdit.content);
      setNoteCategory(noteToEdit.category);
      setNoteColor(noteToEdit.color || 'emerald');
      setNoteIsPinned(noteToEdit.isPinned);
      setNoteDate(noteToEdit.date);
      setNoteTime(noteToEdit.time);
    } else {
      setEditingNote(null);
      setNoteTitle('');
      setNoteContent('');
      setNoteCategory('reminder');
      setNoteColor('emerald');
      setNoteIsPinned(false);
      setNoteDate(new Date().toISOString().split('T')[0]);
      setNoteTime(new Date().toTimeString().slice(0, 5));
    }
    setIsAddNoteOpen(true);
  };

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim() && !noteContent.trim()) return;

    if (noteCategory === 'reminder') {
      requestReminderNotificationPermission().catch(() => {});
    }

    if (editingNote) {
      const updated = notes.map((n) =>
        n.id === editingNote.id
          ? {
              ...n,
              title: noteTitle.trim() || (isHindi ? 'नोट' : 'Note'),
              content: noteContent.trim(),
              category: noteCategory,
              color: noteColor,
              isPinned: noteIsPinned,
              date: noteDate,
              time: noteTime,
              updatedAt: new Date().toISOString()
            }
          : n
      );
      onUpdateNotes(updated);
      Storage.saveNotes(updated);
    } else {
      const newNote: FarmNote = {
        id: `note-${Date.now()}`,
        title: noteTitle.trim() || (isHindi ? 'नया नोट' : 'New Note'),
        content: noteContent.trim(),
        category: noteCategory,
        color: noteColor,
        isPinned: noteIsPinned,
        date: noteDate,
        time: noteTime,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      const updated = [newNote, ...notes];
      onUpdateNotes(updated);
      Storage.saveNotes(updated);
    }

    setIsAddNoteOpen(false);
    setEditingNote(null);
  };

  const handleTogglePin = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = notes.map((n) => (n.id === id ? { ...n, isPinned: !n.isPinned } : n));
    onUpdateNotes(updated);
    Storage.saveNotes(updated);
  };

  const handleDeleteNoteConfirm = () => {
    if (!noteToDelete) return;
    const updated = notes.filter((n) => n.id !== noteToDelete.id);
    onUpdateNotes(updated);
    Storage.saveNotes(updated);
    setNoteToDelete(null);
  };

  const handleShareNoteWhatsApp = (note: FarmNote, e: React.MouseEvent) => {
    e.stopPropagation();
    const text = `*FieldBook खेत नोट: ${note.title}*\n\n${note.content}\n\nतारीख: ${note.date} ${note.time}\n(FieldBook - Mr Nikhil)`;
    shareViaWhatsApp(text);
  };

  const filteredNotes = notes
    .filter((n) => {
      const matchesSearch =
        n.title.toLowerCase().includes(noteSearch.toLowerCase()) ||
        n.content.toLowerCase().includes(noteSearch.toLowerCase());
      const matchesCat = selectedNoteCategory === 'all' || n.category === selectedNoteCategory;
      return matchesSearch && matchesCat;
    })
    .sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  // ---------------- SHOPPING LIST HANDLERS ----------------
  const handleOpenAddShopping = (itemToEdit?: ShoppingItem) => {
    setQuantityError('');
    if (itemToEdit) {
      setEditingShoppingItem(itemToEdit);
      setItemName(itemToEdit.name);
      setItemCategory(itemToEdit.category);
      const savedQty = Number(itemToEdit.quantity);
      setItemQuantityInput(
        Number.isFinite(savedQty) && savedQty > 0 ? String(savedQty) : '1'
      );
      setItemUnit(itemToEdit.unit);
      setItemEstimatedCost(itemToEdit.estimatedCost ? String(itemToEdit.estimatedCost) : '');
      setItemActualCost(itemToEdit.actualCost ? String(itemToEdit.actualCost) : '');
      setItemNotes(itemToEdit.notes || '');
    } else {
      setEditingShoppingItem(null);
      setItemName('');
      setItemCategory('fertilizer');
      setItemQuantityInput('1');
      setItemUnit('बोरी');
      setItemEstimatedCost('');
      setItemActualCost('');
      setItemNotes('');
    }
    setIsAddShoppingOpen(true);
  };

  const handleSaveShoppingItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName.trim()) return;

    const trimmedQty = itemQuantityInput.trim();
    const parsedQty = Number(trimmedQty);
    if (!trimmedQty || !Number.isFinite(parsedQty) || parsedQty <= 0) {
      setQuantityError(
        isHindi
          ? 'कृपया 0 से बड़ी सही मात्रा लिखें (जैसे: 1, 2, 5, 10 या 1.5)।'
          : 'Please enter a valid positive quantity (e.g., 1, 2, 5, 10, or 1.5).'
      );
      return;
    }

    const validQuantity = Number(parsedQty.toFixed(2));
    const estCostNum = itemEstimatedCost ? parseFloat(itemEstimatedCost) : undefined;
    const actCostNum = itemActualCost ? parseFloat(itemActualCost) : undefined;

    if (editingShoppingItem) {
      const updated = shoppingItems.map((item) =>
        item.id === editingShoppingItem.id
          ? {
              ...item,
              name: itemName.trim(),
              category: itemCategory,
              quantity: validQuantity,
              unit: itemUnit,
              estimatedCost: estCostNum,
              actualCost: actCostNum,
              notes: itemNotes.trim() || undefined
            }
          : item
      );
      onUpdateShoppingItems(updated);
      Storage.saveShoppingItems(updated);
    } else {
      const newItem: ShoppingItem = {
        id: `shop-${Date.now()}`,
        name: itemName.trim(),
        category: itemCategory,
        quantity: validQuantity,
        unit: itemUnit,
        estimatedCost: estCostNum,
        actualCost: actCostNum,
        isPurchased: false,
        notes: itemNotes.trim() || undefined,
        date: new Date().toISOString().split('T')[0],
        createdAt: new Date().toISOString()
      };
      const updated = [newItem, ...shoppingItems];
      onUpdateShoppingItems(updated);
      Storage.saveShoppingItems(updated);
    }

    setQuantityError('');
    setIsAddShoppingOpen(false);
    setEditingShoppingItem(null);
  };

  const handleTogglePurchase = (id: string) => {
    const updated = shoppingItems.map((item) =>
      item.id === id ? { ...item, isPurchased: !item.isPurchased } : item
    );
    onUpdateShoppingItems(updated);
    Storage.saveShoppingItems(updated);
  };

  const handleDeleteShoppingItemConfirm = () => {
    if (!itemToDelete) return;
    const updated = shoppingItems.filter((i) => i.id !== itemToDelete.id);
    onUpdateShoppingItems(updated);
    Storage.saveShoppingItems(updated);
    setItemToDelete(null);
  };

  const handleClearCompletedShopping = () => {
    const updated = shoppingItems.filter((i) => !i.isPurchased);
    onUpdateShoppingItems(updated);
    Storage.saveShoppingItems(updated);
  };

  const handleShareShoppingWhatsApp = () => {
    const pending = shoppingItems.filter((i) => !i.isPurchased);
    const purchased = shoppingItems.filter((i) => i.isPurchased);

    let text = `*FieldBook कृषि खरीदारी लिस्ट (सामान की सूची)*\n\n`;

    if (pending.length > 0) {
      text += `*खरीदना बाकी (${pending.length}):*\n`;
      pending.forEach((item, index) => {
        text += `${index + 1}. ${item.name} - ${item.quantity} ${item.unit}${
          item.estimatedCost ? ` (लगभग ₹${item.estimatedCost})` : ''
        }\n`;
      });
    }

    if (purchased.length > 0) {
      text += `\n*खरीद लिया (${purchased.length}):*\n`;
      purchased.forEach((item, index) => {
        text += `✓ ${item.name} - ${item.quantity} ${item.unit}${
          item.actualCost ? ` (₹${item.actualCost})` : ''
        }\n`;
      });
    }

    const totalEst = shoppingItems.reduce((sum, item) => sum + (item.estimatedCost || 0), 0);
    text += `\n*कुल संभावित खर्च:* ₹${totalEst.toLocaleString('en-IN')}\n(FieldBook - Mr Nikhil)`;

    shareViaWhatsApp(text);
  };

  const filteredShopping = shoppingItems.filter((item) => {
    const matchesStatus =
      shoppingFilter === 'all'
        ? true
        : shoppingFilter === 'pending'
        ? !item.isPurchased
        : item.isPurchased;
    const matchesCategory =
      shoppingCategoryFilter === 'all' || item.category === shoppingCategoryFilter;
    return matchesStatus && matchesCategory;
  });

  const totalShoppingEstimated = shoppingItems.reduce((acc, item) => acc + (item.estimatedCost || 0), 0);
  const totalShoppingActual = shoppingItems.reduce((acc, item) => acc + (item.actualCost || 0), 0);
  const pendingCount = shoppingItems.filter((i) => !i.isPurchased).length;
  const purchasedCount = shoppingItems.filter((i) => i.isPurchased).length;

  const categoryLabels: Record<FarmNote['category'], { hi: string; en: string }> = {
    reminder: { hi: 'ज़रूरी याददाश्त', en: 'Reminder' },
    field_work: { hi: 'खेत काम / जुताई', en: 'Field Work' },
    payment: { hi: 'लेन-देन / उधारी', en: 'Payment / Debt' },
    spray: { hi: 'दवाई व स्प्रे', en: 'Spray & Medicine' },
    general: { hi: 'सामान्य', en: 'General' }
  };

  const shoppingCategoryLabels: Record<ShoppingItem['category'], { hi: string; en: string }> = {
    fertilizer: { hi: 'खाद (Fertilizer)', en: 'Fertilizer' },
    seeds: { hi: 'बीज (Seeds)', en: 'Seeds' },
    pesticide: { hi: 'कीटनाशक व दवाई', en: 'Pesticide' },
    machinery_tools: { hi: 'ट्रैक्टर / उपकरण', en: 'Machinery/Tools' },
    irrigation: { hi: 'सिंचाई व पाइप', en: 'Irrigation' },
    general: { hi: 'अन्य सामान', en: 'General' }
  };

  return (
    <div className="space-y-4 max-w-5xl mx-auto pb-20">
      {/* Page Header */}
      <div
        className={`liquid-glass-card rounded-2xl p-4 sm:p-5 ${
          isDark ? 'text-slate-100' : 'text-slate-900'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[11px] font-extrabold text-emerald-800 dark:text-emerald-400 mb-1">
              <FileText className="w-3.5 h-3.5" />
              <span>{isHindi ? 'खेत नोट्स व सामान सूची' : 'Farm Notes & Shopping List'}</span>
            </div>
            <h1 className="text-base sm:text-lg font-extrabold tracking-tight">
              {isHindi ? 'याददाश्त नोट्स व खरीदारी लिस्ट' : 'Daily Notes & Farm Purchases'}
            </h1>
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mt-0.5 max-w-xl">
              {isHindi
                ? 'खाद-बीज की दुकान का हिसाब, ट्यूबवेल की बात, उधारी-बाकी और बाज़ार से लाने वाले सामान की पक्की लिस्ट बनाएं।'
                : 'Jot down field notes, fertilizer supplier reminders, and maintain an agri shopping checklist.'}
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
            {onOpenSimpleCalc && (
              <button
                type="button"
                onClick={onOpenSimpleCalc}
                className="liquid-glass-emerald px-3 py-2 rounded-xl text-xs font-extrabold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-300" />
                <span>{isHindi ? 'कैलकुलेटर खोलें' : 'Open Calc'}</span>
              </button>
            )}

            {activeSubTab === 'notes' ? (
              <button
                type="button"
                onClick={() => handleOpenAddNote()}
                className="btn-3d-primary px-3.5 py-2 rounded-xl text-white font-semibold text-xs flex items-center gap-1 cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? 'नया नोट लिखें' : 'Add Note'}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleOpenAddShopping()}
                className="btn-3d-primary px-3.5 py-2 rounded-xl text-white font-semibold text-xs flex items-center gap-1 cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? 'सामान जोड़ें' : 'Add Item'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Sub-Tab Navigation Bar */}
        <div className="flex flex-wrap items-center gap-2 mt-3.5 pt-3 border-t border-slate-200/70 dark:border-slate-700/70">
          <button
            type="button"
            onClick={() => setActiveSubTab('notes')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
              activeSubTab === 'notes'
                ? 'btn-3d-primary text-white'
                : 'liquid-glass-pill text-slate-800 dark:text-slate-100'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{isHindi ? 'खेत नोट्स (Diary Notes)' : 'Farm Notes'}</span>
            <span
              className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                activeSubTab === 'notes'
                  ? 'bg-emerald-900/60 text-white'
                  : 'bg-slate-200/70 dark:bg-slate-800 text-slate-800 dark:text-slate-200'
              }`}
            >
              {notes.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('shopping')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
              activeSubTab === 'shopping'
                ? 'btn-3d-primary text-white'
                : 'liquid-glass-pill text-slate-800 dark:text-slate-100'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>{isHindi ? 'सामान / खरीदारी लिस्ट' : 'Shopping List'}</span>
            <span
              className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                activeSubTab === 'shopping'
                  ? 'bg-emerald-900/60 text-white'
                  : 'bg-slate-200/70 dark:bg-slate-800 text-slate-800 dark:text-slate-200'
              }`}
            >
              {pendingCount > 0 ? `${pendingCount} बाकी` : `${shoppingItems.length}`}
            </span>
          </button>
        </div>
      </div>

      {/* ===================== TAB 1: NOTES SECTION ===================== */}
      {activeSubTab === 'notes' && (
        <div className="space-y-3.5">
          {/* Controls: Search & Category Filter */}
          <div className="liquid-glass-card p-3 rounded-2xl space-y-2.5">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={noteSearch}
                onChange={(e) => setNoteSearch(e.target.value)}
                placeholder={isHindi ? 'नोट्स में खोजें (उदा. यूरिया, बदायूं, पानी)...' : 'Search notes...'}
                className="w-full pl-9 pr-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              {['all', 'reminder', 'field_work', 'payment', 'spray', 'general'].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedNoteCategory(cat)}
                  className={`px-2.5 py-1.5 rounded-xl text-[11px] sm:text-xs font-extrabold transition-all cursor-pointer ${
                    selectedNoteCategory === cat
                      ? 'btn-3d-primary text-white'
                      : 'liquid-glass-pill text-slate-800 dark:text-slate-100'
                  }`}
                >
                  {cat === 'all'
                    ? isHindi
                      ? 'सभी'
                      : 'All'
                    : categoryLabels[cat as FarmNote['category']][lang]}
                </button>
              ))}
            </div>
          </div>

          {/* Notes Grid */}
          {filteredNotes.length === 0 ? (
            <div
              className={`liquid-glass-card rounded-2xl p-8 text-center ${
                isDark ? 'text-slate-100' : 'text-slate-900'
              }`}
            >
              <FileText className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
              <h3 className="text-sm sm:text-base font-bold">
                {isHindi ? 'कोई नोट नहीं मिला' : 'No notes found'}
              </h3>
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mt-1 max-w-xs mx-auto">
                {isHindi
                  ? 'खेत से जुड़ी कोई भी बात, भाव, सलाह या उधारी लिखने के लिए ऊपर "नया नोट लिखें" पर क्लिक करें।'
                  : 'Start writing farm notes, field observations, or dealer transactions.'}
              </p>
              <button
                type="button"
                onClick={() => handleOpenAddNote()}
                className="btn-3d-primary mt-3.5 px-4 py-2 rounded-xl text-white font-semibold text-xs cursor-pointer inline-flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? 'पहला नोट लिखें' : 'Write First Note'}</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {filteredNotes.map((note) => (
                <div
                  key={note.id}
                  onClick={() => handleOpenAddNote(note)}
                  className={`liquid-glass-card rounded-2xl p-4 transition-all hover:-translate-y-0.5 cursor-pointer flex flex-col justify-between group ${
                    isDark ? 'text-slate-100' : 'text-slate-900'
                  } ${note.isPinned ? 'ring-2 ring-amber-400' : ''}`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-slate-200/70 dark:border-slate-700/70">
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                        {categoryLabels[note.category][lang]}
                      </span>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={(e) => handleTogglePin(note.id, e)}
                          className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                            note.isPinned
                              ? 'liquid-glass-amber text-amber-800 dark:text-amber-300'
                              : 'liquid-glass-pill text-slate-700 dark:text-slate-200'
                          }`}
                          title={note.isPinned ? 'Unpin' : 'Pin to top'}
                        >
                          <Pin className={`w-3.5 h-3.5 ${note.isPinned ? 'fill-amber-500 text-amber-600' : ''}`} />
                        </button>

                        <button
                          type="button"
                          onClick={(e) => handleShareNoteWhatsApp(note, e)}
                          className="p-1.5 rounded-lg liquid-glass-emerald transition-colors cursor-pointer"
                          title="Share on WhatsApp"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setNoteToDelete(note);
                          }}
                          className="p-1.5 rounded-lg liquid-glass-danger transition-colors cursor-pointer"
                          title="Delete Note"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <h3 className="text-sm sm:text-base font-extrabold mt-2.5 leading-snug">
                      {note.title}
                    </h3>

                    <p className="text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-pre-line mt-1.5 line-clamp-5 leading-relaxed">
                      {note.content}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-700 dark:text-slate-300 pt-2.5 mt-3 border-t border-slate-200/70 dark:border-slate-700/80">
                    <div className="flex items-center gap-1 font-mono font-semibold">
                      {note.category === 'reminder' ? (
                        <BellRing className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                      ) : (
                        <Calendar className="w-3 h-3 text-emerald-600" />
                      )}
                      <span>{note.date}</span>
                      <span>•</span>
                      <Clock className="w-3 h-3 text-emerald-600" />
                      <span>{note.time}</span>
                    </div>
                    <span className="text-emerald-700 dark:text-emerald-400 font-bold">
                      {isHindi ? 'बदलें ✎' : 'Edit ✎'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ===================== TAB 2: SHOPPING / SAMAN LIST ===================== */}
      {activeSubTab === 'shopping' && (
        <div className="space-y-3.5">
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="liquid-glass-card rounded-xl p-3">
              <div className="text-[11px] font-bold text-slate-600 dark:text-slate-300">
                {isHindi ? 'कुल सामान (Items)' : 'Total Items'}
              </div>
              <div className="text-base sm:text-lg font-extrabold font-mono mt-0.5">
                {shoppingItems.length}
              </div>
              <div className="text-[10px] font-semibold text-slate-600 dark:text-slate-300 mt-0.5">
                {pendingCount} {isHindi ? 'खरीदना बाकी' : 'pending'}
              </div>
            </div>

            <div className="liquid-glass-income rounded-xl p-3">
              <div className="text-[11px] font-bold text-emerald-900 dark:text-emerald-300">
                {isHindi ? 'खरीद लिया (Purchased)' : 'Purchased'}
              </div>
              <div className="text-base sm:text-lg font-extrabold font-mono mt-0.5 text-emerald-800 dark:text-emerald-400">
                {purchasedCount}
              </div>
              <div className="text-[10px] font-semibold text-emerald-800 dark:text-emerald-300 mt-0.5">
                {shoppingItems.length > 0 ? Math.round((purchasedCount / shoppingItems.length) * 100) : 0}%{' '}
                {isHindi ? 'पूर्ण' : 'completed'}
              </div>
            </div>

            <div className="liquid-glass-amber rounded-xl p-3">
              <div className="text-[11px] font-bold text-amber-900 dark:text-amber-300">
                {isHindi ? 'संभावित खर्च (Est.)' : 'Estimated Cost'}
              </div>
              <div className="text-base sm:text-lg font-extrabold font-mono mt-0.5 text-amber-900 dark:text-amber-300">
                ₹{totalShoppingEstimated.toLocaleString('en-IN')}
              </div>
              <div className="text-[10px] font-semibold text-amber-800 dark:text-amber-400 mt-0.5">
                {isHindi ? 'अनुमानित बजट' : 'Estimated budget'}
              </div>
            </div>

            <div className="liquid-glass-profit rounded-xl p-3">
              <div className="text-[11px] font-bold text-blue-900 dark:text-blue-300">
                {isHindi ? 'वास्तविक खर्च (Spent)' : 'Actual Spent'}
              </div>
              <div className="text-base sm:text-lg font-extrabold font-mono mt-0.5 text-blue-800 dark:text-blue-400">
                ₹{totalShoppingActual.toLocaleString('en-IN')}
              </div>
              <div className="text-[10px] font-semibold text-blue-800 dark:text-blue-300 mt-0.5">
                {isHindi ? 'अब तक की खरीदारी' : 'Total spent'}
              </div>
            </div>
          </div>

          {/* Action and Filter Strip */}
          <div className="liquid-glass-card p-3 rounded-2xl flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => setShoppingFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                  shoppingFilter === 'all'
                    ? 'btn-3d-primary text-white'
                    : 'liquid-glass-pill text-slate-800 dark:text-slate-100'
                }`}
              >
                {isHindi ? 'सभी सामान' : 'All'} ({shoppingItems.length})
              </button>
              <button
                type="button"
                onClick={() => setShoppingFilter('pending')}
                className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                  shoppingFilter === 'pending'
                    ? 'btn-3d-amber text-white'
                    : 'liquid-glass-pill text-slate-800 dark:text-slate-100'
                }`}
              >
                {isHindi ? 'खरीदना बाकी' : 'Pending'} ({pendingCount})
              </button>
              <button
                type="button"
                onClick={() => setShoppingFilter('purchased')}
                className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                  shoppingFilter === 'purchased'
                    ? 'btn-3d-primary text-white'
                    : 'liquid-glass-pill text-slate-800 dark:text-slate-100'
                }`}
              >
                {isHindi ? 'खरीद लिया' : 'Purchased'} ({purchasedCount})
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {shoppingItems.length > 0 && (
                <button
                  type="button"
                  onClick={handleShareShoppingWhatsApp}
                  className="btn-3d-primary px-3 py-1.5 rounded-xl text-xs font-semibold text-white flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>{isHindi ? 'WhatsApp पर भेजें' : 'Share List'}</span>
                </button>
              )}

              {purchasedCount > 0 && (
                <button
                  type="button"
                  onClick={handleClearCompletedShopping}
                  className="liquid-glass-danger px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-colors"
                >
                  {isHindi ? 'खरीदे सामान हटाएं' : 'Clear Done'}
                </button>
              )}
            </div>
          </div>

          {/* Shopping Checklist Items */}
          {filteredShopping.length === 0 ? (
            <div
              className={`liquid-glass-card rounded-2xl p-8 text-center ${
                isDark ? 'text-slate-100' : 'text-slate-900'
              }`}
            >
              <ShoppingBag className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
              <h3 className="text-sm sm:text-base font-bold">
                {isHindi ? 'इस सूची में कोई सामान नहीं है' : 'No items in this list'}
              </h3>
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mt-1 max-w-xs mx-auto">
                {isHindi
                  ? 'खाद, बीज, कीटनाशक दवा या कोई भी सामान खरीदने के लिए ऊपर "सामान जोड़ें" बटन दबाएं।'
                  : 'Add items needed for your farm with expected quantity and cost.'}
              </p>
              <button
                type="button"
                onClick={() => handleOpenAddShopping()}
                className="btn-3d-primary mt-3.5 px-4 py-2 rounded-xl text-white font-semibold text-xs cursor-pointer inline-flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? 'पहला सामान जोड़ें' : 'Add First Item'}</span>
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {convertedItemBanner && (
                <div className="liquid-glass-income rounded-xl p-2.5 text-xs font-extrabold text-emerald-950 dark:text-emerald-200 flex items-center justify-between gap-2">
                  <span>✓ {convertedItemBanner}</span>
                  <button
                    type="button"
                    onClick={() => setConvertedItemBanner(null)}
                    className="text-emerald-800 dark:text-emerald-300 font-black px-1.5 cursor-pointer"
                  >
                    ✕
                  </button>
                </div>
              )}
              {filteredShopping.map((item) => (
                <div
                  key={item.id}
                  className={`liquid-glass-card rounded-xl p-3 transition-all flex flex-wrap sm:flex-nowrap items-center justify-between gap-2.5 ${
                    isDark ? 'text-slate-100' : 'text-slate-900'
                  } ${item.isPurchased ? 'opacity-75' : ''}`}
                >
                  <div className="flex items-start sm:items-center gap-2.5 flex-1 min-w-0">
                    <button
                      type="button"
                      onClick={() => handleTogglePurchase(item.id)}
                      className="mt-0.5 sm:mt-0 p-0.5 text-emerald-600 hover:scale-105 transition-transform cursor-pointer shrink-0"
                    >
                      {item.isPurchased ? (
                        <CheckCircle2 className="w-5 h-5 fill-emerald-600 text-white" />
                      ) : (
                        <Circle className="w-5 h-5 text-emerald-600" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span
                          className={`text-xs sm:text-sm font-bold truncate ${
                            item.isPurchased ? 'line-through text-slate-400' : ''
                          }`}
                        >
                          {item.name}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                          {shoppingCategoryLabels[item.category][lang]}
                        </span>
                      </div>

                      {item.notes && (
                        <p className="text-[11px] font-medium text-slate-600 dark:text-slate-300 mt-0.5 truncate">{item.notes}</p>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-xs sm:text-sm font-bold font-mono text-emerald-700 dark:text-emerald-400">
                      {item.quantity} {item.unit}
                    </div>
                    {(item.actualCost || item.estimatedCost) && (
                      <div className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 font-mono">
                        {item.actualCost ? '₹' : '≈ ₹'}
                        {(item.actualCost || item.estimatedCost || 0).toLocaleString('en-IN')}
                      </div>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                    {crops.length > 0 && onAddShoppingItemToExpense && (
                      <button
                        type="button"
                        onClick={() => {
                          setShoppingToExpenseItem(item);
                          setSelectedExpenseCropId(crops[0]?.id || '');
                          setShoppingExpenseAmount(
                            String(item.actualCost || item.estimatedCost || '')
                          );
                          setShoppingExpensePaymentStatus('paid');
                        }}
                        className="px-2.5 py-1.5 rounded-lg liquid-glass-emerald text-white text-[11px] font-black inline-flex items-center gap-1 cursor-pointer"
                        title={
                          isHindi
                            ? '1-क्लिक में फसल खर्च खाते में जोड़ें'
                            : 'Add directly to Crop Expense in 1 click'
                        }
                      >
                        <Sprout className="w-3 h-3" />
                        <span>{isHindi ? 'फसल खर्च में जोड़ें' : '+ Crop Expense'}</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleOpenAddShopping(item)}
                      className="p-1.5 rounded-lg liquid-glass-pill text-slate-800 dark:text-slate-100 cursor-pointer"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setItemToDelete(item)}
                      className="p-1.5 rounded-lg liquid-glass-danger cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ===================== MODAL: ADD / EDIT NOTE ===================== */}
      {isAddNoteOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/65 backdrop-blur-sm">
          <div className="liquid-glass-modal w-full max-w-lg rounded-3xl p-4 sm:p-5 animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-600" />
                <span>
                  {editingNote
                    ? isHindi
                      ? 'नोट संशोधित करें'
                      : 'Edit Note'
                    : isHindi
                    ? 'नया खेत नोट लिखें'
                    : 'New Farm Note'}
                </span>
              </h3>
              <button
                type="button"
                onClick={() => setIsAddNoteOpen(false)}
                className="w-8 h-8 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveNote} className="space-y-3.5 mt-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'शीर्षक (Title) *' : 'Title *'}
                </label>
                <input
                  type="text"
                  required
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  placeholder={isHindi ? 'उदा. आढ़ती से बात, ट्यूबवेल समय, खाद उधारी...' : 'Note title...'}
                  className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'वर्ग (Category)' : 'Category'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {(['reminder', 'field_work', 'payment', 'spray', 'general'] as FarmNote['category'][]).map(
                    (cat) => (
                      <button
                        type="button"
                        key={cat}
                        onClick={() => setNoteCategory(cat)}
                        className={`p-2 rounded-xl text-xs font-extrabold text-center transition-all cursor-pointer ${
                          noteCategory === cat
                            ? 'btn-3d-primary text-white'
                            : 'liquid-glass-pill text-slate-800 dark:text-slate-100'
                        }`}
                      >
                        {categoryLabels[cat][lang]}
                      </button>
                    )
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'विवरण (Note Details) *' : 'Details *'}
                </label>
                <textarea
                  rows={4}
                  required
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  placeholder={
                    isHindi
                      ? 'यहाँ पूरा हिसाब, भाव, रेट, फोन नंबर, या जो भी याद रखना हो वह लिखें...'
                      : 'Write details, rates, contacts, or reminders...'
                  }
                  className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'तारीख (रिमाइंडर दिनांक)' : 'Date (Reminder Date)'}
                  </label>
                  <input
                    type="date"
                    value={noteDate}
                    onChange={(e) => setNoteDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'समय (अलार्म समय)' : 'Time (Alarm Time)'}
                  </label>
                  <input
                    type="time"
                    value={noteTime}
                    onChange={(e) => setNoteTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-medium"
                  />
                </div>
              </div>

              {noteCategory === 'reminder' && (
                <p className="text-[11px] font-bold text-amber-800 dark:text-amber-300 liquid-glass-amber px-3 py-1.5 rounded-xl flex items-center gap-1.5">
                  <BellRing className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    {isHindi
                      ? 'चुनी गई तारीख व समय पर फोन में रिमाइंडर नोटिफिकेशन और अलार्म बजेगा।'
                      : 'A reminder notification & alarm will trigger at the selected date and time.'}
                  </span>
                </p>
              )}

              <label className="flex items-center gap-2 cursor-pointer select-none pt-1">
                <input
                  type="checkbox"
                  checked={noteIsPinned}
                  onChange={(e) => setNoteIsPinned(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-xs font-semibold">
                  {isHindi ? 'सबसे ऊपर पिन करें (Pin to top)' : 'Pin to top'}
                </span>
              </label>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddNoteOpen(false)}
                  className="liquid-glass-pill px-4 py-2 rounded-xl text-xs font-bold cursor-pointer"
                >
                  {isHindi ? 'रद्द करें' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="btn-3d-primary px-5 py-2 rounded-xl text-white font-semibold text-xs sm:text-sm cursor-pointer shadow-xs"
                >
                  {isHindi ? 'सुरक्षित करें' : 'Save Note'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================== MODAL: ADD / EDIT SHOPPING ITEM ===================== */}
      {isAddShoppingOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/65 backdrop-blur-sm">
          <div className="liquid-glass-modal w-full max-w-lg rounded-3xl p-4 sm:p-5 animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-emerald-600" />
                <span>
                  {editingShoppingItem
                    ? isHindi
                      ? 'सामान बदलें'
                      : 'Edit Shopping Item'
                    : isHindi
                    ? 'खरीदारी लिस्ट में सामान जोड़ें'
                    : 'Add Item to Buy'}
                </span>
              </h3>
              <button
                type="button"
                onClick={() => setIsAddShoppingOpen(false)}
                className="w-8 h-8 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveShoppingItem} className="space-y-3.5 mt-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'सामान का नाम *' : 'Item Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  placeholder={isHindi ? 'उदा. यूरिया खाद, पोटाश, कीटनाशक दवा...' : 'Item name...'}
                  className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'श्रेणी (Category)' : 'Category'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {(
                    [
                      'fertilizer',
                      'seeds',
                      'pesticide',
                      'machinery_tools',
                      'irrigation',
                      'general'
                    ] as ShoppingItem['category'][]
                  ).map((cat) => (
                    <button
                      type="button"
                      key={cat}
                      onClick={() => setItemCategory(cat)}
                      className={`p-2 rounded-xl text-xs font-extrabold text-center transition-all cursor-pointer ${
                        itemCategory === cat
                          ? 'btn-3d-primary text-white'
                          : 'liquid-glass-pill text-slate-800 dark:text-slate-100'
                      }`}
                    >
                      {shoppingCategoryLabels[cat][lang]}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'मात्रा (Quantity) *' : 'Quantity *'}
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0.01"
                    inputMode="decimal"
                    value={itemQuantityInput}
                    onChange={(e) => {
                      setItemQuantityInput(e.target.value);
                      if (quantityError) setQuantityError('');
                    }}
                    placeholder={isHindi ? 'उदा. 1, 2, 5, 10, 1.5' : 'e.g. 1, 2, 5, 10, 1.5'}
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-semibold"
                  />
                  {quantityError && (
                    <p className="text-[11px] font-semibold text-rose-600 dark:text-rose-400 mt-1">
                      {quantityError}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'इकाई (Unit)' : 'Unit'}
                  </label>
                  <select
                    value={itemUnit}
                    onChange={(e) => setItemUnit(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
                  >
                    <option value="बोरी">बोरी (Bags / बोरी)</option>
                    <option value="पैकेट">पैकेट (Packets)</option>
                    <option value="लीटर">लीटर (Liters)</option>
                    <option value="किलो">किलो (Kg)</option>
                    <option value="क्विंटल">क्विंटल (Quintal)</option>
                    <option value="नग">नग / पीस (Pcs)</option>
                    <option value="मीटर">मीटर (Meters)</option>
                    <option value="ड्रम">ड्रम (Drum)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'अनुमानित खर्च (₹ Est.)' : 'Est. Cost (₹)'}
                  </label>
                  <input
                    type="number"
                    value={itemEstimatedCost}
                    onChange={(e) => setItemEstimatedCost(e.target.value)}
                    placeholder="उदा. 850"
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'वास्तविक खर्च (₹ Actual)' : 'Actual Cost (₹)'}
                  </label>
                  <input
                    type="number"
                    value={itemActualCost}
                    onChange={(e) => setItemActualCost(e.target.value)}
                    placeholder="खरीदने के बाद"
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'दुकान का नाम या विशेष नोट' : 'Shop or Details'}
                </label>
                <input
                  type="text"
                  value={itemNotes}
                  onChange={(e) => setItemNotes(e.target.value)}
                  placeholder={isHindi ? 'उदा. बदायूं मंडी वाली दुकान से लेना है' : 'Shop or note...'}
                  className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddShoppingOpen(false)}
                  className="liquid-glass-pill px-4 py-2 rounded-xl text-xs font-bold cursor-pointer"
                >
                  {isHindi ? 'रद्द करें' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="btn-3d-primary px-5 py-2 rounded-xl text-white font-semibold text-xs sm:text-sm cursor-pointer shadow-xs"
                >
                  {isHindi ? 'लिस्ट में जोड़ें' : 'Save Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirm Delete Note Modal */}
      <ConfirmModal
        isOpen={Boolean(noteToDelete)}
        title={isHindi ? 'खेत नोट हटाएं?' : 'Delete Note?'}
        message={
          isHindi
            ? `क्या आप सचमुच "${noteToDelete?.title}" नोट को हटाना चाहते हैं?`
            : `Are you sure you want to delete note "${noteToDelete?.title}"?`
        }
        confirmLabel={isHindi ? 'हटाएं' : 'Delete'}
        cancelLabel={isHindi ? 'रद्द करें' : 'Cancel'}
        onConfirm={handleDeleteNoteConfirm}
        onCancel={() => setNoteToDelete(null)}
        theme={theme}
      />

      {/* Confirm Delete Shopping Item Modal */}
      <ConfirmModal
        isOpen={Boolean(itemToDelete)}
        title={isHindi ? 'सामान हटाएं?' : 'Delete Shopping Item?'}
        message={
          isHindi
            ? `क्या आप सचमुच "${itemToDelete?.name}" को लिस्ट से हटाना चाहते हैं?`
            : `Are you sure you want to delete "${itemToDelete?.name}" from list?`
        }
        confirmLabel={isHindi ? 'हटाएं' : 'Delete'}
        cancelLabel={isHindi ? 'रद्द करें' : 'Cancel'}
        onConfirm={handleDeleteShoppingItemConfirm}
        onCancel={() => setItemToDelete(null)}
        theme={theme}
      />

      {/* 1-Click Shopping Item -> Crop Expense Modal */}
      {shoppingToExpenseItem && onAddShoppingItemToExpense && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/65 backdrop-blur-sm">
          <div className="liquid-glass-modal w-full max-w-md rounded-3xl p-4 sm:p-5 space-y-3.5">
            <div className="flex items-center justify-between pb-2.5 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm sm:text-base font-black flex items-center gap-2">
                <Sprout className="w-4 h-4 text-emerald-600" />
                <span>
                  {isHindi
                    ? '1-क्लिक में फसल खर्च खाते में जोड़ें'
                    : 'Add Shopping Item to Crop Expense'}
                </span>
              </h3>
              <button
                type="button"
                onClick={() => setShoppingToExpenseItem(null)}
                className="w-8 h-8 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="liquid-glass-income rounded-2xl p-3 text-xs space-y-1">
              <div className="font-black text-slate-950 dark:text-white text-sm">
                🛒 {shoppingToExpenseItem.name} ({shoppingToExpenseItem.quantity}{' '}
                {shoppingToExpenseItem.unit})
              </div>
              <div className="font-bold text-emerald-900 dark:text-emerald-300">
                {shoppingCategoryLabels[shoppingToExpenseItem.category][lang]}
              </div>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const cost = Number(shoppingExpenseAmount);
                if (!selectedExpenseCropId || !Number.isFinite(cost) || cost <= 0) return;
                onAddShoppingItemToExpense(
                  shoppingToExpenseItem,
                  selectedExpenseCropId,
                  Math.round(cost),
                  shoppingExpensePaymentStatus
                );
                const updatedItems = shoppingItems.map((it) =>
                  it.id === shoppingToExpenseItem.id
                    ? { ...it, isPurchased: true, actualCost: Math.round(cost) }
                    : it
                );
                onUpdateShoppingItems(updatedItems);
                Storage.saveShoppingItems(updatedItems);
                const targetCrop = crops.find((c) => c.id === selectedExpenseCropId);
                const cropTitle = targetCrop
                  ? isHindi
                    ? targetCrop.hindiName || targetCrop.name
                    : targetCrop.name
                  : '';
                setConvertedItemBanner(
                  isHindi
                    ? `"${shoppingToExpenseItem.name}" (₹${Math.round(cost)}) को "${cropTitle}" के खर्च खाते में जोड़ दिया गया!`
                    : `Added "${shoppingToExpenseItem.name}" (₹${Math.round(cost)}) to "${cropTitle}" expenses!`
                );
                setShoppingToExpenseItem(null);
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs font-extrabold text-slate-800 dark:text-slate-200 mb-1">
                  🌾 {isHindi ? 'किस फसल में यह खर्च जोड़ना है? *' : 'Select Crop *'}
                </label>
                <select
                  value={selectedExpenseCropId}
                  onChange={(e) => setSelectedExpenseCropId(e.target.value)}
                  required
                  className="liquid-glass-input w-full px-3 py-2.5 rounded-xl text-xs sm:text-sm font-bold"
                >
                  {crops.map((c) => (
                    <option key={c.id} value={c.id}>
                      {isHindi ? c.hindiName || c.name : c.name} ({c.landArea} {c.areaUnit})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-extrabold text-slate-800 dark:text-slate-200 mb-1">
                  💰 {isHindi ? 'कुल खर्च रकम (₹) *' : 'Total Expense Amount (₹) *'}
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  step="1"
                  value={shoppingExpenseAmount}
                  onChange={(e) => setShoppingExpenseAmount(e.target.value)}
                  placeholder={isHindi ? 'उदा. 1200' : 'e.g. 1200'}
                  className="liquid-glass-input w-full px-3 py-2.5 rounded-xl text-sm font-mono font-black"
                />
              </div>

              <div>
                <label className="block text-xs font-extrabold text-slate-800 dark:text-slate-200 mb-1">
                  💳 {isHindi ? 'भुगतान स्थिति (Payment Status)' : 'Payment Status'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setShoppingExpensePaymentStatus('paid')}
                    className={`py-2 rounded-xl text-xs font-black cursor-pointer ${
                      shoppingExpensePaymentStatus === 'paid'
                        ? 'liquid-glass-emerald text-white'
                        : 'liquid-glass-pill text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    ✓ {isHindi ? 'नकद / भुगतान हो गया' : 'Paid'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShoppingExpensePaymentStatus('pending')}
                    className={`py-2 rounded-xl text-xs font-black cursor-pointer ${
                      shoppingExpensePaymentStatus === 'pending'
                        ? 'btn-3d-rose text-white'
                        : 'liquid-glass-pill text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    ⏳ {isHindi ? 'उधार / बाकी है' : 'Pending (Udhaar)'}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShoppingToExpenseItem(null)}
                  className="liquid-glass-pill px-4 py-2 rounded-xl text-xs font-bold cursor-pointer"
                >
                  {isHindi ? 'रद्द करें' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="liquid-glass-emerald px-5 py-2 rounded-xl text-white font-black text-xs sm:text-sm cursor-pointer"
                >
                  ✓ {isHindi ? 'फसल खर्च में सेव करें' : 'Save to Crop Expense'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
