import React, { useState, useEffect } from 'react';
import { X, Scale, BookOpen, Calendar, CloudSun, Warehouse, FileText } from 'lucide-react';
import { HarvestEntry, DiaryEntry, Language, Theme } from '../types';
import { getTranslation } from '../utils/translations';

interface AddHarvestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (harvest: Partial<HarvestEntry>) => void;
  cropId: string;
  harvestToEdit?: HarvestEntry | null;
  lang: Language;
  theme: Theme;
}

export const AddHarvestModal: React.FC<AddHarvestModalProps> = ({
  isOpen,
  onClose,
  onSave,
  cropId,
  harvestToEdit,
  lang
}) => {
  const now = new Date();
  const [date, setDate] = useState(now.toISOString().split('T')[0]);
  const [time, setTime] = useState(now.toTimeString().slice(0, 5));
  const [quantityInput, setQuantityInput] = useState<string>('');
  const [quantityUnit, setQuantityUnit] = useState<'quintal' | 'kg'>('quintal');
  const [moisturePercentage, setMoisturePercentage] = useState<number | ''>('');
  const [grade, setGrade] = useState('A-Grade (उत्कृष्ट)');
  const [storageLocation, setStorageLocation] = useState('घर का गोदाम / कोठार');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (harvestToEdit) {
      setDate(harvestToEdit.date || new Date().toISOString().split('T')[0]);
      setTime(harvestToEdit.time || new Date().toTimeString().slice(0, 5));
      if (harvestToEdit.quantityUnit === 'kg' && harvestToEdit.quantityValue) {
        setQuantityUnit('kg');
        setQuantityInput(String(harvestToEdit.quantityValue));
      } else {
        setQuantityUnit(harvestToEdit.quantityUnit || 'quintal');
        setQuantityInput(
          harvestToEdit.quantityValue !== undefined
            ? String(harvestToEdit.quantityValue)
            : harvestToEdit.quantityQuintal !== undefined
            ? String(harvestToEdit.quantityQuintal)
            : ''
        );
      }
      setMoisturePercentage(harvestToEdit.moisturePercentage ?? '');
      setGrade(harvestToEdit.grade || 'A-Grade (उत्कृष्ट)');
      setStorageLocation(harvestToEdit.storageLocation || 'घर का गोदाम / कोठार');
      setNotes(harvestToEdit.notes || '');
    } else {
      const currentNow = new Date();
      setDate(currentNow.toISOString().split('T')[0]);
      setTime(currentNow.toTimeString().slice(0, 5));
      setQuantityInput('');
      setQuantityUnit('quintal');
      setMoisturePercentage('');
      setGrade('A-Grade (उत्कृष्ट)');
      setStorageLocation('घर का गोदाम / कोठार');
      setNotes('');
    }
  }, [isOpen, harvestToEdit]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericQty = Number(quantityInput);
    if (!quantityInput.trim() || !Number.isFinite(numericQty) || numericQty <= 0) return;

    const cleanValue = Number(numericQty.toFixed(2));
    const computedQuintal =
      quantityUnit === 'kg'
        ? Number((cleanValue / 100).toFixed(4))
        : Number(cleanValue.toFixed(2));

    onSave({
      id: harvestToEdit?.id,
      cropId,
      date,
      time,
      quantityQuintal: computedQuintal,
      quantityValue: cleanValue,
      quantityUnit,
      moisturePercentage:
        moisturePercentage && Number(moisturePercentage) >= 0
          ? Number(moisturePercentage)
          : undefined,
      grade,
      storageLocation,
      notes: notes.trim() || undefined
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/60 backdrop-blur-md overflow-y-auto">
      <div className="liquid-glass-modal w-full max-w-md rounded-3xl p-4 sm:p-5 my-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 mb-3.5 border-b-2 border-amber-500/35">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl btn-3d-amber text-white flex items-center justify-center shrink-0">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-950 dark:text-white leading-tight">
                {harvestToEdit
                  ? lang === 'hi'
                    ? 'कटाई / तुड़ाई वजन सुधारें'
                    : 'Edit Harvest Entry'
                  : getTranslation(lang, 'addHarvest')}
              </h2>
              <p className="text-xs font-bold text-amber-950 dark:text-amber-300">
                {lang === 'hi'
                  ? '✍️ पैदावार वजन (किलो या क्विंटल) और विवरण दर्ज करें'
                  : '✍️ Enter harvested quantity (Kg or Quintal) and details'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="liquid-glass-income rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div className="sm:col-span-2">
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  🌾 {lang === 'hi' ? 'पैदावार मात्रा (Quantity) *' : 'Quantity Harvested *'}
                </label>
                <input
                  type="number"
                  step="any"
                  min="0.01"
                  inputMode="decimal"
                  required
                  autoFocus
                  value={quantityInput}
                  onChange={(e) => setQuantityInput(e.target.value)}
                  placeholder={
                    quantityUnit === 'kg'
                      ? lang === 'hi'
                        ? 'उदा. 50 किलो'
                        : 'e.g. 50 Kg'
                      : lang === 'hi'
                      ? 'उदा. 25 क्विंटल'
                      : 'e.g. 25 Quintal'
                  }
                  className="input-3d-amber w-full px-3.5 py-2.5 rounded-xl text-base font-mono font-extrabold tabular-nums text-slate-950 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  ⚖️ {lang === 'hi' ? 'इकाई (Unit)' : 'Unit'}
                </label>
                <select
                  value={quantityUnit}
                  onChange={(e) => setQuantityUnit(e.target.value as 'quintal' | 'kg')}
                  className="input-3d-amber w-full px-3 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white"
                >
                  <option value="quintal">
                    {lang === 'hi' ? 'क्विंटल (Quintal)' : 'Quintal (100 Kg)'}
                  </option>
                  <option value="kg">
                    {lang === 'hi' ? 'किलो (Kg)' : 'Kilogram (Kg)'}
                  </option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{getTranslation(lang, 'date')}</span>
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="liquid-glass-input w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  💧 {getTranslation(lang, 'moisturePercentage')}
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  max="100"
                  placeholder="12%"
                  value={moisturePercentage}
                  onChange={(e) =>
                    setMoisturePercentage(e.target.value === '' ? '' : parseFloat(e.target.value))
                  }
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                />
              </div>
            </div>
          </div>

          <div className="liquid-glass-profit rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  ⭐ {getTranslation(lang, 'grade')}
                </label>
                <select
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  className="input-3d-amber w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-extrabold"
                >
                  <option value="A-Grade (उत्कृष्ट)">A-Grade (उत्कृष्ट / Super)</option>
                  <option value="B-Grade (मध्यम)">B-Grade (मध्यम / Medium)</option>
                  <option value="C-Grade (सामान्य)">C-Grade (सामान्य / Fair)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <Warehouse className="w-3.5 h-3.5 text-blue-700" />
                  <span>रखने का स्थान (Storage)</span>
                </label>
                <input
                  type="text"
                  value={storageLocation}
                  onChange={(e) => setStorageLocation(e.target.value)}
                  placeholder="मंडी / घर का गोदाम"
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-bold"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                <FileText className="w-3.5 h-3.5 text-emerald-700" />
                <span>{getTranslation(lang, 'notes')}</span>
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="थ्रेशर से कटाई, कट्टे भरे..."
                className="liquid-glass-input w-full px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="liquid-glass-pill px-5 py-2.5 rounded-full text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className="btn-3d-amber px-6 py-2.5 rounded-full text-white font-extrabold text-xs sm:text-sm shadow-md cursor-pointer"
            >
              ✓ {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface AddDiaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (entry: Partial<DiaryEntry>) => void;
  onCreateSmartReminder?: (reminder: {
    title: string;
    content: string;
    date: string;
    time: string;
    category: 'reminder' | 'spray' | 'field_work';
  }) => void;
  cropId: string;
  cropName?: string;
  diaryToEdit?: DiaryEntry | null;
  lang: Language;
  theme: Theme;
}

function addDaysToDiaryDate(baseDateStr: string, days: number): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(baseDateStr);
  const d = match
    ? new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]))
    : new Date();
  d.setDate(d.getDate() + days);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export const AddDiaryModal: React.FC<AddDiaryModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onCreateSmartReminder,
  cropId,
  cropName,
  diaryToEdit,
  lang
}) => {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const [date, setDate] = useState(todayStr);
  const [time, setTime] = useState(now.toTimeString().slice(0, 5));
  const [activityType, setActivityType] = useState<DiaryEntry['activityType']>('irrigation');
  const [notes, setNotes] = useState('');
  const [weatherNote, setWeatherNote] = useState('');

  // Smart Next Irrigation / Spray Reminder state
  const [enableSmartReminder, setEnableSmartReminder] = useState<boolean>(false);
  const [smartReminderDays, setSmartReminderDays] = useState<number>(15);
  const [smartReminderDate, setSmartReminderDate] = useState<string>(() =>
    addDaysToDiaryDate(todayStr, 15)
  );
  const [smartReminderTime, setSmartReminderTime] = useState<string>('08:00');

  useEffect(() => {
    if (!isOpen) return;
    setEnableSmartReminder(false);
    setSmartReminderDays(15);
    setSmartReminderDate(addDaysToDiaryDate(new Date().toISOString().split('T')[0], 15));
    setSmartReminderTime('08:00');

    if (diaryToEdit) {
      setDate(diaryToEdit.date || new Date().toISOString().split('T')[0]);
      setTime(diaryToEdit.time || new Date().toTimeString().slice(0, 5));
      setActivityType(diaryToEdit.activityType || 'irrigation');
      setNotes(diaryToEdit.notes || '');
      setWeatherNote(diaryToEdit.weatherNote || '');
    } else {
      const currentNow = new Date();
      setDate(currentNow.toISOString().split('T')[0]);
      setTime(currentNow.toTimeString().slice(0, 5));
      setActivityType('irrigation');
      setNotes('');
      setWeatherNote('');
    }
  }, [isOpen, diaryToEdit]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notes.trim()) return;

    onSave({
      id: diaryToEdit?.id,
      cropId,
      date,
      time,
      activityType,
      notes: notes.trim(),
      weatherNote: weatherNote.trim() || undefined
    });

    if (
      !diaryToEdit &&
      enableSmartReminder &&
      (activityType === 'irrigation' || activityType === 'spray') &&
      onCreateSmartReminder &&
      smartReminderDate
    ) {
      const isIrr = activityType === 'irrigation';
      const cropLabel = cropName ? ` (${cropName})` : '';
      onCreateSmartReminder({
        title: isIrr
          ? `💧 अगली सिंचाई रिमाइंडर${cropLabel}`
          : `🧪 अगला स्प्रे / छिड़काव रिमाइंडर${cropLabel}`,
        content: isIrr
          ? `${cropName || 'फसल'} में पिछली सिंचाई (${notes.trim()}) ${date} को की गई थी। आज अगली सिंचाई (${smartReminderDays} दिन बाद) का समय है।`
          : `${cropName || 'फसल'} में पिछला स्प्रे (${notes.trim()}) ${date} को किया गया था। आज अगले छिड़काव (${smartReminderDays} दिन बाद) की जांच करें।`,
        date: smartReminderDate,
        time: smartReminderTime || '08:00',
        category: 'reminder'
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/60 backdrop-blur-md overflow-y-auto">
      <div className="liquid-glass-modal w-full max-w-md rounded-3xl p-4 sm:p-5 my-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 mb-3.5 border-b-2 border-blue-500/35">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl btn-3d-blue text-white flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-950 dark:text-white leading-tight">
                {diaryToEdit
                  ? lang === 'hi'
                    ? 'खेत डायरी नोट संशोधित करें'
                    : 'Edit Diary Note'
                  : getTranslation(lang, 'addDiary')}
              </h2>
              <p className="text-xs font-bold text-blue-950 dark:text-blue-300">
                {lang === 'hi'
                  ? '✍️ खेत के कार्य और मौसम का नोट दर्ज करें'
                  : '✍️ Log field activity and weather observations'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="liquid-glass-profit rounded-2xl p-3.5 space-y-3">
            <div>
              <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                🚜 {getTranslation(lang, 'activityType')}
              </label>
              <select
                value={activityType}
                onChange={(e) => setActivityType(e.target.value as any)}
                className="input-3d-sky w-full px-3.5 py-2.5 rounded-xl text-sm font-extrabold"
              >
                <option value="irrigation">{getTranslation(lang, 'activityIrrigation')}</option>
                <option value="fertilizer">{getTranslation(lang, 'activityFertilizer')}</option>
                <option value="spray">{getTranslation(lang, 'activitySpray')}</option>
                <option value="sowing">{getTranslation(lang, 'activitySowing')}</option>
                <option value="inspection">{getTranslation(lang, 'activityInspection')}</option>
                <option value="harvest">{getTranslation(lang, 'activityHarvest')}</option>
                <option value="weeding">{getTranslation(lang, 'activityWeeding')}</option>
                <option value="other">अन्य कार्य</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-blue-700" />
                  <span>{getTranslation(lang, 'date')}</span>
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <CloudSun className="w-3.5 h-3.5 text-amber-600" />
                  <span>मौसम की स्थिति</span>
                </label>
                <input
                  type="text"
                  placeholder="साफ धूप, हल्की हवा"
                  value={weatherNote}
                  onChange={(e) => setWeatherNote(e.target.value)}
                  className="input-3d-amber w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-bold"
                />
              </div>
            </div>
          </div>

          <div className="liquid-glass-income rounded-2xl p-3.5">
            <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
              ✍️ कार्य का पूरा विवरण *
            </label>
            <textarea
              rows={3}
              required
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="उदा. 21 दिन पर पहली सिंचाई दी, 2 बैग यूरिया दिया, फसल का फुटाव अच्छा दिख रहा है..."
              className="liquid-glass-input w-full px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold resize-none"
            />
          </div>

          {/* Smart Next Irrigation / Spray Reminder Box */}
          {!diaryToEdit &&
            (activityType === 'irrigation' || activityType === 'spray') &&
            onCreateSmartReminder && (
              <div className="liquid-glass-amber rounded-2xl p-3 space-y-2.5 border border-amber-400/70">
                <label className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableSmartReminder}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      setEnableSmartReminder(checked);
                      if (checked) {
                        const defaultDays = activityType === 'irrigation' ? 15 : 10;
                        setSmartReminderDays(defaultDays);
                        setSmartReminderDate(addDaysToDiaryDate(date, defaultDays));
                      }
                    }}
                    className="mt-0.5 w-4 h-4 rounded accent-emerald-600 cursor-pointer shrink-0"
                  />
                  <div className="text-xs">
                    <span className="font-black text-slate-950 dark:text-white block">
                      🔔{' '}
                      {activityType === 'irrigation'
                        ? lang === 'hi'
                          ? 'अगली सिंचाई का ऑटो रिमाइंडर सेट करें'
                          : 'Set Next Irrigation Smart Reminder'
                        : lang === 'hi'
                        ? 'अगले स्प्रे / छिड़काव का ऑटो रिमाइंडर सेट करें'
                        : 'Set Next Spray Smart Reminder'}
                    </span>
                    <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                      {lang === 'hi'
                        ? 'तय तारीख को फोन पर अपने-आप अलार्म व नोटिफिकेशन बजेगा'
                        : 'Triggers phone alarm & notification on the chosen date'}
                    </span>
                  </div>
                </label>

                {enableSmartReminder && (
                  <div className="space-y-2 pt-1.5 border-t border-amber-400/40">
                    <div className="flex flex-wrap items-center gap-1.5">
                      {[7, 10, 15, 21].map((d) => (
                        <button
                          key={d}
                          type="button"
                          onClick={() => {
                            setSmartReminderDays(d);
                            setSmartReminderDate(addDaysToDiaryDate(date, d));
                          }}
                          className={`px-2.5 py-1 rounded-xl text-[11px] font-black cursor-pointer ${
                            smartReminderDays === d
                              ? 'liquid-glass-emerald text-white'
                              : 'liquid-glass-pill text-slate-900 dark:text-slate-100'
                          }`}
                        >
                          +{d} {lang === 'hi' ? 'दिन बाद' : 'Days'}
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-[10px] font-extrabold text-slate-800 dark:text-slate-200 block mb-0.5">
                          📅 {lang === 'hi' ? 'रिमाइंडर तारीख' : 'Reminder Date'}
                        </span>
                        <input
                          type="date"
                          value={smartReminderDate}
                          onChange={(e) => setSmartReminderDate(e.target.value)}
                          className="liquid-glass-input w-full px-2.5 py-1.5 rounded-xl text-xs font-mono font-bold"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] font-extrabold text-slate-800 dark:text-slate-200 block mb-0.5">
                          ⏰ {lang === 'hi' ? 'अलार्म समय' : 'Alarm Time'}
                        </span>
                        <input
                          type="time"
                          value={smartReminderTime}
                          onChange={(e) => setSmartReminderTime(e.target.value)}
                          className="liquid-glass-input w-full px-2.5 py-1.5 rounded-xl text-xs font-mono font-bold"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="liquid-glass-pill px-5 py-2.5 rounded-full text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className="btn-3d-blue px-6 py-2.5 rounded-full text-white font-extrabold text-xs sm:text-sm shadow-md cursor-pointer"
            >
              ✓ {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
