import React, { useState, useEffect } from 'react';
import { CropCycle, Transaction, HarvestEntry, Language, Theme } from '../types';
import { CropCard } from './CropCard';
import { ConfirmModal } from './ConfirmModal';
import { ReceiptViewerModal } from './ReceiptViewerModal';
import { getTranslation, formatCurrency } from '../utils/translations';
import {
  calculateFarmLandSummary,
  calculateMonthlyFarmAccounting,
  calculatePendingPaymentsSummary,
  formatMonthLabel,
  getCropCategoryLabel,
  getEffectiveCropAccountingType,
  getEffectiveCropCategory
} from '../utils/calculations';
import {
  PlusCircle,
  Search,
  Sprout,
  Wallet,
  BarChart2,
  TrendingUp,
  TrendingDown,
  Calendar,
  Filter,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  Plus,
  Clock,
  Paperclip,
  Edit,
  X,
  ExternalLink,
  Layers,
  Repeat,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface CropListProps {
  crops: CropCycle[];
  transactions: Transaction[];
  harvests: HarvestEntry[];
  lang: Language;
  theme: Theme;
  onSelectCrop: (cropId: string) => void;
  onOpenAddCrop: () => void;
  onDeleteCrop?: (cropId: string) => void;
  onEditTransaction?: (tx: Transaction) => void;
  onMarkTransactionPaid?: (txId: string) => void;
}

const EXPENSE_CATEGORY_ICONS: Record<string, string> = {
  seeds: '🌾',
  fertilizer: '🌱',
  pesticide: '🧪',
  labour: '👥',
  irrigation: '💧',
  transport: '🚚',
  machinery: '🚜',
  other: '📦'
};

export const CropList: React.FC<CropListProps> = ({
  crops,
  transactions,
  harvests,
  lang,
  theme,
  onSelectCrop,
  onOpenAddCrop,
  onDeleteCrop,
  onEditTransaction,
  onMarkTransactionPaid
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSeason, setFilterSeason] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [cropToDelete, setCropToDelete] = useState<{ id: string; name: string } | null>(null);
  const [isUdhaarExpanded, setIsUdhaarExpanded] = useState<boolean>(false);

  // Home Page Monthly Farm Account state
  const initialMonthlyData = calculateMonthlyFarmAccounting(crops, transactions, harvests);
  const [selectedMonthKey, setSelectedMonthKey] = useState<string>(initialMonthlyData.monthKey);
  const [expandedCropId, setExpandedCropId] = useState<string | null>(null);
  const [selectedTxDetail, setSelectedTxDetail] = useState<{
    tx: Transaction;
    cropName: string;
  } | null>(null);
  const [viewingReceiptTx, setViewingReceiptTx] = useState<{
    tx: Transaction;
    cropName: string;
  } | null>(null);

  // Listen for Android hardware back button to close open popups first
  useEffect(() => {
    const handleHardwareBack = (e: Event) => {
      if (viewingReceiptTx) {
        e.preventDefault();
        setViewingReceiptTx(null);
        return;
      }
      if (selectedTxDetail) {
        e.preventDefault();
        setSelectedTxDetail(null);
        return;
      }
      if (cropToDelete) {
        e.preventDefault();
        setCropToDelete(null);
        return;
      }
      if (isUdhaarExpanded) {
        e.preventDefault();
        setIsUdhaarExpanded(false);
        return;
      }
      if (expandedCropId) {
        e.preventDefault();
        setExpandedCropId(null);
      }
    };
    window.addEventListener('fieldbook:hardware-back', handleHardwareBack);
    return () => window.removeEventListener('fieldbook:hardware-back', handleHardwareBack);
  }, [viewingReceiptTx, selectedTxDetail, cropToDelete, isUdhaarExpanded, expandedCropId]);

  const monthlyFarmSummary = calculateMonthlyFarmAccounting(
    crops,
    transactions,
    harvests,
    selectedMonthKey
  );

  // Keep selectedMonthKey synced if user adds first transaction in a new month
  useEffect(() => {
    if (
      monthlyFarmSummary.availableMonthKeys.length > 0 &&
      !monthlyFarmSummary.availableMonthKeys.includes(selectedMonthKey)
    ) {
      setSelectedMonthKey(monthlyFarmSummary.monthKey);
    }
  }, [transactions.length, harvests.length]);

  const selectableMonths = Array.from(
    new Set([
      ...monthlyFarmSummary.availableMonthKeys,
      selectedMonthKey
    ])
  ).sort((a, b) => a.localeCompare(b));

  const currentMonthIdx = selectableMonths.indexOf(selectedMonthKey);

  // Deduplicate valid transactions for overall lifetime farm totals
  const validCropIds = new Set(crops.map((c) => c.id));
  const seenLifetimeTxIds = new Set<string>();
  const validLifetimeTransactions = transactions.filter((t) => {
    if (!t || !t.id || seenLifetimeTxIds.has(t.id)) return false;
    if (!validCropIds.has(t.cropId)) return false;
    seenLifetimeTxIds.add(t.id);
    return true;
  });

  const totalFarmExpenses = validLifetimeTransactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + (Number.isFinite(Number(t.amount)) ? Number(t.amount) : 0), 0);

  const totalFarmIncome = validLifetimeTransactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + (Number.isFinite(Number(t.amount)) ? Number(t.amount) : 0), 0);

  const netFarmProfit = totalFarmIncome - totalFarmExpenses;
  const farmLandSummary = calculateFarmLandSummary(crops, lang);
  const pendingSummary = calculatePendingPaymentsSummary(crops, transactions);
  const cropNameMap = new Map(crops.map((c) => [c.id, lang === 'hi' ? c.hindiName || c.name : c.name]));

  const filteredCrops = crops.filter((crop) => {
    const matchesSearch =
      crop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      crop.hindiName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (crop.variety && crop.variety.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesSeason = filterSeason === 'all' || crop.season === filterSeason;
    const matchesStatus = filterStatus === 'all' || crop.status === filterStatus;

    return matchesSearch && matchesSeason && matchesStatus;
  });

  return (
    <div className="space-y-3.5 pb-20">
      {/* Farm Portfolio Ledger — 3D Translucent Liquid Glass Summary Card */}
      <section className="liquid-glass-card rounded-[26px] p-3.5 sm:p-5">
        <div className="mb-3">
          <div className="inline-flex flex-wrap items-center gap-1.5 text-xs sm:text-sm font-bold text-emerald-800 dark:text-emerald-300 mb-0.5">
            <Sprout className="w-4 h-4 shrink-0 text-emerald-700 dark:text-emerald-400" />
            <span>{lang === 'hi' ? 'खेत का संपूर्ण हिसाब-किताब' : 'Farm Portfolio Ledger'}</span>
            <span>·</span>
            <span>
              {crops.length} {lang === 'hi' ? 'फसलें' : 'Crops'} ({farmLandSummary.primaryDisplayLabel})
            </span>
          </div>
          {farmLandSummary.secondaryConversionLabel && (
            <div className="text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-0.5">
              📍 {farmLandSummary.secondaryConversionLabel}
            </div>
          )}
          <h1 className="text-lg sm:text-2xl font-black tracking-tight text-slate-950 dark:text-white">
            {lang === 'hi' ? 'मेरी फसलें व कुल मुनाफा' : 'My Crops & Net Profit'}
          </h1>
        </div>

        {/* 3 Translucent 3D Glass Financial Sub-Cards — Responsive Font Sizes to Prevent Clipping */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3.5">
          {/* 1. Total Expenses (Lagat) */}
          <div className="liquid-glass-expense rounded-2xl p-2 sm:p-3.5 min-w-0">
            <div className="flex items-start gap-1">
              <Wallet className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-rose-700 dark:text-rose-300 shrink-0 mt-0.5" />
              <span className="text-[10px] sm:text-xs font-extrabold leading-tight text-rose-900 dark:text-rose-200">
                {lang === 'hi' ? 'कुल लागत' : 'Total Lagat'}
              </span>
            </div>
            <span className="text-xs sm:text-xl font-black font-mono tabular-nums block text-rose-800 dark:text-rose-300 mt-1 break-words">
              {formatCurrency(totalFarmExpenses)}
            </span>
          </div>

          {/* 2. Total Income (Kamai) */}
          <div className="liquid-glass-income rounded-2xl p-2 sm:p-3.5 min-w-0">
            <div className="flex items-start gap-1">
              <BarChart2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-800 dark:text-emerald-300 shrink-0 mt-0.5" />
              <span className="text-[10px] sm:text-xs font-extrabold leading-tight text-emerald-950 dark:text-emerald-200">
                {lang === 'hi' ? 'कुल कमाई' : 'Total Kamai'}
              </span>
            </div>
            <span className="text-xs sm:text-xl font-black font-mono tabular-nums block text-emerald-900 dark:text-emerald-300 mt-1 break-words">
              {formatCurrency(totalFarmIncome)}
            </span>
          </div>

          {/* 3. Net Profit / Net Loss */}
          <div
            className={`rounded-2xl p-2 sm:p-3.5 min-w-0 ${
              netFarmProfit >= 0 ? 'liquid-glass-profit' : 'liquid-glass-expense'
            }`}
          >
            <div className="flex items-start gap-1">
              {netFarmProfit >= 0 ? (
                <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-800 dark:text-blue-300 shrink-0 mt-0.5" />
              ) : (
                <TrendingDown className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-rose-700 dark:text-rose-300 shrink-0 mt-0.5" />
              )}
              <span
                className={`text-[10px] sm:text-xs font-extrabold leading-tight ${
                  netFarmProfit >= 0
                    ? 'text-blue-950 dark:text-blue-200'
                    : 'text-rose-950 dark:text-rose-200'
                }`}
              >
                {netFarmProfit >= 0
                  ? getTranslation(lang, 'netProfit')
                  : getTranslation(lang, 'netLoss')}
              </span>
            </div>
            <span
              className={`text-xs sm:text-xl font-black font-mono tabular-nums block mt-1 break-words ${
                netFarmProfit >= 0
                  ? 'text-blue-800 dark:text-blue-300'
                  : 'text-rose-800 dark:text-rose-300'
              }`}
            >
              {netFarmProfit >= 0 ? '+' : ''}
              {formatCurrency(netFarmProfit)}
            </span>
          </div>
        </div>
      </section>

      {/* ==================== PENDING PAYMENTS / UDHAAR KHATA (उधारी / बाकी हिसाब) ==================== */}
      <section className="liquid-glass-card rounded-[26px] p-3 sm:p-4 border border-amber-300/70 dark:border-amber-700/60">
        <div
          onClick={() => pendingSummary.totalPendingCount > 0 && setIsUdhaarExpanded((p) => !p)}
          className={`flex flex-wrap items-center justify-between gap-2 ${
            pendingSummary.totalPendingCount > 0 ? 'cursor-pointer' : ''
          }`}
        >
          <div className="min-w-0">
            <div className="inline-flex items-center gap-1.5 text-[11px] sm:text-xs font-extrabold text-amber-900 dark:text-amber-300">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
              <span>
                {lang === 'hi'
                  ? 'उधारी / बाकी खाता (Pending Udhaar Tracker)'
                  : 'Pending Payments (Udhaar Tracker)'}
              </span>
            </div>
            <p className="text-[11px] font-bold text-slate-700 dark:text-slate-300 mt-0.5">
              {pendingSummary.totalPendingCount > 0
                ? lang === 'hi'
                  ? `कुल ${pendingSummary.totalPendingCount} उधार प्रविष्टियां बाकी हैं — विवरण देखने व 1-क्लिक चुकता करने के लिए टैप करें`
                  : `${pendingSummary.totalPendingCount} pending entries — tap to view & mark paid`
                : lang === 'hi'
                ? '✓ सभी खर्च और मंडी बिक्री का भुगतान पूरा है (कोई उधारी बाकी नहीं)'
                : '✓ All expenses and sales are fully settled (No pending udhaar)'}
            </p>
          </div>

          {pendingSummary.totalPendingCount > 0 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsUdhaarExpanded((p) => !p);
              }}
              className="liquid-glass-btn px-2.5 py-1.5 rounded-xl text-[11px] font-black text-amber-950 dark:text-amber-200 flex items-center gap-1 cursor-pointer shrink-0"
            >
              <span>
                {isUdhaarExpanded
                  ? lang === 'hi'
                    ? 'छुपाएं'
                    : 'Hide'
                  : lang === 'hi'
                  ? `बाकी सूची (${pendingSummary.totalPendingCount})`
                  : `View (${pendingSummary.totalPendingCount})`}
              </span>
              {isUdhaarExpanded ? (
                <ChevronUp className="w-3.5 h-3.5" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5" />
              )}
            </button>
          )}
        </div>

        {/* 2 Summary Boxes: कुल देना बाकी (Payable) & कुल लेना बाकी (Receivable) */}
        <div className="grid grid-cols-2 gap-2 sm:gap-3 mt-2.5">
          <div className="liquid-glass-expense rounded-2xl p-2.5 sm:p-3">
            <span className="text-[10px] sm:text-xs font-extrabold text-rose-950 dark:text-rose-200 block">
              {lang === 'hi' ? '🔴 कुल देना बाकी (उधार खर्च)' : '🔴 Total Payable (Expense)'}
            </span>
            <span className="text-sm sm:text-lg font-black font-mono tabular-nums text-rose-800 dark:text-rose-300 block mt-0.5">
              {formatCurrency(pendingSummary.totalPayableExpenses)}
            </span>
            <span className="text-[10px] font-bold text-rose-900/90 dark:text-rose-300/80 block">
              {pendingSummary.payableTransactions.length}{' '}
              {lang === 'hi' ? 'खर्च प्रविष्टि बाकी' : 'unpaid expenses'}
            </span>
          </div>

          <div className="liquid-glass-income rounded-2xl p-2.5 sm:p-3">
            <span className="text-[10px] sm:text-xs font-extrabold text-emerald-950 dark:text-emerald-200 block">
              {lang === 'hi' ? '🟢 कुल लेना बाकी (मंडी/बिक्री)' : '🟢 Total Receivable (Sales)'}
            </span>
            <span className="text-sm sm:text-lg font-black font-mono tabular-nums text-emerald-900 dark:text-emerald-300 block mt-0.5">
              {formatCurrency(pendingSummary.totalReceivableSales)}
            </span>
            <span className="text-[10px] font-bold text-emerald-950/90 dark:text-emerald-300/80 block">
              {pendingSummary.receivableTransactions.length}{' '}
              {lang === 'hi' ? 'बिक्री प्रविष्टि बाकी' : 'unpaid sales'}
            </span>
          </div>
        </div>

        {/* Expanded Pending Items with 1-Tap Mark Paid */}
        {isUdhaarExpanded && pendingSummary.totalPendingCount > 0 && (
          <div className="mt-3 pt-2.5 border-t border-slate-300/60 dark:border-slate-700/70 space-y-2 max-h-80 overflow-y-auto pr-0.5">
            {[...pendingSummary.payableTransactions, ...pendingSummary.receivableTransactions].map(
              (tx) => {
                const isExp = tx.type === 'expense';
                const cropTitle = cropNameMap.get(tx.cropId) || '';
                return (
                  <div
                    key={tx.id}
                    onClick={() => setSelectedTxDetail({ tx, cropName: cropTitle })}
                    className={`rounded-xl p-2.5 flex items-center justify-between gap-2 cursor-pointer border ${
                      isExp
                        ? 'bg-rose-50/90 dark:bg-rose-950/50 border-rose-200 dark:border-rose-800/70'
                        : 'bg-emerald-50/90 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800/70'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-black ${
                            isExp
                              ? 'bg-rose-200/90 text-rose-950 dark:bg-rose-900 dark:text-rose-200'
                              : 'bg-emerald-200/90 text-emerald-950 dark:bg-emerald-900 dark:text-emerald-200'
                          }`}
                        >
                          {isExp
                            ? lang === 'hi'
                              ? 'देना बाकी'
                              : 'Payable'
                            : lang === 'hi'
                            ? 'लेना बाकी'
                            : 'Receivable'}
                        </span>
                        <span className="text-xs font-black text-slate-950 dark:text-white truncate">
                          {tx.title || getTranslation(lang, tx.category as any)}
                        </span>
                      </div>
                      <div className="text-[11px] font-bold text-slate-700 dark:text-slate-300 mt-0.5 flex flex-wrap items-center gap-1.5">
                        <span>🌾 {cropTitle}</span>
                        <span>•</span>
                        <span>📅 {tx.date}</span>
                        {tx.vendorOrBuyer && (
                          <>
                            <span>•</span>
                            <span>👤 {tx.vendorOrBuyer}</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`text-xs sm:text-sm font-black font-mono tabular-nums ${
                          isExp
                            ? 'text-rose-800 dark:text-rose-300'
                            : 'text-emerald-800 dark:text-emerald-300'
                        }`}
                      >
                        {formatCurrency(tx.amount)}
                      </span>
                      {onMarkTransactionPaid && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onMarkTransactionPaid(tx.id);
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-black flex items-center gap-1 shadow-sm cursor-pointer shrink-0"
                          title={lang === 'hi' ? 'चुकता करें (Mark as Paid)' : 'Mark as Paid'}
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{lang === 'hi' ? 'चुकता करें' : 'Mark Paid'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              }
            )}
          </div>
        )}
      </section>

      {/* ==================== COMPACT HOME PAGE MONTHLY CROP SUMMARY ==================== */}
      <section className="liquid-glass-card rounded-[26px] p-3 sm:p-4 space-y-2.5">
        {/* Compact Header & Month/Year Selector Row */}
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-300/60 dark:border-slate-700/70">
          <div className="min-w-0">
            <div className="inline-flex items-center gap-1.5 text-[11px] sm:text-xs font-extrabold text-emerald-800 dark:text-emerald-300">
              <Calendar className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400 shrink-0" />
              <span>
                {lang === 'hi' ? 'मासिक खेत हिसाब (Monthly Summary)' : 'Monthly Crop Summary'}
              </span>
            </div>
            <h2 className="text-sm sm:text-base font-black text-slate-950 dark:text-white leading-tight">
              {formatMonthLabel(selectedMonthKey, lang)}
            </h2>
          </div>

          {/* Compact Month & Year Selector Controls */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              disabled={currentMonthIdx <= 0}
              onClick={() => {
                if (currentMonthIdx > 0) {
                  setSelectedMonthKey(selectableMonths[currentMonthIdx - 1]);
                }
              }}
              aria-label={lang === 'hi' ? 'पिछला महीना' : 'Previous Month'}
              className="liquid-glass-pill p-1.5 rounded-xl disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>

            <select
              aria-label={lang === 'hi' ? 'महीना और वर्ष चुनें' : 'Select Month and Year'}
              value={selectedMonthKey}
              onChange={(e) => setSelectedMonthKey(e.target.value)}
              className="liquid-glass-pill px-2.5 py-1.5 rounded-xl text-xs font-extrabold cursor-pointer"
            >
              {selectableMonths.map((mKey) => (
                <option key={mKey} value={mKey}>
                  📅 {formatMonthLabel(mKey, lang)}
                </option>
              ))}
            </select>

            <button
              type="button"
              disabled={currentMonthIdx === -1 || currentMonthIdx >= selectableMonths.length - 1}
              onClick={() => {
                if (currentMonthIdx !== -1 && currentMonthIdx < selectableMonths.length - 1) {
                  setSelectedMonthKey(selectableMonths[currentMonthIdx + 1]);
                }
              }}
              aria-label={lang === 'hi' ? 'अगला महीना' : 'Next Month'}
              className="liquid-glass-pill p-1.5 rounded-xl disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>

            <input
              type="month"
              aria-label={lang === 'hi' ? 'अन्य महीना चुनें' : 'Pick Month and Year'}
              value={selectedMonthKey}
              onChange={(e) => {
                if (e.target.value) {
                  setSelectedMonthKey(e.target.value);
                }
              }}
              className="liquid-glass-input px-2 py-1 rounded-xl text-[11px] font-mono font-bold w-[112px] sm:w-auto"
            />
          </div>
        </div>

        {/* Selected Month Compact Spending, Earnings & Net Profit/Loss Strip */}
        <div className="grid grid-cols-3 gap-2">
          {/* Monthly Spending (Expenses) */}
          <div className="liquid-glass-expense rounded-xl p-2 sm:p-2.5 min-w-0">
            <span className="text-[10px] sm:text-xs font-extrabold block text-rose-900 dark:text-rose-200 leading-tight">
              {lang === 'hi' ? 'मासिक खर्च (Spending)' : 'Monthly Spending'}
            </span>
            <span className="text-xs sm:text-base font-black font-mono tabular-nums block text-rose-800 dark:text-rose-300 mt-0.5 break-words">
              {formatCurrency(monthlyFarmSummary.totalExpenses)}
            </span>
          </div>

          {/* Monthly Earnings (Sales) */}
          <div className="liquid-glass-income rounded-xl p-2 sm:p-2.5 min-w-0">
            <span className="text-[10px] sm:text-xs font-extrabold block text-emerald-950 dark:text-emerald-200 leading-tight">
              {lang === 'hi' ? 'मासिक कमाई (Earnings)' : 'Monthly Earnings'}
            </span>
            <span className="text-xs sm:text-base font-black font-mono tabular-nums block text-emerald-900 dark:text-emerald-300 mt-0.5 break-words">
              {formatCurrency(monthlyFarmSummary.totalSales)}
            </span>
          </div>

          {/* Monthly Profit or Loss */}
          <div
            className={`rounded-xl p-2 sm:p-2.5 min-w-0 ${
              monthlyFarmSummary.netProfit >= 0
                ? 'liquid-glass-profit'
                : 'liquid-glass-expense'
            }`}
          >
            <span
              className={`text-[10px] sm:text-xs font-extrabold block leading-tight ${
                monthlyFarmSummary.netProfit >= 0
                  ? 'text-blue-950 dark:text-blue-200'
                  : 'text-rose-950 dark:text-rose-200'
              }`}
            >
              {monthlyFarmSummary.netProfit > 0
                ? lang === 'hi'
                  ? 'मासिक मुनाफा'
                  : 'Monthly Profit'
                : monthlyFarmSummary.netProfit < 0
                ? lang === 'hi'
                  ? 'मासिक घाटा'
                  : 'Monthly Loss'
                : lang === 'hi'
                ? 'मासिक परिणाम'
                : 'Monthly Net'}
            </span>
            <span
              className={`text-xs sm:text-base font-black font-mono tabular-nums block mt-0.5 break-words ${
                monthlyFarmSummary.netProfit >= 0
                  ? 'text-blue-800 dark:text-blue-300'
                  : 'text-rose-800 dark:text-rose-300'
              }`}
            >
              {monthlyFarmSummary.netProfit > 0 ? '+' : ''}
              {formatCurrency(monthlyFarmSummary.netProfit)}
            </span>
          </div>
        </div>

        {/* Crop-Wise Monthly Summary List */}
        {monthlyFarmSummary.cropSummaries.length > 0 ? (
          <div className="space-y-2.5">
            <div className="flex items-center justify-between text-xs font-extrabold text-slate-900 dark:text-slate-200 px-0.5">
              <span>
                {lang === 'hi'
                  ? `फसल-वार मासिक हिसाब (${monthlyFarmSummary.cropSummaries.length} फसल)`
                  : `Crop-wise Monthly Summary (${monthlyFarmSummary.cropSummaries.length} ${
                      monthlyFarmSummary.cropSummaries.length === 1 ? 'Crop' : 'Crops'
                    })`}
              </span>
              <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                {lang === 'hi' ? 'विवरण के लिए फसल पर टैप करें' : 'Tap a crop for details'}
              </span>
            </div>

            {monthlyFarmSummary.cropSummaries.map((cropSum) => {
              const cropId = cropSum.crop.id;
              const cropDisplayName =
                lang === 'hi'
                  ? cropSum.crop.hindiName || cropSum.crop.name
                  : cropSum.crop.name;
              const cropCategory = getEffectiveCropCategory(cropSum.crop);
              const accountingType = getEffectiveCropAccountingType(cropSum.crop);
              const isExpanded = expandedCropId === cropId;
              const isCropProfit = cropSum.netProfit >= 0;
              const nonZeroCategoryEntries = (
                Object.entries(cropSum.expensesByCategory) as [string, number][]
              ).filter(([, amt]) => amt > 0);

              return (
                <div
                  key={cropId}
                  className="liquid-glass-subcard rounded-2xl overflow-hidden border border-slate-300/70 dark:border-slate-700/80 transition-all"
                >
                  {/* Tappable Crop Monthly Summary Header */}
                  <button
                    type="button"
                    onClick={() =>
                      setExpandedCropId((prev) => (prev === cropId ? null : cropId))
                    }
                    className="w-full p-3 sm:p-3.5 text-left flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 cursor-pointer hover:bg-white/40 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-sm sm:text-base font-black text-slate-950 dark:text-white">
                          {cropDisplayName}
                        </span>
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-emerald-100/90 dark:bg-emerald-950/70 text-emerald-900 dark:text-emerald-300 border border-emerald-300/70 dark:border-emerald-800">
                          {getCropCategoryLabel(cropCategory, lang)}
                        </span>
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-100/90 dark:bg-blue-950/70 text-blue-900 dark:text-blue-300 border border-blue-300/70 dark:border-blue-800 inline-flex items-center gap-1">
                          {accountingType === 'recurring' ? (
                            <Repeat className="w-2.5 h-2.5" />
                          ) : (
                            <Layers className="w-2.5 h-2.5" />
                          )}
                          <span>
                            {accountingType === 'recurring'
                              ? lang === 'hi'
                                ? 'बार-बार तुड़ाई'
                                : 'Repeated Harvest'
                              : lang === 'hi'
                              ? 'एक बार कटाई'
                              : 'Single Harvest'}
                          </span>
                        </span>
                      </div>

                      {/* Compact readable line: Expenses ₹..., Sales ₹..., Profit/Loss ₹... */}
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-bold">
                        <span className="text-rose-800 dark:text-rose-300">
                          {lang === 'hi' ? 'खर्च:' : 'Expenses:'}{' '}
                          <strong className="font-mono">{formatCurrency(cropSum.expensesTotal)}</strong>
                        </span>
                        <span className="text-slate-400">•</span>
                        <span className="text-emerald-800 dark:text-emerald-300">
                          {lang === 'hi' ? 'बिक्री:' : 'Sales:'}{' '}
                          <strong className="font-mono">{formatCurrency(cropSum.salesTotal)}</strong>
                        </span>
                        <span className="text-slate-400">•</span>
                        <span
                          className={
                            isCropProfit
                              ? 'text-blue-800 dark:text-blue-300'
                              : 'text-rose-800 dark:text-rose-300'
                          }
                        >
                          {cropSum.netProfit >= 0
                            ? lang === 'hi'
                              ? 'मुनाफा:'
                              : 'Profit:'
                            : lang === 'hi'
                            ? 'घाटा:'
                            : 'Loss:'}{' '}
                          <strong className="font-mono">
                            {cropSum.netProfit > 0 ? '+' : ''}
                            {formatCurrency(cropSum.netProfit)}
                          </strong>
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0">
                      <span className="text-[11px] font-extrabold text-emerald-800 dark:text-emerald-300 underline decoration-dotted">
                        {isExpanded
                          ? lang === 'hi'
                            ? 'ब्यौरा छुपाएं'
                            : 'Hide Details'
                          : lang === 'hi'
                          ? 'खर्च व बिक्री देखें'
                          : 'View Details'}
                      </span>
                      <div className="w-7 h-7 rounded-full liquid-glass-pill flex items-center justify-center">
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </div>
                    </div>
                  </button>

                  {/* Expanded Monthly Crop Expense Categories & Individual Transactions */}
                  {isExpanded && (
                    <div className="p-3 sm:p-4 border-t border-slate-300/80 dark:border-slate-700/80 bg-white/90 dark:bg-slate-900/88 space-y-3.5">
                      {/* 1. Expense Categories Breakdown for Selected Month */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-extrabold text-slate-900 dark:text-slate-100">
                            {lang === 'hi'
                              ? '📋 मद-वार मासिक खर्च (Expense Categories)'
                              : '📋 Monthly Expenses by Category'}
                          </h4>
                          <button
                            type="button"
                            onClick={() => onSelectCrop(cropId)}
                            className="text-[11px] font-extrabold text-emerald-800 dark:text-emerald-300 inline-flex items-center gap-1 hover:underline cursor-pointer"
                          >
                            <span>{lang === 'hi' ? 'पूरी फसल खोलें' : 'Open Crop Page'}</span>
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        </div>

                        {nonZeroCategoryEntries.length > 0 ? (
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                            {nonZeroCategoryEntries.map(([cat, amount]) => (
                              <div
                                key={cat}
                                className="p-2.5 rounded-xl border border-rose-300 dark:border-rose-800/80 bg-rose-50/95 dark:bg-rose-950/70 flex items-center justify-between gap-2"
                              >
                                <span className="text-[11px] font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1 truncate">
                                  <span>{EXPENSE_CATEGORY_ICONS[cat] || '📦'}</span>
                                  <span className="truncate">
                                    {getTranslation(lang, cat as any)}
                                  </span>
                                </span>
                                <span className="text-xs font-black font-mono text-rose-800 dark:text-rose-300 shrink-0">
                                  {formatCurrency(amount)}
                                </span>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                            {lang === 'hi'
                              ? 'इस महीने इस फसल में कोई खर्च दर्ज नहीं है।'
                              : 'No expenses recorded for this crop in this month.'}
                          </p>
                        )}
                      </div>

                      {/* 2. Individual Recorded Expense & Income Entries in Selected Month */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {/* Expense Entries Column */}
                        <div className="space-y-1.5">
                          <h5 className="text-xs font-extrabold text-rose-800 dark:text-rose-300">
                            🔴{' '}
                            {lang === 'hi'
                              ? `दर्ज खर्च (${cropSum.expenseTransactions.length})`
                              : `Recorded Expenses (${cropSum.expenseTransactions.length})`}
                          </h5>
                          {cropSum.expenseTransactions.length > 0 ? (
                            <div className="space-y-1.5">
                              {cropSum.expenseTransactions.map((tx) => (
                                <button
                                  key={tx.id}
                                  type="button"
                                  onClick={() =>
                                    setSelectedTxDetail({
                                      tx,
                                      cropName: cropDisplayName
                                    })
                                  }
                                  className="w-full text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 hover:border-rose-400 transition-colors flex items-center justify-between gap-2 cursor-pointer"
                                >
                                  <div className="min-w-0">
                                    <div className="flex items-center gap-1.5">
                                      <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                                        {tx.title}
                                      </span>
                                      {tx.receiptAttachment && (
                                        <Paperclip className="w-3 h-3 text-emerald-600 shrink-0" />
                                      )}
                                    </div>
                                    <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mt-0.5">
                                      <span className="font-mono">{tx.date}</span>
                                      <span>•</span>
                                      <span>{getTranslation(lang, tx.category as any)}</span>
                                    </div>
                                  </div>
                                  <span className="text-xs font-black font-mono text-rose-700 dark:text-rose-400 shrink-0">
                                    -{formatCurrency(tx.amount)}
                                  </span>
                                </button>
                              ))}
                            </div>
                          ) : (
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 italic">
                              {lang === 'hi' ? 'कोई खर्च प्रविष्टि नहीं' : 'No expense entries'}
                            </p>
                          )}
                        </div>

                        {/* Income / Sales Entries Column */}
                        <div className="space-y-1.5">
                          <h5 className="text-xs font-extrabold text-emerald-800 dark:text-emerald-300">
                            🟢{' '}
                            {lang === 'hi'
                              ? `दर्ज बिक्री / कमाई (${cropSum.salesTransactions.length})`
                              : `Recorded Sales / Income (${cropSum.salesTransactions.length})`}
                          </h5>
                          {cropSum.salesTransactions.length > 0 ? (
                            <div className="space-y-1.5">
                              {cropSum.salesTransactions.map((tx) => (
                                <button
                                  key={tx.id}
                                  type="button"
                                  onClick={() =>
                                    setSelectedTxDetail({
                                      tx,
                                      cropName: cropDisplayName
                                    })
                                  }
                                  className="w-full text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 hover:border-emerald-400 transition-colors flex items-center justify-between gap-2 cursor-pointer"
                                >
                                  <div className="min-w-0">
                                    <div className="flex items-center gap-1.5">
                                      <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                                        {tx.title}
                                      </span>
                                      {tx.receiptAttachment && (
                                        <Paperclip className="w-3 h-3 text-emerald-600 shrink-0" />
                                      )}
                                    </div>
                                    <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mt-0.5">
                                      <span className="font-mono">{tx.date}</span>
                                      {tx.vendorOrBuyer && (
                                        <>
                                          <span>•</span>
                                          <span className="truncate">{tx.vendorOrBuyer}</span>
                                        </>
                                      )}
                                    </div>
                                  </div>
                                  <span className="text-xs font-black font-mono text-emerald-700 dark:text-emerald-400 shrink-0">
                                    +{formatCurrency(tx.amount)}
                                  </span>
                                </button>
                              ))}
                            </div>
                          ) : (
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 italic">
                              {lang === 'hi' ? 'कोई बिक्री प्रविष्टि नहीं' : 'No sale entries'}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-4 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 text-center">
            <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
              {lang === 'hi'
                ? `${formatMonthLabel(selectedMonthKey, lang)} में किसी भी फसल का खर्च या बिक्री दर्ज नहीं है।`
                : `No crop expenses or sales recorded in ${formatMonthLabel(selectedMonthKey, lang)}.`}
            </p>
          </div>
        )}
      </section>

      {/* Search Bar & Filter Controls matching Reference Image */}
      <div className="space-y-2.5">
        {/* Full-Width Rounded Pill Frosted Glass Search Input */}
        <div className="relative w-full">
          <Search className="w-4 h-4 sm:w-5 sm:h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-700 dark:text-slate-200 pointer-events-none z-10" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={
              lang === 'hi'
                ? 'फसल खोजें (गेहूं, सरसों, मिर्च, किस्म)...'
                : 'Search crop by name or variety...'
            }
            className="liquid-glass-input w-full pl-11 pr-4 py-2.5 sm:py-3 rounded-full text-xs sm:text-sm font-semibold focus:outline-hidden"
          />
        </div>

        {/* 3-Control Filter & Action Row: All Seasons | All Status | + Add New Crop — Zero Clipping on Mobile */}
        <div className="grid grid-cols-2 sm:flex sm:items-center sm:justify-between gap-2">
          {/* Season Filter Pill */}
          <div className="relative flex-1 min-w-0">
            <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-800 dark:text-slate-200 pointer-events-none z-10" />
            <select
              value={filterSeason}
              onChange={(e) => setFilterSeason(e.target.value)}
              aria-label={lang === 'hi' ? 'सीज़न चुनें' : 'Filter by season'}
              className="liquid-glass-pill w-full appearance-none pl-8 pr-6 py-2.5 rounded-full text-xs font-extrabold cursor-pointer truncate"
            >
              <option value="all">{lang === 'hi' ? 'सभी सीज़न' : 'All Seasons'}</option>
              <option value="rabi">रबी (Rabi)</option>
              <option value="kharif">खरीफ (Kharif)</option>
              <option value="zaid">जायद (Zaid)</option>
              <option value="annual">वार्षिक (Annual)</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-700 dark:text-slate-300 pointer-events-none z-10" />
          </div>

          {/* Status Filter Pill */}
          <div className="relative flex-1 min-w-0">
            <Filter className="w-3.5 h-3.5 sm:w-4 sm:h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-800 dark:text-slate-200 pointer-events-none z-10" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              aria-label={lang === 'hi' ? 'स्थिति चुनें' : 'Filter by status'}
              className="liquid-glass-pill w-full appearance-none pl-8 pr-6 py-2.5 rounded-full text-xs font-extrabold cursor-pointer truncate"
            >
              <option value="all">{lang === 'hi' ? 'सभी स्थिति' : 'All Status'}</option>
              <option value="active">{getTranslation(lang, 'active')}</option>
              <option value="harvested">{getTranslation(lang, 'harvested')}</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-700 dark:text-slate-300 pointer-events-none z-10" />
          </div>

          {/* + Add New Crop Primary Emerald 3D Glass Pill Button — Full Width on Mobile Row 2 so Text Never Clips */}
          <button
            type="button"
            onClick={onOpenAddCrop}
            className="col-span-2 sm:col-span-1 liquid-glass-emerald flex items-center justify-center gap-1.5 px-4 sm:px-5 py-2.5 rounded-full text-white font-extrabold text-xs sm:text-sm whitespace-nowrap cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 shrink-0" />
            <span>{getTranslation(lang, 'addCrop')}</span>
          </button>
        </div>
      </div>

      {/* Crop Cards Grid */}
      {filteredCrops.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCrops.map((crop) => (
            <CropCard
              key={crop.id}
              crop={crop}
              transactions={transactions}
              harvests={harvests}
              lang={lang}
              theme={theme}
              onSelect={onSelectCrop}
              onDelete={
                onDeleteCrop
                  ? (id, name) => setCropToDelete({ id, name })
                  : undefined
              }
            />
          ))}
        </div>
      ) : (
        <div className="liquid-glass-card text-center py-10 px-4 rounded-[28px]">
          <div className="w-12 h-12 mx-auto rounded-2xl liquid-glass-income text-emerald-800 dark:text-emerald-300 flex items-center justify-center mb-3">
            <Sprout className="w-6 h-6" />
          </div>
          <h3 className="text-base font-extrabold mb-1 text-slate-950 dark:text-white">
            {lang === 'hi' ? 'कोई फसल नहीं मिली' : 'No Crops Found'}
          </h3>
          <p className="text-xs font-medium text-slate-700 dark:text-slate-300 max-w-xs mx-auto mb-4">
            {lang === 'hi'
              ? 'खेत की फसल का हिसाब रखने के लिए नीचे दिए गए बटन से पहली फसल जोड़ें।'
              : 'Add your first crop to begin tracking expenses, mandi sales, and net profit.'}
          </p>
          <button
            type="button"
            onClick={onOpenAddCrop}
            className="liquid-glass-emerald inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-white font-bold text-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{getTranslation(lang, 'addCrop')}</span>
          </button>
        </div>
      )}

      {/* Individual Expense / Income Transaction Detail Modal (Opened when tapping an entry in Home Monthly Account) */}
      {selectedTxDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-sm">
          <div className="liquid-glass-modal w-full max-w-md rounded-3xl p-5 space-y-4">
            <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <span
                  className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-extrabold mb-1 ${
                    selectedTxDetail.tx.type === 'expense'
                      ? 'bg-rose-100 dark:bg-rose-950/80 text-rose-800 dark:text-rose-300'
                      : 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300'
                  }`}
                >
                  {selectedTxDetail.tx.type === 'expense'
                    ? lang === 'hi'
                      ? '🔴 खर्च प्रविष्टि (Expense)'
                      : '🔴 Expense Entry'
                    : lang === 'hi'
                    ? '🟢 बिक्री / कमाई (Income)'
                    : '🟢 Sale / Income Entry'}
                </span>
                <h3 className="text-base font-black text-slate-950 dark:text-white">
                  {selectedTxDetail.tx.title}
                </h3>
                <p className="text-xs font-bold text-emerald-800 dark:text-emerald-300">
                  {selectedTxDetail.cropName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTxDetail(null)}
                className="w-8 h-8 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-100/80 dark:bg-slate-800/70">
                <span className="font-bold text-slate-600 dark:text-slate-300">
                  {lang === 'hi' ? 'कुल राशि (Amount):' : 'Total Amount:'}
                </span>
                <span
                  className={`text-base font-black font-mono ${
                    selectedTxDetail.tx.type === 'expense'
                      ? 'text-rose-700 dark:text-rose-400'
                      : 'text-emerald-700 dark:text-emerald-400'
                  }`}
                >
                  {selectedTxDetail.tx.type === 'expense' ? '-' : '+'}
                  {formatCurrency(selectedTxDetail.tx.amount)}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] font-bold text-slate-500 block">
                    {lang === 'hi' ? 'तारीख और समय' : 'Date & Time'}
                  </span>
                  <span className="font-mono font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1 mt-0.5">
                    <Clock className="w-3 h-3 text-emerald-600" />
                    {selectedTxDetail.tx.date} {selectedTxDetail.tx.time}
                  </span>
                </div>

                <div className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] font-bold text-slate-500 block">
                    {lang === 'hi' ? 'श्रेणी (Category)' : 'Category'}
                  </span>
                  <span className="font-bold text-slate-900 dark:text-slate-100 block mt-0.5">
                    {getTranslation(lang, selectedTxDetail.tx.category as any)}
                  </span>
                </div>
              </div>

              {(selectedTxDetail.tx.quantity || selectedTxDetail.tx.vendorOrBuyer) && (
                <div className="grid grid-cols-2 gap-2">
                  {selectedTxDetail.tx.quantity && (
                    <div className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                      <span className="text-[10px] font-bold text-slate-500 block">
                        {lang === 'hi' ? 'मात्रा (Quantity)' : 'Quantity'}
                      </span>
                      <span className="font-mono font-bold text-slate-900 dark:text-slate-100 block mt-0.5">
                        {selectedTxDetail.tx.quantity} {selectedTxDetail.tx.unit || ''}
                      </span>
                    </div>
                  )}
                  {selectedTxDetail.tx.vendorOrBuyer && (
                    <div className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                      <span className="text-[10px] font-bold text-slate-500 block">
                        {selectedTxDetail.tx.type === 'expense'
                          ? lang === 'hi'
                            ? 'दुकानदार / विक्रेता'
                            : 'Vendor / Shop'
                          : lang === 'hi'
                          ? 'खरीदार / आढ़ती'
                          : 'Buyer / Mandi'}
                      </span>
                      <span className="font-bold text-slate-900 dark:text-slate-100 block mt-0.5">
                        {selectedTxDetail.tx.vendorOrBuyer}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {selectedTxDetail.tx.notes && (
                <div className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] font-bold text-slate-500 block">
                    {lang === 'hi' ? 'नोट्स / विवरण' : 'Notes'}
                  </span>
                  <p className="text-slate-800 dark:text-slate-200 mt-0.5">
                    {selectedTxDetail.tx.notes}
                  </p>
                </div>
              )}

              {selectedTxDetail.tx.receiptAttachment && (
                <button
                  type="button"
                  onClick={() => {
                    const detail = selectedTxDetail;
                    setSelectedTxDetail(null);
                    setViewingReceiptTx(detail);
                  }}
                  className="liquid-glass-pill w-full py-2.5 px-3 rounded-xl font-extrabold text-emerald-900 dark:text-emerald-300 flex items-center justify-center gap-1.5 cursor-pointer border border-emerald-400/60"
                >
                  <Paperclip className="w-3.5 h-3.5" />
                  <span>
                    {lang === 'hi'
                      ? `संलग्न बिल / रसीद देखें (${selectedTxDetail.tx.receiptAttachment.fileName})`
                      : `View Attached Bill / Receipt (${selectedTxDetail.tx.receiptAttachment.fileName})`}
                  </span>
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              {selectedTxDetail.tx.paymentStatus === 'pending' && onMarkTransactionPaid && (
                <button
                  type="button"
                  onClick={() => {
                    onMarkTransactionPaid(selectedTxDetail.tx.id);
                    setSelectedTxDetail(null);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{lang === 'hi' ? '✓ चुकता करें (Mark Paid)' : '✓ Mark as Paid'}</span>
                </button>
              )}
              {onEditTransaction && (
                <button
                  type="button"
                  onClick={() => {
                    const tx = selectedTxDetail.tx;
                    setSelectedTxDetail(null);
                    onEditTransaction(tx);
                  }}
                  className="liquid-glass-pill px-3.5 py-2 rounded-xl text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span>{lang === 'hi' ? 'प्रविष्टि सुधारें' : 'Edit Entry'}</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  const cId = selectedTxDetail.tx.cropId;
                  setSelectedTxDetail(null);
                  onSelectCrop(cId);
                }}
                className="liquid-glass-emerald px-4 py-2 rounded-xl text-xs font-extrabold text-white inline-flex items-center gap-1.5 cursor-pointer"
              >
                <span>{lang === 'hi' ? 'फसल खाते में जाएं' : 'Open Crop Ledger'}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Receipt Viewer Modal from Home Page Monthly Account */}
      <ReceiptViewerModal
        isOpen={!!viewingReceiptTx}
        onClose={() => setViewingReceiptTx(null)}
        transaction={viewingReceiptTx?.tx || null}
        cropName={viewingReceiptTx?.cropName || ''}
        lang={lang}
      />

      {/* Confirm Delete Crop Modal */}
      <ConfirmModal
        isOpen={!!cropToDelete}
        title={lang === 'hi' ? 'फसल हटाएं?' : 'Delete Crop?'}
        message={
          lang === 'hi'
            ? `क्या आप सचमुच "${cropToDelete?.name}" फसल और इसके सभी दर्ज खर्च व कमाई का हिसाब हटाना चाहते हैं?`
            : `Are you sure you want to permanently delete "${cropToDelete?.name}" and all its transaction history?`
        }
        confirmLabel={lang === 'hi' ? 'हाँ, फसल हटाएं' : 'Yes, Delete'}
        cancelLabel={lang === 'hi' ? 'रद्द करें' : 'Cancel'}
        isDestructive={true}
        theme={theme}
        onConfirm={() => {
          if (cropToDelete && onDeleteCrop) {
            onDeleteCrop(cropToDelete.id);
          }
          setCropToDelete(null);
        }}
        onCancel={() => setCropToDelete(null)}
      />
    </div>
  );
};

