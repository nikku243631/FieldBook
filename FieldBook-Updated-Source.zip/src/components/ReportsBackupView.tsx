import React, { useState, useRef, useEffect } from 'react';
import {
  FileSpreadsheet,
  Printer,
  Share2,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  Database,
  FileText,
  Smartphone,
  ShieldCheck,
  Sprout,
  TrendingUp,
  TrendingDown,
  Send,
  User,
  Trash2,
  RefreshCw,
  ClipboardPaste
} from 'lucide-react';
import {
  CropCycle,
  Transaction,
  HarvestEntry,
  DiaryEntry,
  Language,
  Theme
} from '../types';
import { formatCurrency } from '../utils/translations';
import { calculateCropFinancials } from '../utils/calculations';
import { Storage } from '../utils/storage';
import { ConfirmModal } from './ConfirmModal';
import {
  exportTransactionsToCSV,
  printCropReportPDF,
  printFarmMonthlyReportPDF,
  generateWhatsAppSummary,
  shareViaWhatsApp,
  downloadTextOrSaveNative
} from '../utils/export';

interface ReportsBackupViewProps {
  crops: CropCycle[];
  transactions: Transaction[];
  harvests: HarvestEntry[];
  diaryEntries?: DiaryEntry[];
  lang: Language;
  theme?: Theme;
  farmerName?: string;
  onUpdateFarmerName?: (name: string) => void;
  onReloadData?: () => void;
  onResetSampleData?: () => void;
  onClearAllData?: () => void;
  onOpenInstallModal?: () => void;
  onRestoreBackup?: (data: {
    crops: CropCycle[];
    transactions: Transaction[];
    harvests: HarvestEntry[];
    diary?: DiaryEntry[];
  }) => void;
}

export const ReportsBackupView: React.FC<ReportsBackupViewProps> = ({
  crops,
  transactions,
  harvests,
  diaryEntries,
  lang,
  theme = 'light',
  farmerName = '',
  onUpdateFarmerName,
  onReloadData,
  onResetSampleData,
  onClearAllData,
  onRestoreBackup
}) => {
  const [selectedCropId, setSelectedCropId] = useState<string>('all');
  const [whatsappPhone, setWhatsappPhone] = useState<string>('');
  const [nameInput, setNameInput] = useState<string>(farmerName);
  const [isSampleResetOpen, setIsSampleResetOpen] = useState<boolean>(false);
  const [isClearConfirmOpen, setIsClearConfirmOpen] = useState<boolean>(false);
  const [showPasteBox, setShowPasteBox] = useState<boolean>(false);
  const [pastedJson, setPastedJson] = useState<string>('');
  const [backupStatus, setBackupStatus] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Listen for Android hardware back button to close open popups first
  useEffect(() => {
    const handleHardwareBack = (e: Event) => {
      if (isSampleResetOpen) {
        e.preventDefault();
        setIsSampleResetOpen(false);
        return;
      }
      if (isClearConfirmOpen) {
        e.preventDefault();
        setIsClearConfirmOpen(false);
        return;
      }
      if (showPasteBox) {
        e.preventDefault();
        setShowPasteBox(false);
      }
    };
    window.addEventListener('fieldbook:hardware-back', handleHardwareBack);
    return () => window.removeEventListener('fieldbook:hardware-back', handleHardwareBack);
  }, [isSampleResetOpen, isClearConfirmOpen, showPasteBox]);

  const selectedCrop = crops.find(c => c.id === selectedCropId) || null;

  let totalExpense = 0;
  let totalIncome = 0;
  crops.forEach(c => {
    const fin = calculateCropFinancials(c, transactions, harvests);
    totalExpense += fin.totalExpenses;
    totalIncome += fin.totalIncome;
  });
  const netProfit = totalIncome - totalExpense;

  const showFeedback = (type: 'success' | 'error', msg: string) => {
    setBackupStatus({ type, msg });
    setTimeout(() => setBackupStatus(null), 6000);
  };

  const handleSaveFarmerName = (e: React.FormEvent) => {
    e.preventDefault();
    if (onUpdateFarmerName) {
      onUpdateFarmerName(nameInput.trim() || 'किसान भाई');
      showFeedback(
        'success',
        lang === 'hi' ? 'किसान का नाम रिपोर्ट के लिए सेव हो गया!' : 'Farmer name saved for reports!'
      );
    }
  };

  const handleExportCSV = () => {
    if (crops.length === 0) {
      showFeedback(
        'error',
        lang === 'hi'
          ? 'रिपोर्ट डाउनलोड करने के लिए कम से कम 1 फसल होनी चाहिए।'
          : 'At least 1 crop is required to download a report.'
      );
      return;
    }
    let ok = false;
    if (selectedCropId === 'all' || !selectedCrop) {
      ok = exportTransactionsToCSV(crops, transactions, lang);
    } else {
      const cropTx = transactions.filter(t => t.cropId === selectedCrop.id);
      ok = exportTransactionsToCSV([selectedCrop], cropTx, lang);
    }
    if (ok) {
      showFeedback(
        'success',
        lang === 'hi'
          ? 'एक्सेल (CSV) रिपोर्ट सफलतापूर्वक डाउनलोड हो गई!'
          : 'Excel (CSV) report downloaded successfully!'
      );
    }
  };

  const handlePrintPDF = () => {
    if (crops.length === 0) {
      showFeedback(
        'error',
        lang === 'hi'
          ? 'पीडीएफ बनाने के लिए कम से कम 1 फसल होनी चाहिए।'
          : 'At least 1 crop is required to generate PDF.'
      );
      return;
    }
    const resolvedFarmer = nameInput.trim() || farmerName || 'किसान भाई';
    if (selectedCropId === 'all' || !selectedCrop) {
      printFarmMonthlyReportPDF(crops, transactions, harvests, resolvedFarmer, lang);
    } else {
      const cropTx = transactions.filter(t => t.cropId === selectedCrop.id);
      const cropHarv = harvests.filter(h => h.cropId === selectedCrop.id);
      printCropReportPDF(selectedCrop, cropTx, cropHarv, resolvedFarmer, lang);
    }
    showFeedback(
      'success',
      lang === 'hi'
        ? '✅ PDF फाइल तैयार होकर डाउनलोड हो गई है और स्क्रीन पर प्रीव्यू खुल गया है!'
        : '✅ PDF file generated & downloaded! Preview opened on screen.'
    );
  };

  const handleWhatsAppShare = () => {
    if (crops.length === 0) {
      showFeedback(
        'error',
        lang === 'hi'
          ? 'व्हाट्सएप पर भेजने के लिए कम से कम 1 फसल होनी चाहिए।'
          : 'At least 1 crop is required to share on WhatsApp.'
      );
      return;
    }
    if (selectedCropId === 'all' || !selectedCrop) {
      const summaryLines = crops.map(c => {
        const fin = calculateCropFinancials(c, transactions, harvests);
        return `• *${c.hindiName || c.name}*: खर्च ${formatCurrency(fin.totalExpenses)} | आमदनी ${formatCurrency(fin.totalIncome)} | शुद्ध ${fin.netProfit >= 0 ? '+' : ''}${formatCurrency(fin.netProfit)}`;
      });
      const masterMsg =
        `🌾 *FieldBook संपूर्ण कृषि खाता रिपोर्ट* 🌾\n` +
        `किसान: ${nameInput.trim() || farmerName || 'किसान भाई'}\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `${summaryLines.join('\n')}\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `💰 कुल खर्च: ${formatCurrency(totalExpense)}\n` +
        `💵 कुल आमदनी: ${formatCurrency(totalIncome)}\n` +
        `📊 *कुल शुद्ध परिणाम:* ${netProfit >= 0 ? '+' : '-'}${formatCurrency(Math.abs(netProfit))}`;
      shareViaWhatsApp(masterMsg, 'FieldBook Report', whatsappPhone);
    } else {
      const cropTx = transactions.filter(t => t.cropId === selectedCrop.id);
      const cropHarv = harvests.filter(h => h.cropId === selectedCrop.id);
      const encodedMsg = generateWhatsAppSummary(selectedCrop, cropTx, cropHarv, lang);
      shareViaWhatsApp(
        decodeURIComponent(encodedMsg),
        `${selectedCrop.hindiName || selectedCrop.name} - FieldBook Report`,
        whatsappPhone
      );
    }
  };

  const handleDownloadBackupJSON = () => {
    const jsonString = Storage.exportFullBackup();
    const fileName = `FieldBook_Backup_${new Date().toISOString().split('T')[0]}.json`;
    const ok = downloadTextOrSaveNative(jsonString, fileName, 'application/json;charset=utf-8;');
    if (ok) {
      showFeedback(
        'success',
        lang === 'hi'
          ? `✅ बैकअप फाइल (${fileName}) डाउनलोड हो गई! रिस्टोर करने के लिए नीचे "पुरानी बैकअप फाइल रिस्टोर करें" बटन से इस फाइल को चुनें।`
          : `✅ Backup file (${fileName}) saved! Use "Restore from Backup File" below to restore it anytime.`
      );
    } else {
      showFeedback(
        'error',
        lang === 'hi'
          ? 'बैकअप फाइल सेव करने में समस्या आई। कृपया पुनः प्रयास करें।'
          : 'Failed to save backup file. Please try again.'
      );
    }
  };

  const applyBackupString = (content: string) => {
    try {
      const result = Storage.importFullBackupWithDetails(content);
      if (result.success) {
        if (onReloadData) onReloadData();
        const parsed = JSON.parse(content);
        if (onRestoreBackup && Array.isArray(parsed.crops)) {
          onRestoreBackup({
            crops: parsed.crops,
            transactions: Array.isArray(parsed.transactions) ? parsed.transactions : [],
            harvests: Array.isArray(parsed.harvests) ? parsed.harvests : [],
            diary: Array.isArray(parsed.diary) ? parsed.diary : diaryEntries
          });
        }
        setShowPasteBox(false);
        setPastedJson('');
        showFeedback(
          'success',
          lang === 'hi'
            ? `🎉 बैकअप सफलतापूर्वक रिस्टोर हो गया! (${result.counts?.crops || 0} फसलें, ${result.counts?.transactions || 0} लेन-देन वापस आ गए)`
            : `🎉 Backup restored successfully! (${result.counts?.crops || 0} crops, ${result.counts?.transactions || 0} transactions restored)`
        );
      } else {
        showFeedback(
          'error',
          lang === 'hi'
            ? result.errorHi || 'अमान्य बैकअप फाइल!'
            : result.errorEn || 'Invalid backup file!'
        );
      }
    } catch {
      showFeedback(
        'error',
        lang === 'hi'
          ? 'अमान्य बैकअप फाइल! कृपया सही FieldBook_Backup.json फाइल चुनें।'
          : 'Invalid backup file! Please select a valid FieldBook_Backup.json file.'
      );
    }
  };

  const handleImportBackupJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      const content = event.target?.result as string;
      applyBackupString(content);
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="max-w-5xl mx-auto pb-20 space-y-4">
      {/* Page Header */}
      <div className="liquid-glass-card rounded-3xl p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-emerald-900 dark:text-emerald-300 mb-1">
              <FileSpreadsheet className="w-4 h-4" />
              <span>{lang === 'hi' ? 'रिपोर्ट्स, पीडीएफ और डेटा बैकअप' : 'Reports, PDF & Data Backup'}</span>
            </div>
            <h2 className="text-base sm:text-lg font-extrabold tracking-tight text-slate-950 dark:text-white">
              {lang === 'hi' ? 'फसल खाता पीडीएफ और सुरक्षित बैकअप' : 'Farm Ledger PDF Reports & Safe Backup'}
            </h2>
            <p className="text-xs font-bold text-slate-800 dark:text-slate-300 mt-0.5">
              {lang === 'hi'
                ? 'किसी भी फसल की तुरंत पीडीएफ (.PDF) डाउनलोड करें या अपना पूरा डेटा बैकअप/रिस्टोर करें।'
                : 'Instantly download any crop PDF statement or backup and restore your farm data.'}
            </p>
          </div>

          {onUpdateFarmerName && (
            <form onSubmit={handleSaveFarmerName} className="flex items-center gap-2 shrink-0">
              <div className="relative">
                <User className="w-3.5 h-3.5 text-emerald-700 absolute left-3 top-1/2 -translate-y-1/2 z-10" />
                <input
                  type="text"
                  value={nameInput}
                  onChange={e => setNameInput(e.target.value)}
                  placeholder={lang === 'hi' ? 'किसान का नाम' : 'Farmer Name'}
                  className="liquid-glass-input pl-8 pr-2.5 py-2 rounded-xl text-xs font-bold w-40 sm:w-44"
                />
              </div>
              <button
                type="submit"
                className="liquid-glass-emerald px-3.5 py-2 rounded-xl text-white text-xs font-extrabold cursor-pointer"
              >
                {lang === 'hi' ? 'सेव' : 'Save'}
              </button>
            </form>
          )}
        </div>

        {/* Status Toast Banner */}
        {backupStatus && (
          <div
            className={`mt-3.5 flex items-center gap-2 px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-extrabold border-2 ${
              backupStatus.type === 'success'
                ? 'liquid-glass-income text-emerald-950 dark:text-emerald-200 border-emerald-500'
                : 'liquid-glass-expense text-rose-950 dark:text-rose-200 border-rose-500'
            }`}
          >
            {backupStatus.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-700" />
            ) : (
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-700" />
            )}
            <span>{backupStatus.msg}</span>
          </div>
        )}

        {/* Quick Overview Summary Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-4 pt-3.5 border-t border-white/60 dark:border-slate-700/60">
          <div className="p-3 rounded-2xl liquid-glass-income">
            <div className="text-[11px] font-extrabold text-emerald-950 dark:text-emerald-200 flex items-center gap-1">
              <Sprout className="w-3.5 h-3.5" />
              {lang === 'hi' ? 'कुल फसलें' : 'Total Crops'}
            </div>
            <div className="text-base sm:text-lg font-extrabold font-mono text-slate-950 dark:text-white mt-0.5">
              {crops.length}
            </div>
          </div>

          <div className="p-3 rounded-2xl liquid-glass-expense">
            <div className="text-[11px] font-extrabold text-rose-950 dark:text-rose-200 flex items-center gap-1">
              <TrendingDown className="w-3.5 h-3.5" />
              {lang === 'hi' ? 'कुल खर्च' : 'Total Expense'}
            </div>
            <div className="text-base sm:text-lg font-extrabold font-mono text-rose-800 dark:text-rose-300 mt-0.5 truncate">
              {formatCurrency(totalExpense)}
            </div>
          </div>

          <div className="p-3 rounded-2xl liquid-glass-income">
            <div className="text-[11px] font-extrabold text-emerald-950 dark:text-emerald-200 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" />
              {lang === 'hi' ? 'कुल आमदनी' : 'Total Income'}
            </div>
            <div className="text-base sm:text-lg font-extrabold font-mono text-emerald-900 dark:text-emerald-300 mt-0.5 truncate">
              {formatCurrency(totalIncome)}
            </div>
          </div>

          <div className="p-3 rounded-2xl liquid-glass-profit">
            <div className="text-[11px] font-extrabold text-blue-950 dark:text-blue-200">
              {lang === 'hi' ? 'कुल शुद्ध मुनाफा' : 'Total Net Profit'}
            </div>
            <div
              className={`text-base sm:text-lg font-extrabold font-mono mt-0.5 truncate ${
                netProfit >= 0 ? 'text-blue-900 dark:text-blue-300' : 'text-rose-800 dark:text-rose-300'
              }`}
            >
              {netProfit >= 0 ? '+' : '-'}
              {formatCurrency(Math.abs(netProfit))}
            </div>
          </div>
        </div>
      </div>

      {/* Section 1 & 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-7 liquid-glass-card rounded-3xl p-4 sm:p-5 space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl btn-3d-blue flex items-center justify-center text-white shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-extrabold text-slate-950 dark:text-white">
                {lang === 'hi'
                  ? '1. फसल पीडीएफ (.PDF), एक्सेल और व्हाट्सएप रिपोर्ट'
                  : '1. Crop PDF (.PDF), Excel & WhatsApp Reports'}
              </h3>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-300">
                {lang === 'hi'
                  ? 'फसल चुनें और 1 क्लिक में तुरंत असली PDF फाइल डाउनलोड व प्रीव्यू करें'
                  : 'Select crop and download + preview real PDF report in 1 tap'}
              </p>
            </div>
          </div>

          {/* Crop Selector */}
          <div className="liquid-glass-profit p-3.5 rounded-2xl space-y-1.5">
            <label className="block text-xs font-extrabold text-slate-950 dark:text-white">
              🌾 {lang === 'hi' ? 'किस फसल की PDF रिपोर्ट चाहिए? (Select Crop)' : 'Select Crop for PDF Report'}
            </label>
            <select
              value={selectedCropId}
              onChange={e => setSelectedCropId(e.target.value)}
              className="liquid-glass-input w-full px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold"
            >
              <option value="all">
                {lang === 'hi'
                  ? `📋 सभी फसलों की मास्टर PDF रिपोर्ट (${crops.length} फसलें)`
                  : `📋 All Crops Master Summary (${crops.length} Crops)`}
              </option>
              {crops.map(c => (
                <option key={c.id} value={c.id}>
                  🌱 {lang === 'hi' ? c.hindiName || c.name : c.name} {c.variety ? `(${c.variety})` : ''} — {c.landArea} {c.areaUnit}
                </option>
              ))}
            </select>
          </div>

          {/* Action Buttons — Distinct 3D Liquid Glass Colors */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              onClick={handlePrintPDF}
              className="btn-3d-blue flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-white font-extrabold text-xs sm:text-sm cursor-pointer shadow-md"
            >
              <Printer className="w-4 h-4 shrink-0" />
              <span>
                {lang === 'hi' ? '📥 पीडीएफ डाउनलोड व देखें (.PDF)' : '📥 Download & View PDF (.PDF)'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleExportCSV}
              className="liquid-glass-emerald flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-white font-extrabold text-xs sm:text-sm cursor-pointer shadow-md"
            >
              <FileSpreadsheet className="w-4 h-4 shrink-0" />
              <span>
                {lang === 'hi' ? '📊 एक्सेल शीट डाउनलोड (CSV)' : '📊 Download Excel (CSV)'}
              </span>
            </button>
          </div>

          {/* Direct WhatsApp Share */}
          <div className="p-3.5 rounded-2xl liquid-glass-income space-y-2.5">
            <div className="flex items-center gap-1.5 text-emerald-950 dark:text-emerald-200 text-xs font-extrabold">
              <Share2 className="w-4 h-4 text-emerald-700" />
              <span>
                {lang === 'hi'
                  ? 'व्हाट्सएप पर सीधा हिसाब भेजें (WhatsApp Report)'
                  : 'Send Formatted Report on WhatsApp'}
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Smartphone className="w-4 h-4 text-emerald-700 absolute left-3 top-1/2 -translate-y-1/2 z-10" />
                <input
                  type="tel"
                  value={whatsappPhone}
                  onChange={e => setWhatsappPhone(e.target.value)}
                  placeholder={
                    lang === 'hi'
                      ? 'मोबाइल नंबर (वैकल्पिक, जैसे 9876543210)'
                      : 'WhatsApp number (optional, e.g. 9876543210)'
                  }
                  className="liquid-glass-input w-full pl-9 pr-3 py-2.5 rounded-xl text-xs font-bold"
                />
              </div>
              <button
                type="button"
                onClick={handleWhatsAppShare}
                className="liquid-glass-emerald flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-white font-extrabold text-xs shadow-sm cursor-pointer shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? 'व्हाट्सएप भेजें' : 'Share on WhatsApp'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Section 2: Full Data Backup & Restore */}
        <div className="lg:col-span-5 liquid-glass-card rounded-3xl p-4 sm:p-5 flex flex-col justify-between space-y-3.5">
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl btn-3d-amber flex items-center justify-center text-white shrink-0">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-extrabold text-slate-950 dark:text-white">
                  {lang === 'hi' ? '2. डेटा बैकअप और रिस्टोर (.JSON)' : '2. Full Data Backup & Restore'}
                </h3>
                <p className="text-xs font-bold text-slate-800 dark:text-slate-300">
                  {lang === 'hi'
                    ? 'पुराना डेटा सुरक्षित रखें और नए ऐप में 1 क्लिक में वापस लाएं'
                    : 'Keep your farm records safe across devices'}
                </p>
              </div>
            </div>

            {/* Step-by-step explanation for Backup File & Restore */}
            <div className="p-3.5 rounded-2xl liquid-glass-profit text-xs text-slate-950 dark:text-slate-100 leading-relaxed space-y-2">
              <div className="font-extrabold flex items-center gap-1.5 text-blue-950 dark:text-blue-200 text-xs">
                <ShieldCheck className="w-4 h-4 shrink-0 text-blue-700" />
                <span>
                  {lang === 'hi'
                    ? 'बैकअप फाइल (.json) से डेटा वापस कैसे लाएं?'
                    : 'How to Restore from Backup File (.json)?'}
                </span>
              </div>
              <ul className="space-y-1 text-[11px] font-bold list-disc pl-4">
                <li>
                  {lang === 'hi'
                    ? 'जब आप "बैकअप डाउनलोड करें" दबाते हैं, तो फोन में FieldBook_Backup.json फाइल सेव होती है (उसे बाहर खोलने पर कोड दिखता है, जो बिल्कुल सही है)।'
                    : 'Downloading a backup saves a FieldBook_Backup.json data file to your phone.'}
                </li>
                <li>
                  {lang === 'hi'
                    ? 'डेटा वापस लाने के लिए उस फाइल को बाहर से मत खोलें — नीचे दिए सुनहरे "📂 पुरानी बैकअप फाइल रिस्टोर करें" बटन को दबाकर Downloads से वह फाइल चुनें!'
                    : 'To restore your data, tap "Restore from Backup File" below and select that .json file from your Downloads folder!'}
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-2.5 pt-1">
            <button
              type="button"
              onClick={handleDownloadBackupJSON}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-2xl liquid-glass-emerald text-white font-extrabold text-xs sm:text-sm shadow-md cursor-pointer"
            >
              <Download className="w-4 h-4 shrink-0" />
              <span>
                {lang === 'hi'
                  ? '1. पूरा बैकअप डाउनलोड करें (.JSON)'
                  : '1. Download Full Backup (.JSON)'}
              </span>
            </button>

            {/* Accept all file types so Android file pickers never grey out .json files */}
            <input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json,text/plain,*/*"
              onChange={handleImportBackupJSON}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-2xl btn-3d-amber text-white font-extrabold text-xs sm:text-sm shadow-md cursor-pointer"
            >
              <Upload className="w-4 h-4 shrink-0" />
              <span>
                {lang === 'hi'
                  ? '2. 📂 पुरानी बैकअप फाइल रिस्टोर करें (Restore)'
                  : '2. 📂 Restore from Backup File (.JSON)'}
              </span>
            </button>

            {/* Optional Paste Backup JSON helper if user opened JSON in browser and copied text */}
            <button
              type="button"
              onClick={() => setShowPasteBox(!showPasteBox)}
              className="w-full flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl liquid-glass-pill font-extrabold text-xs text-slate-950 dark:text-white cursor-pointer"
            >
              <ClipboardPaste className="w-3.5 h-3.5 text-blue-700" />
              <span>
                {lang === 'hi'
                  ? 'या बैकअप कोड पेस्ट करके रिस्टोर करें (Paste Backup Text)'
                  : 'Or Paste Backup Text to Restore'}
              </span>
            </button>

            {showPasteBox && (
              <div className="p-3 rounded-2xl liquid-glass-income space-y-2">
                <textarea
                  rows={3}
                  value={pastedJson}
                  onChange={e => setPastedJson(e.target.value)}
                  placeholder={
                    lang === 'hi'
                      ? 'अगर आपने बैकअप फाइल खोलकर उसका कोड कॉपी किया है, तो यहां पेस्ट (Paste) करें...'
                      : 'Paste the copied JSON content from your backup file here...'
                  }
                  className="liquid-glass-input w-full px-3 py-2 rounded-xl text-xs font-mono font-bold resize-none"
                />
                <button
                  type="button"
                  onClick={() => applyBackupString(pastedJson)}
                  className="w-full py-2 rounded-xl btn-3d-blue text-white text-xs font-extrabold cursor-pointer"
                >
                  {lang === 'hi' ? '✓ पेस्ट किया हुआ डेटा रिस्टोर करें' : '✓ Restore Pasted Data'}
                </button>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              {onResetSampleData && (
                <button
                  type="button"
                  onClick={() => setIsSampleResetOpen(true)}
                  className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl liquid-glass-pill font-extrabold text-xs text-amber-900 dark:text-amber-300 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    {lang === 'hi' ? 'सैंपल डेटा रीसेट करें' : 'Load Sample Data'}
                  </span>
                </button>
              )}

              {onClearAllData && (
                <button
                  type="button"
                  onClick={() => setIsClearConfirmOpen(true)}
                  className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl liquid-glass-danger font-extrabold text-xs cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    {lang === 'hi' ? 'सारा डेटा खाली करें (Clear All)' : 'Clear All Data'}
                  </span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {onResetSampleData && (
        <ConfirmModal
          isOpen={isSampleResetOpen}
          title={lang === 'hi' ? 'सैंपल डेटा लोड करें?' : 'Load Default Sample Data?'}
          message={
            lang === 'hi'
              ? 'क्या आप वर्तमान डेटा के स्थान पर डिफ़ॉल्ट उदाहरण (सैंपल फसलें व खर्च) लोड करना चाहते हैं?'
              : 'Do you want to replace current records with the default sample crops and transactions?'
          }
          confirmLabel={lang === 'hi' ? 'हां, सैंपल डेटा लोड करें' : 'Yes, Load Sample Data'}
          cancelLabel={lang === 'hi' ? 'रद्द करें' : 'Cancel'}
          onConfirm={() => {
            onResetSampleData();
            setIsSampleResetOpen(false);
            showFeedback(
              'success',
              lang === 'hi'
                ? 'सैंपल डेटा सफलतापूर्वक लोड हो गया!'
                : 'Default sample data loaded successfully!'
            );
          }}
          onCancel={() => setIsSampleResetOpen(false)}
          theme={theme}
        />
      )}

      {onClearAllData && (
        <ConfirmModal
          isOpen={isClearConfirmOpen}
          title={lang === 'hi' ? 'सारा डेटा खाली करें (Start Fresh)?' : 'Clear All Farm Data?'}
          message={
            lang === 'hi'
              ? 'क्या आप सचमुच सभी फसलें, खर्च, मंडी बिक्री, नोट्स और खरीदारी सूची को पूरी तरह खाली करके शून्य से शुरू करना चाहते हैं?'
              : 'Are you sure you want to permanently clear all crops, expenses, sales, and notes to start fresh?'
          }
          confirmLabel={lang === 'hi' ? 'हां, सारा डेटा खाली करें' : 'Yes, Clear Everything'}
          cancelLabel={lang === 'hi' ? 'रद्द करें' : 'Cancel'}
          isDestructive={true}
          onConfirm={() => {
            onClearAllData();
            setIsClearConfirmOpen(false);
            showFeedback(
              'success',
              lang === 'hi'
                ? 'सारा डेटा खाली कर दिया गया है! अब आप अपनी नई फसल जोड़ सकते हैं।'
                : 'All data cleared! You can now add your own crops.'
            );
          }}
          onCancel={() => setIsClearConfirmOpen(false)}
          theme={theme}
        />
      )}
    </div>
  );
};
