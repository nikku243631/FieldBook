import {
  AreaUnit,
  CropAccountingType,
  CropCategory,
  CropCycle,
  CropMonthlyAccountingSummary,
  ExpenseCategory,
  FarmMonthlyAccountingSummary,
  FarmMonthlyCropSummary,
  HarvestEntry,
  MonthlyCropEntry,
  Transaction
} from '../types';

export type LandConverterUnit =
  | 'acre'
  | 'bigha_pucca'
  | 'bigha_kaccha'
  | 'bigha'
  | 'hectare'
  | 'kanal'
  | 'marla'
  | 'guntha'
  | 'sqft';

// Base conversion table in Square Feet (Standard North/Central India Revenue Norms)
export const SQFT_PER_UNIT: Record<LandConverterUnit, number> = {
  acre: 43560, // 1 Acre = 43,560 sq.ft (4,840 sq.yd)
  bigha_pucca: 27225, // 1 Pucca Bigha = 3,025 sq.yd = 27,225 sq.ft (1 Acre = 1.6 Pucca Bigha)
  bigha: 17424, // Standard UP/Budaun regional ledger average (1 Acre = 2.5 Bigha = 17,424 sq.ft)
  bigha_kaccha: 9075, // 1 Kaccha Bigha = 1,008.33 sq.yd = 9,075 sq.ft (1 Pucca Bigha = 3 Kaccha Bigha)
  hectare: 107639.1, // 1 Hectare = 10,000 sq.m = 107,639.1 sq.ft (2.47105 Acres)
  kanal: 5445, // 8 Kanal = 1 Acre (5,445 sq.ft)
  marla: 272.25, // 20 Marla = 1 Kanal (272.25 sq.ft)
  guntha: 1089, // 40 Guntha = 1 Acre (1,089 sq.ft)
  sqft: 1
};

export function sanitizePositiveNumber(value: unknown, fallback = 0): number {
  const num = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(num) || num < 0) return fallback;
  return num;
}

export function convertAreaToAcres(area: number, unit: AreaUnit | LandConverterUnit): number {
  const cleanArea = sanitizePositiveNumber(area, 0);
  if (cleanArea === 0) return 0;
  const sqFtPerUnit = SQFT_PER_UNIT[unit] ?? SQFT_PER_UNIT.acre;
  return Number(((cleanArea * sqFtPerUnit) / SQFT_PER_UNIT.acre).toFixed(4));
}

export interface LandAreaConversionResult {
  inputValue: number;
  fromUnit: LandConverterUnit;
  sqFt: number;
  acre: number;
  bighaPucca: number;
  bighaStandard: number;
  bighaKaccha: number;
  hectare: number;
  kanal: number;
  marla: number;
  guntha: number;
}

export function convertLandAreaAllUnits(
  value: number,
  fromUnit: LandConverterUnit
): LandAreaConversionResult {
  const cleanVal = sanitizePositiveNumber(value, 0);
  const factor = SQFT_PER_UNIT[fromUnit] ?? SQFT_PER_UNIT.acre;
  const totalSqFt = cleanVal * factor;

  return {
    inputValue: cleanVal,
    fromUnit,
    sqFt: Math.round(totalSqFt),
    acre: Number((totalSqFt / SQFT_PER_UNIT.acre).toFixed(3)),
    bighaPucca: Number((totalSqFt / SQFT_PER_UNIT.bigha_pucca).toFixed(3)),
    bighaStandard: Number((totalSqFt / SQFT_PER_UNIT.bigha).toFixed(3)),
    bighaKaccha: Number((totalSqFt / SQFT_PER_UNIT.bigha_kaccha).toFixed(2)),
    hectare: Number((totalSqFt / SQFT_PER_UNIT.hectare).toFixed(3)),
    kanal: Number((totalSqFt / SQFT_PER_UNIT.kanal).toFixed(2)),
    marla: Number((totalSqFt / SQFT_PER_UNIT.marla).toFixed(2)),
    guntha: Number((totalSqFt / SQFT_PER_UNIT.guntha).toFixed(2))
  };
}

export interface CropFinancialSummary {
  totalExpenses: number;
  totalIncome: number;
  netProfit: number;
  isProfit: boolean;
  profitMarginPercent: number;
  roiPercent: number;
  landArea: number;
  areaUnit: AreaUnit;
  landAreaInAcres: number;
  costPerUnit: number;
  incomePerUnit: number;
  profitPerUnit: number;
  costPerAcre: number;
  incomePerAcre: number;
  profitPerAcre: number;
  totalHarvestQuintal: number;
  yieldPerUnit: number;
  yieldPerAcre: number;
  costPerQuintal: number;
  expenseByCategory: Record<string, number>;
}

export function calculateCropFinancials(
  crop: CropCycle,
  transactions: Transaction[],
  harvests: HarvestEntry[]
): CropFinancialSummary {
  const cropTx = transactions.filter((t) => t.cropId === crop.id);
  const expenses = cropTx.filter((t) => t.type === 'expense');
  const incomes = cropTx.filter((t) => t.type === 'income');
  const cropHarvests = harvests.filter((h) => h.cropId === crop.id);

  const totalExpenses = Math.round(
    expenses.reduce((sum, t) => sum + sanitizePositiveNumber(t.amount, 0), 0)
  );
  const totalIncome = Math.round(
    incomes.reduce((sum, t) => sum + sanitizePositiveNumber(t.amount, 0), 0)
  );
  const netProfit = totalIncome - totalExpenses;
  const isProfit = netProfit >= 0;

  const profitMarginPercent =
    totalIncome > 0 ? Number(((netProfit / totalIncome) * 100).toFixed(1)) : 0;
  const roiPercent =
    totalExpenses > 0 ? Number(((netProfit / totalExpenses) * 100).toFixed(1)) : 0;

  const cleanArea = sanitizePositiveNumber(crop.landArea, 0);
  const areaInAcres = convertAreaToAcres(cleanArea, crop.areaUnit);

  const costPerUnit = cleanArea > 0 ? Math.round(totalExpenses / cleanArea) : 0;
  const incomePerUnit = cleanArea > 0 ? Math.round(totalIncome / cleanArea) : 0;
  const profitPerUnit = cleanArea > 0 ? Math.round(netProfit / cleanArea) : 0;

  const costPerAcre = areaInAcres > 0 ? Math.round(totalExpenses / areaInAcres) : 0;
  const incomePerAcre = areaInAcres > 0 ? Math.round(totalIncome / areaInAcres) : 0;
  const profitPerAcre = areaInAcres > 0 ? Math.round(netProfit / areaInAcres) : 0;

  const totalHarvestQuintal = Number(
    cropHarvests
      .reduce((sum, h) => sum + sanitizePositiveNumber(h.quantityQuintal, 0), 0)
      .toFixed(2)
  );

  const yieldPerUnit =
    cleanArea > 0 ? Number((totalHarvestQuintal / cleanArea).toFixed(2)) : 0;
  const yieldPerAcre =
    areaInAcres > 0 ? Number((totalHarvestQuintal / areaInAcres).toFixed(2)) : 0;

  const costPerQuintal =
    totalHarvestQuintal > 0 ? Math.round(totalExpenses / totalHarvestQuintal) : 0;

  const expenseByCategory: Record<string, number> = {};
  for (const e of expenses) {
    const amt = sanitizePositiveNumber(e.amount, 0);
    expenseByCategory[e.category] = Math.round((expenseByCategory[e.category] || 0) + amt);
  }

  return {
    totalExpenses,
    totalIncome,
    netProfit,
    isProfit,
    profitMarginPercent,
    roiPercent,
    landArea: cleanArea,
    areaUnit: crop.areaUnit,
    landAreaInAcres: areaInAcres,
    costPerUnit,
    incomePerUnit,
    profitPerUnit,
    costPerAcre,
    incomePerAcre,
    profitPerAcre,
    totalHarvestQuintal,
    yieldPerUnit,
    yieldPerAcre,
    costPerQuintal,
    expenseByCategory
  };
}

export interface MandiCalculationInput {
  grossWeightKg: number;
  tareWeightKg: number;
  ratePerQuintal: number;
  bagsCount?: number;
  palledariPerBag?: number;
  palledariPerQuintal?: number;
  mandiCessPercent?: number;
}

export interface MandiCalculationResult {
  isValidWeight: boolean;
  weightError?: string;
  netWeightKg: number;
  netWeightQuintal: number;
  netWeightMann: number;
  grossAmount: number;
  totalPalledari: number;
  mandiCessAmount: number;
  totalDeductions: number;
  netPayableAmount: number;
}

export function calculateMandiPayout(input: MandiCalculationInput): MandiCalculationResult {
  const grossKg = sanitizePositiveNumber(input.grossWeightKg, 0);
  const tareKg = sanitizePositiveNumber(input.tareWeightKg, 0);
  const rateQuintal = sanitizePositiveNumber(input.ratePerQuintal, 0);
  const bags = sanitizePositiveNumber(input.bagsCount, 0);
  const palledariBag = sanitizePositiveNumber(input.palledariPerBag, 0);
  const palledariQtl = sanitizePositiveNumber(input.palledariPerQuintal, 0);
  const cessPercent = sanitizePositiveNumber(input.mandiCessPercent, 0);

  const isValidWeight = tareKg <= grossKg;
  const weightError = !isValidWeight
    ? 'खाली ट्रॉली का वजन (Tare) कुल कांटा वजन (Gross) से अधिक नहीं हो सकता।'
    : undefined;

  const netWeightKg = isValidWeight ? Number((grossKg - tareKg).toFixed(2)) : 0;
  const netWeightQuintal = Number((netWeightKg / 100).toFixed(2));
  const netWeightMann = Number((netWeightKg / 40).toFixed(2)); // 1 Mann = 40 Kg

  const grossAmount = Number((netWeightQuintal * rateQuintal).toFixed(2));
  const bagPalledari = bags * palledariBag;
  const quintalPalledari = netWeightQuintal * palledariQtl;
  const totalPalledari = Math.round(bagPalledari + quintalPalledari);
  const mandiCessAmount = Math.round((grossAmount * cessPercent) / 100);
  const totalDeductions = totalPalledari + mandiCessAmount;
  const netPayableAmount = Math.max(0, Math.round(grossAmount - totalDeductions));

  return {
    isValidWeight,
    weightError,
    netWeightKg,
    netWeightQuintal,
    netWeightMann,
    grossAmount: Math.round(grossAmount),
    totalPalledari,
    mandiCessAmount,
    totalDeductions,
    netPayableAmount
  };
}

export interface FertilizerDosageConfig {
  name: string;
  ureaBagsPerAcre: number; // 45kg bag
  dapBagsPerAcre: number; // 50kg bag
  mopBagsPerAcre: number; // 50kg bag
  zincKgPerAcre: number;
  tips: string;
}

export const FERTILIZER_RECOMMENDATIONS: Record<string, FertilizerDosageConfig> = {
  wheat: {
    name: 'गेहूं (Wheat)',
    ureaBagsPerAcre: 2.5,
    dapBagsPerAcre: 1,
    mopBagsPerAcre: 0.5,
    zincKgPerAcre: 5,
    tips: '1 बैग DAP + 1/3 यूरिया बुवाई पर। बाकी यूरिया 21 दिन व 42 दिन पर दो बराबर हिस्सों में दें।'
  },
  paddy: {
    name: 'धान (Paddy/Rice)',
    ureaBagsPerAcre: 3,
    dapBagsPerAcre: 1,
    mopBagsPerAcre: 0.6,
    zincKgPerAcre: 10,
    tips: 'जिंक और DAP को कभी एक साथ मिलाकर न डालें, रासायनिक क्रिया से असर कम हो जाता है।'
  },
  mustard: {
    name: 'सरसों (Mustard)',
    ureaBagsPerAcre: 1.5,
    dapBagsPerAcre: 0.8,
    mopBagsPerAcre: 0.3,
    zincKgPerAcre: 4,
    tips: 'सरसों में सल्फर (20-25 किलो SSP या 90% बेंटोनाइट) अवश्य दें, इससे तेल की मात्रा 3-4% बढ़ती है।'
  },
  sugarcane: {
    name: 'गन्ना (Sugarcane)',
    ureaBagsPerAcre: 5,
    dapBagsPerAcre: 2,
    mopBagsPerAcre: 1.5,
    zincKgPerAcre: 10,
    tips: 'बुवाई के समय फास्फोरस व पोटाश दें। यूरिया को 3-4 बार में मिट्टी चढ़ाते समय तक पूरा करें।'
  },
  potato: {
    name: 'आलू (Potato)',
    ureaBagsPerAcre: 3.5,
    dapBagsPerAcre: 2,
    mopBagsPerAcre: 2,
    zincKgPerAcre: 5,
    tips: 'पोटाश (MOP) आलू के कंदों की चमक और साइज बढ़ाने में अत्यंत महत्वपूर्ण है।'
  }
};

export function calculateFertilizerRequirement(
  cropKey: string,
  area: number,
  unit: 'acre' | 'bigha' | 'hectare' = 'acre'
) {
  const config = FERTILIZER_RECOMMENDATIONS[cropKey] || FERTILIZER_RECOMMENDATIONS.wheat;
  const cleanArea = sanitizePositiveNumber(area, 0);
  const areaInAcres =
    unit === 'acre'
      ? cleanArea
      : unit === 'bigha'
      ? cleanArea / 2.5
      : cleanArea * 2.47105;

  const ureaBags = Number((config.ureaBagsPerAcre * areaInAcres).toFixed(1));
  const dapBags = Number((config.dapBagsPerAcre * areaInAcres).toFixed(1));
  const mopBags = Number((config.mopBagsPerAcre * areaInAcres).toFixed(1));
  const zincKg = Number((config.zincKgPerAcre * areaInAcres).toFixed(1));

  return {
    config,
    areaInAcres: Number(areaInAcres.toFixed(2)),
    ureaBags,
    ureaKg: Math.round(ureaBags * 45),
    dapBags,
    dapKg: Math.round(dapBags * 50),
    mopBags,
    mopKg: Math.round(mopBags * 50),
    zincKg
  };
}

export const SEED_RATES_PER_ACRE: Record<string, { name: string; kgPerAcre: number; tip: string }> = {
  wheat: {
    name: 'गेहूं (Wheat)',
    kgPerAcre: 40,
    tip: 'समय पर बुवाई (नवंबर 1-20): 40 किग्रा/एकड़। पछेती बुवाई: 50 किग्रा/एकड़।'
  },
  mustard: {
    name: 'सरसों (Mustard)',
    kgPerAcre: 1.5,
    tip: 'संकर (हाइब्रिड) बीज: 1.5 किलो/एकड़। देसी किस्में: 2 किलो/एकड़।'
  },
  paddy_dsm: {
    name: 'धान (DSR सीधी बुवाई)',
    kgPerAcre: 8,
    tip: 'सीधी बिजाई (DSR) में 8-10 किलो/एकड़, नर्सरी के लिए 5-6 किलो।'
  },
  chana: {
    name: 'चना (Gram)',
    kgPerAcre: 30,
    tip: 'काबुली चना 35-40 किलो, देसी चना 25-30 किलो प्रति एकड़।'
  },
  cotton: {
    name: 'कपास (Bt Cotton)',
    kgPerAcre: 1.8,
    tip: '2 पैकेट (लगभग 900 ग्राम प्रति पैकेट) प्रति एकड़।'
  }
};

export function calculateSeedRequirement(
  cropKey: string,
  area: number,
  pricePerKg: number,
  unit: 'acre' | 'bigha' | 'hectare' = 'acre'
) {
  const config = SEED_RATES_PER_ACRE[cropKey] || SEED_RATES_PER_ACRE.wheat;
  const cleanArea = sanitizePositiveNumber(area, 0);
  const cleanPrice = sanitizePositiveNumber(pricePerKg, 0);
  const areaInAcres =
    unit === 'acre'
      ? cleanArea
      : unit === 'bigha'
      ? cleanArea / 2.5
      : cleanArea * 2.47105;

  const totalSeedRequiredKg = Number((config.kgPerAcre * areaInAcres).toFixed(1));
  const totalSeedCost = Math.round(totalSeedRequiredKg * cleanPrice);

  return {
    config,
    areaInAcres: Number(areaInAcres.toFixed(2)),
    totalSeedRequiredKg,
    totalSeedCost
  };
}

export function calculateDieselIrrigationCost(
  runHours: number,
  litersPerHour: number,
  pricePerLiter: number,
  irrigatedAcres: number
) {
  const cleanHours = sanitizePositiveNumber(runHours, 0);
  const cleanLph = sanitizePositiveNumber(litersPerHour, 0);
  const cleanPrice = sanitizePositiveNumber(pricePerLiter, 0);
  const cleanAcres = sanitizePositiveNumber(irrigatedAcres, 0);

  const totalDieselLiters = Number((cleanHours * cleanLph).toFixed(1));
  const totalDieselCost = Math.round(totalDieselLiters * cleanPrice);
  const costPerAcre = cleanAcres > 0 ? Math.round(totalDieselCost / cleanAcres) : 0;

  return {
    totalDieselLiters,
    totalDieselCost,
    costPerAcre
  };
}

// ==================== CROP CATEGORY, HARVEST TYPE & TIMELINE ENGINE ====================

const RECURRING_CROP_KEYWORDS = [
  'chilli',
  'chili',
  'mirch',
  'मिर्च',
  'brinjal',
  'eggplant',
  'baingan',
  'बैंगन',
  'vegetable',
  'सब्जियां',
  'सब्जी',
  'tomato',
  'टमाटर',
  'okra',
  'bhindi',
  'भिंडी',
  'cucumber',
  'खीरा',
  'gourd',
  'लौकी',
  'तोरी',
  'करेला',
  'capsicum',
  'शिमला मिर्च',
  'beans',
  'फली',
  'पालक',
  'धनिया'
];

const CROP_CATEGORY_RULES: {
  keywords: string[];
  category: CropCategory;
  defaultAccountingType: CropAccountingType;
}[] = [
  {
    keywords: ['wheat', 'गेहूं', 'paddy', 'rice', 'धान', 'maize', 'corn', 'मक्का', 'bajra', 'बाजरा', 'jowar', 'ज्वार', 'barley', 'जौ'],
    category: 'grain',
    defaultAccountingType: 'one_time'
  },
  {
    keywords: [
      'chilli',
      'chili',
      'mirch',
      'मिर्च',
      'brinjal',
      'eggplant',
      'baingan',
      'बैंगन',
      'tomato',
      'टमाटर',
      'okra',
      'bhindi',
      'भिंडी',
      'cucumber',
      'खीरा',
      'gourd',
      'लौकी',
      'तोरी',
      'करेला',
      'कद्दू',
      'capsicum',
      'शिमला मिर्च',
      'beans',
      'फली',
      'पालक',
      'धनिया',
      'गोभी',
      'मटर',
      'vegetable',
      'सब्जियां',
      'सब्जी'
    ],
    category: 'vegetable',
    defaultAccountingType: 'recurring'
  },
  {
    keywords: ['potato', 'आलू', 'onion', 'प्याज', 'garlic', 'लहसुन', 'गाजर', 'मूली'],
    category: 'vegetable',
    defaultAccountingType: 'one_time'
  },
  {
    keywords: ['gram', 'chana', 'चना', 'lentil', 'मसूर', 'moong', 'मूंग', 'urad', 'उड़द', 'arhar', 'tur', 'अरहर', 'तूर', 'राजमा', 'pulse', 'दाल'],
    category: 'pulse',
    defaultAccountingType: 'one_time'
  },
  {
    keywords: ['mustard', 'सरसों', 'soybean', 'सोयाबीन', 'groundnut', 'peanut', 'मूंगफली', 'sesame', 'तिल', 'sunflower', 'सूरजमुखी'],
    category: 'oilseed',
    defaultAccountingType: 'one_time'
  },
  {
    keywords: ['mango', 'आम', 'guava', 'अमरूद', 'banana', 'केला', 'papaya', 'पपीता', 'watermelon', 'तरबूज', 'muskmelon', 'खरबूजा', 'lemon', 'नींबू', 'अनार', 'fruit', 'फल'],
    category: 'fruit',
    defaultAccountingType: 'recurring'
  },
  {
    keywords: ['sugarcane', 'गन्ना', 'cotton', 'कपास', 'mentha', 'मेंथा', 'बरसीम', 'चारा'],
    category: 'other',
    defaultAccountingType: 'one_time'
  }
];

/**
 * Suggests a suitable CropCategory and Harvest Type (CropAccountingType) based on the crop name.
 * If the crop name is unknown, returns `{ category: null, accountingType: null }` so no forced
 * classification occurs.
 */
export function suggestCropClassification(nameOrHindiName: string): {
  category: CropCategory | null;
  accountingType: CropAccountingType | null;
} {
  if (!nameOrHindiName || typeof nameOrHindiName !== 'string') {
    return { category: null, accountingType: null };
  }
  const normalized = nameOrHindiName.trim().toLowerCase();
  if (!normalized) {
    return { category: null, accountingType: null };
  }
  for (const rule of CROP_CATEGORY_RULES) {
    for (const kw of rule.keywords) {
      if (normalized.includes(kw)) {
        return {
          category: rule.category,
          accountingType: rule.defaultAccountingType
        };
      }
    }
  }
  return { category: null, accountingType: null };
}

/**
 * Infers a suggested crop accounting type from a crop name when creating a new crop.
 */
export function inferCropAccountingTypeFromName(nameOrHindiName: string): CropAccountingType {
  if (!nameOrHindiName || typeof nameOrHindiName !== 'string') return 'one_time';
  const normalized = nameOrHindiName.toLowerCase();
  for (const kw of RECURRING_CROP_KEYWORDS) {
    if (normalized.includes(kw)) {
      return 'recurring';
    }
  }
  return 'one_time';
}

/**
 * Returns the effective accounting type for any crop record.
 * Backward-compatible: if an older saved crop does not have `accountingType`,
 * it safely defaults to `'one_time'` (or `'recurring'` if explicitly set).
 */
export function getEffectiveCropAccountingType(
  crop: Partial<CropCycle> | null | undefined
): CropAccountingType {
  if (!crop) return 'one_time';
  if (crop.accountingType === 'recurring') return 'recurring';
  if (crop.accountingType === 'one_time') return 'one_time';
  return 'one_time';
}

/**
 * Returns the effective CropCategory for any crop record.
 * Preserves explicit `crop.cropCategory` if present; otherwise infers from the crop name
 * for older saved crops, or safely falls back to `'other'`.
 */
export function getEffectiveCropCategory(
  crop: Partial<CropCycle> | null | undefined
): CropCategory {
  if (!crop) return 'other';
  const validCategories: CropCategory[] = ['grain', 'vegetable', 'fruit', 'pulse', 'oilseed', 'other'];
  if (crop.cropCategory && validCategories.includes(crop.cropCategory)) {
    return crop.cropCategory;
  }
  const combinedName = `${crop.name || ''} ${crop.hindiName || ''}`.trim();
  const suggested = suggestCropClassification(combinedName);
  return suggested.category || 'other';
}

export function getCropCategoryLabel(category: CropCategory, lang: 'hi' | 'en' = 'hi'): string {
  const labels: Record<CropCategory, { hi: string; en: string }> = {
    grain: { hi: 'अनाज (Grain)', en: 'Grain' },
    vegetable: { hi: 'सब्जी (Vegetable)', en: 'Vegetable' },
    fruit: { hi: 'फल (Fruit)', en: 'Fruit' },
    pulse: { hi: 'दलहन / दाल (Pulse)', en: 'Pulse' },
    oilseed: { hi: 'तिलहन (Oilseed)', en: 'Oilseed' },
    other: { hi: 'अन्य फसल (Other)', en: 'Other' }
  };
  return labels[category]?.[lang] || labels.other[lang];
}

function parseYMDToUTC(dateStr: string | undefined | null): number | null {
  if (!dateStr || typeof dateStr !== 'string') return null;
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(dateStr.trim());
  if (!match) return null;
  const y = Number(match[1]);
  const m = Number(match[2]);
  const d = Number(match[3]);
  if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) return null;
  if (m < 1 || m > 12 || d < 1 || d > 31) return null;
  return Date.UTC(y, m - 1, d);
}

export function getCurrentLocalDateString(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export interface CropTimelineSummary {
  sowingDate: string;
  referenceDate: string;
  cropAgeDays: number;
  isFutureSowingDate: boolean;
  expectedHarvestDate: string | null;
  daysRemainingUntilHarvest: number | null;
  isHarvestDatePassed: boolean;
  isHarvestDateToday: boolean;
}

/**
 * Calculates crop age in days from the saved sowing/transplantation date and
 * approximate days remaining until expected harvest date.
 * Example: Planted on 2026-10-01, referenceDate 2026-10-20 => cropAgeDays = 19.
 */
export function calculateCropTimeline(
  crop: Pick<CropCycle, 'sowingDate' | 'expectedHarvestDate'>,
  referenceDateStr?: string
): CropTimelineSummary {
  const refStr = referenceDateStr || getCurrentLocalDateString();
  const refUTC = parseYMDToUTC(refStr) ?? Date.now();
  const sowingUTC = parseYMDToUTC(crop.sowingDate);

  let cropAgeDays = 0;
  let isFutureSowingDate = false;
  if (sowingUTC !== null) {
    const diffDays = Math.round((refUTC - sowingUTC) / 86400000);
    if (diffDays < 0) {
      cropAgeDays = 0;
      isFutureSowingDate = true;
    } else {
      cropAgeDays = diffDays;
    }
  }

  const expectedHarvestStr =
    crop.expectedHarvestDate && crop.expectedHarvestDate.trim()
      ? crop.expectedHarvestDate.trim()
      : null;
  const harvestUTC = parseYMDToUTC(expectedHarvestStr);

  let daysRemainingUntilHarvest: number | null = null;
  let isHarvestDatePassed = false;
  let isHarvestDateToday = false;

  if (harvestUTC !== null) {
    daysRemainingUntilHarvest = Math.round((harvestUTC - refUTC) / 86400000);
    isHarvestDatePassed = daysRemainingUntilHarvest < 0;
    isHarvestDateToday = daysRemainingUntilHarvest === 0;
  }

  return {
    sowingDate: crop.sowingDate,
    referenceDate: refStr,
    cropAgeDays,
    isFutureSowingDate,
    expectedHarvestDate: expectedHarvestStr,
    daysRemainingUntilHarvest,
    isHarvestDatePassed,
    isHarvestDateToday
  };
}

// ==================== MONTHLY CROP & FARM PROFIT/LOSS ACCOUNTING ENGINE ====================

/**
 * Extracts normalized `'YYYY-MM'` from a `'YYYY-MM-DD'` or ISO date string.
 */
export function extractYearMonth(dateStr: string | undefined | null): string | null {
  if (!dateStr || typeof dateStr !== 'string') return null;
  const trimmed = dateStr.trim();
  const match = /^(\d{4})-(\d{2})/.exec(trimmed);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  if (!Number.isFinite(year) || !Number.isFinite(month) || month < 1 || month > 12) {
    return null;
  }
  return `${String(year).padStart(4, '0')}-${String(month).padStart(2, '0')}`;
}

const MONTH_NAMES_HI = [
  'जनवरी',
  'फरवरी',
  'मार्च',
  'अप्रैल',
  'मई',
  'जून',
  'जुलाई',
  'अगस्त',
  'सितंबर',
  'अक्टूबर',
  'नवंबर',
  'दिसंबर'
];

const MONTH_NAMES_EN = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December'
];

const MONTH_SHORT_EN = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec'
];

/**
 * Formats a `'YYYY-MM'` month key into a clean bilingual or English label.
 */
export function formatMonthLabel(monthKey: string, lang: 'hi' | 'en' = 'hi'): string {
  const normalized = extractYearMonth(monthKey);
  if (!normalized) return monthKey || '—';
  const [yearStr, monthStr] = normalized.split('-');
  const monthIdx = Number(monthStr) - 1;
  if (monthIdx < 0 || monthIdx > 11) return normalized;
  if (lang === 'hi') {
    return `${MONTH_NAMES_HI[monthIdx]} ${yearStr} (${MONTH_SHORT_EN[monthIdx]})`;
  }
  return `${MONTH_NAMES_EN[monthIdx]} ${yearStr}`;
}

function createEmptyCategoryBreakdown(): Record<ExpenseCategory, number> {
  return {
    fertilizer: 0,
    seeds: 0,
    pesticide: 0,
    irrigation: 0,
    labour: 0,
    machinery: 0,
    transport: 0,
    other: 0
  };
}

/**
 * Calculates deterministic Month-by-Month Sales, Expenses, Net Profit/Loss,
 * and Cumulative Crop Totals for both Type A ('one_time') and Type B ('recurring') crops.
 *
 * Guarantees:
 * - Transactions and harvests are deduplicated by `id` so no entry is ever double-counted.
 * - Uses actual transaction `date` ('YYYY-MM-DD') as the source of truth.
 * - Monthly Net Result = Monthly Total Sales - Monthly Total Expenses.
 * - Explicitly flags months that have sales with ₹0 recorded expenses in that month
 *   (`hasSalesWithoutRecordedExpenses`) vs months with expenses only (`hasExpensesOnly`).
 * - Overall totals (`totalSales`, `totalExpenses`, `overallNetProfit`) match the crop ledger 100%.
 */
export function calculateMonthlyCropAccounting(
  crop: CropCycle,
  transactions: Transaction[],
  harvests: HarvestEntry[] = []
): CropMonthlyAccountingSummary {
  const accountingType = getEffectiveCropAccountingType(crop);

  // 1. Deduplicate crop transactions by id so no transaction is counted twice
  const seenTxIds = new Set<string>();
  const cropTransactions: Transaction[] = [];
  for (const tx of Array.isArray(transactions) ? transactions : []) {
    if (!tx || tx.cropId !== crop.id || typeof tx.id !== 'string') continue;
    if (seenTxIds.has(tx.id)) continue;
    seenTxIds.add(tx.id);
    cropTransactions.push(tx);
  }

  // 2. Deduplicate crop harvests by id
  const seenHarvestIds = new Set<string>();
  const cropHarvests: HarvestEntry[] = [];
  for (const hrv of Array.isArray(harvests) ? harvests : []) {
    if (!hrv || hrv.cropId !== crop.id || typeof hrv.id !== 'string') continue;
    if (seenHarvestIds.has(hrv.id)) continue;
    seenHarvestIds.add(hrv.id);
    cropHarvests.push(hrv);
  }

  // 3. Collect all calendar months that have transactions or harvests
  const monthBuckets = new Map<
    string,
    {
      salesTx: Transaction[];
      expenseTx: Transaction[];
      harvestList: HarvestEntry[];
    }
  >();

  const ensureBucket = (monthKey: string) => {
    let bucket = monthBuckets.get(monthKey);
    if (!bucket) {
      bucket = { salesTx: [], expenseTx: [], harvestList: [] };
      monthBuckets.set(monthKey, bucket);
    }
    return bucket;
  };

  for (const tx of cropTransactions) {
    const monthKey = extractYearMonth(tx.date) || extractYearMonth(crop.sowingDate) || '1970-01';
    const bucket = ensureBucket(monthKey);
    if (tx.type === 'income') {
      bucket.salesTx.push(tx);
    } else if (tx.type === 'expense') {
      bucket.expenseTx.push(tx);
    }
  }

  for (const hrv of cropHarvests) {
    const monthKey = extractYearMonth(hrv.date) || extractYearMonth(crop.sowingDate) || '1970-01';
    const bucket = ensureBucket(monthKey);
    bucket.harvestList.push(hrv);
  }

  const availableMonthKeys = Array.from(monthBuckets.keys()).sort((a, b) => a.localeCompare(b));

  const months: MonthlyCropEntry[] = [];
  const monthsMap: Record<string, MonthlyCropEntry> = {};

  let runningCumulativeSales = 0;
  let runningCumulativeExpenses = 0;
  let totalHarvestQuintal = 0;
  let totalSalesCount = 0;
  let totalExpensesCount = 0;
  let totalHarvestCount = 0;

  for (const monthKey of availableMonthKeys) {
    const bucket = monthBuckets.get(monthKey)!;
    const [yearStr, monthStr] = monthKey.split('-');
    const year = Number(yearStr);
    const month = Number(monthStr);

    // Sort transactions chronologically within the month (newest first for display)
    const salesTransactions = [...bucket.salesTx].sort((a, b) => b.date.localeCompare(a.date));
    const expenseTransactions = [...bucket.expenseTx].sort((a, b) => b.date.localeCompare(a.date));
    const harvestEntries = [...bucket.harvestList].sort((a, b) => b.date.localeCompare(a.date));

    const salesTotal = Math.round(
      salesTransactions.reduce((sum, t) => sum + sanitizePositiveNumber(t.amount, 0), 0)
    );
    const expensesTotal = Math.round(
      expenseTransactions.reduce((sum, t) => sum + sanitizePositiveNumber(t.amount, 0), 0)
    );
    const netProfit = salesTotal - expensesTotal;

    const expensesByCategory = createEmptyCategoryBreakdown();
    for (const exp of expenseTransactions) {
      const cat = exp.category as ExpenseCategory;
      const amt = Math.round(sanitizePositiveNumber(exp.amount, 0));
      if (cat in expensesByCategory) {
        expensesByCategory[cat] += amt;
      } else {
        expensesByCategory.other += amt;
      }
    }

    const harvestQuintal = Number(
      harvestEntries
        .reduce((sum, h) => sum + sanitizePositiveNumber(h.quantityQuintal, 0), 0)
        .toFixed(2)
    );

    runningCumulativeSales += salesTotal;
    runningCumulativeExpenses += expensesTotal;
    const cumulativeNetProfit = runningCumulativeSales - runningCumulativeExpenses;

    totalHarvestQuintal = Number((totalHarvestQuintal + harvestQuintal).toFixed(2));
    totalSalesCount += salesTransactions.length;
    totalExpensesCount += expenseTransactions.length;
    totalHarvestCount += harvestEntries.length;

    const entry: MonthlyCropEntry = {
      monthKey,
      year,
      month,
      salesTotal,
      expensesTotal,
      netProfit,
      isProfit: netProfit >= 0,
      salesCount: salesTransactions.length,
      expensesCount: expenseTransactions.length,
      harvestQuintal,
      harvestCount: harvestEntries.length,
      salesTransactions,
      expenseTransactions,
      harvestEntries,
      expensesByCategory,
      hasSalesWithoutRecordedExpenses: salesTotal > 0 && expensesTotal === 0,
      hasExpensesOnly: expensesTotal > 0 && salesTotal === 0,
      isEmpty:
        salesTransactions.length === 0 &&
        expenseTransactions.length === 0 &&
        harvestEntries.length === 0,
      cumulativeSales: runningCumulativeSales,
      cumulativeExpenses: runningCumulativeExpenses,
      cumulativeNetProfit
    };

    months.push(entry);
    monthsMap[monthKey] = entry;
  }

  const overallNetProfit = runningCumulativeSales - runningCumulativeExpenses;

  return {
    cropId: crop.id,
    accountingType,
    months,
    monthsMap,
    availableMonthKeys,
    totalSales: runningCumulativeSales,
    totalExpenses: runningCumulativeExpenses,
    overallNetProfit,
    isOverallProfit: overallNetProfit >= 0,
    totalHarvestQuintal,
    totalSalesCount,
    totalExpensesCount,
    totalHarvestCount
  };
}

/**
 * Retrieves the monthly accounting entry for any requested `'YYYY-MM'` monthKey.
 * If the requested month has no transactions or harvests, returns a safe empty-state
 * `MonthlyCropEntry` with cumulative totals computed up to that month.
 */
export function getMonthlyEntryForMonth(
  summary: CropMonthlyAccountingSummary,
  monthKey: string
): MonthlyCropEntry {
  const normalized = extractYearMonth(monthKey) || monthKey;
  if (summary.monthsMap[normalized]) {
    return summary.monthsMap[normalized];
  }

  const [yearStr, monthStr] = normalized.includes('-') ? normalized.split('-') : ['2025', '01'];
  const year = Number(yearStr) || 2025;
  const month = Number(monthStr) || 1;

  // Compute cumulative totals from all active months on or before the requested monthKey
  let cumulativeSales = 0;
  let cumulativeExpenses = 0;
  for (const m of summary.months) {
    if (m.monthKey <= normalized) {
      cumulativeSales = m.cumulativeSales;
      cumulativeExpenses = m.cumulativeExpenses;
    }
  }

  return {
    monthKey: normalized,
    year,
    month,
    salesTotal: 0,
    expensesTotal: 0,
    netProfit: 0,
    isProfit: true,
    salesCount: 0,
    expensesCount: 0,
    harvestQuintal: 0,
    harvestCount: 0,
    salesTransactions: [],
    expenseTransactions: [],
    harvestEntries: [],
    expensesByCategory: createEmptyCategoryBreakdown(),
    hasSalesWithoutRecordedExpenses: false,
    hasExpensesOnly: false,
    isEmpty: true,
    cumulativeSales,
    cumulativeExpenses,
    cumulativeNetProfit: cumulativeSales - cumulativeExpenses
  };
}

/**
 * Calculates the Home Page Monthly Farm Account across all crops for a selected `'YYYY-MM'` month.
 *
 * Rules enforced:
 * - Uses actual transaction dates (`tx.date`).
 * - Includes only records belonging to the selected month.
 * - Keeps each transaction strictly linked to its own crop (`tx.cropId`).
 * - Deduplicates transactions by `tx.id` so no transaction is counted twice.
 * - Never treats an expense as income or a sale as an expense.
 * - Unsold harvest entries are never counted as sales.
 */
export function calculateMonthlyFarmAccounting(
  crops: CropCycle[],
  transactions: Transaction[],
  harvests: HarvestEntry[] = [],
  requestedMonthKey?: string
): FarmMonthlyAccountingSummary {
  const cropMap = new Map<string, CropCycle>();
  for (const c of Array.isArray(crops) ? crops : []) {
    if (c && typeof c.id === 'string') {
      cropMap.set(c.id, c);
    }
  }

  // Deduplicate transactions by id and keep only transactions linked to existing crops
  const seenTxIds = new Set<string>();
  const uniqueTransactions: Transaction[] = [];
  const monthKeySet = new Set<string>();

  for (const tx of Array.isArray(transactions) ? transactions : []) {
    if (!tx || typeof tx.id !== 'string' || !cropMap.has(tx.cropId)) continue;
    if (seenTxIds.has(tx.id)) continue;
    const mKey = extractYearMonth(tx.date);
    if (!mKey) continue;
    seenTxIds.add(tx.id);
    uniqueTransactions.push(tx);
    monthKeySet.add(mKey);
  }

  // Deduplicate harvests by id
  const seenHarvestIds = new Set<string>();
  const uniqueHarvests: HarvestEntry[] = [];
  for (const hrv of Array.isArray(harvests) ? harvests : []) {
    if (!hrv || typeof hrv.id !== 'string' || !cropMap.has(hrv.cropId)) continue;
    if (seenHarvestIds.has(hrv.id)) continue;
    const mKey = extractYearMonth(hrv.date);
    if (!mKey) continue;
    seenHarvestIds.add(hrv.id);
    uniqueHarvests.push(hrv);
    monthKeySet.add(mKey);
  }

  // Also include crop sowing months so newly created crops have their month selectable
  for (const c of cropMap.values()) {
    const sowMonth = extractYearMonth(c.sowingDate);
    if (sowMonth) monthKeySet.add(sowMonth);
  }

  const currentMonthKey = getCurrentLocalDateString().slice(0, 7);
  if (monthKeySet.size === 0) {
    monthKeySet.add(currentMonthKey);
  }

  const availableMonthKeys = Array.from(monthKeySet).sort((a, b) => a.localeCompare(b));
  const defaultMonthKey = availableMonthKeys[availableMonthKeys.length - 1] || currentMonthKey;
  const activeMonthKey =
    (requestedMonthKey && extractYearMonth(requestedMonthKey)) || defaultMonthKey;

  if (!availableMonthKeys.includes(activeMonthKey)) {
    availableMonthKeys.push(activeMonthKey);
    availableMonthKeys.sort((a, b) => a.localeCompare(b));
  }

  const [yearStr, monthStr] = activeMonthKey.split('-');
  const year = Number(yearStr) || new Date().getFullYear();
  const month = Number(monthStr) || 1;

  // Group selected month's transactions and harvests by cropId
  const cropBuckets = new Map<
    string,
    {
      expenseTx: Transaction[];
      salesTx: Transaction[];
      harvestList: HarvestEntry[];
    }
  >();

  const ensureCropBucket = (cropId: string) => {
    let bucket = cropBuckets.get(cropId);
    if (!bucket) {
      bucket = { expenseTx: [], salesTx: [], harvestList: [] };
      cropBuckets.set(cropId, bucket);
    }
    return bucket;
  };

  for (const tx of uniqueTransactions) {
    if (extractYearMonth(tx.date) !== activeMonthKey) continue;
    const bucket = ensureCropBucket(tx.cropId);
    if (tx.type === 'expense') {
      bucket.expenseTx.push(tx);
    } else if (tx.type === 'income') {
      bucket.salesTx.push(tx);
    }
  }

  for (const hrv of uniqueHarvests) {
    if (extractYearMonth(hrv.date) !== activeMonthKey) continue;
    const bucket = ensureCropBucket(hrv.cropId);
    bucket.harvestList.push(hrv);
  }

  let totalExpenses = 0;
  let totalSales = 0;
  let totalExpensesCount = 0;
  let totalSalesCount = 0;
  const cropSummaries: FarmMonthlyCropSummary[] = [];

  for (const c of Array.isArray(crops) ? crops : []) {
    const bucket = cropBuckets.get(c.id);
    if (!bucket) continue;
    if (
      bucket.expenseTx.length === 0 &&
      bucket.salesTx.length === 0 &&
      bucket.harvestList.length === 0
    ) {
      continue;
    }

    const expenseTransactions = [...bucket.expenseTx].sort((a, b) => b.date.localeCompare(a.date));
    const salesTransactions = [...bucket.salesTx].sort((a, b) => b.date.localeCompare(a.date));
    const harvestEntries = [...bucket.harvestList].sort((a, b) => b.date.localeCompare(a.date));

    const cropExpensesTotal = Math.round(
      expenseTransactions.reduce((sum, t) => sum + sanitizePositiveNumber(t.amount, 0), 0)
    );
    const cropSalesTotal = Math.round(
      salesTransactions.reduce((sum, t) => sum + sanitizePositiveNumber(t.amount, 0), 0)
    );
    const cropNetProfit = cropSalesTotal - cropExpensesTotal;

    const expensesByCategory = createEmptyCategoryBreakdown();
    for (const exp of expenseTransactions) {
      const cat = exp.category as ExpenseCategory;
      const amt = Math.round(sanitizePositiveNumber(exp.amount, 0));
      if (cat in expensesByCategory) {
        expensesByCategory[cat] += amt;
      } else {
        expensesByCategory.other += amt;
      }
    }

    const harvestQuintal = Number(
      harvestEntries
        .reduce((sum, h) => sum + sanitizePositiveNumber(h.quantityQuintal, 0), 0)
        .toFixed(2)
    );

    totalExpenses += cropExpensesTotal;
    totalSales += cropSalesTotal;
    totalExpensesCount += expenseTransactions.length;
    totalSalesCount += salesTransactions.length;

    cropSummaries.push({
      crop: c,
      monthKey: activeMonthKey,
      expensesTotal: cropExpensesTotal,
      salesTotal: cropSalesTotal,
      netProfit: cropNetProfit,
      isProfit: cropNetProfit >= 0,
      expensesCount: expenseTransactions.length,
      salesCount: salesTransactions.length,
      harvestQuintal,
      harvestCount: harvestEntries.length,
      expenseTransactions,
      salesTransactions,
      harvestEntries,
      expensesByCategory
    });
  }

  const netProfit = totalSales - totalExpenses;

  return {
    monthKey: activeMonthKey,
    year,
    month,
    availableMonthKeys,
    totalExpenses,
    totalSales,
    netProfit,
    isProfit: netProfit >= 0,
    totalExpensesCount,
    totalSalesCount,
    cropSummaries
  };
}

// ==================== ACCURATE FARM LAND AREA SUMMARY & UDHAAR (PENDING PAYMENTS) ENGINE ====================

export interface FarmLandSummary {
  totalAcreDirect: number;
  totalBighaDirect: number;
  totalHectareDirect: number;
  totalEquivalentAcres: number;
  totalEquivalentBighas: number;
  hasMixedUnits: boolean;
  primaryDisplayLabel: string;
  secondaryConversionLabel: string;
}

/**
 * Calculates accurate land area totals without blindly adding mixed units
 * (e.g. never summing 4 Acre + 2.5 Bigha = 6.5 Units).
 * Provides both exact unit-wise breakdown and standardized Acre/Bigha conversion.
 */
export function calculateFarmLandSummary(
  crops: CropCycle[],
  lang: 'hi' | 'en' = 'hi'
): FarmLandSummary {
  let totalAcreDirect = 0;
  let totalBighaDirect = 0;
  let totalHectareDirect = 0;
  let totalEquivalentAcres = 0;

  for (const crop of Array.isArray(crops) ? crops : []) {
    if (!crop) continue;
    const area = sanitizePositiveNumber(crop.landArea, 0);
    if (area <= 0) continue;
    const unit = crop.areaUnit || 'acre';
    if (unit === 'acre') {
      totalAcreDirect = Number((totalAcreDirect + area).toFixed(2));
    } else if (unit === 'bigha') {
      totalBighaDirect = Number((totalBighaDirect + area).toFixed(2));
    } else if (unit === 'hectare') {
      totalHectareDirect = Number((totalHectareDirect + area).toFixed(2));
    }
    totalEquivalentAcres += convertAreaToAcres(area, unit);
  }

  totalEquivalentAcres = Number(totalEquivalentAcres.toFixed(2));
  const totalEquivalentBighas = Number((totalEquivalentAcres * 2.5).toFixed(2));

  const activeUnitCount =
    (totalAcreDirect > 0 ? 1 : 0) +
    (totalBighaDirect > 0 ? 1 : 0) +
    (totalHectareDirect > 0 ? 1 : 0);
  const hasMixedUnits = activeUnitCount > 1;

  const parts: string[] = [];
  if (totalAcreDirect > 0) {
    parts.push(lang === 'hi' ? `${totalAcreDirect} एकड़` : `${totalAcreDirect} Acre`);
  }
  if (totalBighaDirect > 0) {
    parts.push(lang === 'hi' ? `${totalBighaDirect} बीघा` : `${totalBighaDirect} Bigha`);
  }
  if (totalHectareDirect > 0) {
    parts.push(lang === 'hi' ? `${totalHectareDirect} हेक्टेयर` : `${totalHectareDirect} Hectare`);
  }

  const primaryDisplayLabel =
    parts.length > 0 ? parts.join(' • ') : lang === 'hi' ? '0 एकड़' : '0 Acre';

  let secondaryConversionLabel = '';
  if (hasMixedUnits) {
    secondaryConversionLabel =
      lang === 'hi'
        ? `कुल समतुल्य: ≈ ${totalEquivalentAcres} एकड़ (${totalEquivalentBighas} बीघा)`
        : `Total Equiv: ≈ ${totalEquivalentAcres} Acre (${totalEquivalentBighas} Bigha)`;
  } else if (totalBighaDirect > 0) {
    secondaryConversionLabel =
      lang === 'hi'
        ? `≈ ${totalEquivalentAcres} एकड़ मानक क्षेत्रफल`
        : `≈ ${totalEquivalentAcres} Acre equivalent`;
  } else if (totalAcreDirect > 0) {
    secondaryConversionLabel =
      lang === 'hi'
        ? `≈ ${totalEquivalentBighas} बीघा समतुल्य`
        : `≈ ${totalEquivalentBighas} Bigha equivalent`;
  } else if (totalHectareDirect > 0) {
    secondaryConversionLabel =
      lang === 'hi'
        ? `≈ ${totalEquivalentAcres} एकड़ (${totalEquivalentBighas} बीघा)`
        : `≈ ${totalEquivalentAcres} Acre (${totalEquivalentBighas} Bigha)`;
  } else {
    secondaryConversionLabel = lang === 'hi' ? 'कोई भूमि दर्ज नहीं' : 'No land recorded';
  }

  return {
    totalAcreDirect,
    totalBighaDirect,
    totalHectareDirect,
    totalEquivalentAcres,
    totalEquivalentBighas,
    hasMixedUnits,
    primaryDisplayLabel,
    secondaryConversionLabel
  };
}

export interface PendingPaymentsSummary {
  totalPayableExpenses: number; // उधार खर्च (देना बाकी)
  totalReceivableSales: number; // उधार बिक्री (लेना बाकी)
  payableTransactions: Transaction[];
  receivableTransactions: Transaction[];
  totalPendingCount: number;
}

/**
 * Computes Udhaar / Baki Khata (Pending Payments) across all or filtered transactions.
 * - `payableTransactions`: expenses where `paymentStatus === 'pending'` (किसान को दुकानदार/मजदूर को देना बाकी)
 * - `receivableTransactions`: income/sales where `paymentStatus === 'pending'` (किसान को मंडी/व्यापारी से लेना बाकी)
 */
export function calculatePendingPaymentsSummary(
  crops: CropCycle[],
  transactions: Transaction[],
  cropIdFilter?: string
): PendingPaymentsSummary {
  const validCropIds = new Set((Array.isArray(crops) ? crops : []).map((c) => c.id));
  const seenIds = new Set<string>();
  const payableTransactions: Transaction[] = [];
  const receivableTransactions: Transaction[] = [];
  let totalPayableExpenses = 0;
  let totalReceivableSales = 0;

  for (const tx of Array.isArray(transactions) ? transactions : []) {
    if (!tx || typeof tx.id !== 'string' || seenIds.has(tx.id)) continue;
    if (cropIdFilter && tx.cropId !== cropIdFilter) continue;
    if (!cropIdFilter && validCropIds.size > 0 && !validCropIds.has(tx.cropId)) continue;
    seenIds.add(tx.id);

    if (tx.paymentStatus !== 'pending') continue;
    const amt = Math.round(sanitizePositiveNumber(tx.amount, 0));
    if (amt <= 0) continue;

    if (tx.type === 'expense') {
      totalPayableExpenses += amt;
      payableTransactions.push(tx);
    } else if (tx.type === 'income') {
      totalReceivableSales += amt;
      receivableTransactions.push(tx);
    }
  }

  payableTransactions.sort((a, b) => b.date.localeCompare(a.date));
  receivableTransactions.sort((a, b) => b.date.localeCompare(a.date));

  return {
    totalPayableExpenses,
    totalReceivableSales,
    payableTransactions,
    receivableTransactions,
    totalPendingCount: payableTransactions.length + receivableTransactions.length
  };
}
