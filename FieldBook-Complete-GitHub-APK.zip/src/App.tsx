/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { App as CapApp } from '@capacitor/app';
import {
  CropCycle,
  Transaction,
  HarvestEntry,
  DiaryEntry,
  FarmNote,
  ShoppingItem
} from './types';
import { Storage, AppSettings } from './utils/storage';
import { SplashScreen } from './components/SplashScreen';
import { Header } from './components/Header';
import { CropList } from './components/CropList';
import { CropDetailView } from './components/CropDetailView';
import { AddCropModal } from './components/AddCropModal';
import { AddTransactionModal } from './components/AddTransactionModal';
import { AddHarvestModal, AddDiaryModal } from './components/AddHarvestModal';
import { CalculatorsView } from './components/CalculatorsView';
import { WeatherView } from './components/WeatherView';
import { ReportsBackupView } from './components/ReportsBackupView';
import { NotesAndListsView } from './components/NotesAndListsView';
import { SimpleCalculator } from './components/SimpleCalculator';
import { InstallModal } from './components/InstallModal';
import { downloadProjectZip } from './utils/zipExporter';
import { Calculator as CalcFloatingIcon, Smartphone, X, FolderArchive, Loader2 } from 'lucide-react';

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(() => Storage.getSettings());
  const [showSplash, setShowSplash] = useState<boolean>(true);

  const [crops, setCrops] = useState<CropCycle[]>(() => Storage.getCrops());
  const [transactions, setTransactions] = useState<Transaction[]>(() => Storage.getTransactions());
  const [harvests, setHarvests] = useState<HarvestEntry[]>(() => Storage.getHarvests());
  const [diary, setDiary] = useState<DiaryEntry[]>(() => Storage.getDiary());
  const [notes, setNotes] = useState<FarmNote[]>(() => Storage.getNotes());
  const [shoppingItems, setShoppingItems] = useState<ShoppingItem[]>(() => Storage.getShoppingItems());

  const [currentTab, setCurrentTab] = useState<'crops' | 'calculators' | 'notes' | 'weather' | 'reports'>('crops');
  const [selectedCropId, setSelectedCropId] = useState<string | null>(null);
  const [isQuickCalcOpen, setIsQuickCalcOpen] = useState(false);

  // Modals state
  const [isAddCropOpen, setIsAddCropOpen] = useState(false);
  const [cropToEdit, setCropToEdit] = useState<CropCycle | null>(null);
  const [isAddTxOpen, setIsAddTxOpen] = useState(false);
  const [addTxType, setAddTxType] = useState<'expense' | 'income'>('expense');
  const [txToEdit, setTxToEdit] = useState<Transaction | null>(null);
  const [isAddHarvestOpen, setIsAddHarvestOpen] = useState(false);
  const [harvestToEdit, setHarvestToEdit] = useState<HarvestEntry | null>(null);
  const [isAddDiaryOpen, setIsAddDiaryOpen] = useState(false);
  const [diaryToEdit, setDiaryToEdit] = useState<DiaryEntry | null>(null);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [dismissInstallBanner, setDismissInstallBanner] = useState(false);
  const [isBannerZipping, setIsBannerZipping] = useState(false);
  const [bannerZipDone, setBannerZipDone] = useState(false);

  // Keep latest navigation state in ref for Android hardware back-button listener
  const navStateRef = useRef({
    isInstallModalOpen,
    isQuickCalcOpen,
    isAddDiaryOpen,
    isAddHarvestOpen,
    isAddTxOpen,
    isAddCropOpen,
    selectedCropId,
    currentTab
  });

  useEffect(() => {
    navStateRef.current = {
      isInstallModalOpen,
      isQuickCalcOpen,
      isAddDiaryOpen,
      isAddHarvestOpen,
      isAddTxOpen,
      isAddCropOpen,
      selectedCropId,
      currentTab
    };
  }, [
    isInstallModalOpen,
    isQuickCalcOpen,
    isAddDiaryOpen,
    isAddHarvestOpen,
    isAddTxOpen,
    isAddCropOpen,
    selectedCropId,
    currentTab
  ]);

  // Android Capacitor hardware back button & app lifecycle handling
  useEffect(() => {
    let listenerHandle: { remove: () => Promise<void> } | null = null;

    const setupBackListener = async () => {
      try {
        listenerHandle = await CapApp.addListener('backButton', () => {
          const s = navStateRef.current;
          if (s.isInstallModalOpen) {
            setIsInstallModalOpen(false);
          } else if (s.isQuickCalcOpen) {
            setIsQuickCalcOpen(false);
          } else if (s.isAddDiaryOpen) {
            setIsAddDiaryOpen(false);
            setDiaryToEdit(null);
          } else if (s.isAddHarvestOpen) {
            setIsAddHarvestOpen(false);
            setHarvestToEdit(null);
          } else if (s.isAddTxOpen) {
            setIsAddTxOpen(false);
            setTxToEdit(null);
          } else if (s.isAddCropOpen) {
            setIsAddCropOpen(false);
            setCropToEdit(null);
          } else if (s.selectedCropId) {
            setSelectedCropId(null);
          } else if (s.currentTab !== 'crops') {
            setCurrentTab('crops');
          } else {
            CapApp.exitApp();
          }
        });
      } catch {
        // Ignore in standard web browsers where Capacitor native bridge is not active
      }
    };

    setupBackListener();

    return () => {
      if (listenerHandle) {
        listenerHandle.remove().catch(() => {});
      }
    };
  }, []);

  const handleQuickZipDownload = async () => {
    setIsBannerZipping(true);
    try {
      await downloadProjectZip();
      setBannerZipDone(true);
      setTimeout(() => setBannerZipDone(false), 4000);
    } finally {
      setIsBannerZipping(false);
    }
  };

  // Sync settings theme to HTML body
  useEffect(() => {
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.body.className = 'bg-neutral-950 text-neutral-100 min-h-screen';
    } else {
      document.documentElement.classList.remove('dark');
      document.body.className = 'bg-[#f4faf5] text-neutral-900 min-h-screen';
    }
    Storage.saveSettings(settings);
  }, [settings]);

  // Sync database updates to offline Storage
  const reloadFromStorage = () => {
    setCrops(Storage.getCrops());
    setTransactions(Storage.getTransactions());
    setHarvests(Storage.getHarvests());
    setDiary(Storage.getDiary());
    setNotes(Storage.getNotes());
    setShoppingItems(Storage.getShoppingItems());
    setSettings(Storage.getSettings());
  };

  const handleToggleLang = () => {
    setSettings((prev) => ({
      ...prev,
      language: prev.language === 'hi' ? 'en' : 'hi'
    }));
  };

  const handleToggleTheme = () => {
    setSettings((prev) => ({
      ...prev,
      theme: prev.theme === 'dark' ? 'light' : 'dark'
    }));
  };

  const handleUpdateFarmerName = (name: string) => {
    setSettings((prev) => ({
      ...prev,
      farmerName: name
    }));
  };

  // ==================== CROP ACTIONS ====================
  const handleSaveCrop = (cropData: Partial<CropCycle>) => {
    if (cropToEdit) {
      const updated = crops.map((c) =>
        c.id === cropToEdit.id
          ? {
              ...c,
              ...cropData,
              updatedAt: new Date().toISOString()
            }
          : c
      );
      setCrops(updated);
      Storage.saveCrops(updated);
      setCropToEdit(null);
    } else {
      const newCrop: CropCycle = {
        id: `crop-${Date.now()}`,
        name: cropData.name || 'New Crop',
        hindiName: cropData.hindiName || cropData.name || 'नई फसल',
        variety: cropData.variety || '',
        landArea: cropData.landArea || 1,
        areaUnit: cropData.areaUnit || 'acre',
        season: cropData.season || 'rabi',
        sowingDate: cropData.sowingDate || new Date().toISOString().split('T')[0],
        expectedHarvestDate: cropData.expectedHarvestDate,
        status: cropData.status || 'active',
        targetYieldQuintal: cropData.targetYieldQuintal,
        notes: cropData.notes,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      const updated = [newCrop, ...crops];
      setCrops(updated);
      Storage.saveCrops(updated);
      setSelectedCropId(newCrop.id);
    }
  };

  const handleDeleteCrop = (cropId: string) => {
    const updatedCrops = crops.filter((c) => c.id !== cropId);
    const updatedTx = transactions.filter((t) => t.cropId !== cropId);
    const updatedHarvests = harvests.filter((h) => h.cropId !== cropId);
    const updatedDiary = diary.filter((d) => d.cropId !== cropId);

    setCrops(updatedCrops);
    setTransactions(updatedTx);
    setHarvests(updatedHarvests);
    setDiary(updatedDiary);

    Storage.saveCrops(updatedCrops);
    Storage.saveTransactions(updatedTx);
    Storage.saveHarvests(updatedHarvests);
    Storage.saveDiary(updatedDiary);

    setSelectedCropId(null);
  };

  const handleClearAllData = () => {
    Storage.clearAllData();
    setCrops([]);
    setTransactions([]);
    setHarvests([]);
    setDiary([]);
    setNotes([]);
    setShoppingItems([]);
    setSelectedCropId(null);
  };

  // ==================== TRANSACTION ACTIONS ====================
  const handleSaveTransaction = (txData: Partial<Transaction>) => {
    if (txToEdit || txData.id) {
      const targetId = txToEdit?.id || txData.id!;
      const updated = transactions.map((t) =>
        t.id === targetId
          ? {
              ...t,
              ...txData,
              id: targetId,
              cropId: txData.cropId || t.cropId
            }
          : t
      );
      setTransactions(updated);
      Storage.saveTransactions(updated);
      setTxToEdit(null);
    } else {
      const newTx: Transaction = {
        id: `tx-${Date.now()}`,
        cropId: txData.cropId || selectedCropId || '',
        type: txData.type || 'expense',
        category: txData.category || 'other',
        title: txData.title || '',
        amount: txData.amount || 0,
        date: txData.date || new Date().toISOString().split('T')[0],
        time: txData.time || new Date().toTimeString().slice(0, 5),
        quantity: txData.quantity,
        unit: txData.unit,
        ratePerUnit: txData.ratePerUnit,
        vendorOrBuyer: txData.vendorOrBuyer,
        notes: txData.notes,
        paymentStatus: txData.paymentStatus || 'paid',
        mandiDetails: txData.mandiDetails,
        createdAt: new Date().toISOString()
      };

      const updated = [newTx, ...transactions];
      setTransactions(updated);
      Storage.saveTransactions(updated);
    }
  };

  const handleDeleteTransaction = (txId: string) => {
    const updated = transactions.filter((t) => t.id !== txId);
    setTransactions(updated);
    Storage.saveTransactions(updated);
  };

  // ==================== HARVEST ACTIONS ====================
  const handleSaveHarvest = (hrvData: Partial<HarvestEntry>) => {
    if (harvestToEdit || hrvData.id) {
      const targetId = harvestToEdit?.id || hrvData.id!;
      const updated = harvests.map((h) =>
        h.id === targetId
          ? {
              ...h,
              ...hrvData,
              id: targetId,
              cropId: hrvData.cropId || h.cropId
            }
          : h
      );
      setHarvests(updated);
      Storage.saveHarvests(updated);
      setHarvestToEdit(null);
    } else {
      const newHrv: HarvestEntry = {
        id: `hrv-${Date.now()}`,
        cropId: hrvData.cropId || selectedCropId || '',
        date: hrvData.date || new Date().toISOString().split('T')[0],
        time: hrvData.time || new Date().toTimeString().slice(0, 5),
        quantityQuintal: hrvData.quantityQuintal || 0,
        moisturePercentage: hrvData.moisturePercentage,
        grade: hrvData.grade,
        storageLocation: hrvData.storageLocation,
        notes: hrvData.notes
      };

      const updated = [newHrv, ...harvests];
      setHarvests(updated);
      Storage.saveHarvests(updated);
    }
  };

  const handleDeleteHarvest = (hrvId: string) => {
    const updated = harvests.filter((h) => h.id !== hrvId);
    setHarvests(updated);
    Storage.saveHarvests(updated);
  };

  // ==================== DIARY ACTIONS ====================
  const handleSaveDiary = (entryData: Partial<DiaryEntry>) => {
    if (diaryToEdit || entryData.id) {
      const targetId = diaryToEdit?.id || entryData.id!;
      const updated = diary.map((d) =>
        d.id === targetId
          ? {
              ...d,
              ...entryData,
              id: targetId,
              cropId: entryData.cropId || d.cropId
            }
          : d
      );
      setDiary(updated);
      Storage.saveDiary(updated);
      setDiaryToEdit(null);
    } else {
      const newEntry: DiaryEntry = {
        id: `dir-${Date.now()}`,
        cropId: entryData.cropId || selectedCropId || '',
        date: entryData.date || new Date().toISOString().split('T')[0],
        time: entryData.time || new Date().toTimeString().slice(0, 5),
        activityType: entryData.activityType || 'other',
        notes: entryData.notes || '',
        weatherNote: entryData.weatherNote
      };

      const updated = [newEntry, ...diary];
      setDiary(updated);
      Storage.saveDiary(updated);
    }
  };

  const handleDeleteDiary = (diaryId: string) => {
    const updated = diary.filter((d) => d.id !== diaryId);
    setDiary(updated);
    Storage.saveDiary(updated);
  };

  const activeSelectedCrop = crops.find((c) => c.id === selectedCropId);

  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-emerald-500 selection:text-neutral-950">
      {/* 1. Splash Screen on Launch */}
      {showSplash && (
        <SplashScreen
          lang={settings.language}
          onDismiss={() => setShowSplash(false)}
        />
      )}

      {/* 2. Top Header with 3-Zone Contract and Developer Recognition */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setSelectedCropId(null);
          setCurrentTab(tab);
        }}
        lang={settings.language}
        onToggleLang={handleToggleLang}
        theme={settings.theme}
        onToggleTheme={handleToggleTheme}
        onOpenAddCrop={() => {
          setCropToEdit(null);
          setIsAddCropOpen(true);
        }}
        selectedCropId={selectedCropId}
        onBackToCrops={() => setSelectedCropId(null)}
        onOpenQuickCalc={() => setIsQuickCalcOpen(true)}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
      />

      {/* 3. Main Workspace Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 pt-5">
        {/* PWA & GitHub Auto-APK ZIP Promotion Banner */}
        {!dismissInstallBanner && (
          <div className="mb-4 p-3 sm:p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/90 via-teal-950/90 to-purple-950/80 border border-emerald-500/40 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg shadow-emerald-950/30">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
                <Smartphone className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <p className="text-xs sm:text-sm font-bold truncate">
                  {settings.language === 'hi'
                    ? 'FieldBook APK और GitHub Auto-APK ZIP पैकेज तैयार है'
                    : 'FieldBook APK & Complete GitHub Auto-APK ZIP Ready'}
                </p>
                <p className="text-[11px] text-emerald-200/80 truncate">
                  {settings.language === 'hi'
                    ? 'सारी सोर्स फाइल्स + Android प्रोजेक्ट + YAML एक ही ZIP में'
                    : 'All source files + Android project + YAML workflow in 1 ZIP'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
              <button
                onClick={handleQuickZipDownload}
                disabled={isBannerZipping}
                className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-bold text-xs hover:from-purple-400 hover:to-indigo-400 shadow-sm transition active:scale-95 cursor-pointer whitespace-nowrap flex items-center gap-1.5"
              >
                {isBannerZipping ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>{settings.language === 'hi' ? 'बन रहा है...' : 'Packing...'}</span>
                  </>
                ) : (
                  <>
                    <FolderArchive className="w-3.5 h-3.5" />
                    <span>
                      {bannerZipDone
                        ? (settings.language === 'hi' ? '✓ डाउनलोड हुआ!' : '✓ Downloaded!')
                        : (settings.language === 'hi' ? '📦 GitHub APK ZIP डाउनलोड' : '📦 Download GitHub APK ZIP')}
                    </span>
                  </>
                )}
              </button>
              <button
                onClick={() => setIsInstallModalOpen(true)}
                className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-neutral-950 font-bold text-xs hover:from-emerald-400 hover:to-teal-400 shadow-sm transition active:scale-95 cursor-pointer whitespace-nowrap"
              >
                {settings.language === 'hi' ? '📱 इंस्टॉल / गाइड' : '📱 Install / Guide'}
              </button>
              <button
                onClick={() => setDismissInstallBanner(true)}
                className="p-1 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white transition cursor-pointer"
                title={settings.language === 'hi' ? 'हटाएं' : 'Dismiss'}
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
        {selectedCropId && activeSelectedCrop ? (
          <CropDetailView
            crop={activeSelectedCrop}
            transactions={transactions}
            harvests={harvests}
            diary={diary}
            lang={settings.language}
            theme={settings.theme}
            farmerName={settings.farmerName}
            onBack={() => setSelectedCropId(null)}
            onEditCrop={(crop) => {
              setCropToEdit(crop);
              setIsAddCropOpen(true);
            }}
            onDeleteCrop={handleDeleteCrop}
            onAddTransaction={(type) => {
              setTxToEdit(null);
              setAddTxType(type);
              setIsAddTxOpen(true);
            }}
            onEditTransaction={(tx) => {
              setTxToEdit(tx);
              setAddTxType(tx.type);
              setIsAddTxOpen(true);
            }}
            onDeleteTransaction={handleDeleteTransaction}
            onAddHarvest={() => {
              setHarvestToEdit(null);
              setIsAddHarvestOpen(true);
            }}
            onEditHarvest={(hrv) => {
              setHarvestToEdit(hrv);
              setIsAddHarvestOpen(true);
            }}
            onDeleteHarvest={handleDeleteHarvest}
            onAddDiary={() => {
              setDiaryToEdit(null);
              setIsAddDiaryOpen(true);
            }}
            onEditDiary={(entry) => {
              setDiaryToEdit(entry);
              setIsAddDiaryOpen(true);
            }}
            onDeleteDiary={handleDeleteDiary}
          />
        ) : currentTab === 'crops' ? (
          <CropList
            crops={crops}
            transactions={transactions}
            harvests={harvests}
            lang={settings.language}
            theme={settings.theme}
            onSelectCrop={(id) => setSelectedCropId(id)}
            onOpenAddCrop={() => {
              setCropToEdit(null);
              setIsAddCropOpen(true);
            }}
            onDeleteCrop={handleDeleteCrop}
          />
        ) : currentTab === 'calculators' ? (
          <CalculatorsView lang={settings.language} theme={settings.theme} />
        ) : currentTab === 'notes' ? (
          <NotesAndListsView
            lang={settings.language}
            theme={settings.theme}
            notes={notes}
            shoppingItems={shoppingItems}
            onUpdateNotes={(updated) => {
              setNotes(updated);
              Storage.saveNotes(updated);
            }}
            onUpdateShoppingItems={(updated) => {
              setShoppingItems(updated);
              Storage.saveShoppingItems(updated);
            }}
            onOpenSimpleCalc={() => setIsQuickCalcOpen(true)}
          />
        ) : currentTab === 'weather' ? (
          <WeatherView lang={settings.language} theme={settings.theme} />
        ) : (
          <ReportsBackupView
            crops={crops}
            transactions={transactions}
            harvests={harvests}
            lang={settings.language}
            theme={settings.theme}
            farmerName={settings.farmerName}
            onUpdateFarmerName={handleUpdateFarmerName}
            onReloadData={reloadFromStorage}
            onClearAllData={handleClearAllData}
            onOpenInstallModal={() => setIsInstallModalOpen(true)}
          />
        )}
      </main>

      {/* Floating Quick Calculator Action Button */}
      <button
        onClick={() => setIsQuickCalcOpen(true)}
        className="fixed bottom-6 right-6 z-40 p-3.5 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white shadow-xl shadow-emerald-600/30 hover:scale-105 active:scale-95 transition-all border border-emerald-400/40 cursor-pointer flex items-center gap-2 group"
        title={settings.language === 'hi' ? 'साधारण हिसाब कैलकुलेटर' : 'Quick Calculator'}
      >
        <CalcFloatingIcon className="w-5 h-5 group-hover:rotate-12 transition-transform" />
        <span className="hidden sm:inline text-xs font-bold font-sans">
          {settings.language === 'hi' ? 'कैलकुलेटर' : 'Calculator'}
        </span>
      </button>

      {/* Quick General Calculator Modal */}
      {isQuickCalcOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-neutral-950/80 backdrop-blur-md">
          <div className="w-full max-w-md animate-in fade-in zoom-in-95 duration-200">
            <SimpleCalculator
              lang={settings.language}
              theme={settings.theme}
              isModal={true}
              onClose={() => setIsQuickCalcOpen(false)}
              onSendToNotes={(calcText) => {
                const newNote: FarmNote = {
                  id: `note-${Date.now()}`,
                  title: settings.language === 'hi' ? 'कैलकुलेटर हिसाब' : 'Calculation Note',
                  content: calcText,
                  category: 'payment',
                  isPinned: true,
                  date: new Date().toISOString().split('T')[0],
                  time: new Date().toTimeString().slice(0, 5),
                  color: 'emerald',
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString()
                };
                const updated = [newNote, ...notes];
                setNotes(updated);
                Storage.saveNotes(updated);
                setIsQuickCalcOpen(false);
                setCurrentTab('notes');
              }}
            />
          </div>
        </div>
      )}

      {/* 4. Quiet Footer with Developer Attribution */}
      <footer
        className={`w-full py-4 text-center border-t text-xs ${
          settings.theme === 'dark'
            ? 'bg-neutral-950/80 border-neutral-900 text-neutral-500'
            : 'bg-white/80 border-neutral-200 text-neutral-600'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>FieldBook — डिजिटल खेत लेजर व फसल हिसाब-किताब</span>
          <span className="font-medium text-emerald-600 dark:text-emerald-400">
            {settings.language === 'hi' ? 'डेवलपर:' : 'Developer:'}{' '}
            <strong className="text-emerald-500">Mr Nikhil</strong>
          </span>
          <span className="text-[11px] font-mono opacity-80">
            Offline-First Local Storage
          </span>
        </div>
      </footer>

      {/* ==================== INTERACTIVE MODALS ==================== */}

      {/* Add / Edit Crop Modal */}
      <AddCropModal
        isOpen={isAddCropOpen}
        onClose={() => {
          setIsAddCropOpen(false);
          setCropToEdit(null);
        }}
        onSaveCrop={handleSaveCrop}
        lang={settings.language}
        theme={settings.theme}
        cropToEdit={cropToEdit}
      />

      {/* Add / Edit Expense / Income Modal */}
      {selectedCropId && (
        <AddTransactionModal
          isOpen={isAddTxOpen}
          onClose={() => {
            setIsAddTxOpen(false);
            setTxToEdit(null);
          }}
          onSave={handleSaveTransaction}
          cropId={selectedCropId}
          defaultType={addTxType}
          lang={settings.language}
          theme={settings.theme}
          txToEdit={txToEdit}
        />
      )}

      {/* Add / Edit Harvest Modal */}
      {selectedCropId && (
        <AddHarvestModal
          isOpen={isAddHarvestOpen}
          onClose={() => {
            setIsAddHarvestOpen(false);
            setHarvestToEdit(null);
          }}
          onSave={handleSaveHarvest}
          cropId={selectedCropId}
          lang={settings.language}
          theme={settings.theme}
          harvestToEdit={harvestToEdit}
        />
      )}

      {/* Add / Edit Diary Modal */}
      {selectedCropId && (
        <AddDiaryModal
          isOpen={isAddDiaryOpen}
          onClose={() => {
            setIsAddDiaryOpen(false);
            setDiaryToEdit(null);
          }}
          onSave={handleSaveDiary}
          cropId={selectedCropId}
          lang={settings.language}
          theme={settings.theme}
          diaryToEdit={diaryToEdit}
        />
      )}

      {/* Install App / APK Guide Modal */}
      <InstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        lang={settings.language}
        theme={settings.theme}
      />
    </div>
  );
}
