export type Language = 'hi' | 'en';
export type Theme = 'dark' | 'light';

export type AreaUnit = 'acre' | 'bigha' | 'hectare' | 'marla' | 'kanal' | 'guntha';

export type CropSeason = 'kharif' | 'rabi' | 'zaid' | 'annual';

export interface CropCycle {
  id: string;
  name: string;
  hindiName: string;
  variety?: string;
  landArea: number;
  areaUnit: AreaUnit;
  season: CropSeason;
  sowingDate: string; // YYYY-MM-DD
  expectedHarvestDate?: string;
  status: 'active' | 'harvested' | 'archived';
  targetYieldQuintal?: number;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type ExpenseCategory =
  | 'fertilizer' // खाद
  | 'seeds' // बीज
  | 'pesticide' // कीटनाशक / दवाई
  | 'irrigation' // पानी / सिंचाई / डीजल
  | 'labour' // मजदूरी / लेबर
  | 'machinery' // ट्रैक्टर / जुताई / कटाई
  | 'other'; // अन्य खर्च

export type IncomeCategory =
  | 'mandi_sale' // मंडी बिक्री
  | 'local_sale' // स्थानीय / गांव में बिक्री
  | 'subsidy' // सरकारी अनुदान / सब्सिडी
  | 'byproduct'; // भूसा / पराली बिक्री

export interface MandiDetails {
  grossWeightKg?: number;
  tareWeightKg?: number;
  netWeightQuintal: number;
  ratePerQuintal: number;
  palledariPerQuintal?: number;
  totalPalledari?: number;
  mandiCess?: number;
  buyerName?: string;
  receiptNumber?: string;
}

export interface Transaction {
  id: string;
  cropId: string;
  type: 'expense' | 'income';
  category: ExpenseCategory | IncomeCategory;
  title: string;
  amount: number;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  quantity?: number;
  unit?: string; // kg, liter, bag, hours, days
  ratePerUnit?: number;
  vendorOrBuyer?: string;
  notes?: string;
  paymentStatus: 'paid' | 'pending';
  mandiDetails?: MandiDetails;
  createdAt: string;
}

export interface HarvestEntry {
  id: string;
  cropId: string;
  date: string;
  time: string;
  quantityQuintal: number;
  moisturePercentage?: number;
  grade?: string; // A, B, C
  storageLocation?: string; // Mandi direct, Home godown, Warehouse
  notes?: string;
}

export interface DiaryEntry {
  id: string;
  cropId: string;
  date: string;
  time: string;
  activityType: 'sowing' | 'irrigation' | 'fertilizer' | 'spray' | 'inspection' | 'harvest' | 'weeding' | 'other';
  notes: string;
  weatherNote?: string;
}

export interface FarmReportSummary {
  totalLagat: number;
  totalKamai: number;
  netProfit: number;
  profitMarginPercent: number;
  totalLandAreaAcre: number;
  costPerAcre: number;
  profitPerAcre: number;
  totalYieldQuintal: number;
  expenseByCategory: Record<string, number>;
}

export interface FarmNote {
  id: string;
  title: string;
  content: string;
  category: 'general' | 'reminder' | 'field_work' | 'payment' | 'spray';
  isPinned: boolean;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  color?: string; // emerald, amber, sky, purple, rose
  createdAt: string;
  updatedAt: string;
}

export interface ShoppingItem {
  id: string;
  name: string;
  category: 'fertilizer' | 'seeds' | 'pesticide' | 'machinery_tools' | 'irrigation' | 'general';
  quantity: number;
  unit: string; // बोरी (Bags), पैकेट (Packets), लीटर (Liters), किलो (Kg), नग (Pcs)
  estimatedCost?: number;
  actualCost?: number;
  isPurchased: boolean;
  notes?: string;
  date: string; // YYYY-MM-DD
  createdAt: string;
}
