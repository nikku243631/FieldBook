import React, { useState } from 'react';
import { Calculator, Scale, Sprout, Ruler, Fuel, CheckCircle, ArrowRightLeft, Sparkles, Hash } from 'lucide-react';
import { Language, Theme } from '../types';
import { getTranslation, formatCurrency, formatNumber } from '../utils/translations';
import {
  calculateMandiPayout,
  calculateFertilizerRequirement,
  calculateSeedRequirement,
  convertLandAreaAllUnits,
  calculateDieselIrrigationCost,
  FERTILIZER_RECOMMENDATIONS,
  SEED_RATES_PER_ACRE,
  LandConverterUnit
} from '../utils/calculations';
import { SimpleCalculator } from './SimpleCalculator';

interface CalculatorsViewProps {
  lang: Language;
  theme: Theme;
}

export const CalculatorsView: React.FC<CalculatorsViewProps> = ({ lang, theme }) => {
  const isDark = theme === 'dark';
  const [selectedCalc, setSelectedCalc] = useState<
    'simple' | 'mandi' | 'fertilizer' | 'seed' | 'area' | 'diesel'
  >('simple');

  // ==================== CALC 1: MANDI RATE & WEIGHT ====================
  const [mandiGrossKg, setMandiGrossKg] = useState<number>(3500);
  const [mandiTareKg, setMandiTareKg] = useState<number>(1000);
  const [mandiRateQuintal, setMandiRateQuintal] = useState<number>(2325);
  const [mandiPalledariPerBag, setMandiPalledariPerBag] = useState<number>(14);
  const [mandiBagsCount, setMandiBagsCount] = useState<number>(50);

  const mandiResult = calculateMandiPayout({
    grossWeightKg: mandiGrossKg,
    tareWeightKg: mandiTareKg,
    ratePerQuintal: mandiRateQuintal,
    bagsCount: mandiBagsCount,
    palledariPerBag: mandiPalledariPerBag
  });
  const mandiNetKg = mandiResult.netWeightKg;
  const mandiNetQuintals = mandiResult.netWeightQuintal;
  const mandiGrossPayout = mandiResult.grossAmount;
  const mandiTotalPalledari = mandiResult.totalDeductions;
  const mandiFinalPayout = mandiResult.netPayableAmount;
  const mandiMannCount = mandiResult.netWeightMann;

  // ==================== CALC 2: FERTILIZER NPK DOSAGE ====================
  const [selectedFertCrop, setSelectedFertCrop] = useState<string>('wheat');
  const [fertArea, setFertArea] = useState<number>(2.5);
  const [fertUnit, setFertUnit] = useState<'acre' | 'bigha'>('acre');

  const FERT_RECOMMENDATIONS = FERTILIZER_RECOMMENDATIONS;
  const fertCalc = calculateFertilizerRequirement(selectedFertCrop, fertArea, fertUnit);
  const currentFertConfig = fertCalc.config;
  const totalUreaBags = fertCalc.ureaBags;
  const totalDapBags = fertCalc.dapBags;
  const totalMopBags = fertCalc.mopBags;
  const totalZincKg = fertCalc.zincKg;

  // ==================== CALC 3: SEED RATE ====================
  const [seedCrop, setSeedCrop] = useState<string>('wheat');
  const [seedArea, setSeedArea] = useState<number>(3);
  const [seedPricePerKg, setSeedPricePerKg] = useState<number>(40);

  const seedCalc = calculateSeedRequirement(seedCrop, seedArea, seedPricePerKg, 'acre');
  const currentSeedConfig = seedCalc.config;
  const totalSeedRequiredKg = seedCalc.totalSeedRequiredKg;
  const totalSeedCost = seedCalc.totalSeedCost;

  // ==================== CALC 4: LAND AREA UNIT CONVERTER ====================
  const [convertValue, setConvertValue] = useState<number>(1);
  const [fromUnit, setFromUnit] = useState<LandConverterUnit>('acre');

  const areaConv = convertLandAreaAllUnits(convertValue, fromUnit);
  const resultAcre = areaConv.acre.toFixed(3);
  const resultBighaPucca = areaConv.bighaPucca.toFixed(3);
  const resultBighaKaccha = areaConv.bighaKaccha.toFixed(2);
  const resultHectare = areaConv.hectare.toFixed(3);
  const resultKanal = areaConv.kanal.toFixed(2);
  const resultSqFt = areaConv.sqFt.toLocaleString('en-IN');

  // ==================== CALC 5: TUBE-WELL DIESEL PUMPING ====================
  const [dieselRunHours, setDieselRunHours] = useState<number>(6);
  const [dieselLitersPerHour, setDieselLitersPerHour] = useState<number>(2.5);
  const [dieselPricePerLiter, setDieselPricePerLiter] = useState<number>(89);
  const [dieselIrrigatedAcres, setDieselIrrigatedAcres] = useState<number>(2);

  const dieselCalc = calculateDieselIrrigationCost(
    dieselRunHours,
    dieselLitersPerHour,
    dieselPricePerLiter,
    dieselIrrigatedAcres
  );
  const totalDieselLiters = dieselCalc.totalDieselLiters;
  const totalDieselCost = dieselCalc.totalDieselCost;
  const costPerAcreDiesel = dieselCalc.costPerAcre;

  return (
    <div className="space-y-6 pb-20">
      {/* Title Banner */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border ${
          isDark ? 'glass-panel text-white' : 'glass-panel-light text-neutral-900'
        }`}
      >
        <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
          <Calculator className="w-4 h-4" />
          <span>{lang === 'hi' ? 'विशेष कृषि कैलकुलेटर' : 'Agricultural Calculators'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          {lang === 'hi' ? 'मंडी, खाद, बीज व जमीन हिसाब' : 'Mandi & Farm Yield Math'}
        </h1>
        <p className="text-xs text-neutral-400 mt-1 max-w-xl">
          {lang === 'hi'
            ? 'मंडी भाव व पल्लेदारी, NPK खाद मात्रा, बीज दर, जमीन क्षेत्रफल और ट्यूबवेल डीजल का सही हिसाब एक जगह।'
            : 'Accurate field calculations for mandi trade payouts, fertilizer requirements, seed rates, and acreage.'}
        </p>
      </div>

      {/* Calculator Mode Switcher */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
        <button
          onClick={() => setSelectedCalc('simple')}
          className={`p-3 rounded-2xl border text-center transition-all cursor-pointer ${
            selectedCalc === 'simple'
              ? 'bg-emerald-600 text-white border-emerald-500 shadow-md font-bold ring-2 ring-emerald-400/50'
              : 'bg-neutral-900/60 text-neutral-300 border-neutral-800 hover:border-emerald-500/50'
          }`}
        >
          <Calculator className="w-5 h-5 mx-auto mb-1 text-emerald-400" />
          <span className="text-xs block font-bold">{lang === 'hi' ? 'साधारण कैलकुलेटर' : 'General Calc'}</span>
        </button>

        <button
          onClick={() => setSelectedCalc('mandi')}
          className={`p-3 rounded-2xl border text-center transition-all cursor-pointer ${
            selectedCalc === 'mandi'
              ? 'bg-emerald-600 text-white border-emerald-500 shadow-md font-bold'
              : 'bg-neutral-900/60 text-neutral-300 border-neutral-800 hover:border-emerald-500/50'
          }`}
        >
          <Scale className="w-5 h-5 mx-auto mb-1" />
          <span className="text-xs block font-medium">{lang === 'hi' ? 'मंडी भाव व वजन' : 'Mandi Rates'}</span>
        </button>

        <button
          onClick={() => setSelectedCalc('fertilizer')}
          className={`p-3 rounded-2xl border text-center transition-all cursor-pointer ${
            selectedCalc === 'fertilizer'
              ? 'bg-emerald-600 text-white border-emerald-500 shadow-md font-bold'
              : 'bg-neutral-900/60 text-neutral-300 border-neutral-800 hover:border-emerald-500/50'
          }`}
        >
          <Sprout className="w-5 h-5 mx-auto mb-1" />
          <span className="text-xs block font-medium">{lang === 'hi' ? 'खाद (NPK) मात्रा' : 'Fertilizer Math'}</span>
        </button>

        <button
          onClick={() => setSelectedCalc('seed')}
          className={`p-3 rounded-2xl border text-center transition-all cursor-pointer ${
            selectedCalc === 'seed'
              ? 'bg-emerald-600 text-white border-emerald-500 shadow-md font-bold'
              : 'bg-neutral-900/60 text-neutral-300 border-neutral-800 hover:border-emerald-500/50'
          }`}
        >
          <Sparkles className="w-5 h-5 mx-auto mb-1" />
          <span className="text-xs block font-medium">{lang === 'hi' ? 'बीज मात्रा (Seed)' : 'Seed Rate'}</span>
        </button>

        <button
          onClick={() => setSelectedCalc('area')}
          className={`p-3 rounded-2xl border text-center transition-all cursor-pointer ${
            selectedCalc === 'area'
              ? 'bg-emerald-600 text-white border-emerald-500 shadow-md font-bold'
              : 'bg-neutral-900/60 text-neutral-300 border-neutral-800 hover:border-emerald-500/50'
          }`}
        >
          <Ruler className="w-5 h-5 mx-auto mb-1" />
          <span className="text-xs block font-medium">{lang === 'hi' ? 'जमीन क्षेत्रफल' : 'Land Area'}</span>
        </button>

        <button
          onClick={() => setSelectedCalc('diesel')}
          className={`p-3 rounded-2xl border text-center transition-all cursor-pointer ${
            selectedCalc === 'diesel'
              ? 'bg-emerald-600 text-white border-emerald-500 shadow-md font-bold'
              : 'bg-neutral-900/60 text-neutral-300 border-neutral-800 hover:border-emerald-500/50'
          }`}
        >
          <Fuel className="w-5 h-5 mx-auto mb-1" />
          <span className="text-xs block font-medium">{lang === 'hi' ? 'डीजल व सिंचाई' : 'Diesel Cost'}</span>
        </button>
      </div>

      {/* ==================== 0. SIMPLE WORKING CALCULATOR ==================== */}
      {selectedCalc === 'simple' && (
        <div className="space-y-4">
          <SimpleCalculator lang={lang} theme={theme} />
        </div>
      )}

      {/* ==================== 1. MANDI CALCULATOR ==================== */}
      {selectedCalc === 'mandi' && (
        <div
          className={`rounded-3xl p-5 sm:p-6 border space-y-6 ${
            isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
          }`}
        >

          <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
            <div>
              <h2 className="text-lg font-bold">मंडी तौल, कटौती व शुद्ध रकम कैलकुलेटर</h2>
              <p className="text-xs text-neutral-400">
                कांटा वजन में से खाली ट्रॉली घटाएं और पल्लेदारी काटकर हाथ में आने वाली सही रकम जानें
              </p>
            </div>
            <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              1 क्विंटल = 100 kg = 2.5 मन
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Inputs */}
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-neutral-400 block mb-1">
                    कांटा कुल वजन (Gross Kg)
                  </label>
                  <input
                    type="number"
                    value={mandiGrossKg}
                    onChange={(e) => setMandiGrossKg(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl text-sm font-mono font-bold bg-neutral-800 border border-neutral-700 text-white focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-neutral-400 block mb-1">
                    ट्रॉली/खाली वजन (Tare Kg)
                  </label>
                  <input
                    type="number"
                    value={mandiTareKg}
                    onChange={(e) => setMandiTareKg(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl text-sm font-mono bg-neutral-800 border border-neutral-700 text-white focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-neutral-400 block mb-1">
                  मंडी भाव (₹ प्रति क्विंटल)
                </label>
                <input
                  type="number"
                  value={mandiRateQuintal}
                  onChange={(e) => setMandiRateQuintal(Number(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-xl text-base font-mono font-extrabold bg-neutral-800 border border-emerald-500/50 text-emerald-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-neutral-400 block mb-1">
                    कुल बोरियां (Bags)
                  </label>
                  <input
                    type="number"
                    value={mandiBagsCount}
                    onChange={(e) => setMandiBagsCount(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl text-sm font-mono bg-neutral-800 border border-neutral-700 text-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-neutral-400 block mb-1">
                    पल्लेदारी/तुलाई (₹ प्रति बोरी)
                  </label>
                  <input
                    type="number"
                    value={mandiPalledariPerBag}
                    onChange={(e) => setMandiPalledariPerBag(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl text-sm font-mono bg-neutral-800 border border-neutral-700 text-white"
                  />
                </div>
              </div>
            </div>

            {/* Live Outputs */}
            <div className="p-5 rounded-2xl bg-neutral-900/90 border border-emerald-500/30 flex flex-col justify-between space-y-4">
              <div>
                <span className="text-xs uppercase tracking-wider text-emerald-400 font-bold block mb-1">
                  शुद्ध नकद भुगतान (Net Payout)
                </span>
                <span className="text-3xl sm:text-4xl font-extrabold font-mono text-emerald-400 tabular-nums">
                  {formatCurrency(mandiFinalPayout)}
                </span>
                <p className="text-xs text-neutral-400 mt-1">
                  सभी कटौती के बाद किसान को मिलने वाली कुल रकम
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-neutral-800 text-xs">
                <div>
                  <span className="text-neutral-400 block">शुद्ध वजन (Net Weight)</span>
                  <span className="text-sm font-bold font-mono text-white">
                    {mandiNetQuintals} क्विंटल ({mandiNetKg} kg)
                  </span>
                </div>

                <div>
                  <span className="text-neutral-400 block">मन में वजन (In Mann)</span>
                  <span className="text-sm font-bold font-mono text-white">
                    {mandiMannCount} मन (40kg)
                  </span>
                </div>

                <div>
                  <span className="text-neutral-400 block">सकल मूल्य (Gross)</span>
                  <span className="text-sm font-bold font-mono text-neutral-200">
                    {formatCurrency(mandiGrossPayout)}
                  </span>
                </div>

                <div>
                  <span className="text-neutral-400 block">पल्लेदारी कटौती</span>
                  <span className="text-sm font-bold font-mono text-rose-400">
                    -{formatCurrency(mandiTotalPalledari)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== 2. FERTILIZER NPK CALCULATOR ==================== */}
      {selectedCalc === 'fertilizer' && (
        <div
          className={`rounded-3xl p-5 sm:p-6 border space-y-6 ${
            isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
          }`}
        >
          <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
            <div>
              <h2 className="text-lg font-bold">उर्वरक (खाद) मात्रा सिफारिश कैलकुलेटर</h2>
              <p className="text-xs text-neutral-400">
                कृषि विश्वविद्यालय द्वारा अनुशंसित वैज्ञानिक खाद का सटीक पैमाना
              </p>
            </div>
            <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              यूरिया = 45 kg | DAP = 50 kg
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">फसल चुनें</label>
              <select
                value={selectedFertCrop}
                onChange={(e) => setSelectedFertCrop(e.target.value)}
                className="w-full px-3 py-2 rounded-xl text-sm bg-neutral-800 border border-neutral-700 text-white"
              >
                {Object.entries(FERT_RECOMMENDATIONS).map(([key, val]) => (
                  <option key={key} value={key}>
                    {val.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">खेत का रकबा</label>
              <input
                type="number"
                step="0.1"
                value={fertArea}
                onChange={(e) => setFertArea(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl text-sm font-mono bg-neutral-800 border border-neutral-700 text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">इकाई</label>
              <select
                value={fertUnit}
                onChange={(e) => setFertUnit(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl text-sm bg-neutral-800 border border-neutral-700 text-white"
              >
                <option value="acre">एकड़ (Acre)</option>
                <option value="bigha">बीघा (Bigha)</option>
              </select>
            </div>
          </div>

          {/* Results Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-center">
              <span className="text-xs text-neutral-400 block">यूरिया (Urea 45kg)</span>
              <span className="text-2xl font-extrabold font-mono text-emerald-400 mt-1 block">
                {totalUreaBags} <span className="text-xs font-normal">कट्टे</span>
              </span>
              <span className="text-[10px] text-neutral-500 block mt-0.5">
                लगभग {Math.round(totalUreaBags * 45)} किग्रा
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-center">
              <span className="text-xs text-neutral-400 block">DAP (50kg बैग)</span>
              <span className="text-2xl font-extrabold font-mono text-amber-400 mt-1 block">
                {totalDapBags} <span className="text-xs font-normal">कट्टे</span>
              </span>
              <span className="text-[10px] text-neutral-500 block mt-0.5">
                फास्फोरस व नाइट्रोजन
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-center">
              <span className="text-xs text-neutral-400 block">MOP पोटाश (50kg)</span>
              <span className="text-2xl font-extrabold font-mono text-teal-400 mt-1 block">
                {totalMopBags} <span className="text-xs font-normal">कट्टे</span>
              </span>
              <span className="text-[10px] text-neutral-500 block mt-0.5">
                दानों की चमक व वजन
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-center">
              <span className="text-xs text-neutral-400 block">जिंक सल्फेट 33%</span>
              <span className="text-2xl font-extrabold font-mono text-indigo-400 mt-1 block">
                {totalZincKg} <span className="text-xs font-normal">किग्रा</span>
              </span>
              <span className="text-[10px] text-neutral-500 block mt-0.5">
                सूक्ष्म पोषक तत्व
              </span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-xs text-emerald-300">
            <strong>कृषि वैज्ञानिक सलाह:</strong> {currentFertConfig.tips}
          </div>
        </div>
      )}

      {/* ==================== 3. SEED RATE CALCULATOR ==================== */}
      {selectedCalc === 'seed' && (
        <div
          className={`rounded-3xl p-5 sm:p-6 border space-y-6 ${
            isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
          }`}
        >
          <div className="pb-3 border-b border-neutral-800">
            <h2 className="text-lg font-bold">बीज दर व बीज खर्च कैलकुलेटर</h2>
            <p className="text-xs text-neutral-400">
              खेत के क्षेत्रफल के अनुसार कितने किलोग्राम बीज की आवश्यकता होगी
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">फसल</label>
              <select
                value={seedCrop}
                onChange={(e) => setSeedCrop(e.target.value)}
                className="w-full px-3 py-2 rounded-xl text-sm bg-neutral-800 border border-neutral-700 text-white"
              >
                {Object.entries(SEED_RATES_PER_ACRE).map(([key, val]) => (
                  <option key={key} value={key}>
                    {val.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">रकबा (एकड़)</label>
              <input
                type="number"
                step="0.5"
                value={seedArea}
                onChange={(e) => setSeedArea(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl text-sm font-mono bg-neutral-800 border border-neutral-700 text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">बीज भाव (₹ प्रति kg)</label>
              <input
                type="number"
                value={seedPricePerKg}
                onChange={(e) => setSeedPricePerKg(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl text-sm font-mono bg-neutral-800 border border-neutral-700 text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800">
              <span className="text-xs text-neutral-400 block">कुल आवश्यक बीज</span>
              <span className="text-3xl font-extrabold font-mono text-emerald-400 mt-1 block">
                {totalSeedRequiredKg} <span className="text-sm">किग्रा (Kg)</span>
              </span>
              <p className="text-xs text-neutral-400 mt-2">{currentSeedConfig.tip}</p>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800">
              <span className="text-xs text-neutral-400 block">अनुमानित बीज खर्च</span>
              <span className="text-3xl font-extrabold font-mono text-amber-400 mt-1 block">
                {formatCurrency(totalSeedCost)}
              </span>
              <p className="text-xs text-neutral-400 mt-2">
                उपचारित बीज का ही प्रयोग करें ताकि रोगों से फसल सुरक्षित रहे।
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ==================== 4. LAND AREA UNIT CONVERTER ==================== */}
      {selectedCalc === 'area' && (
        <div
          className={`rounded-3xl p-5 sm:p-6 border space-y-6 ${
            isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
          }`}
        >
          <div className="pb-3 border-b border-neutral-800">
            <h2 className="text-lg font-bold">जमीन क्षेत्रफल इकाई परिवर्तक (Land Area Converter)</h2>
            <p className="text-xs text-neutral-400">
              एकड़, बीघा (पक्का व कच्चा), हेक्टेयर, कनाल और वर्ग फीट में तुरंत परिवर्तन
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">क्षेत्रफल दर्ज करें</label>
              <input
                type="number"
                step="0.1"
                value={convertValue}
                onChange={(e) => setConvertValue(Number(e.target.value) || 0)}
                className="w-full px-3 py-2.5 rounded-xl text-lg font-mono font-bold bg-neutral-800 border border-neutral-700 text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">इकाई चुनें (From)</label>
              <select
                value={fromUnit}
                onChange={(e) => setFromUnit(e.target.value as any)}
                className="w-full px-3 py-2.5 rounded-xl text-sm bg-neutral-800 border border-neutral-700 text-white"
              >
                <option value="acre">एकड़ (Acre)</option>
                <option value="bigha_pucca">बीघा - पक्का (Pucca Bigha - 3025 sq yd)</option>
                <option value="bigha_kaccha">बीघा - कच्चा (Kaccha Bigha - 1008 sq yd)</option>
                <option value="hectare">हेक्टेयर (Hectare)</option>
                <option value="kanal">कनाल (Kanal)</option>
                <option value="marla">मरला (Marla)</option>
              </select>
            </div>
          </div>

          {/* Conversion Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800">
              <span className="text-[11px] text-neutral-400 block">एकड़ (Acre)</span>
              <span className="text-lg font-bold font-mono text-emerald-400">{resultAcre}</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800">
              <span className="text-[11px] text-neutral-400 block">पक्का बीघा (Pucca)</span>
              <span className="text-lg font-bold font-mono text-white">{resultBighaPucca}</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800">
              <span className="text-[11px] text-neutral-400 block">कच्चा बीघा (Kaccha)</span>
              <span className="text-lg font-bold font-mono text-white">{resultBighaKaccha}</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800">
              <span className="text-[11px] text-neutral-400 block">हेक्टेयर (Hectare)</span>
              <span className="text-lg font-bold font-mono text-amber-400">{resultHectare}</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800">
              <span className="text-[11px] text-neutral-400 block">कनाल (Kanal)</span>
              <span className="text-lg font-bold font-mono text-white">{resultKanal}</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800">
              <span className="text-[11px] text-neutral-400 block">वर्ग फीट (Sq. Feet)</span>
              <span className="text-lg font-bold font-mono text-teal-400">{resultSqFt}</span>
            </div>
          </div>
        </div>
      )}

      {/* ==================== 5. DIESEL & IRRIGATION COST ==================== */}
      {selectedCalc === 'diesel' && (
        <div
          className={`rounded-3xl p-5 sm:p-6 border space-y-6 ${
            isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
          }`}
        >
          <div className="pb-3 border-b border-neutral-800">
            <h2 className="text-lg font-bold">ट्यूबवेल डीजल व सिंचाई खर्च कैलकुलेटर</h2>
            <p className="text-xs text-neutral-400">
              इंजन चलने के घंटों और डीजल खपत के आधार पर प्रति एकड़ सिंचाई का सही खर्च
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                इंजन चले (घंटे)
              </label>
              <input
                type="number"
                step="0.5"
                value={dieselRunHours}
                onChange={(e) => setDieselRunHours(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl text-sm font-mono bg-neutral-800 border border-neutral-700 text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                खपत (लीटर / घंटा)
              </label>
              <input
                type="number"
                step="0.1"
                value={dieselLitersPerHour}
                onChange={(e) => setDieselLitersPerHour(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl text-sm font-mono bg-neutral-800 border border-neutral-700 text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                डीजल भाव (₹ / लीटर)
              </label>
              <input
                type="number"
                value={dieselPricePerLiter}
                onChange={(e) => setDieselPricePerLiter(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl text-sm font-mono bg-neutral-800 border border-neutral-700 text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                सिंचित रकबा (एकड़)
              </label>
              <input
                type="number"
                step="0.5"
                value={dieselIrrigatedAcres}
                onChange={(e) => setDieselIrrigatedAcres(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl text-sm font-mono bg-neutral-800 border border-neutral-700 text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-center">
              <span className="text-xs text-neutral-400 block">कुल डीजल खपत</span>
              <span className="text-2xl font-extrabold font-mono text-emerald-400 mt-1 block">
                {totalDieselLiters} <span className="text-xs font-normal">लीटर</span>
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-center">
              <span className="text-xs text-neutral-400 block">कुल डीजल खर्च</span>
              <span className="text-2xl font-extrabold font-mono text-rose-400 mt-1 block">
                {formatCurrency(totalDieselCost)}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-center">
              <span className="text-xs text-neutral-400 block">लागत प्रति एकड़</span>
              <span className="text-2xl font-extrabold font-mono text-amber-400 mt-1 block">
                {formatCurrency(costPerAcreDiesel)}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
