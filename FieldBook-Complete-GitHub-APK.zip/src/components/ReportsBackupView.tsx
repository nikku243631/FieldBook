import React, { useState } from 'react';
import {
  FileText,
  Download,
  Upload,
  Calendar,
  Share2,
  DollarSign,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  CheckCircle,
  AlertCircle,
  UserCheck,
  Sparkles,
  RotateCcw,
  Trash2,
  Smartphone,
  FolderArchive,
  Loader2
} from 'lucide-react';
import { CropCycle, Transaction, HarvestEntry, Language, Theme } from '../types';
import { formatCurrency, getTranslation } from '../utils/translations';
import { exportTransactionsToCSV } from '../utils/export';
import { Storage } from '../utils/storage';
import { ConfirmModal } from './ConfirmModal';
import { downloadProjectZip } from '../utils/zipExporter';

interface ReportsBackupViewProps {
  crops: CropCycle[];
  transactions: Transaction[];
  harvests: HarvestEntry[];
  lang: Language;
  theme: Theme;
  farmerName: string;
  onUpdateFarmerName: (name: string) => void;
  onReloadData: () => void;
  onClearAllData?: () => void;
  onOpenInstallModal?: () => void;
}

export const ReportsBackupView: React.FC<ReportsBackupViewProps> = ({
  crops,
  transactions,
  harvests,
  lang,
  theme,
  farmerName,
  onUpdateFarmerName,
  onReloadData,
  onClearAllData,
  onOpenInstallModal
}) => {
  const isDark = theme === 'dark';
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [isImportError, setIsImportError] = useState<boolean>(false);
  const [nameInput, setNameInput] = useState(farmerName);
  const [isClearAllModalOpen, setIsClearAllModalOpen] = useState(false);
  const [isReloadDemoModalOpen, setIsReloadDemoModalOpen] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [zipStatus, setZipStatus] = useState<string | null>(null);

  const handleDownloadProjectZip = async () => {
    setIsZipping(true);
    try {
      await downloadProjectZip((msg) => setZipStatus(msg));
      setZipStatus('डाउनलोड पूर्ण!');
      setTimeout(() => {
        setZipStatus(null);
        setIsZipping(false);
      }, 3500);
    } catch {
      setZipStatus('डाउनलोड असफल');
      setIsZipping(false);
    }
  };

  // Group transactions by month
  const monthlyData: Record<string, { expenses: number; income: number; txCount: number }> = {};

  transactions.forEach((tx) => {
    const monthKey = tx.date.slice(0, 7); // YYYY-MM
    if (!monthlyData[monthKey]) {
      monthlyData[monthKey] = { expenses: 0, income: 0, txCount: 0 };
    }
    if (tx.type === 'expense') {
      monthlyData[monthKey].expenses += tx.amount;
    } else {
      monthlyData[monthKey].income += tx.amount;
    }
    monthlyData[monthKey].txCount += 1;
  });

  const sortedMonths = Object.keys(monthlyData).sort().reverse();

  const totalExpenses = transactions
    .filter((t) => t.type === 'expense')
    .reduce((s, t) => s + t.amount, 0);
  const totalIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((s, t) => s + t.amount, 0);
  const overallNetProfit = totalIncome - totalExpenses;

  // Handle Full JSON Backup Export
  const handleExportJSON = () => {
    const jsonStr = Storage.exportFullBackup();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `FieldBook_Complete_Backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Handle JSON Restore with strict validation and error reporting
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const result = Storage.importFullBackupWithDetails(text);
        if (result.success) {
          setIsImportError(false);
          setImportStatus(
            lang === 'hi'
              ? `डेटा सफलतापूर्वक पुनर्स्थापित हो गया! (${result.counts?.crops || 0} फसलें, ${result.counts?.transactions || 0} लेन-देन)`
              : `Data restored successfully! (${result.counts?.crops || 0} crops, ${result.counts?.transactions || 0} transactions)`
          );
          onReloadData();
        } else {
          setIsImportError(true);
          setImportStatus(
            lang === 'hi'
              ? `अमान्य बैकअप फ़ाइल: ${result.errorHi || 'कृपया सही FieldBook JSON फ़ाइल चुनें। आपका मौजूदा डेटा सुरक्षित है।'}`
              : `Invalid backup file: ${result.errorEn || 'Existing data was not modified.'}`
          );
        }
      } catch {
        setIsImportError(true);
        setImportStatus(
          lang === 'hi'
            ? 'बैकअप लोड करने में त्रुटि आई। आपका मौजूदा डेटा सुरक्षित है।'
            : 'Error reading backup file. Existing data remains untouched.'
        );
      }
      e.target.value = '';
    };
    reader.readAsText(file);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;
    onUpdateFarmerName(nameInput.trim());
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Title */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border ${
          isDark ? 'glass-panel text-white' : 'glass-panel-light text-neutral-900'
        }`}
      >
        <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
          <FileText className="w-4 h-4" />
          <span>{lang === 'hi' ? 'वित्तीय ऑडिट व डेटा बैकअप' : 'Financial Reports & Cloud Backup'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          {lang === 'hi' ? 'मासिक रिपोर्ट व डेटा सुरक्षा' : 'Monthly Statements & Backup'}
        </h1>
        <p className="text-xs text-neutral-400 mt-1">
          {lang === 'hi'
            ? 'महीनेवार कुल कमाई, खर्च व मुनाफे का विवरण देखें और फोन बदलने पर भी डेटा सुरक्षित रखने हेतु बैकअप लें।'
            : 'Review month-by-month cashflow and export secure offline/cloud backups anytime.'}
        </p>
      </div>

      {/* Farm Lifetime Summary Card */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-white">
          <span className="text-xs text-neutral-400 block">{getTranslation(lang, 'totalLagat')}</span>
          <span className="text-2xl font-extrabold font-mono text-rose-500 mt-1 block">
            {formatCurrency(totalExpenses)}
          </span>
          <span className="text-[11px] text-neutral-500 block mt-0.5">
            सभी फसलों पर कुल निवेश
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-white">
          <span className="text-xs text-neutral-400 block">{getTranslation(lang, 'totalKamai')}</span>
          <span className="text-2xl font-extrabold font-mono text-emerald-400 mt-1 block">
            {formatCurrency(totalIncome)}
          </span>
          <span className="text-[11px] text-neutral-500 block mt-0.5">
            कुल मंडी व स्थानीय प्राप्ति
          </span>
        </div>

        <div
          className={`p-4 rounded-2xl border ${
            overallNetProfit >= 0
              ? 'bg-emerald-950/40 border-emerald-500/40'
              : 'bg-rose-950/30 border-rose-800/40'
          }`}
        >
          <span className="text-xs text-neutral-400 block">
            {overallNetProfit >= 0 ? getTranslation(lang, 'netProfit') : getTranslation(lang, 'netLoss')}
          </span>
          <span
            className={`text-2xl font-extrabold font-mono mt-1 block ${
              overallNetProfit >= 0 ? 'text-emerald-400' : 'text-rose-500'
            }`}
          >
            {overallNetProfit >= 0 ? '+' : ''}
            {formatCurrency(overallNetProfit)}
          </span>
          <span className="text-[11px] text-neutral-400 block mt-0.5">
            {totalExpenses > 0
              ? `कुल ROI: ${((overallNetProfit / totalExpenses) * 100).toFixed(1)}%`
              : 'शून्य निवेश'}
          </span>
        </div>
      </div>

      {/* MONTHLY BREAKDOWN TABLE */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border space-y-4 ${
          isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
        }`}
      >
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div>
            <h3 className="text-base font-bold">महीनेवार लाभ-हानि हिसाब (Monthly Breakdown)</h3>
            <p className="text-xs text-neutral-400">हर माह कितना खर्च हुआ और कितनी आमदनी हुई</p>
          </div>
          <button
            onClick={() => exportTransactionsToCSV(crops, transactions, lang)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-neutral-800 border border-neutral-700 hover:border-emerald-500 text-white cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Excel / CSV</span>
          </button>
        </div>

        {sortedMonths.length > 0 ? (
          <div className="space-y-2">
            {sortedMonths.map((month) => {
              const data = monthlyData[month];
              const monthProfit = data.income - data.expenses;
              const isProfit = monthProfit >= 0;

              return (
                <div
                  key={month}
                  className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-neutral-800 text-emerald-400 flex items-center justify-center font-mono font-bold text-xs">
                      {month.slice(5)}
                    </div>
                    <div>
                      <span className="text-sm font-bold text-white block">
                        माह: {month} ({data.txCount} प्रविष्टियां)
                      </span>
                      <div className="flex items-center gap-3 text-xs text-neutral-400 font-mono mt-0.5">
                        <span className="text-rose-400">लागत: {formatCurrency(data.expenses)}</span>
                        <span>·</span>
                        <span className="text-emerald-400">कमाई: {formatCurrency(data.income)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right sm:self-center">
                    <span
                      className={`text-base font-extrabold font-mono tabular-nums ${
                        isProfit ? 'text-emerald-400' : 'text-rose-500'
                      }`}
                    >
                      {isProfit ? '+' : ''}
                      {formatCurrency(monthProfit)}
                    </span>
                    <span className="text-[10px] text-neutral-500 block">
                      {isProfit ? 'मासिक शुद्ध बचत' : 'मासिक शुद्ध लागत'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-xs text-neutral-400 text-center py-6">कोई मासिक लेन-देन दर्ज नहीं है।</p>
        )}
      </div>

      {/* DATA BACKUP & RESTORE SECTION */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border space-y-5 ${
          isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
        }`}
      >
        <div className="pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-bold">डेटा बैकअप, रीस्टोर व निर्यात (Backup & Restore)</h3>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            आपका डेटा 100% आपके फोन में सुरक्षित है। फोन खो जाने या बदलने पर डेटा न खोए, इसके लिए बैकअप फाइल डाउनलोड करके WhatsApp या Google Drive पर सुरक्षित रखें।
          </p>
        </div>

        {importStatus && (
          <div
            className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
              isImportError
                ? 'bg-rose-950/60 border-rose-500/50 text-rose-200'
                : 'bg-emerald-950/50 border-emerald-500/40 text-emerald-300'
            }`}
          >
            {isImportError ? (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            ) : (
              <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
            )}
            <span>{importStatus}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Download JSON Backup */}
          <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-3">
            <div>
              <span className="text-sm font-bold text-white block">1. बैकअप फाइल डाउनलोड करें</span>
              <p className="text-xs text-neutral-400 mt-1">
                अपनी सभी फसलों, खर्चों, मंडी बिक्रियों और डायरी का सम्पूर्ण बैकअप JSON फाइल में सुरक्षित करें।
              </p>
            </div>
            <button
              onClick={handleExportJSON}
              className="btn-3d-primary w-full py-2.5 px-4 rounded-xl text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              <Download className="w-4 h-4" />
              <span>पूरा बैकअप डाउनलोड करें</span>
            </button>
          </div>

          {/* Upload JSON Backup */}
          <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-3">
            <div>
              <span className="text-sm font-bold text-white block">2. बैकअप फ़ाइल से डेटा रीस्टोर करें</span>
              <p className="text-xs text-neutral-400 mt-1">
                यदि आपने पहले कोई बैकअप फ़ाइल डाउनलोड की है, तो उसे यहाँ अपलोड करके पूरा हिसाब वापस लाएं।
              </p>
            </div>
            <label className="btn-3d-secondary w-full py-2.5 px-4 rounded-xl text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md border border-neutral-700">
              <Upload className="w-4 h-4 text-emerald-400" />
              <span>फ़ाइल चुनें व रीस्टोर करें</span>
              <input
                type="file"
                accept=".json"
                onChange={handleImportFile}
                className="hidden"
              />
            </label>
          </div>

          {/* 3. Mobile App & APK Guide Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/40 to-teal-950/40 border border-emerald-500/40 space-y-3 sm:col-span-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-white block">3. मोबाइल ऐप (APK / WebAPK) व GitHub ZIP</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    PWA & APK Ready
                  </span>
                </div>
                <p className="text-xs text-neutral-400 mt-1">
                  FieldBook को फोन में असली ऐप की तरह चलाएं या GitHub Actions से ऑटोमैटिक .apk बनाने के लिए प्रोजेक्ट ZIP डाउनलोड करें।
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleDownloadProjectZip}
                  disabled={isZipping}
                  className="py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md transition"
                >
                  {isZipping ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{zipStatus || 'ज़िप बन रही है...'}</span>
                    </>
                  ) : (
                    <>
                      <FolderArchive className="w-4 h-4" />
                      <span>{zipStatus || '📦 प्रोजेक्ट ZIP (GitHub / APK)'}</span>
                    </>
                  )}
                </button>

                {onOpenInstallModal && (
                  <button
                    type="button"
                    onClick={onOpenInstallModal}
                    className="btn-3d-primary py-2.5 px-4 rounded-xl text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md"
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>ऐप इंस्टॉल / APK गाइड</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Reset / Clear Data Controls */}
        <div className="pt-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs border-t border-neutral-800">
          <button
            type="button"
            onClick={() => setIsClearAllModalOpen(true)}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-rose-400 bg-rose-500/10 border border-rose-500/30 hover:bg-rose-500/20 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>सारा पुराना डेटा हटाएं (Delete All / Start Fresh)</span>
          </button>

          <button
            type="button"
            onClick={() => setIsReloadDemoModalOpen(true)}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-neutral-300 bg-neutral-800 border border-neutral-700 hover:text-amber-400 hover:border-amber-400/50 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>सैंपल डेमो डेटा रीलोड करें</span>
          </button>
        </div>
      </div>

      {/* DEVELOPER CREDIT & ABOUT PROFILE BOX */}
      <div className="p-5 rounded-3xl bg-emerald-950/40 border border-emerald-500/30 text-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/40">
              <UserCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-emerald-300">
                  {lang === 'hi' ? 'डेवलपर:' : 'Developer:'}
                </span>
                <span className="text-base font-extrabold text-white">Mr Nikhil</span>
              </div>
              <p className="text-xs text-neutral-300 mt-0.5">
                {lang === 'hi'
                  ? 'FieldBook — भारतीय किसान भाइयों के लिए समर्पित डिजिटल लेजर व हिसाब-किताब'
                  : 'FieldBook — High performance digital ledger dedicated for farmers'}
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveProfile} className="flex items-center gap-2">
            <input
              type="text"
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              placeholder="आपका नाम (Farmer Name)"
              className="px-3 py-1.5 rounded-xl text-xs bg-neutral-900 border border-neutral-700 text-white"
            />
            <button
              type="submit"
              className="px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
            >
              सुरक्षित करें
            </button>
          </form>
        </div>
      </div>

      {/* Modal: Clear All Data */}
      <ConfirmModal
        isOpen={isClearAllModalOpen}
        title={lang === 'hi' ? 'सारा डेटा हटाएं?' : 'Clear All Data?'}
        message={
          lang === 'hi'
            ? 'क्या आप सचमुच सभी फसलों, खर्चों, मंडी बिक्रियों और डायरी का सारा पुराना डेटा हटाकर नया खाली लेजर शुरू करना चाहते हैं?'
            : 'Are you sure you want to wipe all crops, expenses, and farm entries to start with a blank ledger?'
        }
        confirmLabel={lang === 'hi' ? 'हाँ, सारा डेटा साफ़ करें' : 'Yes, Delete Everything'}
        cancelLabel={lang === 'hi' ? 'रद्द करें' : 'Cancel'}
        isDestructive={true}
        theme={theme}
        onConfirm={() => {
          setIsClearAllModalOpen(false);
          if (onClearAllData) {
            onClearAllData();
          } else {
            Storage.clearAllData();
            onReloadData();
          }
        }}
        onCancel={() => setIsClearAllModalOpen(false)}
      />

      {/* Modal: Reload Demo Data */}
      <ConfirmModal
        isOpen={isReloadDemoModalOpen}
        title={lang === 'hi' ? 'सैंपल डेटा रीलोड करें?' : 'Reload Demo Data?'}
        message={
          lang === 'hi'
            ? 'क्या आप गेहूं व सरसों का सैंपल डेमो डेटा वापस लोड करना चाहते हैं?'
            : 'Do you want to reload sample demonstration data?'
        }
        confirmLabel={lang === 'hi' ? 'हाँ, रीलोड करें' : 'Yes, Reload'}
        cancelLabel={lang === 'hi' ? 'रद्द करें' : 'Cancel'}
        isDestructive={false}
        theme={theme}
        onConfirm={() => {
          setIsReloadDemoModalOpen(false);
          Storage.resetToSampleData();
          onReloadData();
        }}
        onCancel={() => setIsReloadDemoModalOpen(false)}
      />
    </div>
  );
};
