import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  CropCycle,
  Transaction,
  HarvestEntry,
  DiaryEntry,
  ExpenseCategory,
  IncomeCategory,
  Language,
  Theme
} from '../types';
import { formatCurrency, formatNumber, getTranslation } from '../utils/translations';
import {
  generateWhatsAppSummary,
  printCropReportPDF
} from '../utils/export';
import { calculateCropFinancials } from '../utils/calculations';
import { ConfirmModal } from './ConfirmModal';
import {
  ArrowLeft,
  Share2,
  Printer,
  Trash2,
  Edit,
  Plus,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Scale,
  Calendar,
  Clock,
  Sparkles,
  PieChart,
  ShoppingCart,
  BookOpen,
  CheckCircle2,
  Clock4,
  AlertCircle
} from 'lucide-react';

interface CropDetailViewProps {
  crop: CropCycle;
  transactions: Transaction[];
  harvests: HarvestEntry[];
  diary: DiaryEntry[];
  lang: Language;
  theme: Theme;
  farmerName?: string;
  onBack: () => void;
  onEditCrop: (crop: CropCycle) => void;
  onDeleteCrop: (cropId: string) => void;
  onAddTransaction: (type: 'expense' | 'income') => void;
  onEditTransaction?: (tx: Transaction) => void;
  onDeleteTransaction: (txId: string) => void;
  onAddHarvest: () => void;
  onEditHarvest?: (harvest: HarvestEntry) => void;
  onDeleteHarvest: (harvestId: string) => void;
  onAddDiary: () => void;
  onEditDiary?: (entry: DiaryEntry) => void;
  onDeleteDiary: (diaryId: string) => void;
}

export const CropDetailView: React.FC<CropDetailViewProps> = ({
  crop,
  transactions,
  harvests,
  diary,
  lang,
  theme,
  farmerName = 'Kisan Bhai',
  onBack,
  onEditCrop,
  onDeleteCrop,
  onAddTransaction,
  onEditTransaction,
  onDeleteTransaction,
  onAddHarvest,
  onEditHarvest,
  onDeleteHarvest,
  onAddDiary,
  onEditDiary,
  onDeleteDiary
}) => {
  const isDark = theme === 'dark';
  const [activeTab, setActiveTab] = useState<'dashboard' | 'expenses' | 'income' | 'harvest' | 'diary'>('dashboard');
  const [expenseFilter, setExpenseFilter] = useState<string>('all');
  const [isDeleteCropModalOpen, setIsDeleteCropModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{
    type: 'tx' | 'harvest' | 'diary';
    id: string;
    name: string;
  } | null>(null);

  const cropTx = transactions.filter((t) => t.cropId === crop.id);
  const expenses = cropTx.filter((t) => t.type === 'expense');
  const incomes = cropTx.filter((t) => t.type === 'income');
  const cropHarvests = harvests.filter((h) => h.cropId === crop.id);
  const cropDiary = diary.filter((d) => d.cropId === crop.id);

  const financials = calculateCropFinancials(crop, transactions, harvests);
  const totalLagat = financials.totalExpenses;
  const totalKamai = financials.totalIncome;
  const netProfit = financials.netProfit;
  const isProfit = financials.isProfit;
  const profitMarginPercent = financials.profitMarginPercent.toFixed(1);

  const totalYieldQuintal = financials.totalHarvestQuintal;
  const costPerAreaUnit = financials.costPerUnit;
  const profitPerAreaUnit = financials.profitPerUnit;
  const areaUnitLabel = getTranslation(lang, crop.areaUnit);
  const expenseByCategory = financials.expenseByCategory;

  const categoryIcons: Record<string, string> = {
    fertilizer: '🌱',
    seeds: '🌾',
    pesticide: '🧪',
    irrigation: '💧',
    labour: '👥',
    machinery: '🚜',
    other: '📦'
  };

  const handleConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  const handleShareWhatsApp = () => {
    const encoded = generateWhatsAppSummary(crop, transactions, harvests, lang);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
  };

  const handlePrintPDF = () => {
    printCropReportPDF(crop, transactions, harvests, farmerName, lang);
  };

  const filteredExpenses = expenses.filter((e) => {
    if (expenseFilter === 'all') return true;
    return e.category === expenseFilter;
  });

  return (
    <div className="space-y-6 pb-20">
      {/* Top Navigation & Action Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer bg-neutral-100 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-800 hover:border-emerald-500"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{getTranslation(lang, 'allCrops')}</span>
        </button>

        <div className="flex items-center gap-2">
          {/* WhatsApp Share */}
          <button
            onClick={handleShareWhatsApp}
            title="Share on WhatsApp"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-emerald-600 text-white cursor-pointer hover:bg-emerald-500 transition-colors shadow-sm"
          >
            <Share2 className="w-4 h-4" />
            <span className="hidden sm:inline">WhatsApp</span>
          </button>

          {/* Print PDF Statement */}
          <button
            onClick={handlePrintPDF}
            title="Print PDF Statement"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-neutral-200 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 border border-neutral-300 dark:border-neutral-700 cursor-pointer hover:border-emerald-500 transition-colors shadow-sm"
          >
            <Printer className="w-4 h-4" />
            <span className="hidden sm:inline">PDF</span>
          </button>

          {/* Edit Crop */}
          <button
            onClick={() => onEditCrop(crop)}
            title="Edit Crop"
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 border border-neutral-700 cursor-pointer"
          >
            <Edit className="w-4 h-4" />
          </button>

          {/* Delete Crop */}
          <button
            onClick={() => setIsDeleteCropModalOpen(true)}
            title={lang === 'hi' ? 'पूरी फसल का खाता हटाएं' : 'Delete Crop Record'}
            className="p-2 rounded-xl text-rose-400 hover:text-white hover:bg-rose-900/50 border border-rose-800/40 cursor-pointer transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Glass Hero Card */}
      <div
        className={`relative rounded-3xl p-5 sm:p-6 border overflow-hidden ${
          isDark ? 'glass-panel text-white' : 'glass-panel-light text-neutral-900'
        }`}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-medium text-emerald-600 dark:text-emerald-400 mb-1">
              <span className="font-bold uppercase tracking-wider">
                {crop.season === 'rabi'
                  ? 'रबी (Rabi)'
                  : crop.season === 'kharif'
                  ? 'खरीफ (Kharif)'
                  : crop.season === 'zaid'
                  ? 'जायद (Zaid)'
                  : 'वार्षिक (Annual)'}
              </span>
              <span>·</span>
              <span>
                {crop.landArea} {getTranslation(lang, crop.areaUnit)}
              </span>
              <span>·</span>
              <span>बुवाई: {crop.sowingDate}</span>
            </div>

            <h1 className="text-3xl font-extrabold tracking-tight">
              {lang === 'hi' ? crop.hindiName || crop.name : crop.name}
            </h1>

            {crop.variety && (
              <p className="text-xs text-neutral-400 mt-1 font-medium">
                वैरायटी: <span className="text-emerald-400 font-semibold">{crop.variety}</span>
                {crop.targetYieldQuintal && (
                  <span className="ml-3">
                    लक्ष्य पैदावार: {crop.targetYieldQuintal} क्विंटल
                  </span>
                )}
              </p>
            )}
          </div>

          {/* Status Badge */}
          <div className="flex items-center gap-2">
            <span
              className={`px-3 py-1 rounded-xl text-xs font-extrabold border ${
                crop.status === 'active'
                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                  : 'bg-amber-500/20 text-amber-400 border-amber-500/40'
              }`}
            >
              {crop.status === 'active'
                ? getTranslation(lang, 'active')
                : getTranslation(lang, 'harvested')}
            </span>
          </div>
        </div>

        {/* 4-KPI Financial Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {/* Total Lagat */}
          <div className="p-4 rounded-2xl bg-neutral-900/60 dark:bg-neutral-900/70 border border-neutral-800">
            <span className="text-[11px] font-semibold text-neutral-400 block uppercase">
              {getTranslation(lang, 'totalLagat')}
            </span>
            <span className="text-xl sm:text-2xl font-extrabold font-mono text-rose-500 tabular-nums">
              {formatCurrency(totalLagat)}
            </span>
            <span className="text-[11px] text-neutral-500 block mt-1">
              {costPerAreaUnit > 0 ? `${formatCurrency(costPerAreaUnit)}/${areaUnitLabel}` : 'शून्य लागत'}
            </span>
          </div>

          {/* Total Kamai */}
          <div className="p-4 rounded-2xl bg-neutral-900/60 dark:bg-neutral-900/70 border border-neutral-800">
            <span className="text-[11px] font-semibold text-neutral-400 block uppercase">
              {getTranslation(lang, 'totalKamai')}
            </span>
            <span className="text-xl sm:text-2xl font-extrabold font-mono text-emerald-400 tabular-nums">
              {formatCurrency(totalKamai)}
            </span>
            <span className="text-[11px] text-neutral-500 block mt-1">
              {incomes.length} मंडी/स्थानीय बिक्री
            </span>
          </div>

          {/* Net Profit / Loss */}
          <div
            onClick={isProfit ? handleConfetti : undefined}
            className={`p-4 rounded-2xl border transition-all ${
              isProfit
                ? 'bg-emerald-950/40 border-emerald-500/40 cursor-pointer hover:border-emerald-400'
                : 'bg-rose-950/30 border-rose-800/40'
            }`}
          >
            <div className="flex items-center justify-between">
              <span
                className={`text-[11px] font-bold block uppercase ${
                  isProfit ? 'text-emerald-300' : 'text-rose-300'
                }`}
              >
                {isProfit ? getTranslation(lang, 'netProfit') : getTranslation(lang, 'netLoss')}
              </span>
              {isProfit && <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />}
            </div>
            <div className="flex items-center gap-1.5 mt-0.5">
              {isProfit ? (
                <TrendingUp className="w-5 h-5 text-emerald-400 shrink-0" />
              ) : (
                <TrendingDown className="w-5 h-5 text-rose-500 shrink-0" />
              )}
              <span
                className={`text-xl sm:text-2xl font-extrabold font-mono tabular-nums ${
                  isProfit ? 'text-emerald-400' : 'text-rose-500'
                }`}
              >
                {isProfit ? '+' : ''}
                {formatCurrency(netProfit)}
              </span>
            </div>
            <span className="text-[11px] text-neutral-400 block mt-1">
              मुनाफा दर: {profitMarginPercent}% ({profitPerAreaUnit !== 0 ? `${profitPerAreaUnit > 0 ? '+' : ''}${formatCurrency(profitPerAreaUnit)}/${areaUnitLabel}` : `₹0/${areaUnitLabel}`})
            </span>
          </div>

          {/* Total Yield Harvest */}
          <div className="p-4 rounded-2xl bg-neutral-900/60 dark:bg-neutral-900/70 border border-neutral-800">
            <span className="text-[11px] font-semibold text-neutral-400 block uppercase">
              {getTranslation(lang, 'totalHarvest')}
            </span>
            <span className="text-xl sm:text-2xl font-extrabold font-mono text-amber-400 tabular-nums">
              {totalYieldQuintal} <span className="text-sm">क्विंटल</span>
            </span>
            <span className="text-[11px] text-neutral-500 block mt-1">
              {cropHarvests.length} कटाई/तुड़ाई सत्र दर्ज
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-neutral-100 dark:bg-neutral-900/90 border border-neutral-200 dark:border-neutral-800 overflow-x-auto">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'dashboard'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'text-neutral-600 dark:text-neutral-400 hover:text-white'
          }`}
        >
          <PieChart className="w-4 h-4" />
          <span>{getTranslation(lang, 'dashboard')}</span>
        </button>

        <button
          onClick={() => setActiveTab('expenses')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'expenses'
              ? 'bg-rose-600 text-white shadow-md'
              : 'text-neutral-600 dark:text-neutral-400 hover:text-white'
          }`}
        >
          <span>🔴 {getTranslation(lang, 'expenses')}</span>
          <span className="px-1.5 py-0.2 rounded-md bg-black/20 text-[10px] font-mono">
            {expenses.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('income')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'income'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'text-neutral-600 dark:text-neutral-400 hover:text-white'
          }`}
        >
          <span>🟢 {getTranslation(lang, 'income')}</span>
          <span className="px-1.5 py-0.2 rounded-md bg-black/20 text-[10px] font-mono">
            {incomes.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('harvest')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'harvest'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-neutral-600 dark:text-neutral-400 hover:text-white'
          }`}
        >
          <Scale className="w-4 h-4" />
          <span>{getTranslation(lang, 'harvest')}</span>
          <span className="px-1.5 py-0.2 rounded-md bg-black/20 text-[10px] font-mono">
            {cropHarvests.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('diary')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'diary'
              ? 'bg-teal-600 text-white shadow-md'
              : 'text-neutral-600 dark:text-neutral-400 hover:text-white'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>{getTranslation(lang, 'diary')}</span>
          <span className="px-1.5 py-0.2 rounded-md bg-black/20 text-[10px] font-mono">
            {cropDiary.length}
          </span>
        </button>
      </div>

      {/* ==================== TAB 1: DASHBOARD & P&L ANALYSIS ==================== */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Expense Category Breakdown Card */}
          <div
            className={`rounded-3xl p-5 sm:p-6 border ${
              isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold">
                  {lang === 'hi' ? 'लागत वर्गीकरण (Expense Breakdown)' : 'Expense Breakdown'}
                </h3>
                <p className="text-xs text-neutral-400">
                  {lang === 'hi'
                    ? 'किस मद में कितना रुपया खर्च हुआ (खाद, बीज, दवाई, डीजल, मजदूरी)'
                    : 'Rupees spent across each farming input'}
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-rose-400">
                कुल लागत: {formatCurrency(totalLagat)}
              </span>
            </div>

            {totalLagat > 0 ? (
              <div className="space-y-3">
                {Object.entries(expenseByCategory).map(([cat, amt]) => {
                  const percent = Math.round((amt / totalLagat) * 100);
                  return (
                    <div key={cat} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-medium">
                        <span className="flex items-center gap-1.5">
                          <span>{categoryIcons[cat] || '📦'}</span>
                          <span>{getTranslation(lang, cat as any)}</span>
                        </span>
                        <div className="flex items-center gap-2 font-mono">
                          <span className="font-bold">{formatCurrency(amt)}</span>
                          <span className="text-neutral-400">({percent}%)</span>
                        </div>
                      </div>
                      <div className="w-full h-2 rounded-full bg-neutral-800 overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300"
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-neutral-400 py-6 text-center">
                {lang === 'hi'
                  ? 'अभी तक कोई खर्च दर्ज नहीं किया गया है। "लागत (खर्च)" टैब में जाकर खर्च जोड़ें।'
                  : 'No expenses logged yet. Tap Add Expense to begin.'}
              </p>
            )}
          </div>

          {/* Mandi Profitability Insight */}
          <div
            className={`rounded-3xl p-5 sm:p-6 border ${
              isDark ? 'glass-panel text-white' : 'glass-panel-light text-neutral-900'
            }`}
          >
            <h3 className="text-lg font-bold mb-3">
              {lang === 'hi' ? 'मंडी व आर्थिक विश्लेषण' : 'Crop Economics Summary'}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800">
                <span className="text-[11px] text-neutral-400 block">कुल पैदावार</span>
                <span className="text-lg font-bold font-mono text-emerald-400">
                  {totalYieldQuintal} क्विंटल
                </span>
                <span className="text-[10px] text-neutral-500 block mt-0.5">
                  {crop.landArea > 0 ? `${(totalYieldQuintal / crop.landArea).toFixed(1)} क्विंटल/एकड़` : ''}
                </span>
              </div>

              <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800">
                <span className="text-[11px] text-neutral-400 block">प्रति क्विंटल औसत लागत</span>
                <span className="text-lg font-bold font-mono text-amber-400">
                  {totalYieldQuintal > 0 ? formatCurrency(Math.round(totalLagat / totalYieldQuintal)) : '₹0'}
                </span>
                <span className="text-[10px] text-neutral-500 block mt-0.5">
                  1 क्विंटल तैयार करने का खर्च
                </span>
              </div>

              <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800">
                <span className="text-[11px] text-neutral-400 block">शुद्ध रिटर्न (ROI)</span>
                <span
                  className={`text-lg font-bold font-mono ${
                    isProfit ? 'text-emerald-400' : 'text-rose-500'
                  }`}
                >
                  {totalLagat > 0 ? `${((netProfit / totalLagat) * 100).toFixed(1)}%` : '0%'}
                </span>
                <span className="text-[10px] text-neutral-500 block mt-0.5">
                  लागत पर शुद्ध मुनाफा प्रतिशत
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== TAB 2: LAGAT (EXPENSES) ==================== */}
      {activeTab === 'expenses' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            {/* Filter by Category */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
              {['all', 'fertilizer', 'seeds', 'pesticide', 'irrigation', 'labour', 'machinery', 'other'].map(
                (cat) => (
                  <button
                    key={cat}
                    onClick={() => setExpenseFilter(cat)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                      expenseFilter === cat
                        ? 'bg-rose-600 text-white'
                        : 'bg-neutral-800/80 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {cat === 'all' ? 'सभी खर्च' : getTranslation(lang, cat as any)}
                  </button>
                )
              )}
            </div>

            <button
              onClick={() => onAddTransaction('expense')}
              className="btn-3d-amber flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-white font-bold text-xs whitespace-nowrap cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>{getTranslation(lang, 'addExpense')}</span>
            </button>
          </div>

          {filteredExpenses.length > 0 ? (
            <div className="space-y-2.5">
              {filteredExpenses.map((tx) => (
                <div
                  key={tx.id}
                  className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isDark ? 'bg-neutral-900/70 border-neutral-800' : 'bg-white border-neutral-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center shrink-0 text-lg">
                      {categoryIcons[tx.category] || '📦'}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-neutral-100">{tx.title}</h4>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-300 font-medium">
                          {getTranslation(lang, tx.category as any)}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400 mt-1 font-mono">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-neutral-500" />
                          <span>{tx.date}</span>
                        </span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-neutral-500" />
                          <span>{tx.time}</span>
                        </span>
                        {tx.quantity && (
                          <>
                            <span>·</span>
                            <span>
                              {tx.quantity} {tx.unit || ''}
                            </span>
                          </>
                        )}
                        {tx.vendorOrBuyer && (
                          <>
                            <span>·</span>
                            <span className="text-neutral-300">{tx.vendorOrBuyer}</span>
                          </>
                        )}
                      </div>

                      {tx.notes && (
                        <p className="text-xs text-neutral-400 mt-1 bg-neutral-800/40 px-2 py-0.5 rounded">
                          {tx.notes}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-2 self-end sm:self-center">
                    <span className="text-base font-extrabold font-mono text-rose-400 tabular-nums mr-1">
                      -{formatCurrency(tx.amount)}
                    </span>
                    {onEditTransaction && (
                      <button
                        onClick={() => onEditTransaction(tx)}
                        title={lang === 'hi' ? 'खर्च सुधारें' : 'Edit Expense'}
                        className="p-1.5 rounded-lg text-neutral-400 hover:text-emerald-400 hover:bg-neutral-800 cursor-pointer transition-colors"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => setItemToDelete({ type: 'tx', id: tx.id, name: tx.title })}
                      title={lang === 'hi' ? 'खर्च हटाएं' : 'Delete Expense'}
                      className="p-1.5 rounded-lg text-neutral-500 hover:text-rose-400 hover:bg-neutral-800 cursor-pointer transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-2xl border-dashed border-neutral-800">
              <p className="text-xs text-neutral-400 mb-3">
                {lang === 'hi' ? 'इस श्रेणी में कोई खर्च दर्ज नहीं है' : 'No expenses in this category'}
              </p>
              <button
                onClick={() => onAddTransaction('expense')}
                className="btn-3d-amber inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-white font-bold text-xs cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>{getTranslation(lang, 'addExpense')}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB 3: KAMAI (INCOME & MANDI SALES) ==================== */}
      {activeTab === 'income' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-neutral-300">
              {lang === 'hi' ? 'मंडी बिक्री व आमदनी खाते' : 'Mandi Sales & Realization'}
            </h3>

            <button
              onClick={() => onAddTransaction('income')}
              className="btn-3d-primary flex items-center gap-1.5 px-4 py-2 rounded-xl text-white font-bold text-xs cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>{getTranslation(lang, 'addIncome')}</span>
            </button>
          </div>

          {incomes.length > 0 ? (
            <div className="space-y-3">
              {incomes.map((tx) => (
                <div
                  key={tx.id}
                  className={`p-4 rounded-2xl border ${
                    isDark ? 'bg-neutral-900/80 border-emerald-500/20' : 'bg-white border-emerald-200'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-base font-bold text-white">{tx.title}</span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          {getTranslation(lang, tx.category as any)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-neutral-400 mt-1 font-mono">
                        <span>{tx.date}</span>
                        <span>·</span>
                        <span>{tx.time}</span>
                        {tx.vendorOrBuyer && (
                          <>
                            <span>·</span>
                            <span className="text-emerald-400 font-medium">{tx.vendorOrBuyer}</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xl font-extrabold font-mono text-emerald-400 tabular-nums mr-1">
                        +{formatCurrency(tx.amount)}
                      </span>
                      {onEditTransaction && (
                        <button
                          onClick={() => onEditTransaction(tx)}
                          title={lang === 'hi' ? 'कमाई सुधारें' : 'Edit Income'}
                          className="p-1.5 rounded-lg text-neutral-400 hover:text-emerald-400 hover:bg-neutral-800 cursor-pointer transition-colors"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        onClick={() => setItemToDelete({ type: 'tx', id: tx.id, name: tx.title })}
                        title={lang === 'hi' ? 'कमाई हटाएं' : 'Delete Income'}
                        className="p-1.5 rounded-lg text-neutral-500 hover:text-rose-400 cursor-pointer transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Mandi Slip Breakdown Card if present */}
                  {tx.mandiDetails && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-3 pt-1 text-xs">
                      <div className="p-2 rounded-lg bg-neutral-950/60 border border-neutral-800">
                        <span className="text-[10px] text-neutral-400 block">शुद्ध वजन (Net Qtl)</span>
                        <span className="font-bold font-mono text-white">
                          {tx.mandiDetails.netWeightQuintal} क्विंटल
                        </span>
                      </div>

                      <div className="p-2 rounded-lg bg-neutral-950/60 border border-neutral-800">
                        <span className="text-[10px] text-neutral-400 block">मंडी भाव (Rate/Qtl)</span>
                        <span className="font-bold font-mono text-emerald-400">
                          ₹{tx.mandiDetails.ratePerQuintal}
                        </span>
                      </div>

                      <div className="p-2 rounded-lg bg-neutral-950/60 border border-neutral-800">
                        <span className="text-[10px] text-neutral-400 block">पल्लेदारी कटौती</span>
                        <span className="font-bold font-mono text-rose-400">
                          ₹{tx.mandiDetails.totalPalledari || 0}
                        </span>
                      </div>

                      <div className="p-2 rounded-lg bg-neutral-950/60 border border-neutral-800">
                        <span className="text-[10px] text-neutral-400 block">पर्ची नंबर (Slip)</span>
                        <span className="font-mono text-neutral-300">
                          {tx.mandiDetails.receiptNumber || 'N/A'}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-2xl border-dashed border-neutral-800">
              <p className="text-xs text-neutral-400 mb-3">
                {lang === 'hi' ? 'अभी कोई बिक्री दर्ज नहीं हुई है' : 'No sales or income logged yet'}
              </p>
              <button
                onClick={() => onAddTransaction('income')}
                className="btn-3d-primary inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-white font-bold text-xs cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>{getTranslation(lang, 'addIncome')}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB 4: TUDAI (HARVEST WEIGHT LOGS) ==================== */}
      {activeTab === 'harvest' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-neutral-300">
                {lang === 'hi' ? 'कटाई व तुड़ाई वजन हिसाब' : 'Harvest Weight Logging'}
              </h3>
              <p className="text-xs text-neutral-400">
                कुल दर्ज पैदावार: <span className="font-bold font-mono text-amber-400">{totalYieldQuintal} क्विंटल</span>
              </p>
            </div>

            <button
              onClick={onAddHarvest}
              className="btn-3d-primary flex items-center gap-1.5 px-4 py-2 rounded-xl text-white font-bold text-xs cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>{getTranslation(lang, 'addHarvest')}</span>
            </button>
          </div>

          {cropHarvests.length > 0 ? (
            <div className="space-y-2.5">
              {cropHarvests.map((hrv) => (
                <div
                  key={hrv.id}
                  className={`p-4 rounded-2xl border flex items-center justify-between ${
                    isDark ? 'bg-neutral-900/70 border-neutral-800' : 'bg-white border-neutral-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center shrink-0">
                      <Scale className="w-5 h-5" />
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-base font-bold font-mono text-white">
                          {hrv.quantityQuintal} क्विंटल
                        </span>
                        {hrv.grade && (
                          <span className="px-2 py-0.5 rounded text-[10px] bg-neutral-800 text-neutral-300">
                            {hrv.grade}
                          </span>
                        )}
                        {hrv.moisturePercentage && (
                          <span className="text-xs text-emerald-400 font-mono">
                            नमी: {hrv.moisturePercentage}%
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-xs text-neutral-400 mt-1 font-mono">
                        <span>{hrv.date}</span>
                        <span>·</span>
                        <span>{hrv.time}</span>
                        {hrv.storageLocation && (
                          <>
                            <span>·</span>
                            <span>{hrv.storageLocation}</span>
                          </>
                        )}
                      </div>

                      {hrv.notes && <p className="text-xs text-neutral-400 mt-1">{hrv.notes}</p>}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {onEditHarvest && (
                      <button
                        onClick={() => onEditHarvest(hrv)}
                        title={lang === 'hi' ? 'कटाई वजन सुधारें' : 'Edit Harvest Entry'}
                        className="p-1.5 rounded-lg text-neutral-400 hover:text-emerald-400 hover:bg-neutral-800 cursor-pointer transition-colors"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => setItemToDelete({ type: 'harvest', id: hrv.id, name: `${hrv.quantityQuintal} क्विंटल कटाई` })}
                      title={lang === 'hi' ? 'कटाई वजन हटाएं' : 'Delete Harvest Entry'}
                      className="p-1.5 rounded-lg text-neutral-500 hover:text-rose-400 cursor-pointer transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-2xl border-dashed border-neutral-800">
              <p className="text-xs text-neutral-400 mb-3">
                {lang === 'hi' ? 'कटाई का वजन दर्ज करने के लिए बटन दबाएं' : 'Log your first harvest session'}
              </p>
              <button
                onClick={onAddHarvest}
                className="btn-3d-primary inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-white font-bold text-xs cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>{getTranslation(lang, 'addHarvest')}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB 5: KHET DIARY ==================== */}
      {activeTab === 'diary' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-neutral-300">
                {lang === 'hi' ? 'खेत डायरी व गतिविधि टाइमलाइन' : 'Farm Activity Diary'}
              </h3>
              <p className="text-xs text-neutral-400">
                {lang === 'hi' ? 'सिंचाई, छिड़काव व खाद डालने की तारीख व टिप्पणियां' : 'Timestamps of irrigation, sprays, and fertilizer'}
              </p>
            </div>

            <button
              onClick={onAddDiary}
              className="btn-3d-primary flex items-center gap-1.5 px-4 py-2 rounded-xl text-white font-bold text-xs cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>{getTranslation(lang, 'addDiary')}</span>
            </button>
          </div>

          {cropDiary.length > 0 ? (
            <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-emerald-500/30">
              {cropDiary.map((item) => (
                <div key={item.id} className="relative">
                  <div className="absolute -left-6 top-1.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-neutral-950 ring-2 ring-emerald-500/40" />

                  <div
                    className={`p-4 rounded-2xl border ${
                      isDark ? 'bg-neutral-900/70 border-neutral-800' : 'bg-white border-neutral-200'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-emerald-400">
                          {item.activityType === 'irrigation'
                            ? '💧 सिंचाई'
                            : item.activityType === 'spray'
                            ? '🧪 स्प्रे छिड़काव'
                            : item.activityType === 'fertilizer'
                            ? '🌱 खाद'
                            : item.activityType === 'sowing'
                            ? '🌾 बुवाई'
                            : item.activityType === 'inspection'
                            ? '🔍 निरीक्षण'
                            : '📋 अन्य कार्य'}
                        </span>
                        <span className="text-xs text-neutral-400 font-mono">
                          {item.date} · {item.time}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        {onEditDiary && (
                          <button
                            onClick={() => onEditDiary(item)}
                            title={lang === 'hi' ? 'डायरी नोट सुधारें' : 'Edit Diary Note'}
                            className="p-1 rounded-lg text-neutral-400 hover:text-emerald-400 cursor-pointer transition-colors"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => setItemToDelete({ type: 'diary', id: item.id, name: 'खेत डायरी नोट' })}
                          title={lang === 'hi' ? 'डायरी नोट हटाएं' : 'Delete Diary Note'}
                          className="p-1 rounded-lg text-neutral-500 hover:text-rose-400 cursor-pointer transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <p className="text-xs text-neutral-200 leading-relaxed">{item.notes}</p>

                    {item.weatherNote && (
                      <p className="text-[11px] text-neutral-400 mt-2 italic flex items-center gap-1">
                        <span>☀️</span> {item.weatherNote}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-2xl border-dashed border-neutral-800">
              <p className="text-xs text-neutral-400 mb-3">
                {lang === 'hi' ? 'खेत डायरी में कोई प्रविष्टि नहीं है' : 'No diary entries yet'}
              </p>
              <button
                onClick={onAddDiary}
                className="btn-3d-primary inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-white font-bold text-xs cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>{getTranslation(lang, 'addDiary')}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Delete Crop Confirmation Modal */}
      <ConfirmModal
        isOpen={isDeleteCropModalOpen}
        title={lang === 'hi' ? 'पूरी फसल का खाता हटाएं?' : 'Delete Entire Crop?'}
        message={
          lang === 'hi'
            ? `क्या आप सचमुच "${crop.hindiName || crop.name}" फसल और इसके अंदर दर्ज सभी खर्च, मंडी बिक्री, तुड़ाई व डायरी के हिसाब को हमेशा के लिए हटाना चाहते हैं?`
            : `Are you sure you want to permanently delete "${crop.name}" and all its recorded expenses, mandi sales, and logs?`
        }
        confirmLabel={lang === 'hi' ? 'हाँ, पूरा खाता हटाएं' : 'Yes, Delete All'}
        cancelLabel={lang === 'hi' ? 'रद्द करें' : 'Cancel'}
        isDestructive={true}
        theme={theme}
        onConfirm={() => {
          setIsDeleteCropModalOpen(false);
          onDeleteCrop(crop.id);
        }}
        onCancel={() => setIsDeleteCropModalOpen(false)}
      />

      {/* Delete Single Entry (Expense/Income/Harvest/Diary) Confirmation Modal */}
      <ConfirmModal
        isOpen={!!itemToDelete}
        title={lang === 'hi' ? 'प्रविष्टि हटाएं?' : 'Delete Entry?'}
        message={
          lang === 'hi'
            ? `क्या आप "${itemToDelete?.name}" का रिकॉर्ड हटाना चाहते हैं?`
            : `Are you sure you want to delete "${itemToDelete?.name}"?`
        }
        confirmLabel={lang === 'hi' ? 'हाँ, हटाएं' : 'Yes, Delete'}
        cancelLabel={lang === 'hi' ? 'रद्द करें' : 'Cancel'}
        isDestructive={true}
        theme={theme}
        onConfirm={() => {
          if (!itemToDelete) return;
          if (itemToDelete.type === 'tx') onDeleteTransaction(itemToDelete.id);
          else if (itemToDelete.type === 'harvest') onDeleteHarvest(itemToDelete.id);
          else if (itemToDelete.type === 'diary') onDeleteDiary(itemToDelete.id);
          setItemToDelete(null);
        }}
        onCancel={() => setItemToDelete(null)}
      />
    </div>
  );
};
