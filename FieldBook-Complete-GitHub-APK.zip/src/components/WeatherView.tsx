import React, { useState, useEffect } from 'react';
import {
  CloudSun,
  Droplets,
  Wind,
  Compass,
  AlertTriangle,
  CheckCircle,
  MapPin,
  RefreshCw,
  Sun,
  CloudRain,
  Search,
  X,
  Sparkles,
  Navigation
} from 'lucide-react';
import { Language, Theme } from '../types';
import {
  WeatherData,
  fetchLiveWeather,
  getWeatherDescription,
  searchLocationApi,
  LocationSearchResult,
  BUDAUN_COORDINATES
} from '../utils/weather';
import { Storage, SavedLocation } from '../utils/storage';
import { getTranslation } from '../utils/translations';

interface WeatherViewProps {
  lang: Language;
  theme: Theme;
}

// Regional presets around Budaun, UP & major agricultural belts
const POPULAR_LOCATIONS: SavedLocation[] = [
  {
    name: 'चितौरा / धनौरा, ज़िला बदायूं (243631)',
    district: 'बदायूं (Budaun)',
    state: 'उत्तर प्रदेश (UP)',
    pincode: '243631',
    lat: 28.0381,
    lon: 79.1267
  },
  {
    name: 'बदायूं मुख्य शहर (Budaun City)',
    district: 'Budaun',
    state: 'Uttar Pradesh',
    lat: 28.0381,
    lon: 79.1267
  },
  {
    name: 'बरेली (Bareilly)',
    district: 'Bareilly',
    state: 'Uttar Pradesh',
    lat: 28.3670,
    lon: 79.4304
  },
  {
    name: 'संभल (Sambhal)',
    district: 'Sambhal',
    state: 'Uttar Pradesh',
    lat: 28.5833,
    lon: 78.5667
  },
  {
    name: 'मुरादाबाद (Moradabad)',
    district: 'Moradabad',
    state: 'Uttar Pradesh',
    lat: 28.8354,
    lon: 78.7758
  },
  {
    name: 'अलीगढ़ (Aligarh)',
    district: 'Aligarh',
    state: 'Uttar Pradesh',
    lat: 27.8974,
    lon: 78.0880
  },
  {
    name: 'शाहजहांपुर (Shahjahanpur)',
    district: 'Shahjahanpur',
    state: 'Uttar Pradesh',
    lat: 27.8814,
    lon: 79.9113
  }
];

export const WeatherView: React.FC<WeatherViewProps> = ({ lang, theme }) => {
  const isDark = theme === 'dark';

  // Load saved location from storage or default to Budaun Chitaura/Dhanaura 243631
  const [currentLocation, setCurrentLocation] = useState<SavedLocation>(() =>
    Storage.getWeatherLocation()
  );

  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);

  // Search Modal state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<LocationSearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Manual Coordinates input
  const [showManualCoord, setShowManualCoord] = useState(false);
  const [manualName, setManualName] = useState('');
  const [manualLat, setManualLat] = useState('');
  const [manualLon, setManualLon] = useState('');

  const loadWeatherForLocation = async (loc: SavedLocation) => {
    setLoading(true);
    const data = await fetchLiveWeather(loc.lat, loc.lon, loc.name);
    setWeather(data);
    setLoading(false);
  };

  useEffect(() => {
    loadWeatherForLocation(currentLocation);
  }, []);

  const handleSelectLocation = (loc: SavedLocation) => {
    setCurrentLocation(loc);
    Storage.saveWeatherLocation(loc);
    loadWeatherForLocation(loc);
    setIsSearchOpen(false);
    setSearchQuery('');
    setSearchResults([]);
  };

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    const results = await searchLocationApi(searchQuery);
    setSearchResults(results);
    setIsSearching(false);
  };

  const handleUseCurrentLocation = () => {
    if (navigator.geolocation) {
      setLoading(true);
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const gpsLoc: SavedLocation = {
            name: 'मेरा खेत (GPS लोकेशन)',
            lat: pos.coords.latitude,
            lon: pos.coords.longitude
          };
          handleSelectLocation(gpsLoc);
        },
        () => {
          // Fallback to saved
          loadWeatherForLocation(currentLocation);
        }
      );
    }
  };

  const handleSaveManualCoordinates = (e: React.FormEvent) => {
    e.preventDefault();
    const lat = parseFloat(manualLat);
    const lon = parseFloat(manualLon);
    if (isNaN(lat) || isNaN(lon)) return;

    const loc: SavedLocation = {
      name: manualName.trim() || 'मेरा खेत (कस्टम)',
      lat,
      lon
    };
    handleSelectLocation(loc);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Top Header Banner with Active Location & Change Button */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border ${
          isDark ? 'glass-panel text-white' : 'glass-panel-light text-neutral-900'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
              <CloudSun className="w-4 h-4" />
              <span>{lang === 'hi' ? 'कृषि मौसम व छिड़काव अलर्ट' : 'Agricultural Weather Advisory'}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight flex items-center gap-2 flex-wrap">
              <span>{currentLocation.name}</span>
            </h1>

            <p className="text-xs text-neutral-400 mt-1 flex items-center gap-2 flex-wrap">
              <span className="flex items-center gap-1 font-mono text-emerald-400">
                <MapPin className="w-3.5 h-3.5" />
                <span>
                  {currentLocation.lat.toFixed(4)}° N, {currentLocation.lon.toFixed(4)}° E
                </span>
              </span>
              <span>·</span>
              <span>
                {lang === 'hi'
                  ? 'कीटनाशक और खाद छिड़काव हेतु हवा व बारिश की सटीक निगरानी'
                  : 'Real-time wind speed and precipitation forecasts for farm spraying'}
              </span>
            </p>
          </div>

          {/* Action Buttons: Change Location & GPS */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => {
                setManualName(currentLocation.name);
                setManualLat(String(currentLocation.lat));
                setManualLon(String(currentLocation.lon));
                setIsSearchOpen(true);
              }}
              className="btn-3d-primary flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-white font-bold text-xs cursor-pointer shadow-md"
            >
              <Search className="w-4 h-4" />
              <span>{lang === 'hi' ? 'लोकेशन बदलें / संपादित करें' : 'Change / Edit Location'}</span>
            </button>

            <button
              onClick={handleUseCurrentLocation}
              title="Detect GPS Location"
              className="p-2.5 rounded-xl border border-neutral-700 bg-neutral-900 text-neutral-300 hover:text-emerald-400 hover:border-emerald-500 cursor-pointer"
            >
              <Navigation className="w-4 h-4" />
            </button>

            <button
              onClick={() => loadWeatherForLocation(currentLocation)}
              title="Refresh Weather"
              className="p-2.5 rounded-xl border border-neutral-700 bg-neutral-900 text-neutral-300 hover:text-white cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Quick Location Chips Bar */}
        <div className="mt-4 pt-3 border-t border-neutral-800 flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-xs text-neutral-400 whitespace-nowrap flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-emerald-500" />
            <span>त्वरित चुनें:</span>
          </span>

          {POPULAR_LOCATIONS.map((loc) => (
            <button
              key={loc.name}
              onClick={() => handleSelectLocation(loc)}
              className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap border transition-colors cursor-pointer ${
                currentLocation.name === loc.name
                  ? 'bg-emerald-600 text-white border-emerald-500 font-bold shadow-sm'
                  : 'bg-neutral-900/60 border-neutral-800 text-neutral-300 hover:border-emerald-500'
              }`}
            >
              {loc.pincode ? `📍 ${loc.name.split(' (')[0]}` : loc.name.split(' (')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Weather Loading State */}
      {loading && !weather && (
        <div
          className={`rounded-3xl p-8 text-center border ${
            isDark ? 'glass-card border-neutral-800 text-white' : 'glass-card-light border-neutral-200 text-neutral-900'
          }`}
        >
          <RefreshCw className="w-8 h-8 text-emerald-500 animate-spin mx-auto mb-3" />
          <p className="text-sm font-bold">
            {lang === 'hi' ? 'ताज़ा मौसम डेटा प्राप्त किया जा रहा है...' : 'Fetching live weather forecast...'}
          </p>
        </div>
      )}

      {/* Offline with NO Cached Data Available (Never fabricate temperatures) */}
      {!loading && !weather && (
        <div className="p-6 rounded-3xl border bg-amber-950/50 border-amber-500/50 text-amber-100 space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-extrabold">
                {lang === 'hi'
                  ? 'ऑफलाइन मोड: लाइव मौसम के लिए इंटरनेट आवश्यक है'
                  : 'Offline Mode: Internet Required for Live Weather'}
              </h3>
              <p className="text-xs opacity-90 leading-relaxed">
                {lang === 'hi'
                  ? 'अभी इंटरनेट कनेक्शन उपलब्ध नहीं है और इस स्थान के लिए कोई पूर्व सहेजा गया (Cached) मौसम डेटा नहीं मिला। FieldBook गलत या काल्पनिक तापमान नहीं दिखाता है। आपका फसल हिसाब, कैलकुलेटर और नोट्स 100% ऑफलाइन काम कर रहे हैं।'
                  : 'No internet connection detected and no cached forecast is stored for this location. FieldBook never fabricates weather readings. All your crop ledgers, calculators, and notes remain 100% usable offline.'}
              </p>
              <div className="pt-2">
                <button
                  onClick={() => loadWeatherForLocation(currentLocation)}
                  className="btn-3d-primary px-4 py-2 rounded-xl text-xs font-bold text-white inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  <span>{lang === 'hi' ? 'पुनः प्रयास करें (Retry)' : 'Retry Live Fetch'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Weather Content */}
      {weather && (
        <>
          {/* Cached / Stale Data Warning Banner when Offline */}
          {weather.isCached && (
            <div className="p-4 rounded-2xl bg-amber-950/60 border border-amber-500/50 text-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-start sm:items-center gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5 sm:mt-0" />
                <span>
                  {lang === 'hi'
                    ? weather.networkWarningHi ||
                      `ऑफलाइन / कैश्ड डेटा: यह ${weather.updatedAt} का सहेजा गया मौसम है। लाइव मौसम के लिए इंटरनेट से जुड़ें।`
                    : weather.networkWarningEn ||
                      `Offline / Cached Data: Showing saved weather from ${weather.updatedAt}. Connect to internet for live updates.`}
                </span>
              </div>
              <button
                onClick={() => loadWeatherForLocation(currentLocation)}
                className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-bold whitespace-nowrap cursor-pointer self-start sm:self-auto"
              >
                {lang === 'hi' ? 'ताज़ा करें' : 'Refresh'}
              </button>
            </div>
          )}

          {/* CRITICAL SPRAY ADVISORY ALERT BOX */}
          <div
            className={`p-5 rounded-3xl border shadow-lg ${
              weather.sprayStatus === 'rain_warning'
                ? 'bg-rose-950/60 border-rose-500/60 text-rose-100'
                : weather.sprayStatus === 'caution'
                ? 'bg-amber-950/50 border-amber-500/50 text-amber-100'
                : 'bg-emerald-950/60 border-emerald-500/50 text-emerald-100'
            }`}
          >
            <div className="flex items-start gap-3">
              <div
                className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${
                  weather.sprayStatus === 'rain_warning'
                    ? 'bg-rose-500/20 text-rose-400'
                    : weather.sprayStatus === 'caution'
                    ? 'bg-amber-500/20 text-amber-400'
                    : 'bg-emerald-500/20 text-emerald-400'
                }`}
              >
                {weather.sprayStatus === 'rain_warning' ? (
                  <AlertTriangle className="w-6 h-6" />
                ) : weather.sprayStatus === 'caution' ? (
                  <AlertTriangle className="w-6 h-6" />
                ) : (
                  <CheckCircle className="w-6 h-6" />
                )}
              </div>

              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs uppercase font-extrabold tracking-wider">
                    {lang === 'hi' ? 'छिड़काव अलर्ट (Spray Advisory)' : 'Spray Safety Status'}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      weather.isCached
                        ? 'bg-amber-500/25 text-amber-300 border border-amber-500/40'
                        : 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/40'
                    }`}
                  >
                    {weather.isCached
                      ? lang === 'hi'
                        ? `CACHED (सहेजा गया: ${weather.updatedAt})`
                        : `CACHED (${weather.updatedAt})`
                      : lang === 'hi'
                      ? `LIVE (ताज़ा: ${weather.updatedAt})`
                      : `LIVE (${weather.updatedAt})`}
                  </span>
                </div>

                <h3 className="text-lg font-extrabold mt-0.5">
                  {weather.sprayStatus === 'rain_warning'
                    ? lang === 'hi'
                      ? '⚠️ बारिश की संभावना: अभी कीटनाशक / यूरिया छिड़काव न करें!'
                      : '⚠️ Rain Imminent: Do Not Spray Chemicals Now!'
                    : weather.sprayStatus === 'caution'
                    ? lang === 'hi'
                      ? '⚡ सावधानी: तेज हवा या अधिक नमी है'
                      : '⚡ Caution: Elevated Wind or High Humidity'
                    : lang === 'hi'
                    ? '✅ मौसम साफ है: दवाई व खाद छिड़काव के लिए बहुत उत्तम समय'
                    : '✅ Excellent Conditions for Foliar & Pesticide Spray'}
                </h3>

                <p className="text-xs mt-1.5 opacity-90 leading-relaxed font-medium">
                  {lang === 'hi' ? weather.sprayAdvisoryHi : weather.sprayAdvisoryEn}
                </p>
              </div>
            </div>
          </div>

          {/* Current Weather KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-white">
              <span className="text-xs text-neutral-400 block">{getTranslation(lang, 'temperature')}</span>
              <span className="text-3xl font-extrabold font-mono text-emerald-400 mt-1 block">
                {weather.currentTemp}°C
              </span>
              <span className="text-xs text-neutral-300 mt-1 block">
                {getWeatherDescription(weather.weatherCode, lang)}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-white">
              <span className="text-xs text-neutral-400 block">{getTranslation(lang, 'humidity')}</span>
              <span className="text-3xl font-extrabold font-mono text-cyan-400 mt-1 block">
                {weather.humidity}%
              </span>
              <span className="text-[11px] text-neutral-400 mt-1 block">
                {weather.humidity > 80 ? 'फफूंद का जोखिम' : 'सामान्य नमी'}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-white">
              <span className="text-xs text-neutral-400 block">{getTranslation(lang, 'windSpeed')}</span>
              <span className="text-3xl font-extrabold font-mono text-amber-400 mt-1 block">
                {weather.windSpeedKmh} <span className="text-xs font-normal">km/h</span>
              </span>
              <span className="text-[11px] text-neutral-400 mt-1 block">
                {weather.windSpeedKmh > 18 ? 'स्प्रे का बहाव संभव' : 'शांत अनुकूल हवा'}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-white">
              <span className="text-xs text-neutral-400 block">बारिश संभावना (Rain)</span>
              <span className="text-3xl font-extrabold font-mono text-indigo-400 mt-1 block">
                {weather.dailyForecast[0]?.rainProbability || 0}%
              </span>
              <span className="text-[11px] text-neutral-400 mt-1 block">
                आज कुल वर्षा: {weather.dailyForecast[0]?.precipitationMm || 0} mm
              </span>
            </div>
          </div>

          {/* 7-Day Agricultural Forecast */}
          <div
            className={`rounded-3xl p-5 sm:p-6 border ${
              isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
            }`}
          >
            <h3 className="text-base font-bold mb-4 flex items-center justify-between">
              <span>{getTranslation(lang, 'forecast7Days')}</span>
              <span className="text-xs font-mono font-normal text-emerald-400">
                स्थान: {currentLocation.name}
              </span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5">
              {weather.dailyForecast.map((day, idx) => (
                <div
                  key={day.date}
                  className={`p-3 rounded-2xl border text-center transition-all ${
                    idx === 0
                      ? 'bg-emerald-950/40 border-emerald-500/50'
                      : 'bg-neutral-900/60 border-neutral-800'
                  }`}
                >
                  <span className="text-xs font-bold text-neutral-200 block truncate">
                    {day.dayName}
                  </span>
                  <span className="text-[10px] text-neutral-400 font-mono block mb-2">
                    {day.date.slice(5)}
                  </span>

                  <div className="text-xl font-bold font-mono text-white">
                    {day.maxTemp}° <span className="text-xs font-normal text-neutral-400">{day.minTemp}°</span>
                  </div>

                  <span className="text-[11px] text-neutral-300 block my-1">
                    {getWeatherDescription(day.weatherCode, lang)}
                  </span>

                  <div className="pt-2 border-t border-neutral-800 text-[10px] space-y-0.5 font-mono">
                    <div className="text-cyan-400">बारिश: {day.rainProbability}%</div>
                    <div className="text-neutral-400">हवा: {day.windSpeedKmh} km/h</div>
                  </div>

                  {/* Spray indicator badge */}
                  <div
                    className={`mt-2 py-0.5 rounded text-[9px] font-bold ${
                      day.sprayCondition === 'safe'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : day.sprayCondition === 'caution'
                        ? 'bg-amber-500/20 text-amber-400'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}
                  >
                    {day.sprayCondition === 'safe'
                      ? 'स्प्रे सुरक्षित'
                      : day.sprayCondition === 'caution'
                      ? 'सावधानी'
                      : 'स्प्रे न करें'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* ==================== LOCATION SEARCH MODAL ==================== */}
      {isSearchOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div
            className={`w-full max-w-lg rounded-3xl border p-5 sm:p-6 shadow-2xl transition-all my-8 max-h-[90vh] overflow-y-auto ${
              isDark
                ? 'bg-neutral-900 border-emerald-500/30 text-white'
                : 'bg-white border-emerald-300 text-neutral-900'
            }`}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-neutral-200 dark:border-neutral-800">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-emerald-400" />
                <h2 className="text-lg font-bold">खेत की लोकेशन चुनें / सर्च करें</h2>
              </div>
              <button
                onClick={() => setIsSearchOpen(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Search Input Form */}
            <form onSubmit={handleSearchSubmit} className="mt-4 space-y-3">
              <label className="text-xs font-semibold text-neutral-400 block">
                गांव, शहर, ज़िला या पिन कोड दर्ज करें (उदा. 243631, Budaun, Chitaura):
              </label>

              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="उदा. 243631 या बदायूं या धनौरा..."
                    autoFocus
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl text-sm bg-neutral-800 border border-neutral-700 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isSearching}
                  className="btn-3d-primary px-4 py-2.5 rounded-xl text-white font-bold text-xs whitespace-nowrap cursor-pointer shadow-md"
                >
                  {isSearching ? 'खोज रहे हैं...' : 'खोजें'}
                </button>
              </div>
            </form>

            {/* Search Results */}
            {searchResults.length > 0 && (
              <div className="mt-4 space-y-2">
                <span className="text-xs font-semibold text-emerald-400 block">सर्च परिणाम:</span>
                <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                  {searchResults.map((res) => (
                    <button
                      key={res.id}
                      onClick={() =>
                        handleSelectLocation({
                          name: res.displayName,
                          district: res.district,
                          state: res.state,
                          lat: res.latitude,
                          lon: res.longitude
                        })
                      }
                      className="w-full text-left p-3 rounded-xl bg-neutral-800/80 hover:bg-emerald-950/60 border border-neutral-700 hover:border-emerald-500 transition-colors flex items-center justify-between cursor-pointer group"
                    >
                      <div>
                        <div className="text-sm font-bold text-white group-hover:text-emerald-300">
                          {res.displayName}
                        </div>
                        <div className="text-xs text-neutral-400 font-mono">
                          {res.latitude.toFixed(4)}° N, {res.longitude.toFixed(4)}° E
                        </div>
                      </div>
                      <span className="text-xs font-bold text-emerald-400">चुनें →</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quick Presets */}
            <div className="mt-5 pt-4 border-t border-neutral-800">
              <span className="text-xs font-semibold text-neutral-400 block mb-2">
                पसंदीदा व आस-पास के क्षेत्र:
              </span>
              <div className="space-y-1.5">
                {POPULAR_LOCATIONS.map((loc) => (
                  <button
                    key={loc.name}
                    onClick={() => handleSelectLocation(loc)}
                    className={`w-full text-left p-2.5 rounded-xl border transition-colors flex items-center justify-between cursor-pointer ${
                      currentLocation.name === loc.name
                        ? 'bg-emerald-900/40 border-emerald-500 text-emerald-300 font-bold'
                        : 'bg-neutral-800/50 border-neutral-700/80 text-neutral-200 hover:border-emerald-500'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs">{loc.name}</span>
                    </div>
                    {loc.pincode && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400">
                        PIN: {loc.pincode}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Manual Lat/Lon Toggle */}
            <div className="mt-4 pt-3 border-t border-neutral-800">
              <button
                onClick={() => setShowManualCoord(!showManualCoord)}
                className="text-xs text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>+ सटीक अक्षांश व देशांतर (Latitude/Longitude) खुद दर्ज करें</span>
              </button>

              {showManualCoord && (
                <form onSubmit={handleSaveManualCoordinates} className="mt-3 space-y-2.5">
                  <input
                    type="text"
                    placeholder="खेत या गांव का नाम (उदा. मेरा खेत चितौरा)"
                    value={manualName}
                    onChange={(e) => setManualName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl text-xs bg-neutral-800 border border-neutral-700 text-white"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      step="0.0001"
                      required
                      placeholder="Latitude (उदा. 28.0381)"
                      value={manualLat}
                      onChange={(e) => setManualLat(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl text-xs font-mono bg-neutral-800 border border-neutral-700 text-white"
                    />
                    <input
                      type="number"
                      step="0.0001"
                      required
                      placeholder="Longitude (उदा. 79.1267)"
                      value={manualLon}
                      onChange={(e) => setManualLon(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl text-xs font-mono bg-neutral-800 border border-neutral-700 text-white"
                    />
                  </div>
                  <button
                    type="submit"
                    className="btn-3d-primary w-full py-2 rounded-xl text-xs font-bold text-white cursor-pointer"
                  >
                    कस्टम लोकेशन सेट करें
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
