import React from 'react';
import { Sprout, Sun, Moon, Globe, Plus, Sparkles, Calculator, FileText, Download } from 'lucide-react';
import { Language, Theme } from '../types';
import { getTranslation } from '../utils/translations';

interface HeaderProps {
  currentTab: 'crops' | 'calculators' | 'notes' | 'weather' | 'reports';
  onSelectTab: (tab: 'crops' | 'calculators' | 'notes' | 'weather' | 'reports') => void;
  lang: Language;
  onToggleLang: () => void;
  theme: Theme;
  onToggleTheme: () => void;
  onOpenAddCrop: () => void;
  selectedCropId: string | null;
  onBackToCrops: () => void;
  onOpenQuickCalc?: () => void;
  onOpenInstallModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  lang,
  onToggleLang,
  theme,
  onToggleTheme,
  onOpenAddCrop,
  selectedCropId,
  onBackToCrops,
  onOpenQuickCalc,
  onOpenInstallModal
}) => {
  const isDark = theme === 'dark';

  return (
    <header
      className={`sticky top-0 z-40 w-full border-b transition-colors ${
        isDark
          ? 'bg-neutral-950/80 border-emerald-900/30 backdrop-blur-xl'
          : 'bg-white/80 border-emerald-200/60 backdrop-blur-xl shadow-xs'
      }`}
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Zone 1: Brand Wordmark & Developer Tag */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => {
                onBackToCrops();
                onSelectTab('crops');
              }}
              className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-hidden"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 p-[1.5px] shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform">
                <div
                  className={`w-full h-full rounded-[10px] flex items-center justify-center ${
                    isDark ? 'bg-neutral-950' : 'bg-white'
                  }`}
                >
                  <Sprout className="w-5 h-5 text-emerald-500" />
                </div>
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <span
                    className={`text-lg font-extrabold tracking-tight ${
                      isDark ? 'text-white' : 'text-neutral-900'
                    }`}
                  >
                    FieldBook
                  </span>
                  <span className="hidden sm:inline-block px-1.5 py-0.2 rounded text-[10px] font-mono font-semibold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                    Agri-Ledger
                  </span>
                </div>
                {/* Developer credit inside the app as requested */}
                <div className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  <span>{lang === 'hi' ? 'डेवलपर:' : 'Developer:'}</span>
                  <span className="font-bold underline decoration-emerald-500/40">Mr Nikhil</span>
                </div>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-1.5 p-1 rounded-xl bg-neutral-100/80 dark:bg-neutral-900/80 border border-neutral-200 dark:border-neutral-800">
            <button
              onClick={() => {
                if (selectedCropId) onBackToCrops();
                onSelectTab('crops');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                currentTab === 'crops'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-300 hover:text-emerald-600 dark:hover:text-emerald-400'
              }`}
            >
              {getTranslation(lang, 'allCrops')}
            </button>

            <button
              onClick={() => onSelectTab('calculators')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                currentTab === 'calculators'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-300 hover:text-emerald-600 dark:hover:text-emerald-400'
              }`}
            >
              {getTranslation(lang, 'calculators')}
            </button>

            <button
              onClick={() => onSelectTab('notes')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                currentTab === 'notes'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-300 hover:text-emerald-600 dark:hover:text-emerald-400'
              }`}
            >
              {lang === 'hi' ? 'नोट्स व सामान' : 'Notes & Lists'}
            </button>

            <button
              onClick={() => onSelectTab('weather')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                currentTab === 'weather'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-300 hover:text-emerald-600 dark:hover:text-emerald-400'
              }`}
            >
              {getTranslation(lang, 'weather')}
            </button>

            <button
              onClick={() => onSelectTab('reports')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                currentTab === 'reports'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-300 hover:text-emerald-600 dark:hover:text-emerald-400'
              }`}
            >
              {getTranslation(lang, 'reports')}
            </button>
          </nav>

          {/* Zone 3: Toggles & Actions */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Install App / APK Button */}
            {onOpenInstallModal && (
              <button
                onClick={onOpenInstallModal}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer shadow-xs ${
                  isDark
                    ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-300 hover:bg-emerald-900/80 hover:border-emerald-400'
                    : 'bg-emerald-100 border-emerald-300 text-emerald-900 hover:bg-emerald-200'
                }`}
                title={lang === 'hi' ? 'फोन में ऐप/APK इंस्टॉल करें' : 'Install App / APK'}
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{lang === 'hi' ? 'ऐप इंस्टॉल (APK)' : 'Install App'}</span>
                <span className="sm:hidden">{lang === 'hi' ? 'ऐप' : 'App'}</span>
              </button>
            )}

            {/* Quick General Calculator Button */}
            {onOpenQuickCalc && (
              <button
                onClick={onOpenQuickCalc}
                className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                  isDark
                    ? 'bg-neutral-900 border-neutral-700 text-emerald-400 hover:border-emerald-500'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:border-emerald-400'
                }`}
                title={lang === 'hi' ? 'साधारण हिसाब कैलकुलेटर खोलें' : 'Open Calculator'}
              >
                <Calculator className="w-4 h-4" />
              </button>
            )}

            {/* Language Switcher */}
            <button
              onClick={onToggleLang}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-bold transition-colors cursor-pointer ${
                isDark
                  ? 'bg-neutral-900 border-neutral-700 text-emerald-400 hover:border-emerald-500'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-800 hover:border-emerald-400'
              }`}
              title="Change Language / भाषा बदलें"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'English' : 'हिंदी'}</span>
            </button>

            {/* Dark / Light Mode Toggle */}
            <button
              onClick={onToggleTheme}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                isDark
                  ? 'bg-neutral-900 border-neutral-700 text-amber-400 hover:border-amber-500'
                  : 'bg-neutral-100 border-neutral-300 text-neutral-700 hover:border-neutral-400'
              }`}
              title={isDark ? 'Light Mode' : 'Dark Mode'}
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Quick Add Crop Button */}
            <button
              onClick={onOpenAddCrop}
              className="btn-3d-primary hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-white font-bold text-xs cursor-pointer"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>{getTranslation(lang, 'addCrop')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Secondary Tab Bar (Clean, scrollable) */}
      <div className="md:hidden flex items-center justify-between gap-1 px-2 py-2 border-t border-neutral-200/50 dark:border-neutral-800/80 bg-neutral-100/50 dark:bg-neutral-950/50 overflow-x-auto scrollbar-none">
        <button
          onClick={() => {
            if (selectedCropId) onBackToCrops();
            onSelectTab('crops');
          }}
          className={`px-2.5 py-1 text-xs font-semibold rounded-md whitespace-nowrap transition-colors shrink-0 ${
            currentTab === 'crops'
              ? 'bg-emerald-600 text-white'
              : 'text-neutral-600 dark:text-neutral-400'
          }`}
        >
          {getTranslation(lang, 'allCrops')}
        </button>

        <button
          onClick={() => onSelectTab('calculators')}
          className={`px-2.5 py-1 text-xs font-semibold rounded-md whitespace-nowrap transition-colors shrink-0 ${
            currentTab === 'calculators'
              ? 'bg-emerald-600 text-white'
              : 'text-neutral-600 dark:text-neutral-400'
          }`}
        >
          {getTranslation(lang, 'calculators')}
        </button>

        <button
          onClick={() => onSelectTab('notes')}
          className={`px-2.5 py-1 text-xs font-semibold rounded-md whitespace-nowrap transition-colors shrink-0 ${
            currentTab === 'notes'
              ? 'bg-emerald-600 text-white'
              : 'text-neutral-600 dark:text-neutral-400'
          }`}
        >
          {lang === 'hi' ? 'नोट्स/सामान' : 'Notes/List'}
        </button>

        <button
          onClick={() => onSelectTab('weather')}
          className={`px-2.5 py-1 text-xs font-semibold rounded-md whitespace-nowrap transition-colors shrink-0 ${
            currentTab === 'weather'
              ? 'bg-emerald-600 text-white'
              : 'text-neutral-600 dark:text-neutral-400'
          }`}
        >
          {getTranslation(lang, 'weather')}
        </button>

        <button
          onClick={() => onSelectTab('reports')}
          className={`px-2.5 py-1 text-xs font-semibold rounded-md whitespace-nowrap transition-colors shrink-0 ${
            currentTab === 'reports'
              ? 'bg-emerald-600 text-white'
              : 'text-neutral-600 dark:text-neutral-400'
          }`}
        >
          {getTranslation(lang, 'reports')}
        </button>

        {onOpenInstallModal && (
          <button
            onClick={onOpenInstallModal}
            className="px-2.5 py-1 text-xs font-bold rounded-md whitespace-nowrap bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1 shrink-0 cursor-pointer"
          >
            <Download className="w-3 h-3" />
            <span>{lang === 'hi' ? 'ऐप इंस्टॉल' : 'Install App'}</span>
          </button>
        )}
      </div>
    </header>
  );
};
