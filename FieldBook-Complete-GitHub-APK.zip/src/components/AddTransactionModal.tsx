import React, { useState, useEffect } from 'react';
import { X, DollarSign, Tag, Calendar, Clock, ShoppingCart, User, FileText, CheckCircle2 } from 'lucide-react';
import { Transaction, ExpenseCategory, IncomeCategory, Language, Theme } from '../types';
import { getTranslation, formatCurrency } from '../utils/translations';

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (tx: Partial<Transaction>) => void;
  cropId: string;
  defaultType?: 'expense' | 'income';
  txToEdit?: Transaction | null;
  lang: Language;
  theme: Theme;
}

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  cropId,
  defaultType = 'expense',
  txToEdit,
  lang,
  theme
}) => {
  const isDark = theme === 'dark';

  const [type, setType] = useState<'expense' | 'income'>(defaultType);
  const [category, setCategory] = useState<string>(
    defaultType === 'expense' ? 'fertilizer' : 'mandi_sale'
  );
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState<number | ''>('');

  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const timeStr = now.toTimeString().slice(0, 5);
  const [date, setDate] = useState(todayStr);
  const [time, setTime] = useState(timeStr);

  const [quantity, setQuantity] = useState<number | ''>('');
  const [unit, setUnit] = useState('');
  const [ratePerUnit, setRatePerUnit] = useState<number | ''>('');
  const [vendorOrBuyer, setVendorOrBuyer] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<'paid' | 'pending'>('paid');

  // Mandi specific fields
  const [mandiGrossWeightKg, setMandiGrossWeightKg] = useState<number | ''>('');
  const [mandiTareWeightKg, setMandiTareWeightKg] = useState<number | ''>('');
  const [mandiNetWeightQuintal, setMandiNetWeightQuintal] = useState<number | ''>('');
  const [mandiRatePerQuintal, setMandiRatePerQuintal] = useState<number | ''>('');
  const [mandiPalledariPerQuintal, setMandiPalledariPerQuintal] = useState<number | ''>('');
  const [mandiBuyerName, setMandiBuyerName] = useState('');
  const [mandiReceiptNumber, setMandiReceiptNumber] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (txToEdit) {
      setType(txToEdit.type);
      setCategory(txToEdit.category);
      setTitle(txToEdit.title || '');
      setAmount(txToEdit.amount ?? '');
      setDate(txToEdit.date || new Date().toISOString().split('T')[0]);
      setTime(txToEdit.time || new Date().toTimeString().slice(0, 5));
      setQuantity(txToEdit.quantity ?? '');
      setUnit(txToEdit.unit || '');
      setRatePerUnit(txToEdit.ratePerUnit ?? '');
      setVendorOrBuyer(txToEdit.vendorOrBuyer || '');
      setNotes(txToEdit.notes || '');
      setPaymentStatus(txToEdit.paymentStatus || 'paid');
      setMandiGrossWeightKg(txToEdit.mandiDetails?.grossWeightKg ?? '');
      setMandiTareWeightKg(txToEdit.mandiDetails?.tareWeightKg ?? '');
      setMandiNetWeightQuintal(txToEdit.mandiDetails?.netWeightQuintal ?? '');
      setMandiRatePerQuintal(txToEdit.mandiDetails?.ratePerQuintal ?? '');
      setMandiPalledariPerQuintal(txToEdit.mandiDetails?.palledariPerQuintal ?? '');
      setMandiBuyerName(txToEdit.mandiDetails?.buyerName || txToEdit.vendorOrBuyer || '');
      setMandiReceiptNumber(txToEdit.mandiDetails?.receiptNumber || '');
    } else {
      const currentNow = new Date();
      setType(defaultType);
      setCategory(defaultType === 'expense' ? 'fertilizer' : 'mandi_sale');
      setTitle('');
      setAmount('');
      setDate(currentNow.toISOString().split('T')[0]);
      setTime(currentNow.toTimeString().slice(0, 5));
      setQuantity('');
      setUnit('');
      setRatePerUnit('');
      setVendorOrBuyer('');
      setNotes('');
      setPaymentStatus('paid');
      setMandiGrossWeightKg('');
      setMandiTareWeightKg('');
      setMandiNetWeightQuintal('');
      setMandiRatePerQuintal('');
      setMandiPalledariPerQuintal('');
      setMandiBuyerName('');
      setMandiReceiptNumber('');
    }
  }, [isOpen, defaultType, txToEdit]);

  if (!isOpen) return null;

  // Auto calculate Mandi total
  const calculateMandiTotal = (netQ: number, rateQ: number, palledariQ: number) => {
    if (!netQ || !rateQ || netQ <= 0 || rateQ <= 0) return;
    const grossVal = netQ * rateQ;
    const palledariDeduction = Math.max(0, palledariQ || 0) * netQ;
    const netPayout = Math.max(0, grossVal - palledariDeduction);
    setAmount(Math.round(netPayout));
  };

  const handleMandiWeightChange = (grossKg: number, tareKg: number) => {
    const netKg = Math.max(0, grossKg - tareKg);
    const netQ = Number((netKg / 100).toFixed(2));
    setMandiNetWeightQuintal(netQ);
    if (mandiRatePerQuintal) {
      calculateMandiTotal(netQ, Number(mandiRatePerQuintal), Number(mandiPalledariPerQuintal));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || Number(amount) <= 0) return;

    const defaultTitle =
      title.trim() ||
      (type === 'expense'
        ? getTranslation(lang, category as any)
        : getTranslation(lang, category as any));

    const txData: Partial<Transaction> = {
      id: txToEdit?.id,
      cropId,
      type,
      category: category as any,
      title: defaultTitle,
      amount: Math.round(Number(amount)),
      date,
      time,
      quantity: quantity && Number(quantity) > 0 ? Number(quantity) : undefined,
      unit: unit.trim() || undefined,
      ratePerUnit: ratePerUnit && Number(ratePerUnit) > 0 ? Number(ratePerUnit) : undefined,
      vendorOrBuyer: (vendorOrBuyer || mandiBuyerName).trim() || undefined,
      notes: notes.trim() || undefined,
      paymentStatus
    };

    if (category === 'mandi_sale') {
      const netQ = Number(mandiNetWeightQuintal) || (quantity ? Number(quantity) : 0);
      const rateQ = Number(mandiRatePerQuintal) || (ratePerUnit ? Number(ratePerUnit) : 0);
      const palledariQ = Math.max(0, Number(mandiPalledariPerQuintal) || 0);
      txData.mandiDetails = {
        grossWeightKg: mandiGrossWeightKg ? Number(mandiGrossWeightKg) : undefined,
        tareWeightKg: mandiTareWeightKg ? Number(mandiTareWeightKg) : undefined,
        netWeightQuintal: netQ,
        ratePerQuintal: rateQ,
        palledariPerQuintal: palledariQ,
        totalPalledari: Math.round(palledariQ * netQ),
        buyerName: mandiBuyerName.trim() || undefined,
        receiptNumber: mandiReceiptNumber.trim() || undefined
      };
    }

    onSave(txData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md overflow-y-auto">
      <div
        className={`w-full max-w-lg rounded-2xl border p-5 sm:p-6 shadow-2xl transition-all my-8 max-h-[90vh] overflow-y-auto ${
          isDark
            ? 'bg-neutral-900 border-emerald-500/30 text-white'
            : 'bg-white border-emerald-300 text-neutral-900'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <h2 className="text-lg font-bold">
            {txToEdit
              ? lang === 'hi'
                ? 'प्रविष्टि संशोधित करें (Edit Entry)'
                : 'Edit Transaction'
              : type === 'expense'
              ? getTranslation(lang, 'addExpense')
              : getTranslation(lang, 'addIncome')}
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Type Switcher (लागत vs कमाई) */}
        <div className="flex gap-2 p-1.5 my-4 rounded-xl bg-neutral-800/60 border border-neutral-700">
          <button
            type="button"
            onClick={() => {
              setType('expense');
              setCategory('fertilizer');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              type === 'expense'
                ? 'bg-rose-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            🔴 {getTranslation(lang, 'expenses')}
          </button>
          <button
            type="button"
            onClick={() => {
              setType('income');
              setCategory('mandi_sale');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              type === 'income'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            🟢 {getTranslation(lang, 'income')}
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Category Dropdown */}
          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1">
              {type === 'expense' ? 'खर्च की श्रेणी (Category)' : 'कमाई का जरिया (Source)'}
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl text-sm border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                isDark
                  ? 'bg-neutral-800 border-neutral-700 text-white'
                  : 'bg-neutral-50 border-neutral-300 text-neutral-900'
              }`}
            >
              {type === 'expense' ? (
                <>
                  <option value="fertilizer">{getTranslation(lang, 'fertilizer')}</option>
                  <option value="seeds">{getTranslation(lang, 'seeds')}</option>
                  <option value="pesticide">{getTranslation(lang, 'pesticide')}</option>
                  <option value="irrigation">{getTranslation(lang, 'irrigation')}</option>
                  <option value="labour">{getTranslation(lang, 'labour')}</option>
                  <option value="machinery">{getTranslation(lang, 'machinery')}</option>
                  <option value="other">{getTranslation(lang, 'other')}</option>
                </>
              ) : (
                <>
                  <option value="mandi_sale">{getTranslation(lang, 'mandi_sale')}</option>
                  <option value="local_sale">{getTranslation(lang, 'local_sale')}</option>
                  <option value="subsidy">{getTranslation(lang, 'subsidy')}</option>
                  <option value="byproduct">{getTranslation(lang, 'byproduct')}</option>
                </>
              )}
            </select>
          </div>

          {/* Special Mandi Calculator Section */}
          {category === 'mandi_sale' && (
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                <ShoppingCart className="w-4 h-4" />
                <span>मंडी तौल व भाव कैलकुलेटर (Mandi Weighing & Rate)</span>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] text-neutral-300 block mb-1">
                    कांटा कुल वजन (Gross Kg)
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="उदा. 4250"
                    value={mandiGrossWeightKg}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiGrossWeightKg(val);
                      handleMandiWeightChange(Number(val) || 0, Number(mandiTareWeightKg) || 0);
                    }}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-neutral-900/90 border border-neutral-700 font-mono tabular-nums text-white"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-neutral-300 block mb-1">
                    ट्रॉली/खाली वजन (Tare Kg)
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="उदा. 1250"
                    value={mandiTareWeightKg}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiTareWeightKg(val);
                      handleMandiWeightChange(Number(mandiGrossWeightKg) || 0, Number(val) || 0);
                    }}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-neutral-900/90 border border-neutral-700 font-mono tabular-nums text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[11px] text-emerald-300 font-semibold block mb-1">
                    शुद्ध वजन (क्विंटल) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="30.00"
                    value={mandiNetWeightQuintal}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiNetWeightQuintal(val);
                      if (mandiRatePerQuintal) {
                        calculateMandiTotal(Number(val), Number(mandiRatePerQuintal), Number(mandiPalledariPerQuintal));
                      }
                    }}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-neutral-900/90 border border-emerald-500/50 font-mono font-bold tabular-nums text-emerald-300"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-neutral-300 block mb-1">
                    भाव प्रति क्विंटल (₹) *
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="2275"
                    value={mandiRatePerQuintal}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiRatePerQuintal(val);
                      if (mandiNetWeightQuintal) {
                        calculateMandiTotal(Number(mandiNetWeightQuintal), Number(val), Number(mandiPalledariPerQuintal));
                      }
                    }}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-neutral-900/90 border border-neutral-700 font-mono tabular-nums text-white"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-neutral-300 block mb-1">
                    पल्लेदारी/क्विंटल (₹)
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="15"
                    value={mandiPalledariPerQuintal}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiPalledariPerQuintal(val);
                      if (mandiNetWeightQuintal && mandiRatePerQuintal) {
                        calculateMandiTotal(Number(mandiNetWeightQuintal), Number(mandiRatePerQuintal), Number(val));
                      }
                    }}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-neutral-900/90 border border-neutral-700 font-mono tabular-nums text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] text-neutral-400 block mb-1">आढ़ती / फर्म नाम</label>
                  <input
                    type="text"
                    placeholder="उदा. राधेश्याम ट्रेडिंग"
                    value={mandiBuyerName}
                    onChange={(e) => setMandiBuyerName(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-neutral-900/90 border border-neutral-700 text-white"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-neutral-400 block mb-1">पर्ची / बिल नंबर</label>
                  <input
                    type="text"
                    placeholder="उदा. MND-450"
                    value={mandiReceiptNumber}
                    onChange={(e) => setMandiReceiptNumber(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-neutral-900/90 border border-neutral-700 text-white font-mono"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Description Title & Amount */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'transactionTitle')}
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={
                  type === 'expense'
                    ? lang === 'hi' ? 'उदा. 2 बोरी DAP खाद' : 'e.g. 2 Bags DAP'
                    : lang === 'hi' ? 'उदा. 20 क्विंटल गेहूं बिक्री' : 'e.g. 20 Quintal Wheat Sale'
                }
                className={`w-full px-3 py-2 rounded-xl text-sm border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'amount')} *
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="1"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value === '' ? '' : parseFloat(e.target.value))}
                  placeholder="2500"
                  className={`w-full px-3 py-2 rounded-xl text-sm font-mono font-bold tabular-nums border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                    type === 'expense' ? 'text-rose-400' : 'text-emerald-400'
                  } ${
                    isDark
                      ? 'bg-neutral-800 border-neutral-700'
                      : 'bg-neutral-50 border-neutral-300'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* Auto Timestamp: Date & Time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                <span>{getTranslation(lang, 'date')} *</span>
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-sm font-mono tabular-nums border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                <span>{getTranslation(lang, 'time')} *</span>
              </label>
              <input
                type="time"
                required
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-sm font-mono tabular-nums border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>
          </div>

          {/* Optional Details: Quantity & Unit */}
          {category !== 'mandi_sale' && (
            <div className="grid grid-cols-3 gap-2.5">
              <div>
                <label className="text-xs font-semibold text-neutral-400 block mb-1">
                  {getTranslation(lang, 'quantity')}
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value === '' ? '' : parseFloat(e.target.value))}
                  placeholder="2"
                  className={`w-full px-2.5 py-1.5 rounded-xl text-sm font-mono tabular-nums border ${
                    isDark
                      ? 'bg-neutral-800 border-neutral-700 text-white'
                      : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-neutral-400 block mb-1">
                  इकाई (Unit)
                </label>
                <input
                  type="text"
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  placeholder="बोरी / लीटर / kg"
                  className={`w-full px-2.5 py-1.5 rounded-xl text-sm border ${
                    isDark
                      ? 'bg-neutral-800 border-neutral-700 text-white'
                      : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-neutral-400 block mb-1">
                  दर (Rate/Unit)
                </label>
                <input
                  type="number"
                  step="1"
                  value={ratePerUnit}
                  onChange={(e) => setRatePerUnit(e.target.value === '' ? '' : parseFloat(e.target.value))}
                  placeholder="₹1350"
                  className={`w-full px-2.5 py-1.5 rounded-xl text-sm font-mono tabular-nums border ${
                    isDark
                      ? 'bg-neutral-800 border-neutral-700 text-white'
                      : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                  }`}
                />
              </div>
            </div>
          )}

          {/* Vendor / Buyer & Payment Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {category !== 'mandi_sale' && (
              <div>
                <label className="text-xs font-semibold text-neutral-400 block mb-1">
                  {getTranslation(lang, 'vendorOrBuyer')}
                </label>
                <input
                  type="text"
                  value={vendorOrBuyer}
                  onChange={(e) => setVendorOrBuyer(e.target.value)}
                  placeholder={lang === 'hi' ? 'दुकानदार या मजदूर का नाम' : 'Vendor/Labour name'}
                  className={`w-full px-3 py-2 rounded-xl text-sm border ${
                    isDark
                      ? 'bg-neutral-800 border-neutral-700 text-white'
                      : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                  }`}
                />
              </div>
            )}

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'paymentStatus')}
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentStatus('paid')}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                    paymentStatus === 'paid'
                      ? 'bg-emerald-600 text-white border-emerald-500'
                      : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                  }`}
                >
                  ✓ {getTranslation(lang, 'paid')}
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentStatus('pending')}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                    paymentStatus === 'pending'
                      ? 'bg-amber-600 text-white border-amber-500'
                      : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                  }`}
                >
                  ⏳ {getTranslation(lang, 'pending')}
                </button>
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1">
              {getTranslation(lang, 'notes')}
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={lang === 'hi' ? 'कोई विशेष बात या बिल नंबर...' : 'Bill number, notes...'}
              className={`w-full px-3 py-2 rounded-xl text-sm border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                isDark
                  ? 'bg-neutral-800 border-neutral-700 text-white'
                  : 'bg-neutral-50 border-neutral-300 text-neutral-900'
              }`}
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-200 dark:border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-sm font-semibold text-neutral-400 hover:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className={`${
                type === 'expense' ? 'btn-3d-amber' : 'btn-3d-primary'
              } px-6 py-2.5 rounded-xl text-white font-bold text-sm cursor-pointer shadow-lg`}
            >
              {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
