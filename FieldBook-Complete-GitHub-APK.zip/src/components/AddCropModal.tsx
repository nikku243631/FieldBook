import React, { useState, useEffect } from 'react';
import { X, Sprout, Calendar, Ruler, TrendingUp, CheckCircle2 } from 'lucide-react';
import { CropCycle, CropSeason, AreaUnit, Language, Theme } from '../types';
import { getTranslation } from '../utils/translations';

interface AddCropModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveCrop: (cropData: Partial<CropCycle>) => void;
  lang: Language;
  theme: Theme;
  cropToEdit?: CropCycle | null;
}

const COMMON_CROPS = [
  { name: 'Wheat (गेहूं)', hindiName: 'गेहूं (Wheat)', season: 'rabi' },
  { name: 'Paddy / Rice (धान)', hindiName: 'धान (Paddy)', season: 'kharif' },
  { name: 'Mustard (सरसों)', hindiName: 'सरसों (Mustard)', season: 'rabi' },
  { name: 'Cotton (कपास)', hindiName: 'कपास (Cotton)', season: 'kharif' },
  { name: 'Sugarcane (गन्ना)', hindiName: 'गन्ना (Sugarcane)', season: 'annual' },
  { name: 'Potato (आलू)', hindiName: 'आलू (Potato)', season: 'rabi' },
  { name: 'Maize (मक्का)', hindiName: 'मक्का (Maize)', season: 'kharif' },
  { name: 'Gram / Chana (चना)', hindiName: 'चना (Gram)', season: 'rabi' },
  { name: 'Soybean (सोयाबीन)', hindiName: 'सोयाबीन (Soybean)', season: 'kharif' },
  { name: 'Vegetables (सब्जियां)', hindiName: 'सब्जियां (Vegetables)', season: 'zaid' }
];

export const AddCropModal: React.FC<AddCropModalProps> = ({
  isOpen,
  onClose,
  onSaveCrop,
  lang,
  theme,
  cropToEdit
}) => {
  const isDark = theme === 'dark';

  const [name, setName] = useState(cropToEdit?.name || '');
  const [hindiName, setHindiName] = useState(cropToEdit?.hindiName || '');
  const [variety, setVariety] = useState(cropToEdit?.variety || '');
  const [landArea, setLandArea] = useState<number | ''>(cropToEdit?.landArea ?? 2);
  const [areaUnit, setAreaUnit] = useState<AreaUnit>(cropToEdit?.areaUnit || 'acre');
  const [season, setSeason] = useState<CropSeason>(cropToEdit?.season || 'rabi');
  const [sowingDate, setSowingDate] = useState(
    cropToEdit?.sowingDate || new Date().toISOString().split('T')[0]
  );
  const [expectedHarvestDate, setExpectedHarvestDate] = useState(
    cropToEdit?.expectedHarvestDate || ''
  );
  const [targetYieldQuintal, setTargetYieldQuintal] = useState<number | ''>(
    cropToEdit?.targetYieldQuintal ?? ''
  );
  const [status, setStatus] = useState<CropCycle['status']>(cropToEdit?.status || 'active');
  const [notes, setNotes] = useState(cropToEdit?.notes || '');

  useEffect(() => {
    if (!isOpen) return;
    if (cropToEdit) {
      setName(cropToEdit.name || '');
      setHindiName(cropToEdit.hindiName || '');
      setVariety(cropToEdit.variety || '');
      setLandArea(cropToEdit.landArea ?? 2);
      setAreaUnit(cropToEdit.areaUnit || 'acre');
      setSeason(cropToEdit.season || 'rabi');
      setSowingDate(cropToEdit.sowingDate || new Date().toISOString().split('T')[0]);
      setExpectedHarvestDate(cropToEdit.expectedHarvestDate || '');
      setTargetYieldQuintal(cropToEdit.targetYieldQuintal ?? '');
      setStatus(cropToEdit.status || 'active');
      setNotes(cropToEdit.notes || '');
    } else {
      setName('');
      setHindiName('');
      setVariety('');
      setLandArea(2);
      setAreaUnit('acre');
      setSeason('rabi');
      setSowingDate(new Date().toISOString().split('T')[0]);
      setExpectedHarvestDate('');
      setTargetYieldQuintal('');
      setStatus('active');
      setNotes('');
    }
  }, [isOpen, cropToEdit]);

  if (!isOpen) return null;

  const handleQuickCropSelect = (crop: (typeof COMMON_CROPS)[0]) => {
    setName(crop.name);
    setHindiName(crop.hindiName);
    setSeason(crop.season as CropSeason);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const cleanArea = Number(landArea);
    if (!Number.isFinite(cleanArea) || cleanArea <= 0) return;

    onSaveCrop({
      name: name.trim(),
      hindiName: hindiName.trim() || name.trim(),
      variety: variety.trim(),
      landArea: Number(cleanArea.toFixed(2)),
      areaUnit,
      season,
      sowingDate,
      expectedHarvestDate: expectedHarvestDate || undefined,
      targetYieldQuintal:
        targetYieldQuintal && Number(targetYieldQuintal) > 0
          ? Number(targetYieldQuintal)
          : undefined,
      notes: notes.trim(),
      status
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-md overflow-y-auto">
      <div
        className={`w-full max-w-lg rounded-2xl border p-5 sm:p-6 shadow-2xl transition-all my-8 ${
          isDark
            ? 'bg-neutral-900 border-emerald-500/30 text-white'
            : 'bg-white border-emerald-300 text-neutral-900'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-500 flex items-center justify-center">
              <Sprout className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">
                {cropToEdit ? getTranslation(lang, 'editCrop') : getTranslation(lang, 'addCrop')}
              </h2>
              <p className="text-xs text-neutral-400">
                {lang === 'hi'
                  ? 'अपनी फसल का नाम, रकबा व बुवाई की तारीख दर्ज करें'
                  : 'Enter crop name, field area, and sowing date'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          {/* Quick suggestions */}
          {!cropToEdit && (
            <div>
              <label className="text-xs font-medium text-neutral-400 mb-1.5 block">
                {lang === 'hi' ? 'जल्दी चुनें (Quick Pick):' : 'Common Crops:'}
              </label>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pb-1">
                {COMMON_CROPS.map((crop) => (
                  <button
                    key={crop.name}
                    type="button"
                    onClick={() => handleQuickCropSelect(crop)}
                    className={`px-2.5 py-1 rounded-md text-xs font-medium border transition-colors cursor-pointer ${
                      name === crop.name
                        ? 'bg-emerald-600 text-white border-emerald-500'
                        : isDark
                        ? 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:border-emerald-500'
                        : 'bg-neutral-100 border-neutral-300 text-neutral-700 hover:border-emerald-500'
                    }`}
                  >
                    {lang === 'hi' ? crop.hindiName : crop.name.split(' (')[0]}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Crop Name & Variety */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'cropName')} *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (!hindiName) setHindiName(e.target.value);
                }}
                placeholder={lang === 'hi' ? 'उदा. गेहूं, सरसों, धान' : 'e.g. Wheat, Mustard'}
                className={`w-full px-3 py-2 rounded-xl text-sm border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'cropVariety')}
              </label>
              <input
                type="text"
                value={variety}
                onChange={(e) => setVariety(e.target.value)}
                placeholder={lang === 'hi' ? 'उदा. HD 2967, पायनियर 45S46' : 'e.g. HD 2967'}
                className={`w-full px-3 py-2 rounded-xl text-sm border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>
          </div>

          {/* Land Area & Unit */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'landArea')} *
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  required
                  value={landArea}
                  onChange={(e) => setLandArea(e.target.value === '' ? '' : parseFloat(e.target.value))}
                  placeholder="2.5"
                  className={`w-full px-3 py-2 rounded-xl text-sm border font-mono tabular-nums focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                    isDark
                      ? 'bg-neutral-800 border-neutral-700 text-white'
                      : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'areaUnit')}
              </label>
              <select
                value={areaUnit}
                onChange={(e) => setAreaUnit(e.target.value as AreaUnit)}
                className={`w-full px-3 py-2 rounded-xl text-sm border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              >
                <option value="acre">{getTranslation(lang, 'acre')}</option>
                <option value="bigha">{getTranslation(lang, 'bigha')}</option>
                <option value="hectare">{getTranslation(lang, 'hectare')}</option>
                <option value="kanal">{getTranslation(lang, 'kanal')}</option>
                <option value="marla">{getTranslation(lang, 'marla')}</option>
                <option value="guntha">{getTranslation(lang, 'guntha')}</option>
              </select>
            </div>
          </div>

          {/* Season & Sowing Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'season')}
              </label>
              <select
                value={season}
                onChange={(e) => setSeason(e.target.value as CropSeason)}
                className={`w-full px-3 py-2 rounded-xl text-sm border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              >
                <option value="rabi">रबी (Rabi - गेहूं/सरसों/चना)</option>
                <option value="kharif">खरीफ (Kharif - धान/कपास/बाजरा)</option>
                <option value="zaid">जायद (Zaid - तरबूज/सब्जियां)</option>
                <option value="annual">वार्षिक (Annual - गन्ना)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'sowingDate')} *
              </label>
              <input
                type="date"
                required
                value={sowingDate}
                onChange={(e) => setSowingDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-sm border font-mono tabular-nums focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>
          </div>

          {/* Expected Harvest, Target Yield & Status */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'harvestDate')}
              </label>
              <input
                type="date"
                value={expectedHarvestDate}
                onChange={(e) => setExpectedHarvestDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-sm border font-mono tabular-nums focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'targetYield')}
              </label>
              <input
                type="number"
                step="0.5"
                min="0"
                value={targetYieldQuintal}
                onChange={(e) => setTargetYieldQuintal(e.target.value === '' ? '' : parseFloat(e.target.value))}
                placeholder={lang === 'hi' ? 'उदा. 50' : 'e.g. 50'}
                className={`w-full px-3 py-2 rounded-xl text-sm border font-mono tabular-nums focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'status')}
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as CropCycle['status'])}
                className={`w-full px-3 py-2 rounded-xl text-sm border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              >
                <option value="active">{getTranslation(lang, 'active')}</option>
                <option value="harvested">{getTranslation(lang, 'harvested')}</option>
                <option value="archived">{getTranslation(lang, 'archived')}</option>
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1">
              {getTranslation(lang, 'notes')}
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={
                lang === 'hi'
                  ? 'खेत का स्थान, मिट्टी की किस्म, या विशेष याद रखने वाली बात...'
                  : 'Field location, soil details, or special notes...'
              }
              className={`w-full px-3 py-2 rounded-xl text-sm border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden resize-none ${
                isDark
                  ? 'bg-neutral-800 border-neutral-700 text-white'
                  : 'bg-neutral-50 border-neutral-300 text-neutral-900'
              }`}
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-200 dark:border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-sm font-semibold text-neutral-400 hover:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className="btn-3d-primary px-6 py-2.5 rounded-xl text-white font-bold text-sm cursor-pointer shadow-lg"
            >
              {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
