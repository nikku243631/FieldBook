import React, { useState, useEffect } from 'react';
import { X, Sprout, Calendar, MapPin, Tag, Sparkles, FileText } from 'lucide-react';
import { CropCycle, CropSeason, AreaUnit, Language, Theme } from '../types';
import { getTranslation } from '../utils/translations';

interface AddCropModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveCrop: (cropData: Partial<CropCycle>) => void;
  lang: Language;
  theme: Theme;
  cropToEdit?: CropCycle | null;
}

const COMMON_CROPS = [
  { name: 'Wheat (गेहूं)', hindiName: 'गेहूं (Wheat)', season: 'rabi', icon: '🌾' },
  { name: 'Paddy / Rice (धान)', hindiName: 'धान (Paddy)', season: 'kharif', icon: '🌱' },
  { name: 'Mustard (सरसों)', hindiName: 'सरसों (Mustard)', season: 'rabi', icon: '🌼' },
  { name: 'Cotton (कपास)', hindiName: 'कपास (Cotton)', season: 'kharif', icon: '☁️' },
  { name: 'Sugarcane (गन्ना)', hindiName: 'गन्ना (Sugarcane)', season: 'annual', icon: '🎋' },
  { name: 'Potato (आलू)', hindiName: 'आलू (Potato)', season: 'rabi', icon: '🥔' },
  { name: 'Maize (मक्का)', hindiName: 'मक्का (Maize)', season: 'kharif', icon: '🌽' },
  { name: 'Gram / Chana (चना)', hindiName: 'चना (Gram)', season: 'rabi', icon: '🫘' },
  { name: 'Soybean (सोयाबीन)', hindiName: 'सोयाबीन (Soybean)', season: 'kharif', icon: '🌿' },
  { name: 'Vegetables (सब्जियां)', hindiName: 'सब्जियां (Vegetables)', season: 'zaid', icon: '🌶️' }
];

export const AddCropModal: React.FC<AddCropModalProps> = ({
  isOpen,
  onClose,
  onSaveCrop,
  lang,
  cropToEdit
}) => {
  const [name, setName] = useState(cropToEdit?.name || '');
  const [hindiName, setHindiName] = useState(cropToEdit?.hindiName || '');
  const [variety, setVariety] = useState(cropToEdit?.variety || '');
  const [landArea, setLandArea] = useState<number | ''>(cropToEdit?.landArea ?? 2);
  const [areaUnit, setAreaUnit] = useState<AreaUnit>(cropToEdit?.areaUnit || 'acre');
  const [season, setSeason] = useState<CropSeason>(cropToEdit?.season || 'rabi');
  const [sowingDate, setSowingDate] = useState(
    cropToEdit?.sowingDate || new Date().toISOString().split('T')[0]
  );
  const [expectedHarvestDate, setExpectedHarvestDate] = useState(
    cropToEdit?.expectedHarvestDate || ''
  );
  const [targetYieldQuintal, setTargetYieldQuintal] = useState<number | ''>(
    cropToEdit?.targetYieldQuintal ?? ''
  );
  const [status, setStatus] = useState<CropCycle['status']>(cropToEdit?.status || 'active');
  const [notes, setNotes] = useState(cropToEdit?.notes || '');

  useEffect(() => {
    if (!isOpen) return;
    if (cropToEdit) {
      setName(cropToEdit.name || '');
      setHindiName(cropToEdit.hindiName || '');
      setVariety(cropToEdit.variety || '');
      setLandArea(cropToEdit.landArea ?? 2);
      setAreaUnit(cropToEdit.areaUnit || 'acre');
      setSeason(cropToEdit.season || 'rabi');
      setSowingDate(cropToEdit.sowingDate || new Date().toISOString().split('T')[0]);
      setExpectedHarvestDate(cropToEdit.expectedHarvestDate || '');
      setTargetYieldQuintal(cropToEdit.targetYieldQuintal ?? '');
      setStatus(cropToEdit.status || 'active');
      setNotes(cropToEdit.notes || '');
    } else {
      setName('');
      setHindiName('');
      setVariety('');
      setLandArea(2);
      setAreaUnit('acre');
      setSeason('rabi');
      setSowingDate(new Date().toISOString().split('T')[0]);
      setExpectedHarvestDate('');
      setTargetYieldQuintal('');
      setStatus('active');
      setNotes('');
    }
  }, [isOpen, cropToEdit]);

  if (!isOpen) return null;

  const handleQuickCropSelect = (crop: (typeof COMMON_CROPS)[0]) => {
    setName(crop.name);
    setHindiName(crop.hindiName);
    setSeason(crop.season as CropSeason);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const cleanArea = Number(landArea);
    if (!Number.isFinite(cleanArea) || cleanArea <= 0) return;

    onSaveCrop({
      name: name.trim(),
      hindiName: hindiName.trim() || name.trim(),
      variety: variety.trim(),
      landArea: Number(cleanArea.toFixed(2)),
      areaUnit,
      season,
      sowingDate,
      expectedHarvestDate: expectedHarvestDate || undefined,
      targetYieldQuintal:
        targetYieldQuintal && Number(targetYieldQuintal) > 0
          ? Number(targetYieldQuintal)
          : undefined,
      notes: notes.trim(),
      status
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/60 backdrop-blur-md overflow-y-auto">
      <div className="liquid-glass-modal w-full max-w-lg rounded-3xl p-4 sm:p-5 my-4 max-h-[92vh] overflow-y-auto">
        {/* 3D Liquid Glass Header Banner */}
        <div className="flex items-center justify-between pb-3.5 mb-3.5 border-b-2 border-emerald-500/30">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl liquid-glass-emerald flex items-center justify-center text-white shrink-0">
              <Sprout className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-950 dark:text-white leading-tight">
                {cropToEdit ? getTranslation(lang, 'editCrop') : getTranslation(lang, 'addCrop')}
              </h2>
              <p className="text-xs font-bold text-emerald-900 dark:text-emerald-300">
                {lang === 'hi'
                  ? '✍️ नीचे दिए गए रंगीन बॉक्स में फसल का विवरण भरें'
                  : '✍️ Fill crop details in the 3D boxes below'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* Quick Pick Suggestions */}
          {!cropToEdit && (
            <div className="liquid-glass-income rounded-2xl p-3">
              <label className="text-xs font-extrabold text-emerald-950 dark:text-emerald-200 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-300" />
                <span>
                  {lang === 'hi'
                    ? 'जल्दी चुनें (1 टैप में फसल चुनें):'
                    : 'Quick Pick Common Crop (1-Tap):'}
                </span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {COMMON_CROPS.map((crop) => {
                  const isSelected = name === crop.name;
                  return (
                    <button
                      key={crop.name}
                      type="button"
                      onClick={() => handleQuickCropSelect(crop)}
                      className={`px-3 py-1.5 rounded-full text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1 ${
                        isSelected
                          ? 'liquid-glass-emerald text-white scale-105'
                          : 'bg-white/90 dark:bg-slate-900/90 border-2 border-emerald-500/70 text-slate-950 dark:text-white shadow-xs hover:bg-emerald-50'
                      }`}
                    >
                      <span>{crop.icon}</span>
                      <span>{lang === 'hi' ? crop.hindiName : crop.name.split(' (')[0]}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Section 1: Crop Name & Variety (Emerald & Sky 3D Glass Card) */}
          <div className="liquid-glass-profit rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5 mb-1.5">
                  <Sprout className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                  <span>{getTranslation(lang, 'cropName')} *</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (!hindiName) setHindiName(e.target.value);
                  }}
                  placeholder={lang === 'hi' ? 'यहां फसल का नाम लिखें (जैसे: गेहूं, मिर्च)' : 'Type crop name (e.g. Wheat)'}
                  className="liquid-glass-input w-full px-3.5 py-2.5 rounded-xl text-sm font-bold text-slate-950 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5 mb-1.5">
                  <Tag className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400" />
                  <span>{getTranslation(lang, 'cropVariety')}</span>
                </label>
                <input
                  type="text"
                  value={variety}
                  onChange={(e) => setVariety(e.target.value)}
                  placeholder={lang === 'hi' ? 'किस्म लिखें (जैसे: HD 2967)' : 'Type variety (e.g. HD 2967)'}
                  className="input-3d-sky w-full px-3.5 py-2.5 rounded-xl text-sm font-bold text-slate-950 dark:text-white"
                />
              </div>
            </div>

            {/* Land Area & Area Unit */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-amber-950 dark:text-amber-300 flex items-center gap-1 mb-1.5">
                  <MapPin className="w-3.5 h-3.5 text-amber-700 dark:text-amber-400" />
                  <span>{getTranslation(lang, 'landArea')} *</span>
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  required
                  value={landArea}
                  onChange={(e) =>
                    setLandArea(e.target.value === '' ? '' : parseFloat(e.target.value))
                  }
                  placeholder="2.5"
                  className="input-3d-amber w-full px-3.5 py-2.5 rounded-xl text-sm font-mono font-extrabold tabular-nums text-slate-950 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-amber-950 dark:text-amber-300 block mb-1.5">
                  📐 {getTranslation(lang, 'areaUnit')}
                </label>
                <select
                  value={areaUnit}
                  onChange={(e) => setAreaUnit(e.target.value as AreaUnit)}
                  className="input-3d-amber w-full px-3 py-2.5 rounded-xl text-sm font-extrabold text-slate-950 dark:text-white"
                >
                  <option value="acre">{getTranslation(lang, 'acre')}</option>
                  <option value="bigha">{getTranslation(lang, 'bigha')}</option>
                  <option value="hectare">{getTranslation(lang, 'hectare')}</option>
                  <option value="kanal">{getTranslation(lang, 'kanal')}</option>
                  <option value="marla">{getTranslation(lang, 'marla')}</option>
                  <option value="guntha">{getTranslation(lang, 'guntha')}</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 2: Season, Sowing Date, Expected Harvest, Target Yield & Status */}
          <div className="liquid-glass-income rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-emerald-950 dark:text-emerald-200 block mb-1.5">
                  🌤️ {getTranslation(lang, 'season')}
                </label>
                <select
                  value={season}
                  onChange={(e) => setSeason(e.target.value as CropSeason)}
                  className="liquid-glass-input w-full px-3 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white"
                >
                  <option value="rabi">रबी (Rabi - गेहूं/सरसों/चना)</option>
                  <option value="kharif">खरीफ (Kharif - धान/कपास/बाजरा)</option>
                  <option value="zaid">जायद (Zaid - तरबूज/सब्जियां)</option>
                  <option value="annual">वार्षिक (Annual - गन्ना)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-extrabold text-emerald-950 dark:text-emerald-200 flex items-center gap-1 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{getTranslation(lang, 'sowingDate')} *</span>
                </label>
                <input
                  type="date"
                  required
                  value={sowingDate}
                  onChange={(e) => setSowingDate(e.target.value)}
                  className="liquid-glass-input w-full px-3 py-2.5 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums text-slate-950 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  📅 {getTranslation(lang, 'harvestDate')}
                </label>
                <input
                  type="date"
                  value={expectedHarvestDate}
                  onChange={(e) => setExpectedHarvestDate(e.target.value)}
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-bold tabular-nums text-slate-950 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  🎯 {getTranslation(lang, 'targetYield')}
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  value={targetYieldQuintal}
                  onChange={(e) =>
                    setTargetYieldQuintal(e.target.value === '' ? '' : parseFloat(e.target.value))
                  }
                  placeholder={lang === 'hi' ? 'उदा. 50 क्विंटल' : 'e.g. 50'}
                  className="input-3d-amber w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums text-slate-950 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  📌 {getTranslation(lang, 'status')}
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as CropCycle['status'])}
                  className="liquid-glass-input w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white"
                >
                  <option value="active">{getTranslation(lang, 'active')}</option>
                  <option value="harvested">{getTranslation(lang, 'harvested')}</option>
                  <option value="archived">{getTranslation(lang, 'archived')}</option>
                </select>
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="liquid-glass-profit rounded-2xl p-3">
            <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5 mb-1.5">
              <FileText className="w-3.5 h-3.5 text-blue-700" />
              <span>{getTranslation(lang, 'notes')}</span>
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={
                lang === 'hi'
                  ? 'खेत का नाम/स्थान, मिट्टी की किस्म, या विशेष नोट यहां लिखें...'
                  : 'Type field location, soil details, or special notes here...'
              }
              className="input-3d-sky w-full px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold text-slate-950 dark:text-white resize-none"
            />
          </div>

          {/* Bottom 3D Liquid Glass Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="liquid-glass-pill px-5 py-2.5 rounded-full text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className="liquid-glass-emerald px-6 py-2.5 rounded-full text-white font-extrabold text-xs sm:text-sm cursor-pointer shadow-md"
            >
              ✓ {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
