import React, { useState, useEffect } from 'react';
import {
  Calculator as CalcIcon,
  RotateCcw,
  Copy,
  Check,
  Share2,
  FileText,
  Clock,
  Trash2,
  Sparkles,
  Volume2,
  VolumeX
} from 'lucide-react';
import { Language, Theme } from '../types';
import { Storage } from '../utils/storage';
import { shareViaWhatsApp } from '../utils/export';

interface SimpleCalculatorProps {
  lang: Language;
  theme: Theme;
  onSendToNotes?: (calcText: string) => void;
  isModal?: boolean;
  onClose?: () => void;
}

export const SimpleCalculator: React.FC<SimpleCalculatorProps> = ({
  lang,
  theme,
  onSendToNotes,
  isModal = false,
  onClose
}) => {
  const isHindi = lang === 'hi';
  const isDark = theme === 'dark';

  const [expression, setExpression] = useState<string>('');
  const [currentVal, setCurrentVal] = useState<string>('0');
  const [isNewNumber, setIsNewNumber] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(false);
  const [history, setHistory] = useState<{ id: string; expression: string; result: string; timestamp: string }[]>(
    () => Storage.getCalcHistory()
  );

  const playClick = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.05);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.05);
    } catch {}
  };

  const safeEvaluate = (expr: string): number | null => {
    try {
      const sanitized = expr
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/[^0-9+\-*/.()%]/g, '');

      if (!sanitized) return null;

      const processed = sanitized.replace(/([0-9.]+)%/g, '($1/100)');

      // eslint-disable-next-line @typescript-eslint/no-implied-eval
      const result = new Function(`return ${processed}`)();
      if (typeof result === 'number' && !isNaN(result) && isFinite(result)) {
        return result;
      }
      return null;
    } catch {
      return null;
    }
  };

  const handleDigit = (digit: string) => {
    playClick();
    if (isNewNumber) {
      if (digit === '.') {
        setCurrentVal('0.');
      } else {
        setCurrentVal(digit);
      }
      setIsNewNumber(false);
    } else {
      if (digit === '.' && currentVal.includes('.')) return;
      if (currentVal === '0' && digit !== '.') {
        setCurrentVal(digit);
      } else {
        setCurrentVal(currentVal + digit);
      }
    }
  };

  const handleDoubleZero = () => {
    playClick();
    if (isNewNumber || currentVal === '0') {
      setCurrentVal('0');
      setIsNewNumber(false);
    } else {
      setCurrentVal(currentVal + '00');
    }
  };

  const handleOperator = (op: string) => {
    playClick();
    const symbol = op === '*' ? '×' : op === '/' ? '÷' : op;

    if (expression && !isNewNumber) {
      const full = `${expression} ${currentVal}`;
      const res = safeEvaluate(full);
      if (res !== null) {
        const rounded = Number(res.toFixed(4));
        setExpression(`${rounded} ${symbol}`);
        setCurrentVal(String(rounded));
        setIsNewNumber(true);
        return;
      }
    }

    setExpression(`${currentVal} ${symbol}`);
    setIsNewNumber(true);
  };

  const handleEquals = () => {
    playClick();
    if (!expression) return;
    const fullExpr = `${expression} ${currentVal}`;
    const result = safeEvaluate(fullExpr);

    if (result !== null) {
      const rounded = Number(result.toFixed(4));
      const formattedResult = rounded.toLocaleString('en-IN');
      const now = new Date();
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      const dateStr = now.toLocaleDateString(isHindi ? 'hi-IN' : 'en-IN', { day: 'numeric', month: 'short' });

      const newHistoryItem = {
        id: `calc-${Date.now()}`,
        expression: fullExpr,
        result: formattedResult,
        timestamp: `${dateStr}, ${timeStr}`
      };

      const updatedHistory = [newHistoryItem, ...history.slice(0, 49)];
      setHistory(updatedHistory);
      Storage.saveCalcHistory(updatedHistory);

      setExpression(`${fullExpr} =`);
      setCurrentVal(String(rounded));
      setIsNewNumber(true);
    } else {
      setCurrentVal('Error');
      setIsNewNumber(true);
    }
  };

  const handleClear = () => {
    playClick();
    setCurrentVal('0');
    setExpression('');
    setIsNewNumber(true);
  };

  const handleBackspace = () => {
    playClick();
    if (isNewNumber) {
      setCurrentVal('0');
      return;
    }
    if (currentVal.length <= 1) {
      setCurrentVal('0');
      setIsNewNumber(true);
    } else {
      setCurrentVal(currentVal.slice(0, -1));
    }
  };

  const handleToggleSign = () => {
    playClick();
    if (currentVal === '0') return;
    if (currentVal.startsWith('-')) {
      setCurrentVal(currentVal.substring(1));
    } else {
      setCurrentVal('-' + currentVal);
    }
  };

  const handlePercentage = () => {
    playClick();
    const val = parseFloat(currentVal);
    if (!isNaN(val)) {
      const res = val / 100;
      setCurrentVal(String(res));
      setIsNewNumber(true);
    }
  };

  const applyFarmShortcut = (type: 'addGst' | 'subGst' | 'toQuintal' | 'toKg' | 'toMann' | 'fromMann') => {
    playClick();
    const val = parseFloat(currentVal);
    if (isNaN(val)) return;

    let res = val;
    let label = '';

    switch (type) {
      case 'addGst':
        res = val * 1.18;
        label = `${val} + 18% GST`;
        break;
      case 'subGst':
        res = val / 1.18;
        label = `${val} - 18% GST`;
        break;
      case 'toQuintal':
        res = val / 100;
        label = `${val} kg ÷ 100 = क्विंटल`;
        break;
      case 'toKg':
        res = val * 100;
        label = `${val} क्विंटल × 100 = kg`;
        break;
      case 'toMann':
        res = val / 40;
        label = `${val} kg ÷ 40 = मन (Mann)`;
        break;
      case 'fromMann':
        res = val * 40;
        label = `${val} मन × 40 = kg`;
        break;
    }

    const rounded = Number(res.toFixed(3));
    setExpression(label);
    setCurrentVal(String(rounded));
    setIsNewNumber(true);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(currentVal);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareWhatsApp = () => {
    const text = `*FieldBook हिसाब गणना*\n${expression ? expression + '\n' : ''}कुल रकम: ₹${currentVal}\n(तैयार: FieldBook - Mr Nikhil)`;
    shareViaWhatsApp(text);
  };

  const handleSaveToNotesAction = () => {
    const noteText = `कैलकुलेटर हिसाब:\n${expression ? expression + ' = ' : ''}₹${currentVal}\nतारीख: ${new Date().toLocaleString()}`;
    if (onSendToNotes) {
      onSendToNotes(noteText);
    } else {
      const existing = Storage.getNotes();
      const newNote = {
        id: `note-${Date.now()}`,
        title: `हिसाब: ₹${currentVal}`,
        content: noteText,
        category: 'payment' as const,
        isPinned: false,
        date: new Date().toISOString().split('T')[0],
        time: new Date().toTimeString().slice(0, 5),
        color: 'emerald',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      Storage.saveNotes([newNote, ...existing]);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleClearHistory = () => {
    setHistory([]);
    Storage.saveCalcHistory([]);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(e.key)) {
        handleDigit(e.key);
      } else if (e.key === '.') {
        handleDigit('.');
      } else if (e.key === '+') {
        handleOperator('+');
      } else if (e.key === '-') {
        handleOperator('-');
      } else if (e.key === '*' || e.key === 'x') {
        handleOperator('*');
      } else if (e.key === '/') {
        e.preventDefault();
        handleOperator('/');
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (e.key === 'Backspace') {
        handleBackspace();
      } else if (e.key === 'Escape') {
        if (isModal && onClose) onClose();
        else handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentVal, expression, isNewNumber]);

  return (
    <div
      className={`relative w-full max-w-md mx-auto rounded-2xl border overflow-hidden shadow-xl transition-all ${
        isDark
          ? 'bg-slate-900 border-slate-800 text-slate-100'
          : 'bg-white border-slate-200 text-slate-900'
      }`}
    >
      {/* Top Header */}
      <div
        className={`flex items-center justify-between px-4 py-3 border-b ${
          isDark ? 'border-slate-800 bg-slate-800/60' : 'border-slate-200 bg-slate-50'
        }`}
      >
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white shadow-xs">
            <CalcIcon className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold tracking-tight">
              {isHindi ? 'डिजिटल हिसाब कैलकुलेटर' : 'Field Digital Calculator'}
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {isHindi ? 'साधारण व सटीक जोड़-घटाव' : 'Simple & accurate arithmetic'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
              soundEnabled
                ? 'bg-emerald-600 text-white border-emerald-700'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-700'
            }`}
            title={soundEnabled ? 'Click sound on' : 'Click sound off'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          <button
            type="button"
            onClick={() => setShowHistory(!showHistory)}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
              showHistory
                ? 'bg-emerald-600 text-white border-emerald-700'
                : 'bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{isHindi ? 'इतिहास' : 'History'}</span>
          </button>

          {isModal && onClose && (
            <button
              type="button"
              onClick={onClose}
              className="px-2 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 hover:bg-rose-100 text-xs font-bold cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* History Tape Drawer */}
      {showHistory ? (
        <div className="p-4 max-h-[360px] overflow-y-auto space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
            <span className="text-xs font-bold">
              {isHindi ? 'पिछली गणनाएं (Calculation Tape)' : 'Past Calculations'}
            </span>
            {history.length > 0 && (
              <button
                type="button"
                onClick={handleClearHistory}
                className="text-[11px] font-semibold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/50 px-2 py-1 rounded-md border border-rose-200 dark:border-rose-800 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
                <span>{isHindi ? 'मिटाएं' : 'Clear'}</span>
              </button>
            )}
          </div>

          {history.length === 0 ? (
            <div className="text-center py-8 text-slate-500 text-xs">
              {isHindi ? 'कोई पुराना हिसाब नहीं है' : 'No previous calculations yet'}
            </div>
          ) : (
            history.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  setCurrentVal(item.result.replace(/,/g, ''));
                  setExpression(item.expression);
                  setShowHistory(false);
                }}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-left cursor-pointer transition-all hover:border-emerald-400"
              >
                <div className="flex justify-between items-center text-[11px] text-slate-500 mb-0.5">
                  <span className="font-mono">{item.timestamp}</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold">टैप कर लोड करें</span>
                </div>
                <div className="text-xs font-mono text-slate-600 dark:text-slate-300 truncate">{item.expression}</div>
                <div className="text-base font-bold text-emerald-700 dark:text-emerald-400 font-mono">₹ {item.result}</div>
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="p-3.5 space-y-3">
          {/* LCD Digital Display */}
          <div className="rounded-xl p-3.5 border border-emerald-200 dark:border-emerald-800/70 bg-emerald-50/70 dark:bg-emerald-950/30 relative">
            <div className="h-5 flex items-center justify-end text-xs font-mono font-medium text-slate-600 dark:text-slate-400 overflow-x-auto whitespace-nowrap">
              {expression || <span className="opacity-0">0</span>}
            </div>

            <div className="flex items-baseline justify-between gap-2 mt-0.5">
              <span className="text-base font-bold text-emerald-700 dark:text-emerald-400 select-none">₹</span>
              <div
                className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-slate-900 dark:text-white text-right overflow-x-auto scrollbar-none select-all w-full"
                style={{ direction: 'ltr' }}
              >
                {currentVal}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-1.5 pt-2.5 mt-2.5 border-t border-emerald-200/80 dark:border-emerald-800/60 text-[11px]">
              <span className="text-slate-600 dark:text-slate-400 font-medium">
                {isHindi ? 'शेयर / सेव:' : 'Save/Share:'}
              </span>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleCopy}
                  className="px-2 py-1 rounded-lg bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 text-[11px] font-semibold flex items-center gap-1 cursor-pointer"
                  title="Copy result"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? (isHindi ? 'कॉपी हुआ' : 'Copied') : (isHindi ? 'कॉपी' : 'Copy')}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveToNotesAction}
                  className="px-2 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800 text-[11px] font-semibold flex items-center gap-1 cursor-pointer"
                  title="Save to Farm Notes"
                >
                  <FileText className="w-3 h-3" />
                  <span>{isHindi ? 'नोट्स' : 'Note'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleShareWhatsApp}
                  className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold flex items-center gap-1 cursor-pointer"
                  title="Share on WhatsApp"
                >
                  <Share2 className="w-3 h-3" />
                  <span>WhatsApp</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick Agricultural Conversions Strip */}
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-600 dark:text-slate-400">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isHindi ? 'कृषि व मंडी शॉर्टकट' : 'Agri Quick Math'}:</span>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
              <button
                type="button"
                onClick={() => applyFarmShortcut('addGst')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-semibold bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 cursor-pointer"
              >
                +18% GST
              </button>
              <button
                type="button"
                onClick={() => applyFarmShortcut('subGst')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-semibold bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 cursor-pointer"
              >
                -18% GST
              </button>
              <button
                type="button"
                onClick={() => applyFarmShortcut('toQuintal')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-semibold bg-amber-50 dark:bg-amber-950/50 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 cursor-pointer"
              >
                ÷100 (क्विं.)
              </button>
              <button
                type="button"
                onClick={() => applyFarmShortcut('toKg')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-semibold bg-amber-50 dark:bg-amber-950/50 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 cursor-pointer"
              >
                ×100 (kg)
              </button>
              <button
                type="button"
                onClick={() => applyFarmShortcut('toMann')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-semibold bg-blue-50 dark:bg-blue-950/50 border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-300 cursor-pointer"
              >
                ÷40 (मन)
              </button>
              <button
                type="button"
                onClick={() => applyFarmShortcut('fromMann')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-semibold bg-blue-50 dark:bg-blue-950/50 border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-300 cursor-pointer"
              >
                ×40 (मन→kg)
              </button>
            </div>
          </div>

          {/* Calculator Keypad Grid — Compact, Clean & Distinct Colors */}
          <div className="grid grid-cols-4 gap-1.5 text-base font-bold font-mono">
            <button
              type="button"
              onClick={handleClear}
              className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 active:scale-95 transition-all cursor-pointer"
            >
              AC
            </button>
            <button
              type="button"
              onClick={handleBackspace}
              className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 active:scale-95 transition-all cursor-pointer flex items-center justify-center"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handlePercentage}
              className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 active:scale-95 transition-all cursor-pointer"
            >
              %
            </button>
            <button
              type="button"
              onClick={() => handleOperator('/')}
              className="p-2.5 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 active:scale-95 transition-all cursor-pointer"
            >
              ÷
            </button>

            {['7', '8', '9'].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => handleDigit(d)}
                className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 active:scale-95 transition-all cursor-pointer"
              >
                {d}
              </button>
            ))}
            <button
              type="button"
              onClick={() => handleOperator('*')}
              className="p-2.5 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 active:scale-95 transition-all cursor-pointer"
            >
              ×
            </button>

            {['4', '5', '6'].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => handleDigit(d)}
                className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 active:scale-95 transition-all cursor-pointer"
              >
                {d}
              </button>
            ))}
            <button
              type="button"
              onClick={() => handleOperator('-')}
              className="p-2.5 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 active:scale-95 transition-all cursor-pointer"
            >
              -
            </button>

            {['1', '2', '3'].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => handleDigit(d)}
                className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 active:scale-95 transition-all cursor-pointer"
              >
                {d}
              </button>
            ))}
            <button
              type="button"
              onClick={() => handleOperator('+')}
              className="p-2.5 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 active:scale-95 transition-all cursor-pointer"
            >
              +
            </button>

            <button
              type="button"
              onClick={handleToggleSign}
              className="p-2.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-600 active:scale-95 transition-all cursor-pointer text-xs"
            >
              +/-
            </button>
            <button
              type="button"
              onClick={() => handleDigit('0')}
              className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 active:scale-95 transition-all cursor-pointer"
            >
              0
            </button>
            <button
              type="button"
              onClick={handleDoubleZero}
              className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 active:scale-95 transition-all cursor-pointer text-sm"
            >
              00
            </button>
            <button
              type="button"
              onClick={() => handleDigit('.')}
              className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 active:scale-95 transition-all cursor-pointer"
            >
              .
            </button>

            <button
              type="button"
              onClick={handleEquals}
              className="col-span-4 py-2.5 px-4 rounded-xl btn-3d-primary text-white font-semibold text-sm shadow-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>=</span>
              <span className="font-sans">
                {isHindi ? 'जोड़ें / परिणाम निकालें' : 'Calculate'}
              </span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
