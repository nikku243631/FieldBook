import React, { useState, useEffect } from 'react';
import {
  Calculator as CalcIcon,
  RotateCcw,
  Copy,
  Check,
  Share2,
  FileText,
  Clock,
  Trash2,
  Sparkles,
  Volume2,
  VolumeX
} from 'lucide-react';
import { Language, Theme } from '../types';
import { Storage } from '../utils/storage';

interface SimpleCalculatorProps {
  lang: Language;
  theme: Theme;
  onSendToNotes?: (calcText: string) => void;
  isModal?: boolean;
  onClose?: () => void;
}

export const SimpleCalculator: React.FC<SimpleCalculatorProps> = ({
  lang,
  theme,
  onSendToNotes,
  isModal = false,
  onClose
}) => {
  const isDark = theme === 'dark';
  const isHindi = lang === 'hi';

  const [expression, setExpression] = useState<string>('');
  const [currentVal, setCurrentVal] = useState<string>('0');
  const [isNewNumber, setIsNewNumber] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(false);
  const [history, setHistory] = useState<{ id: string; expression: string; result: string; timestamp: string }[]>(
    () => Storage.getCalcHistory()
  );

  const playClick = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.05);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.05);
    } catch {}
  };

  const safeEvaluate = (expr: string): number | null => {
    try {
      // Clean and sanitize expression: only allow numbers and operators
      const sanitized = expr
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/[^0-9+\-*/.()%]/g, '');

      if (!sanitized) return null;

      // Handle percentage: e.g. 500 * 18% -> 500 * 0.18
      const processed = sanitized.replace(/([0-9.]+)%/g, '($1/100)');

      // Safe Function evaluation
      // eslint-disable-next-line @typescript-eslint/no-implied-eval
      const result = new Function(`return ${processed}`)();
      if (typeof result === 'number' && !isNaN(result) && isFinite(result)) {
        return result;
      }
      return null;
    } catch {
      return null;
    }
  };

  const handleDigit = (digit: string) => {
    playClick();
    if (isNewNumber) {
      if (digit === '.') {
        setCurrentVal('0.');
      } else {
        setCurrentVal(digit);
      }
      setIsNewNumber(false);
    } else {
      if (digit === '.' && currentVal.includes('.')) return;
      if (currentVal === '0' && digit !== '.') {
        setCurrentVal(digit);
      } else {
        setCurrentVal(currentVal + digit);
      }
    }
  };

  const handleDoubleZero = () => {
    playClick();
    if (isNewNumber || currentVal === '0') {
      setCurrentVal('0');
      setIsNewNumber(false);
    } else {
      setCurrentVal(currentVal + '00');
    }
  };

  const handleOperator = (op: string) => {
    playClick();
    const symbol = op === '*' ? '×' : op === '/' ? '÷' : op;
    
    if (expression && !isNewNumber) {
      // Evaluate progressive
      const full = `${expression} ${currentVal}`;
      const res = safeEvaluate(full);
      if (res !== null) {
        const rounded = Number(res.toFixed(4));
        setExpression(`${rounded} ${symbol}`);
        setCurrentVal(String(rounded));
        setIsNewNumber(true);
        return;
      }
    }

    setExpression(`${currentVal} ${symbol}`);
    setIsNewNumber(true);
  };

  const handleEquals = () => {
    playClick();
    if (!expression) return;
    const fullExpr = `${expression} ${currentVal}`;
    const result = safeEvaluate(fullExpr);

    if (result !== null) {
      const rounded = Number(result.toFixed(4));
      const formattedResult = rounded.toLocaleString('en-IN');
      const now = new Date();
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      const dateStr = now.toLocaleDateString(isHindi ? 'hi-IN' : 'en-IN', { day: 'numeric', month: 'short' });
      
      const newHistoryItem = {
        id: `calc-${Date.now()}`,
        expression: fullExpr,
        result: formattedResult,
        timestamp: `${dateStr}, ${timeStr}`
      };

      const updatedHistory = [newHistoryItem, ...history.slice(0, 49)];
      setHistory(updatedHistory);
      Storage.saveCalcHistory(updatedHistory);

      setExpression(`${fullExpr} =`);
      setCurrentVal(String(rounded));
      setIsNewNumber(true);
    } else {
      setCurrentVal('Error');
      setIsNewNumber(true);
    }
  };

  const handleClear = () => {
    playClick();
    setCurrentVal('0');
    setExpression('');
    setIsNewNumber(true);
  };

  const handleBackspace = () => {
    playClick();
    if (isNewNumber) {
      setCurrentVal('0');
      return;
    }
    if (currentVal.length <= 1) {
      setCurrentVal('0');
      setIsNewNumber(true);
    } else {
      setCurrentVal(currentVal.slice(0, -1));
    }
  };

  const handleToggleSign = () => {
    playClick();
    if (currentVal === '0') return;
    if (currentVal.startsWith('-')) {
      setCurrentVal(currentVal.substring(1));
    } else {
      setCurrentVal('-' + currentVal);
    }
  };

  const handlePercentage = () => {
    playClick();
    const val = parseFloat(currentVal);
    if (!isNaN(val)) {
      const res = val / 100;
      setCurrentVal(String(res));
      setIsNewNumber(true);
    }
  };

  // Quick Agricultural Shortcuts
  const applyFarmShortcut = (type: 'addGst' | 'subGst' | 'toQuintal' | 'toKg' | 'toMann' | 'fromMann') => {
    playClick();
    const val = parseFloat(currentVal);
    if (isNaN(val)) return;

    let res = val;
    let label = '';

    switch (type) {
      case 'addGst':
        res = val * 1.18;
        label = `${val} + 18% GST`;
        break;
      case 'subGst':
        res = val / 1.18;
        label = `${val} - 18% GST`;
        break;
      case 'toQuintal':
        res = val / 100;
        label = `${val} kg ÷ 100 = क्विंटल`;
        break;
      case 'toKg':
        res = val * 100;
        label = `${val} क्विंटल × 100 = kg`;
        break;
      case 'toMann':
        res = val / 40;
        label = `${val} kg ÷ 40 = मन (Mann)`;
        break;
      case 'fromMann':
        res = val * 40;
        label = `${val} मन × 40 = kg`;
        break;
    }

    const rounded = Number(res.toFixed(3));
    setExpression(label);
    setCurrentVal(String(rounded));
    setIsNewNumber(true);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(currentVal);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareWhatsApp = () => {
    const text = `*FieldBook हिसाब गणना*\n${expression ? expression + '\n' : ''}कुल रकम: ₹${currentVal}\n(तैयार: FieldBook - Mr Nikhil)`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const handleSaveToNotesAction = () => {
    const noteText = `कैलकुलेटर हिसाब:\n${expression ? expression + ' = ' : ''}₹${currentVal}\nतारीख: ${new Date().toLocaleString()}`;
    if (onSendToNotes) {
      onSendToNotes(noteText);
    } else {
      // Directly append to notes
      const existing = Storage.getNotes();
      const newNote = {
        id: `note-${Date.now()}`,
        title: `हिसाब: ₹${currentVal}`,
        content: noteText,
        category: 'payment' as const,
        isPinned: false,
        date: new Date().toISOString().split('T')[0],
        time: new Date().toTimeString().slice(0, 5),
        color: 'emerald',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      Storage.saveNotes([newNote, ...existing]);
      alert(isHindi ? 'हिसाब खेत नोट्स में सुरक्षित हो गया!' : 'Calculation saved to Farm Notes!');
    }
  };

  const handleClearHistory = () => {
    setHistory([]);
    Storage.saveCalcHistory([]);
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(e.key)) {
        handleDigit(e.key);
      } else if (e.key === '.') {
        handleDigit('.');
      } else if (e.key === '+') {
        handleOperator('+');
      } else if (e.key === '-') {
        handleOperator('-');
      } else if (e.key === '*' || e.key === 'x') {
        handleOperator('*');
      } else if (e.key === '/') {
        e.preventDefault();
        handleOperator('/');
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (e.key === 'Backspace') {
        handleBackspace();
      } else if (e.key === 'Escape') {
        if (isModal && onClose) onClose();
        else handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentVal, expression, isNewNumber]);

  return (
    <div
      className={`relative w-full max-w-md mx-auto rounded-3xl border overflow-hidden shadow-2xl transition-all ${
        isDark
          ? 'bg-neutral-950/95 border-emerald-900/40 text-white shadow-emerald-950/30'
          : 'bg-white/95 border-emerald-200 text-neutral-900 shadow-emerald-100'
      }`}
    >
      {/* Top Header */}
      <div className="flex items-center justify-between px-5 pt-4 pb-2 border-b border-neutral-800/40">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-600/30">
            <CalcIcon className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold tracking-tight">
              {isHindi ? 'डिजिटल हिसाब कैलकुलेटर' : 'Field Digital Calculator'}
            </h3>
            <p className="text-[10px] text-emerald-500 font-medium">
              {isHindi ? 'साधारण व सटीक जोड़-घटाव' : 'Simple & accurate arithmetic'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Sound toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-2 rounded-xl text-xs transition-colors cursor-pointer ${
              soundEnabled
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'text-neutral-500 hover:text-neutral-300'
            }`}
            title={soundEnabled ? 'Click sound on' : 'Click sound off'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* History Toggle */}
          <button
            onClick={() => setShowHistory(!showHistory)}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
              showHistory
                ? 'bg-emerald-600 text-white border-emerald-500'
                : isDark
                ? 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                : 'bg-neutral-100 border-neutral-200 text-neutral-700 hover:text-neutral-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span className="text-[11px]">{isHindi ? 'इतिहास' : 'History'}</span>
          </button>

          {isModal && onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* History Tape Drawer */}
      {showHistory ? (
        <div className="p-4 max-h-[380px] overflow-y-auto space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <span className="text-xs font-bold text-neutral-400">
              {isHindi ? 'पिछली गणनाएं (Calculation Tape)' : 'Past Calculations'}
            </span>
            {history.length > 0 && (
              <button
                onClick={handleClearHistory}
                className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
                <span>{isHindi ? 'इतिहास मिटाएं' : 'Clear'}</span>
              </button>
            )}
          </div>

          {history.length === 0 ? (
            <div className="text-center py-10 text-neutral-500 text-xs">
              {isHindi ? 'कोई पुराना हिसाब नहीं है' : 'No previous calculations yet'}
            </div>
          ) : (
            history.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  setCurrentVal(item.result.replace(/,/g, ''));
                  setExpression(item.expression);
                  setShowHistory(false);
                }}
                className={`p-3 rounded-2xl border text-left cursor-pointer transition-all hover:scale-[1.01] ${
                  isDark
                    ? 'bg-neutral-900/60 border-neutral-800 hover:border-emerald-500/40'
                    : 'bg-neutral-50 border-neutral-200 hover:border-emerald-500/40'
                }`}
              >
                <div className="flex justify-between items-center text-[10px] text-neutral-500 mb-0.5">
                  <span className="font-mono">{item.timestamp}</span>
                  <span className="text-emerald-500 text-[10px] font-bold">टैप कर लोड करें</span>
                </div>
                <div className="text-xs text-neutral-400 font-mono truncate">{item.expression}</div>
                <div className="text-base font-extrabold text-emerald-500 font-mono">₹ {item.result}</div>
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="p-4 space-y-4">
          {/* LCD Digital Display */}
          <div
            className={`rounded-2xl p-4 border relative transition-all ${
              isDark
                ? 'bg-gradient-to-b from-neutral-900 to-neutral-950 border-emerald-900/50 shadow-inner'
                : 'bg-gradient-to-b from-emerald-50/50 to-neutral-100/90 border-emerald-200/80 shadow-inner'
            }`}
          >
            {/* Expression line */}
            <div className="h-6 flex items-center justify-end text-xs font-mono text-neutral-400 overflow-x-auto whitespace-nowrap">
              {expression || <span className="opacity-0">0</span>}
            </div>

            {/* Current Large Digits */}
            <div className="flex items-baseline justify-between gap-2 mt-1">
              <span className="text-sm font-bold text-emerald-500/70 select-none">₹</span>
              <div
                className="text-3xl sm:text-4xl font-extrabold font-mono tracking-tight text-right overflow-x-auto scrollbar-none select-all w-full"
                style={{ direction: 'ltr' }}
              >
                {currentVal}
              </div>
            </div>

            {/* Action Bar inside display */}
            <div className="flex items-center justify-between pt-2 mt-2 border-t border-neutral-800/40 text-xs">
              <span className="text-[10px] text-neutral-500 font-medium">
                {isHindi ? 'कीबोर्ड इनपुट समर्थित (0-9, +, -, *, /, Enter)' : 'Keyboard supported'}
              </span>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleCopy}
                  className="px-2 py-1 rounded-lg bg-neutral-800/60 hover:bg-neutral-700/80 text-neutral-300 text-[11px] font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                  title="Copy result"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? (isHindi ? 'कॉपी हुआ' : 'Copied') : (isHindi ? 'कॉपी' : 'Copy')}</span>
                </button>

                <button
                  onClick={handleSaveToNotesAction}
                  className="px-2 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 text-[11px] font-semibold flex items-center gap-1 border border-emerald-500/30 cursor-pointer transition-colors"
                  title="Save to Farm Notes"
                >
                  <FileText className="w-3 h-3" />
                  <span>{isHindi ? 'नोट्स' : 'Note'}</span>
                </button>

                <button
                  onClick={handleShareWhatsApp}
                  className="px-2 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-[11px] font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                  title="Share on WhatsApp"
                >
                  <Share2 className="w-3 h-3" />
                  <span>WhatsApp</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick Agricultural Conversions Strip */}
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-[10px] font-semibold text-neutral-400">
              <Sparkles className="w-3 h-3 text-emerald-500" />
              <span>{isHindi ? 'कृषि व मंडी शॉर्टकट' : 'Agri Quick Math'}:</span>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
              <button
                onClick={() => applyFarmShortcut('addGst')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-bold bg-neutral-900/50 border-neutral-800 hover:border-emerald-500 text-emerald-400 cursor-pointer"
                title="Add 18% GST"
              >
                +18% GST
              </button>
              <button
                onClick={() => applyFarmShortcut('subGst')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-bold bg-neutral-900/50 border-neutral-800 hover:border-emerald-500 text-emerald-400 cursor-pointer"
                title="Subtract 18% GST"
              >
                -18% GST
              </button>
              <button
                onClick={() => applyFarmShortcut('toQuintal')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-bold bg-neutral-900/50 border-neutral-800 hover:border-emerald-500 text-amber-400 cursor-pointer"
                title="Convert kg to Quintal"
              >
                ÷100 (क्विं.)
              </button>
              <button
                onClick={() => applyFarmShortcut('toKg')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-bold bg-neutral-900/50 border-neutral-800 hover:border-emerald-500 text-amber-400 cursor-pointer"
                title="Convert Quintal to kg"
              >
                ×100 (kg)
              </button>
              <button
                onClick={() => applyFarmShortcut('toMann')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-bold bg-neutral-900/50 border-neutral-800 hover:border-emerald-500 text-teal-400 cursor-pointer"
                title="Convert kg to Mann (40kg)"
              >
                ÷40 (मन)
              </button>
              <button
                onClick={() => applyFarmShortcut('fromMann')}
                className="px-1.5 py-1.5 rounded-lg border text-[11px] font-bold bg-neutral-900/50 border-neutral-800 hover:border-emerald-500 text-teal-400 cursor-pointer"
                title="Convert Mann to kg"
              >
                ×40 (मन→kg)
              </button>
            </div>
          </div>

          {/* Calculator Keypad Grid */}
          <div className="grid grid-cols-4 gap-2 text-base font-bold font-mono">
            {/* Row 1 */}
            <button
              onClick={handleClear}
              className="p-3.5 rounded-2xl bg-rose-500/15 text-rose-500 hover:bg-rose-500/25 border border-rose-500/30 active:scale-95 transition-all cursor-pointer"
            >
              AC
            </button>
            <button
              onClick={handleBackspace}
              className="p-3.5 rounded-2xl bg-neutral-800/60 hover:bg-neutral-800 text-neutral-300 border border-neutral-700/60 active:scale-95 transition-all cursor-pointer flex items-center justify-center"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={handlePercentage}
              className="p-3.5 rounded-2xl bg-neutral-800/60 hover:bg-neutral-800 text-neutral-300 border border-neutral-700/60 active:scale-95 transition-all cursor-pointer"
            >
              %
            </button>
            <button
              onClick={() => handleOperator('/')}
              className="p-3.5 rounded-2xl bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 border border-emerald-500/40 text-lg active:scale-95 transition-all cursor-pointer"
            >
              ÷
            </button>

            {/* Row 2 */}
            <button
              onClick={() => handleDigit('7')}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              7
            </button>
            <button
              onClick={() => handleDigit('8')}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              8
            </button>
            <button
              onClick={() => handleDigit('9')}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              9
            </button>
            <button
              onClick={() => handleOperator('*')}
              className="p-3.5 rounded-2xl bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 border border-emerald-500/40 text-lg active:scale-95 transition-all cursor-pointer"
            >
              ×
            </button>

            {/* Row 3 */}
            <button
              onClick={() => handleDigit('4')}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              4
            </button>
            <button
              onClick={() => handleDigit('5')}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              5
            </button>
            <button
              onClick={() => handleDigit('6')}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              6
            </button>
            <button
              onClick={() => handleOperator('-')}
              className="p-3.5 rounded-2xl bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 border border-emerald-500/40 text-lg active:scale-95 transition-all cursor-pointer"
            >
              -
            </button>

            {/* Row 4 */}
            <button
              onClick={() => handleDigit('1')}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              1
            </button>
            <button
              onClick={() => handleDigit('2')}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              2
            </button>
            <button
              onClick={() => handleDigit('3')}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              3
            </button>
            <button
              onClick={() => handleOperator('+')}
              className="p-3.5 rounded-2xl bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 border border-emerald-500/40 text-lg active:scale-95 transition-all cursor-pointer"
            >
              +
            </button>

            {/* Row 5 */}
            <button
              onClick={handleToggleSign}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-neutral-300 border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs text-sm"
            >
              +/-
            </button>
            <button
              onClick={() => handleDigit('0')}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              0
            </button>
            <button
              onClick={handleDoubleZero}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              00
            </button>
            <button
              onClick={() => handleDigit('.')}
              className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 text-white border border-neutral-800 active:scale-95 transition-all cursor-pointer shadow-xs"
            >
              .
            </button>

            {/* Big Equals Button */}
            <button
              onClick={handleEquals}
              className="col-span-4 p-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 text-white hover:from-emerald-500 hover:to-teal-400 active:scale-[0.99] font-extrabold text-xl shadow-lg shadow-emerald-600/30 transition-all cursor-pointer flex items-center justify-center gap-2 border border-emerald-400/40"
            >
              <span>=</span>
              <span className="text-sm font-sans font-bold">
                {isHindi ? 'जोड़ें / परिणाम निकालें' : 'Calculate'}
              </span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
