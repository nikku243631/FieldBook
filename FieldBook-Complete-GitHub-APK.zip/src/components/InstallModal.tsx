import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  CheckCircle2,
  Share2,
  X,
  ExternalLink,
  ShieldCheck,
  Zap,
  HardDrive,
  WifiOff,
  MoreVertical,
  PlusSquare,
  Sparkles,
  HelpCircle,
  PackageCheck,
  FolderArchive,
  Loader2,
  Copy,
  Check,
  FileCode,
  Github
} from 'lucide-react';
import { Language, Theme } from '../types';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { downloadProjectZip, downloadWorkflowYaml, GITHUB_WORKFLOW_YAML } from '../utils/zipExporter';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  theme: Theme;
}

export const InstallModal: React.FC<InstallModalProps> = ({
  isOpen,
  onClose,
  lang,
  theme
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'android' | 'apk' | 'ios'>('apk');
  const [installClicked, setInstallClicked] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedLiveUrl, setCopiedLiveUrl] = useState(false);
  const [copiedYaml, setCopiedYaml] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [zipStatus, setZipStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const isHindi = lang === 'hi';
  const isDark = theme === 'dark';

  const liveAppUrl = "https://ais-pre-r2stqjpopqjqnvs5err4lv-603898960151.asia-east1.run.app";
  const pwaBuilderDirectUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(liveAppUrl)}`;

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const count = await downloadProjectZip((msg) => setZipStatus(msg));
      setZipStatus(
        isHindi
          ? `✓ ज़िप डाउनलोड पूर्ण! (${count} फाइल्स पैक की गईं)`
          : `✓ ZIP Download Complete! (${count} files packed)`
      );
      setTimeout(() => {
        setZipStatus(null);
        setIsZipping(false);
      }, 5000);
    } catch {
      setZipStatus(isHindi ? 'त्रुटि हुई, पुनः प्रयास करें' : 'Download failed');
      setIsZipping(false);
    }
  };

  const handleCopyYaml = () => {
    navigator.clipboard.writeText(GITHUB_WORKFLOW_YAML);
    setCopiedYaml(true);
    setTimeout(() => setCopiedYaml(false), 2500);
  };

  const handleCopyLiveUrl = () => {
    navigator.clipboard.writeText(liveAppUrl);
    setCopiedLiveUrl(true);
    setTimeout(() => setCopiedLiveUrl(false), 2500);
  };

  const handleDirectInstall = async () => {
    setInstallClicked(true);
    const success = await install();
    if (success) {
      setTimeout(() => {
        onClose();
      }, 1000);
    }
  };

  const handleShareApp = async () => {
    const shareData = {
      title: 'FieldBook - किसान खेत लेजर व हिसाब',
      text: 'किसान भाइयों के लिए मुफ्त डिजिटल खेत लेजर, मंडी कैलकुलेटर, मौसम अलर्ट और खाद-बीज हिसाब ऐप।',
      url: window.location.href
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {
        // User cancelled or not supported
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div
        className={`relative w-full max-w-xl rounded-3xl border shadow-2xl overflow-hidden z-10 transition-all my-8 ${
          isDark
            ? 'bg-neutral-900 border-neutral-800 text-neutral-100 shadow-emerald-950/40'
            : 'bg-white border-neutral-200 text-neutral-900 shadow-neutral-400/30'
        }`}
      >
        {/* Header Ribbon */}
        <div className="relative bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 px-6 py-6 text-white">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center p-1.5 shadow-inner">
                <img
                  src="/icon.svg"
                  alt="FieldBook Logo"
                  className="w-full h-full object-contain drop-shadow"
                  onError={(e) => {
                    // Fallback to Smartphone icon if image fails to load
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-bold tracking-tight">
                    {isHindi ? 'FieldBook ऐप इंस्टॉल व डाउनलोड' : 'Install FieldBook App'}
                  </h2>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-amber-950 uppercase tracking-wider">
                    Official
                  </span>
                </div>
                <p className="text-xs text-emerald-100 mt-0.5">
                  {isHindi
                    ? 'Android फोन पर बिना झंझट असली ऐप की तरह चलाएं'
                    : 'Install directly on Android & iOS without third-party risk'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-black/20 hover:bg-black/30 text-white/90 transition cursor-pointer"
              title={isHindi ? 'बंद करें' : 'Close'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Tabs */}
          <div className="flex gap-2 mt-5 p-1 bg-black/25 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setActiveTab('android')}
              className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer ${
                activeTab === 'android'
                  ? 'bg-white text-emerald-900 shadow-sm'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>{isHindi ? 'Android फोन (सीधा ऐप)' : 'Android (Instant)'}</span>
            </button>

            <button
              onClick={() => setActiveTab('apk')}
              className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer ${
                activeTab === 'apk'
                  ? 'bg-white text-emerald-900 shadow-sm'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              <Download className="w-4 h-4" />
              <span>{isHindi ? 'APK व गाइड' : 'APK & Offline'}</span>
            </button>

            <button
              onClick={() => setActiveTab('ios')}
              className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer ${
                activeTab === 'ios'
                  ? 'bg-white text-emerald-900 shadow-sm'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              <ExternalLink className="w-4 h-4" />
              <span>{isHindi ? 'iPhone / iPad' : 'iOS Safari'}</span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Status banner if already installed */}
          {isInstalled && (
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center gap-3">
              <PackageCheck className="w-6 h-6 shrink-0" />
              <div className="text-xs">
                <p className="font-bold">
                  {isHindi ? 'FieldBook आपके फोन में पहले से इंस्टॉल है!' : 'FieldBook is already installed!'}
                </p>
                <p className="opacity-90">
                  {isHindi
                    ? 'आप इसे सीधे फोन की होम स्क्रीन से खोल सकते हैं। यह बिना इंटरनेट के भी चलेगा।'
                    : 'You can launch it directly from your home screen. Works 100% offline.'}
                </p>
              </div>
            </div>
          )}

          {/* TAB 1: Android Direct Install */}
          {activeTab === 'android' && (
            <div className="space-y-5">
              {/* Direct 1-Tap Button if supported by browser */}
              {isInstallable ? (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-teal-500/15 to-emerald-500/15 border border-emerald-500/30 text-center space-y-3">
                  <div className="flex items-center justify-center gap-2 text-emerald-700 dark:text-emerald-400 font-bold text-sm">
                    <Sparkles className="w-4 h-4" />
                    <span>{isHindi ? '1-क्लिक में फोन पर लगाएं' : 'One-Click Direct Install'}</span>
                  </div>
                  <button
                    onClick={handleDirectInstall}
                    className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-base shadow-lg shadow-emerald-600/30 active:scale-[0.99] transition cursor-pointer flex items-center justify-center gap-2.5"
                  >
                    <Download className="w-5 h-5" />
                    <span>{isHindi ? '📱 अभी फोन में इंस्टॉल करें' : '📱 Install App on Device'}</span>
                  </button>
                  <p className="text-[11px] text-neutral-500">
                    {isHindi
                      ? 'क्लिक करते ही क्रोम आपको "Install" करने को कहेगा। बस पुष्टि करें।'
                      : 'Clicking will trigger your browser native install prompt.'}
                  </p>
                </div>
              ) : null}

              {/* Visual 3-Step Guide */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold flex items-center gap-2 text-neutral-800 dark:text-neutral-200">
                  <Smartphone className="w-4 h-4 text-emerald-600" />
                  <span>
                    {isHindi
                      ? 'Android फोन पर कैसे लगाएं? (सरल 3 चरण)'
                      : 'How to install on Android (3 Simple Steps)'}
                  </span>
                </h3>

                <div className="grid gap-3">
                  {/* Step 1 */}
                  <div
                    className={`p-3.5 rounded-2xl border flex items-start gap-3.5 ${
                      isDark ? 'bg-neutral-800/60 border-neutral-700/60' : 'bg-neutral-50 border-neutral-200'
                    }`}
                  >
                    <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-sm">
                      1
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs font-bold flex items-center gap-1.5 text-neutral-800 dark:text-neutral-100">
                        <span>{isHindi ? 'Chrome ब्राउज़र में 3 बिंदी पर टच करें' : 'Open Chrome Menu'}</span>
                        <span className="p-1 rounded bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300">
                          <MoreVertical className="w-3 h-3 inline" />
                        </span>
                      </p>
                      <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-relaxed">
                        {isHindi
                          ? 'फोन में ऊपर दाईं ओर कोने में दिख रहे 3 डॉट (तीन बिंदी ⋮) के बटन पर क्लिक करें।'
                          : 'Tap the three vertical dots (⋮) in the top-right corner of Chrome.'}
                      </p>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div
                    className={`p-3.5 rounded-2xl border flex items-start gap-3.5 ${
                      isDark ? 'bg-neutral-800/60 border-neutral-700/60' : 'bg-neutral-50 border-neutral-200'
                    }`}
                  >
                    <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-sm">
                      2
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs font-bold flex items-center gap-1.5 text-neutral-800 dark:text-neutral-100">
                        <span>
                          {isHindi ? '"App इंस्टॉल करें" या "होम स्क्रीन पर जोड़ें" चुनें' : 'Select "Install app" or "Add to Home screen"'}
                        </span>
                        <span className="p-1 rounded bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300">
                          <PlusSquare className="w-3 h-3 inline" />
                        </span>
                      </p>
                      <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-relaxed">
                        {isHindi
                          ? 'मेनू लिस्ट में "Install app" या "Add to Home screen" (होम स्क्रीन पर जोड़ें) का विकल्प मिलेगा, उस पर दबाएं।'
                          : 'In the menu dropdown, tap "Install app" or "Add to Home screen".'}
                      </p>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div
                    className={`p-3.5 rounded-2xl border flex items-start gap-3.5 ${
                      isDark ? 'bg-neutral-800/60 border-neutral-700/60' : 'bg-neutral-50 border-neutral-200'
                    }`}
                  >
                    <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-sm">
                      3
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs font-bold flex items-center gap-1.5 text-neutral-800 dark:text-neutral-100">
                        <span>{isHindi ? '"Install" पर टच करें — काम पूरा!' : 'Tap "Install" to finish'}</span>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 inline" />
                      </p>
                      <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-relaxed">
                        {isHindi
                          ? 'Android अपने आप FieldBook का असली ऐप आइकन आपके मोबाइल की होम स्क्रीन पर लगा देगा। फिर इसे जब चाहें बिना इंटरनेट भी खोलें!'
                          : 'Android creates a standalone app icon on your home screen. Launches full-screen like any Play Store app.'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Key Highlights */}
              <div
                className={`p-4 rounded-2xl border space-y-2.5 ${
                  isDark ? 'bg-neutral-800/40 border-neutral-800' : 'bg-emerald-50/50 border-emerald-100'
                }`}
              >
                <p className="text-xs font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isHindi ? 'यह सामान्य APK से बेहतर क्यों है?' : 'Why is this better than raw APK?'}</span>
                </p>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-neutral-600 dark:text-neutral-300">
                  <div className="flex items-center gap-2">
                    <Zap className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span>{isHindi ? 'केवल 2 MB मेमोरी' : 'Only 2-3 MB storage'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <WifiOff className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                    <span>{isHindi ? 'बिना इंटरनेट चलता है' : '100% Offline ready'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>{isHindi ? 'कोई वायरस का डर नहीं' : 'No security warnings'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <HardDrive className="w-3.5 h-3.5 text-purple-500 shrink-0" />
                    <span>{isHindi ? 'हिसाब फोन में सुरक्षित' : 'Private offline storage'}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: APK & Offline Source */}
          {activeTab === 'apk' && (
            <div className="space-y-4 text-xs">
              {/* PRIMARY HERO: Complete GitHub Auto-APK ZIP Package */}
              <div
                className={`p-4 rounded-2xl border-2 space-y-3.5 ${
                  isDark
                    ? 'bg-gradient-to-br from-purple-950/40 via-neutral-900 to-emerald-950/30 border-purple-500/50'
                    : 'bg-gradient-to-br from-purple-50 via-white to-emerald-50 border-purple-300'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <h4 className="font-extrabold text-sm text-neutral-900 dark:text-white flex items-center gap-2">
                    <FolderArchive className="w-5 h-5 text-purple-500 shrink-0" />
                    <span>
                      {isHindi
                        ? '📦 GitHub Auto-APK कम्प्लीट ZIP पैकेज'
                        : '📦 Complete GitHub Auto-APK ZIP Package'}
                    </span>
                  </h4>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/15 text-emerald-500 border border-emerald-500/30 shrink-0">
                    100% Same UI & Features
                  </span>
                </div>

                <p className="text-[11px] text-neutral-600 dark:text-neutral-300 leading-relaxed">
                  {isHindi
                    ? 'इस एक ZIP फाइल के अंदर ऐप की सारी जरूरी फाइल्स, सोर्स कोड फोल्डर्स (src/, public/), YAML फाइल (.github/workflows/build-apk.yml), और सारी Requirement फाइल्स शामिल हैं। इसे GitHub पर अपलोड करते ही अपने आप असली Android .APK बनकर तैयार हो जाएगी!'
                    : 'Contains 100% of all required app files, folders (src/, public/), GitHub Actions YAML workflow (.github/workflows/build-apk.yml), and config files. Upload to GitHub to automatically build and download your .apk file!'}
                </p>

                {/* File Checklist inside the ZIP */}
                <div
                  className={`p-3 rounded-xl border grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] ${
                    isDark ? 'bg-black/40 border-neutral-800' : 'bg-white/90 border-neutral-200'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span className="truncate font-medium">
                      {isHindi ? 'src/ (सारे 18+ ओरिजिनल फीचर्स)' : 'src/ (All 18+ original components)'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span className="truncate font-medium">
                      {isHindi ? '.github/workflows/build-apk.yml' : '.github/workflows/build-apk.yml'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span className="truncate font-medium">
                      {isHindi ? 'package.json व capacitor.config.json' : 'package.json & capacitor.config.json'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span className="truncate font-medium">
                      {isHindi ? 'public/ (ओरिजिनल आइकॉन व PWA)' : 'public/ (Icons & PWA assets)'}
                    </span>
                  </div>
                </div>

                {/* Big 1-Click ZIP Download Button */}
                <button
                  onClick={handleDownloadZip}
                  disabled={isZipping}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-purple-950/40 transition active:scale-[0.99] cursor-pointer"
                >
                  {isZipping ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{zipStatus || (isHindi ? 'ज़िप फ़ाइल बन रही है...' : 'Generating Complete ZIP...')}</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      <span>
                        {zipStatus ||
                          (isHindi
                            ? '📥 पूरी GitHub Auto-APK ZIP डाउनलोड करें (.zip)'
                            : '📥 Download Complete GitHub Auto-APK ZIP (.zip)')}
                      </span>
                    </>
                  )}
                </button>

                {/* Backup Direct YAML Download & Copy for Mobile File Managers */}
                <div className="flex flex-col sm:flex-row gap-2 pt-1">
                  <button
                    onClick={downloadWorkflowYaml}
                    className={`flex-1 py-2 px-3 rounded-xl border font-semibold text-[11px] flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      isDark
                        ? 'bg-neutral-800/80 border-neutral-700 hover:bg-neutral-700 text-neutral-200'
                        : 'bg-neutral-100 border-neutral-300 hover:bg-neutral-200 text-neutral-800'
                    }`}
                  >
                    <FileCode className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span>{isHindi ? 'अलग से build-apk.yml डाउनलोड करें' : 'Download build-apk.yml only'}</span>
                  </button>
                  <button
                    onClick={handleCopyYaml}
                    className={`flex-1 py-2 px-3 rounded-xl border font-semibold text-[11px] flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      isDark
                        ? 'bg-neutral-800/80 border-neutral-700 hover:bg-neutral-700 text-neutral-200'
                        : 'bg-neutral-100 border-neutral-300 hover:bg-neutral-200 text-neutral-800'
                    }`}
                  >
                    {copiedYaml ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        <span>{isHindi ? '✓ YAML कोड कॉपी हो गया!' : '✓ YAML Code Copied!'}</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        <span>{isHindi ? 'YAML कोड कॉपी करें' : 'Copy YAML Workflow Code'}</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Simple 3-step instructions */}
                <div
                  className={`p-3 rounded-xl border space-y-1.5 text-[11px] ${
                    isDark ? 'bg-neutral-900/90 border-neutral-800 text-neutral-300' : 'bg-neutral-50 border-neutral-200 text-neutral-700'
                  }`}
                >
                  <p className="font-bold text-emerald-500">
                    {isHindi
                      ? '🚀 GitHub से ऑटोमैटिक .APK पाने के 3 आसान स्टेप्स:'
                      : '🚀 3 Simple Steps to Get Auto-Built .APK on GitHub:'}
                  </p>
                  <p>
                    {isHindi
                      ? '1. ऊपर बटन दबाकर ZIP डाउनलोड करें और उसे अपने फोन/कंप्यूटर में Extract (Unzip) करें।'
                      : '1. Download the ZIP above and Extract (Unzip) all files & folders.'}
                  </p>
                  <p>
                    {isHindi
                      ? '2. GitHub पर नई Public Repository बनाकर सारी फाइल्स अपलोड (Commit) कर दें।'
                      : '2. Create a new Public Repository on GitHub and upload (Commit) all extracted files.'}
                  </p>
                  <p>
                    {isHindi
                      ? '3. अपलोड होते ही GitHub अपने आप APK बना देगा! 2 मिनट बाद "Releases" या "Actions" टैब से FieldBook-Kisan-App.apk डाउनलोड करके इंस्टॉल कर लें।'
                      : '3. GitHub automatically builds the APK! In ~2 minutes, download FieldBook-Kisan-App.apk from "Releases" or "Actions" tab.'}
                  </p>
                </div>
              </div>

              {/* Question 1: Is the APK identical to preview? */}
              <div
                className={`p-3.5 rounded-2xl border space-y-2 ${
                  isDark
                    ? 'bg-gradient-to-br from-emerald-950/40 to-teal-950/30 border-emerald-800/40'
                    : 'bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200'
                }`}
              >
                <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-bold text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>
                    {isHindi
                      ? '100% सेम प्रीव्यू गारंटी (कोई बदलाव नहीं)'
                      : '100% Identical to Preview Guarantee'}
                  </span>
                </div>
                <p className="text-[11px] text-neutral-600 dark:text-neutral-300 leading-relaxed">
                  {isHindi
                    ? 'इस ज़िप से बनने वाला APK 100% बिल्कुल इस प्रीव्यू जैसा ही दिखेगा और काम करेगा—वही किसान थीम, फसल हिसाब, मंडी कैलकुलेटर, साधारण कैलकुलेटर, मौसम अलर्ट, और नोट्स/सामान लिस्ट।'
                    : 'The APK built from this ZIP is 100% identical to this preview—same theme, crop ledger, mandi calculator, simple calculator, weather forecast, and notes/shopping list.'}
                </p>
              </div>

              {/* OPTION 2: PWABuilder Direct 1-Click APK Generator */}
              <div
                className={`p-4 rounded-2xl border space-y-3 ${
                  isDark ? 'bg-neutral-800/50 border-neutral-700/60' : 'bg-neutral-50 border-neutral-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-neutral-800 dark:text-neutral-100 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    <span>
                      {isHindi ? 'विकल्प 2: बिना GitHub सीधे PWABuilder से .APK' : 'Option 2: Direct .APK via PWABuilder'}
                    </span>
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
                    {isHindi ? '1 मिनट' : '1 min'}
                  </span>
                </div>

                {/* Live App URL Box with Copy */}
                <div className="p-2.5 rounded-xl bg-black/10 dark:bg-black/30 border border-neutral-300 dark:border-neutral-700 flex items-center justify-between gap-2">
                  <div className="truncate text-[10px] font-mono opacity-80 text-emerald-700 dark:text-emerald-400">
                    {liveAppUrl}
                  </div>
                  <button
                    onClick={handleCopyLiveUrl}
                    className="p-1.5 rounded-lg bg-neutral-200 dark:bg-neutral-700 hover:bg-neutral-300 dark:hover:bg-neutral-600 transition shrink-0 flex items-center gap-1 text-[10px] font-semibold cursor-pointer"
                    title={isHindi ? 'लिंक कॉपी करें' : 'Copy Link'}
                  >
                    {copiedLiveUrl ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-500" />
                        <span>{isHindi ? 'कॉपी हुआ' : 'Copied'}</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 text-neutral-600 dark:text-neutral-300" />
                        <span>{isHindi ? 'कॉपी' : 'Copy'}</span>
                      </>
                    )}
                  </button>
                </div>

                <a
                  href={pwaBuilderDirectUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>{isHindi ? '🚀 PWABuilder पर डायरेक्ट .APK बनाएं' : '🚀 Generate Direct .APK on PWABuilder'}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              {/* OPTION 3: Share with other Farmers */}
              <div className="pt-1 flex flex-col sm:flex-row gap-2">
                <button
                  onClick={handleShareApp}
                  className="w-full py-2.5 px-4 rounded-xl border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-200 font-semibold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <Share2 className="w-4 h-4 text-emerald-600" />
                  <span>
                    {copiedLink
                      ? (isHindi ? '✓ लिंक कॉपी हो गया!' : '✓ Link Copied!')
                      : (isHindi ? 'किसान भाइयों को लिंक शेयर करें' : 'Share App Link with Farmers')}
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: iOS / iPhone */}
          {activeTab === 'ios' && (
            <div className="space-y-4">
              <div
                className={`p-4 rounded-2xl border space-y-3 ${
                  isDark ? 'bg-neutral-800/40 border-neutral-700/60' : 'bg-neutral-50 border-neutral-200'
                }`}
              >
                <h3 className="text-sm font-bold flex items-center gap-2 text-neutral-800 dark:text-neutral-200">
                  <Smartphone className="w-4 h-4 text-emerald-600" />
                  <span>
                    {isHindi ? 'iPhone व iPad पर कैसे लगाएं?' : 'How to install on iPhone & iPad'}
                  </span>
                </h3>

                <div className="space-y-3 text-xs text-neutral-600 dark:text-neutral-300">
                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                      1
                    </span>
                    <p className="text-[11px] leading-relaxed">
                      {isHindi
                        ? 'इस पेज को केवल Apple के Safari ब्राउज़र में खोलें।'
                        : 'Make sure you are viewing this page in Safari browser on iOS.'}
                    </p>
                  </div>

                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                      2
                    </span>
                    <p className="text-[11px] leading-relaxed">
                      {isHindi
                        ? 'नीचे दिए गए शेयर बटन (तीर का निशान वाला चौकोर 📤) पर टच करें।'
                        : 'Tap the Share icon (square with upward arrow 📤) at the bottom toolbar.'}
                    </p>
                  </div>

                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                      3
                    </span>
                    <p className="text-[11px] leading-relaxed">
                      {isHindi
                        ? 'मेनू को नीचे स्क्रॉल करें और "होम स्क्रीन में जोड़ें" (Add to Home Screen) चुनें और Add दबाएं।'
                        : 'Scroll down and tap "Add to Home Screen", then tap "Add" in the top corner.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div
          className={`px-6 py-4 border-t flex flex-wrap items-center justify-between gap-3 text-xs ${
            isDark ? 'bg-neutral-950/80 border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div className="flex items-center gap-2 text-neutral-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="text-[11px]">
              {isHindi ? '100% सुरक्षित • कोई विज्ञापन नहीं • किसान हितैषी' : '100% Secure • Ad-Free • Farmer First'}
            </span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-neutral-200 hover:bg-neutral-300 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 font-semibold transition cursor-pointer"
          >
            {isHindi ? 'समझ गया / बंद करें' : 'Got it / Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
