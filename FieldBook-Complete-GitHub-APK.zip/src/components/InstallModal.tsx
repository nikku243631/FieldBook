import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  Share2,
  X,
  ExternalLink,
  ShieldCheck,
  MoreVertical,
  PlusSquare,
  PackageCheck,
  FolderArchive,
  Loader2,
  Copy,
  Check,
  FileCode,
  User
} from 'lucide-react';
import { Language, Theme } from '../types';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { downloadProjectZip, downloadWorkflowYaml, GITHUB_WORKFLOW_YAML } from '../utils/zipExporter';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  theme: Theme;
  onGoToAccountReports?: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({
  isOpen,
  onClose,
  lang,
  onGoToAccountReports
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'apk' | 'android' | 'ios'>('apk');
  const [copiedYaml, setCopiedYaml] = useState(false);
  const [showYamlCode, setShowYamlCode] = useState(false);
  const [directZipClicked, setDirectZipClicked] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [zipStatus, setZipStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const isHindi = lang === 'hi';

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const count = await downloadProjectZip((msg) => setZipStatus(msg));
      setZipStatus(
        isHindi
          ? `✓ नया ज़िप डाउनलोड पूर्ण! (${count} फाइल्स पैक की गईं)`
          : `✓ New ZIP Download Complete! (${count} files packed)`
      );
      setTimeout(() => {
        setZipStatus(null);
        setIsZipping(false);
      }, 5000);
    } catch {
      setZipStatus(isHindi ? 'त्रुटि हुई, पुनः प्रयास करें' : 'Download failed');
      setIsZipping(false);
    }
  };

  const handleCopyYaml = async () => {
    try {
      await navigator.clipboard.writeText(GITHUB_WORKFLOW_YAML);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = GITHUB_WORKFLOW_YAML;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    setCopiedYaml(true);
    setTimeout(() => setCopiedYaml(false), 3500);
  };

  const handleDirectInstall = async () => {
    const success = await install();
    if (success) {
      setTimeout(() => {
        onClose();
      }, 1000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-950/65 backdrop-blur-md">
      <div className="liquid-glass-modal relative w-full max-w-xl rounded-3xl overflow-hidden z-10 my-6 animate-in fade-in zoom-in-95 duration-200">
        {/* Header Ribbon */}
        <div className="px-5 py-4 border-b border-white/60 dark:border-slate-700/70 bg-gradient-to-r from-emerald-500/25 via-teal-500/20 to-sky-500/25">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-emerald-950 border-2 border-white/80 flex items-center justify-center overflow-hidden shadow-md shrink-0">
                <img
                  src="/logo.png"
                  alt="FieldBook Logo"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-extrabold tracking-tight text-slate-950 dark:text-white">
                    {isHindi ? 'अकाउंट, सेटिंग्स व 1-Click डाउनलोड ZIP' : 'Account, Settings & 1-Click ZIP / YAML'}
                  </h2>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-700 text-white uppercase">
                    v2.4
                  </span>
                </div>
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                  {isHindi
                    ? '1-क्लिक में पूरी ZIP डाउनलोड करें और YAML फाइल कॉपी करें'
                    : 'Download complete GitHub APK ZIP in 1 click & copy YAML file'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="liquid-glass-pill w-9 h-9 rounded-full flex items-center justify-center text-slate-950 dark:text-white cursor-pointer shrink-0"
              title={isHindi ? 'बंद करें' : 'Close'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Tabs */}
          <div className="flex gap-2 mt-3.5 p-1 rounded-2xl bg-white/50 dark:bg-slate-900/60 border border-white/70 dark:border-slate-700 text-xs font-extrabold">
            <button
              type="button"
              onClick={() => setActiveTab('apk')}
              className={`flex-1 py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer ${
                activeTab === 'apk'
                  ? 'liquid-glass-emerald text-white shadow-sm'
                  : 'text-slate-900 dark:text-slate-200'
              }`}
            >
              <Download className="w-4 h-4 shrink-0" />
              <span>{isHindi ? '📥 डाउनलोड ZIP व YAML' : '📥 Download ZIP & YAML'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('android')}
              className={`flex-1 py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer ${
                activeTab === 'android'
                  ? 'liquid-glass-emerald text-white shadow-sm'
                  : 'text-slate-900 dark:text-slate-200'
              }`}
            >
              <Smartphone className="w-4 h-4 shrink-0" />
              <span>{isHindi ? '📱 ऐप इंस्टॉल' : '📱 Direct Install'}</span>
            </button>

            {onGoToAccountReports && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onGoToAccountReports();
                }}
                className="flex-1 py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 text-slate-900 dark:text-slate-200 hover:bg-white/60 transition cursor-pointer"
              >
                <User className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>{isHindi ? '👤 किसान खाता / बैकअप' : '👤 Account / Backup'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 space-y-4 max-h-[72vh] overflow-y-auto">
          {isInstalled && (
            <div className="p-3 rounded-2xl liquid-glass-income flex items-center gap-2.5 text-xs font-extrabold text-emerald-950 dark:text-emerald-200">
              <PackageCheck className="w-5 h-5 shrink-0 text-emerald-700" />
              <span>{isHindi ? 'FieldBook आपके फोन में इंस्टॉल है!' : 'FieldBook is installed!'}</span>
            </div>
          )}

          {activeTab === 'apk' && (
            <div className="space-y-4 text-xs">
              {/* STEP 1: 1-CLICK DIRECT DOWNLOAD ZIP */}
              <div className="p-4 rounded-2xl liquid-glass-income space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="font-extrabold text-sm text-emerald-950 dark:text-emerald-200 flex items-center gap-2">
                    <FolderArchive className="w-5 h-5 text-emerald-700 shrink-0" />
                    <span>
                      {isHindi
                        ? '📦 Step 1: 1-Click डाउनलोड पूरी ZIP फाइल'
                        : '📦 Step 1: 1-Click Download Complete ZIP'}
                    </span>
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-700 text-white shrink-0">
                    All-in-One Ready
                  </span>
                </div>

                <p className="text-xs font-bold text-slate-900 dark:text-slate-200 leading-relaxed">
                  {isHindi
                    ? 'नीचे हरे बटन पर 1 क्लिक करते ही पूरी FieldBook-Complete-GitHub-APK.zip सीधे डाउनलोड हो जाएगी। इसमें नया लोगो, 3D Liquid Glass मोडल, PDF जनरेटर और पूरा Android प्रोजेक्ट सब कुछ शामिल है:'
                    : 'Click the green button below to directly download FieldBook-Complete-GitHub-APK.zip in 1 click with everything included:'}
                </p>

                {/* Primary 1-Click Direct Static ZIP Download Link */}
                <a
                  href="/FieldBook-Complete-GitHub-APK.zip"
                  download="FieldBook-Complete-GitHub-APK.zip"
                  onClick={() => {
                    setDirectZipClicked(true);
                    setTimeout(() => setDirectZipClicked(false), 4500);
                  }}
                  className="w-full py-3.5 px-4 rounded-2xl liquid-glass-emerald text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer no-underline"
                >
                  <Download className="w-5 h-5 shrink-0" />
                  <span>
                    {directZipClicked
                      ? isHindi
                        ? '✓ FieldBook-Complete-GitHub-APK.zip डाउनलोड शुरू!'
                        : '✓ FieldBook-Complete-GitHub-APK.zip Downloading!'
                      : isHindi
                      ? '📥 1-Click Download ZIP (FieldBook-Complete-GitHub-APK.zip)'
                      : '📥 1-Click Download ZIP (FieldBook-Complete-GitHub-APK.zip)'}
                  </span>
                </a>

                {/* Secondary Dynamic Browser Packager Fallback */}
                <button
                  type="button"
                  onClick={handleDownloadZip}
                  disabled={isZipping}
                  className="w-full py-2.5 px-3 rounded-xl liquid-glass-pill text-slate-950 dark:text-white font-extrabold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {isZipping ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-emerald-700" />
                      <span>{zipStatus || (isHindi ? 'ज़िप पैक हो रही है...' : 'Packing ZIP...')}</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 text-emerald-700" />
                      <span>
                        {zipStatus ||
                          (isHindi
                            ? 'विकल्प 2: ब्राउज़र में नई ZIP जनरेट व डाउनलोड करें'
                            : 'Option 2: Generate & Download Fresh ZIP in Browser')}
                      </span>
                    </>
                  )}
                </button>
              </div>

              {/* STEP 2: 1-CLICK COPY YAML FILE */}
              <div className="p-4 rounded-2xl liquid-glass-sky space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="font-extrabold text-sm text-sky-950 dark:text-sky-200 flex items-center gap-2">
                    <FileCode className="w-5 h-5 text-blue-700 shrink-0" />
                    <span>
                      {isHindi
                        ? '📋 Step 2: 1-Click कॉपी YAML फाइल (build-apk.yml)'
                        : '📋 Step 2: 1-Click Copy YAML File (build-apk.yml)'}
                    </span>
                  </h4>
                </div>

                <p className="text-xs font-bold text-slate-900 dark:text-slate-200 leading-relaxed">
                  {isHindi
                    ? 'नीचे नीले बटन को दबाकर पूरा build-apk.yml कोड 1 क्लिक में कॉपी करें। GitHub पर ZIP अपलोड करते ही यह अपने-आप नया APK बना देगा:'
                    : 'Tap the blue button below to copy the complete build-apk.yml workflow code in 1 click:'}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={handleCopyYaml}
                    className="py-3.5 px-4 rounded-2xl btn-3d-blue text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                  >
                    {copiedYaml ? (
                      <>
                        <Check className="w-4 h-4 shrink-0" />
                        <span>{isHindi ? '✓ पूरा YAML कोड कॉपी हो गया!' : '✓ Full YAML Code Copied!'}</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 shrink-0" />
                        <span>{isHindi ? '📋 Copy YAML File (build-apk.yml)' : '📋 Copy YAML File (build-apk.yml)'}</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => downloadWorkflowYaml()}
                    className="py-3.5 px-4 rounded-2xl liquid-glass-pill text-slate-950 dark:text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-blue-700 shrink-0" />
                    <span>{isHindi ? '📄 डाउनलोड build-apk.yml फाइल' : '📄 Download build-apk.yml'}</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setShowYamlCode(!showYamlCode)}
                  className="w-full py-2 rounded-xl liquid-glass-pill text-xs font-extrabold text-slate-950 dark:text-white cursor-pointer"
                >
                  {showYamlCode
                    ? isHindi
                      ? '▲ YAML कोड छुपाएं (Hide YAML Code)'
                      : '▲ Hide YAML Code'
                    : isHindi
                    ? '▼ पूरा YAML कोड यहां देखें व कॉपी करें (View YAML Code)'
                    : '▼ View Full YAML Code Box'}
                </button>

                {showYamlCode && (
                  <textarea
                    readOnly
                    rows={8}
                    value={GITHUB_WORKFLOW_YAML}
                    onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                    className="liquid-glass-input w-full p-3 rounded-xl text-[11px] font-mono font-bold"
                  />
                )}
              </div>
            </div>
          )}

          {activeTab === 'android' && (
            <div className="space-y-4">
              {isInstallable ? (
                <div className="p-4 rounded-2xl liquid-glass-income text-center space-y-3">
                  <button
                    type="button"
                    onClick={handleDirectInstall}
                    className="w-full py-3.5 px-6 rounded-2xl liquid-glass-emerald text-white font-extrabold text-sm shadow-lg cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Download className="w-5 h-5" />
                    <span>{isHindi ? '📱 अभी फोन में इंस्टॉल करें' : '📱 Install App on Device'}</span>
                  </button>
                </div>
              ) : null}

              <div className="space-y-2.5">
                <div className="p-3.5 rounded-2xl liquid-glass-subcard flex items-center gap-3">
                  <div className="w-7 h-7 rounded-xl liquid-glass-emerald text-white flex items-center justify-center font-extrabold text-xs shrink-0">
                    1
                  </div>
                  <p className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5">
                    <span>{isHindi ? 'Chrome ब्राउज़र में ऊपर 3 बिंदी दबाएं' : 'Open Chrome 3-dot Menu'}</span>
                    <MoreVertical className="w-4 h-4 inline" />
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl liquid-glass-subcard flex items-center gap-3">
                  <div className="w-7 h-7 rounded-xl liquid-glass-emerald text-white flex items-center justify-center font-extrabold text-xs shrink-0">
                    2
                  </div>
                  <p className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5">
                    <span>{isHindi ? '"Install app" या "Add to Home screen" चुनें' : 'Select "Install app"'}</span>
                    <PlusSquare className="w-4 h-4 inline" />
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3.5 border-t border-white/60 dark:border-slate-700/70 bg-white/45 dark:bg-slate-900/75 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5 text-slate-950 dark:text-slate-200 font-extrabold">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>{isHindi ? '100% सुरक्षित • By Mr Nikhil' : '100% Secure • By Mr Nikhil'}</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="liquid-glass-pill px-4 py-2 rounded-xl text-slate-950 dark:text-white font-extrabold cursor-pointer"
          >
            {isHindi ? 'बंद करें (Close)' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
