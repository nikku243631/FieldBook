import React, { useState } from 'react';
import { CropCycle, Transaction, HarvestEntry, Language, Theme } from '../types';
import { CropCard } from './CropCard';
import { ConfirmModal } from './ConfirmModal';
import { getTranslation, formatCurrency } from '../utils/translations';
import { Plus, Search, Filter, Sprout, TrendingUp, DollarSign, ShieldCheck, Sparkles } from 'lucide-react';

interface CropListProps {
  crops: CropCycle[];
  transactions: Transaction[];
  harvests: HarvestEntry[];
  lang: Language;
  theme: Theme;
  onSelectCrop: (cropId: string) => void;
  onOpenAddCrop: () => void;
  onDeleteCrop?: (cropId: string) => void;
}

export const CropList: React.FC<CropListProps> = ({
  crops,
  transactions,
  harvests,
  lang,
  theme,
  onSelectCrop,
  onOpenAddCrop,
  onDeleteCrop
}) => {
  const isDark = theme === 'dark';
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSeason, setFilterSeason] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [cropToDelete, setCropToDelete] = useState<{ id: string; name: string } | null>(null);

  // Overall calculations across all crops
  const totalFarmExpenses = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalFarmIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const netFarmProfit = totalFarmIncome - totalFarmExpenses;
  const totalLand = crops.reduce((sum, c) => sum + c.landArea, 0);

  const filteredCrops = crops.filter((crop) => {
    const matchesSearch =
      crop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      crop.hindiName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (crop.variety && crop.variety.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesSeason = filterSeason === 'all' || crop.season === filterSeason;
    const matchesStatus = filterStatus === 'all' || crop.status === filterStatus;

    return matchesSearch && matchesSeason && matchesStatus;
  });

  return (
    <div className="space-y-6 pb-20">
      {/* Farm Overview Glass Banner */}
      <div
        className={`relative rounded-3xl p-5 sm:p-6 border overflow-hidden ${
          isDark
            ? 'glass-panel text-white'
            : 'glass-panel-light text-neutral-900'
        }`}
      >
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
              <Sprout className="w-4 h-4" />
              <span>{lang === 'hi' ? 'खेत का संपूर्ण हिसाब-किताब' : 'Farm Portfolio Ledger'}</span>
              <span className="text-neutral-400">·</span>
              <span className="font-mono">
                {crops.length} {lang === 'hi' ? 'फसलें' : 'Crops'} ({totalLand} {lang === 'hi' ? 'एकड़' : 'Acres'})
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {lang === 'hi' ? 'मेरी फसलें व कुल मुनाफा' : 'My Crops & Net Profit'}
            </h1>
          </div>

          {/* Quick Summary Numbers */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="px-4 py-2.5 rounded-2xl bg-neutral-100/80 dark:bg-neutral-900/80 border border-neutral-200 dark:border-neutral-800">
              <span className="text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 block uppercase">
                {getTranslation(lang, 'totalLagat')}
              </span>
              <span className="text-lg font-bold font-mono text-rose-500 tabular-nums">
                {formatCurrency(totalFarmExpenses)}
              </span>
            </div>

            <div className="px-4 py-2.5 rounded-2xl bg-neutral-100/80 dark:bg-neutral-900/80 border border-neutral-200 dark:border-neutral-800">
              <span className="text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 block uppercase">
                {getTranslation(lang, 'totalKamai')}
              </span>
              <span className="text-lg font-bold font-mono text-emerald-500 tabular-nums">
                {formatCurrency(totalFarmIncome)}
              </span>
            </div>

            <div className="px-4 py-2.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30">
              <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-300 block uppercase">
                {netFarmProfit >= 0 ? getTranslation(lang, 'netProfit') : getTranslation(lang, 'netLoss')}
              </span>
              <span
                className={`text-lg font-extrabold font-mono tabular-nums ${
                  netFarmProfit >= 0 ? 'text-emerald-500' : 'text-rose-500'
                }`}
              >
                {netFarmProfit >= 0 ? '+' : ''}
                {formatCurrency(netFarmProfit)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={
              lang === 'hi'
                ? 'फसल खोजें (गेहूं, सरसों, किस्म)...'
                : 'Search crop by name or variety...'
            }
            className={`w-full pl-10 pr-4 py-2.5 rounded-2xl text-sm border focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
              isDark
                ? 'bg-neutral-900/80 border-neutral-800 text-white placeholder-neutral-500'
                : 'bg-white border-neutral-300 text-neutral-900 placeholder-neutral-400'
            }`}
          />
        </div>

        {/* Season and Status Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <select
            value={filterSeason}
            onChange={(e) => setFilterSeason(e.target.value)}
            className={`px-3 py-2 text-xs font-semibold rounded-xl border focus:outline-hidden ${
              isDark
                ? 'bg-neutral-900 border-neutral-800 text-neutral-200'
                : 'bg-white border-neutral-300 text-neutral-800'
            }`}
          >
            <option value="all">{lang === 'hi' ? 'सभी सीज़न' : 'All Seasons'}</option>
            <option value="rabi">रबी (Rabi)</option>
            <option value="kharif">खरीफ (Kharif)</option>
            <option value="zaid">जायद (Zaid)</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className={`px-3 py-2 text-xs font-semibold rounded-xl border focus:outline-hidden ${
              isDark
                ? 'bg-neutral-900 border-neutral-800 text-neutral-200'
                : 'bg-white border-neutral-300 text-neutral-800'
            }`}
          >
            <option value="all">{lang === 'hi' ? 'सभी स्थिति' : 'All Status'}</option>
            <option value="active">{getTranslation(lang, 'active')}</option>
            <option value="harvested">{getTranslation(lang, 'harvested')}</option>
          </select>

          <button
            onClick={onOpenAddCrop}
            className="btn-3d-primary flex items-center gap-1.5 px-4 py-2 rounded-xl text-white font-bold text-xs whitespace-nowrap cursor-pointer shadow-md"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>{getTranslation(lang, 'addCrop')}</span>
          </button>
        </div>
      </div>

      {/* Crop Cards Grid */}
      {filteredCrops.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {filteredCrops.map((crop) => (
            <CropCard
              key={crop.id}
              crop={crop}
              transactions={transactions}
              harvests={harvests}
              lang={lang}
              theme={theme}
              onSelect={onSelectCrop}
              onDelete={
                onDeleteCrop
                  ? (id, name) => setCropToDelete({ id, name })
                  : undefined
              }
            />
          ))}
        </div>
      ) : (
        <div
          className={`text-center py-16 px-4 rounded-3xl border ${
            isDark ? 'bg-neutral-900/40 border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center mb-4">
            <Sprout className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold mb-1">
            {lang === 'hi' ? 'कोई फसल नहीं मिली' : 'No Crops Found'}
          </h3>
          <p className="text-xs text-neutral-400 max-w-sm mx-auto mb-5">
            {lang === 'hi'
              ? 'खेत की फसल का हिसाब रखने के लिए नीचे दिए गए बटन से पहली फसल जोड़ें।'
              : 'Add your first crop to begin tracking expenses, mandi sales, and net profit.'}
          </p>
          <button
            onClick={onOpenAddCrop}
            className="btn-3d-primary inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-white font-bold text-sm cursor-pointer shadow-lg"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>{getTranslation(lang, 'addCrop')}</span>
          </button>
        </div>
      )}

      {/* Floating 3D Action Button for Quick Add Crop (User request: "ek + button jisse nay fasal add kr sake") */}
      <button
        onClick={onOpenAddCrop}
        aria-label="Add New Crop"
        className="fixed bottom-6 right-6 z-40 btn-3d-primary w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center text-white shadow-2xl cursor-pointer group"
      >
        <Plus className="w-8 h-8 stroke-[3] group-hover:rotate-90 transition-transform duration-200" />
      </button>

      {/* Confirm Delete Crop Modal */}
      <ConfirmModal
        isOpen={!!cropToDelete}
        title={lang === 'hi' ? 'फसल हटाएं?' : 'Delete Crop?'}
        message={
          lang === 'hi'
            ? `क्या आप सचमुच "${cropToDelete?.name}" फसल और इसके सभी दर्ज खर्च व कमाई का हिसाब हटाना चाहते हैं?`
            : `Are you sure you want to permanently delete "${cropToDelete?.name}" and all its transaction history?`
        }
        confirmLabel={lang === 'hi' ? 'हाँ, फसल हटाएं' : 'Yes, Delete'}
        cancelLabel={lang === 'hi' ? 'रद्द करें' : 'Cancel'}
        isDestructive={true}
        theme={theme}
        onConfirm={() => {
          if (cropToDelete && onDeleteCrop) {
            onDeleteCrop(cropToDelete.id);
          }
          setCropToDelete(null);
        }}
        onCancel={() => setCropToDelete(null)}
      />
    </div>
  );
};
