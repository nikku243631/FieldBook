import React, { useState } from 'react';
import { CropCycle, Transaction, HarvestEntry, Language, Theme } from '../types';
import { CropCard } from './CropCard';
import { ConfirmModal } from './ConfirmModal';
import { getTranslation, formatCurrency } from '../utils/translations';
import {
  PlusCircle,
  Search,
  Sprout,
  Wallet,
  BarChart2,
  TrendingUp,
  TrendingDown,
  Calendar,
  Filter,
  ChevronDown,
  Plus
} from 'lucide-react';

interface CropListProps {
  crops: CropCycle[];
  transactions: Transaction[];
  harvests: HarvestEntry[];
  lang: Language;
  theme: Theme;
  onSelectCrop: (cropId: string) => void;
  onOpenAddCrop: () => void;
  onDeleteCrop?: (cropId: string) => void;
}

export const CropList: React.FC<CropListProps> = ({
  crops,
  transactions,
  harvests,
  lang,
  theme,
  onSelectCrop,
  onOpenAddCrop,
  onDeleteCrop
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSeason, setFilterSeason] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [cropToDelete, setCropToDelete] = useState<{ id: string; name: string } | null>(null);

  const totalFarmExpenses = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalFarmIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const netFarmProfit = totalFarmIncome - totalFarmExpenses;
  const totalLand = Number(crops.reduce((sum, c) => sum + c.landArea, 0).toFixed(2));

  const filteredCrops = crops.filter((crop) => {
    const matchesSearch =
      crop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      crop.hindiName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (crop.variety && crop.variety.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesSeason = filterSeason === 'all' || crop.season === filterSeason;
    const matchesStatus = filterStatus === 'all' || crop.status === filterStatus;

    return matchesSearch && matchesSeason && matchesStatus;
  });

  return (
    <div className="space-y-3.5 pb-20">
      {/* Farm Portfolio Ledger — 3D Translucent Liquid Glass Summary Card */}
      <section className="liquid-glass-card rounded-[28px] p-4 sm:p-5">
        <div className="mb-3.5">
          <div className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-emerald-800 dark:text-emerald-300 mb-1">
            <Sprout className="w-4 h-4 shrink-0 text-emerald-700 dark:text-emerald-400" />
            <span>{lang === 'hi' ? 'खेत का संपूर्ण हिसाब-किताब' : 'Farm Portfolio Ledger'}</span>
            <span>·</span>
            <span>
              {crops.length} {lang === 'hi' ? 'फसलें' : 'Crops'} ({totalLand}{' '}
              {lang === 'hi' ? 'इकाई' : 'Units'})
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-950 dark:text-white">
            {lang === 'hi' ? 'मेरी फसलें व कुल मुनाफा' : 'My Crops & Net Profit'}
          </h1>
        </div>

        {/* 3 Translucent 3D Glass Financial Sub-Cards matching Reference Image */}
        <div className="grid grid-cols-3 gap-2.5 sm:gap-3.5">
          {/* 1. Total Expenses (Lagat) */}
          <div className="liquid-glass-expense rounded-2xl p-2.5 sm:p-3.5">
            <div className="flex items-start gap-1.5">
              <Wallet className="w-4 h-4 text-rose-700 dark:text-rose-300 shrink-0 mt-0.5" />
              <span className="text-[11px] sm:text-xs font-bold leading-tight text-rose-900 dark:text-rose-200">
                {lang === 'hi' ? 'कुल लागत (Lagat)' : 'Total Expenses (Lagat)'}
              </span>
            </div>
            <span className="text-base sm:text-xl font-black tabular-nums block text-rose-800 dark:text-rose-300 mt-1.5 truncate">
              {formatCurrency(totalFarmExpenses)}
            </span>
          </div>

          {/* 2. Total Income (Kamai) */}
          <div className="liquid-glass-income rounded-2xl p-2.5 sm:p-3.5">
            <div className="flex items-start gap-1.5">
              <BarChart2 className="w-4 h-4 text-emerald-800 dark:text-emerald-300 shrink-0 mt-0.5" />
              <span className="text-[11px] sm:text-xs font-bold leading-tight text-emerald-950 dark:text-emerald-200">
                {lang === 'hi' ? 'कुल कमाई (Kamai)' : 'Total Income (Kamai)'}
              </span>
            </div>
            <span className="text-base sm:text-xl font-black tabular-nums block text-emerald-900 dark:text-emerald-300 mt-1.5 truncate">
              {formatCurrency(totalFarmIncome)}
            </span>
          </div>

          {/* 3. Net Profit / Net Loss */}
          <div
            className={`rounded-2xl p-2.5 sm:p-3.5 ${
              netFarmProfit >= 0 ? 'liquid-glass-profit' : 'liquid-glass-expense'
            }`}
          >
            <div className="flex items-start gap-1.5">
              {netFarmProfit >= 0 ? (
                <TrendingUp className="w-4 h-4 text-blue-800 dark:text-blue-300 shrink-0 mt-0.5" />
              ) : (
                <TrendingDown className="w-4 h-4 text-rose-700 dark:text-rose-300 shrink-0 mt-0.5" />
              )}
              <span
                className={`text-[11px] sm:text-xs font-bold leading-tight ${
                  netFarmProfit >= 0
                    ? 'text-blue-950 dark:text-blue-200'
                    : 'text-rose-950 dark:text-rose-200'
                }`}
              >
                {netFarmProfit >= 0
                  ? getTranslation(lang, 'netProfit')
                  : getTranslation(lang, 'netLoss')}
              </span>
            </div>
            <span
              className={`text-base sm:text-xl font-black tabular-nums block mt-1.5 truncate ${
                netFarmProfit >= 0
                  ? 'text-blue-800 dark:text-blue-300'
                  : 'text-rose-800 dark:text-rose-300'
              }`}
            >
              {netFarmProfit >= 0 ? '+' : ''}
              {formatCurrency(netFarmProfit)}
            </span>
          </div>
        </div>
      </section>

      {/* Search Bar & Filter Controls matching Reference Image */}
      <div className="space-y-2.5">
        {/* Full-Width Rounded Pill Frosted Glass Search Input */}
        <div className="relative w-full">
          <Search className="w-4 h-4 sm:w-5 sm:h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-700 dark:text-slate-200 pointer-events-none z-10" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={
              lang === 'hi'
                ? 'फसल खोजें (गेहूं, सरसों, मिर्च, किस्म)...'
                : 'Search crop by name or variety...'
            }
            className="liquid-glass-input w-full pl-11 pr-4 py-2.5 sm:py-3 rounded-full text-xs sm:text-sm font-semibold focus:outline-hidden"
          />
        </div>

        {/* 3-Control Filter & Action Row: All Seasons | All Status | + Add New Crop */}
        <div className="grid grid-cols-3 gap-2 sm:flex sm:items-center sm:justify-between">
          {/* Season Filter Pill */}
          <div className="relative flex-1">
            <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-800 dark:text-slate-200 pointer-events-none z-10" />
            <select
              value={filterSeason}
              onChange={(e) => setFilterSeason(e.target.value)}
              aria-label={lang === 'hi' ? 'सीज़न चुनें' : 'Filter by season'}
              className="liquid-glass-pill w-full appearance-none pl-8 pr-6 py-2.5 rounded-full text-[11px] sm:text-xs font-extrabold cursor-pointer truncate"
            >
              <option value="all">{lang === 'hi' ? 'सभी सीज़न' : 'All Seasons'}</option>
              <option value="rabi">रबी (Rabi)</option>
              <option value="kharif">खरीफ (Kharif)</option>
              <option value="zaid">जायद (Zaid)</option>
              <option value="annual">वार्षिक (Annual)</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-700 dark:text-slate-300 pointer-events-none z-10" />
          </div>

          {/* Status Filter Pill */}
          <div className="relative flex-1">
            <Filter className="w-3.5 h-3.5 sm:w-4 sm:h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-800 dark:text-slate-200 pointer-events-none z-10" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              aria-label={lang === 'hi' ? 'स्थिति चुनें' : 'Filter by status'}
              className="liquid-glass-pill w-full appearance-none pl-8 pr-6 py-2.5 rounded-full text-[11px] sm:text-xs font-extrabold cursor-pointer truncate"
            >
              <option value="all">{lang === 'hi' ? 'सभी स्थिति' : 'All Status'}</option>
              <option value="active">{getTranslation(lang, 'active')}</option>
              <option value="harvested">{getTranslation(lang, 'harvested')}</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-700 dark:text-slate-300 pointer-events-none z-10" />
          </div>

          {/* + Add New Crop Primary Emerald 3D Glass Pill Button */}
          <button
            type="button"
            onClick={onOpenAddCrop}
            className="liquid-glass-emerald flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 sm:px-5 py-2.5 rounded-full text-white font-extrabold text-[11px] sm:text-xs whitespace-nowrap cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 shrink-0" />
            <span className="truncate">{getTranslation(lang, 'addCrop')}</span>
          </button>
        </div>
      </div>

      {/* Crop Cards Grid */}
      {filteredCrops.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCrops.map((crop) => (
            <CropCard
              key={crop.id}
              crop={crop}
              transactions={transactions}
              harvests={harvests}
              lang={lang}
              theme={theme}
              onSelect={onSelectCrop}
              onDelete={
                onDeleteCrop
                  ? (id, name) => setCropToDelete({ id, name })
                  : undefined
              }
            />
          ))}
        </div>
      ) : (
        <div className="liquid-glass-card text-center py-10 px-4 rounded-[28px]">
          <div className="w-12 h-12 mx-auto rounded-2xl liquid-glass-income text-emerald-800 dark:text-emerald-300 flex items-center justify-center mb-3">
            <Sprout className="w-6 h-6" />
          </div>
          <h3 className="text-base font-extrabold mb-1 text-slate-950 dark:text-white">
            {lang === 'hi' ? 'कोई फसल नहीं मिली' : 'No Crops Found'}
          </h3>
          <p className="text-xs font-medium text-slate-700 dark:text-slate-300 max-w-xs mx-auto mb-4">
            {lang === 'hi'
              ? 'खेत की फसल का हिसाब रखने के लिए नीचे दिए गए बटन से पहली फसल जोड़ें।'
              : 'Add your first crop to begin tracking expenses, mandi sales, and net profit.'}
          </p>
          <button
            type="button"
            onClick={onOpenAddCrop}
            className="liquid-glass-emerald inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-white font-bold text-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{getTranslation(lang, 'addCrop')}</span>
          </button>
        </div>
      )}

      {/* Confirm Delete Crop Modal */}
      <ConfirmModal
        isOpen={!!cropToDelete}
        title={lang === 'hi' ? 'फसल हटाएं?' : 'Delete Crop?'}
        message={
          lang === 'hi'
            ? `क्या आप सचमुच "${cropToDelete?.name}" फसल और इसके सभी दर्ज खर्च व कमाई का हिसाब हटाना चाहते हैं?`
            : `Are you sure you want to permanently delete "${cropToDelete?.name}" and all its transaction history?`
        }
        confirmLabel={lang === 'hi' ? 'हाँ, फसल हटाएं' : 'Yes, Delete'}
        cancelLabel={lang === 'hi' ? 'रद्द करें' : 'Cancel'}
        isDestructive={true}
        theme={theme}
        onConfirm={() => {
          if (cropToDelete && onDeleteCrop) {
            onDeleteCrop(cropToDelete.id);
          }
          setCropToDelete(null);
        }}
        onCancel={() => setCropToDelete(null)}
      />
    </div>
  );
};
