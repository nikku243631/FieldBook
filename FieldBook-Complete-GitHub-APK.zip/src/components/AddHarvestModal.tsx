import React, { useState, useEffect } from 'react';
import { X, Scale, Calendar, Clock, BookOpen } from 'lucide-react';
import { HarvestEntry, DiaryEntry, Language, Theme } from '../types';
import { getTranslation } from '../utils/translations';

interface AddHarvestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (harvest: Partial<HarvestEntry>) => void;
  cropId: string;
  harvestToEdit?: HarvestEntry | null;
  lang: Language;
  theme: Theme;
}

export const AddHarvestModal: React.FC<AddHarvestModalProps> = ({
  isOpen,
  onClose,
  onSave,
  cropId,
  harvestToEdit,
  lang,
  theme
}) => {
  const isDark = theme === 'dark';

  const now = new Date();
  const [date, setDate] = useState(now.toISOString().split('T')[0]);
  const [time, setTime] = useState(now.toTimeString().slice(0, 5));
  const [quantityQuintal, setQuantityQuintal] = useState<number | ''>('');
  const [moisturePercentage, setMoisturePercentage] = useState<number | ''>('');
  const [grade, setGrade] = useState('A-Grade (उत्कृष्ट)');
  const [storageLocation, setStorageLocation] = useState('घर का गोदाम / कोठार');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (harvestToEdit) {
      setDate(harvestToEdit.date || new Date().toISOString().split('T')[0]);
      setTime(harvestToEdit.time || new Date().toTimeString().slice(0, 5));
      setQuantityQuintal(harvestToEdit.quantityQuintal ?? '');
      setMoisturePercentage(harvestToEdit.moisturePercentage ?? '');
      setGrade(harvestToEdit.grade || 'A-Grade (उत्कृष्ट)');
      setStorageLocation(harvestToEdit.storageLocation || 'घर का गोदाम / कोठार');
      setNotes(harvestToEdit.notes || '');
    } else {
      const currentNow = new Date();
      setDate(currentNow.toISOString().split('T')[0]);
      setTime(currentNow.toTimeString().slice(0, 5));
      setQuantityQuintal('');
      setMoisturePercentage('');
      setGrade('A-Grade (उत्कृष्ट)');
      setStorageLocation('घर का गोदाम / कोठार');
      setNotes('');
    }
  }, [isOpen, harvestToEdit]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quantityQuintal || Number(quantityQuintal) <= 0) return;

    onSave({
      id: harvestToEdit?.id,
      cropId,
      date,
      time,
      quantityQuintal: Number(Number(quantityQuintal).toFixed(2)),
      moisturePercentage:
        moisturePercentage && Number(moisturePercentage) >= 0
          ? Number(moisturePercentage)
          : undefined,
      grade,
      storageLocation,
      notes: notes.trim() || undefined
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md overflow-y-auto">
      <div
        className={`w-full max-w-md rounded-2xl border p-5 sm:p-6 shadow-2xl transition-all my-8 ${
          isDark
            ? 'bg-neutral-900 border-emerald-500/30 text-white'
            : 'bg-white border-emerald-300 text-neutral-900'
        }`}
      >
        <div className="flex items-center justify-between pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold">
              {harvestToEdit
                ? lang === 'hi'
                  ? 'कटाई वजन संशोधित करें'
                  : 'Edit Harvest Entry'
                : getTranslation(lang, 'addHarvest')}
            </h2>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-neutral-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1">
              {getTranslation(lang, 'quantityQuintal')} *
            </label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              required
              autoFocus
              value={quantityQuintal}
              onChange={(e) => setQuantityQuintal(e.target.value === '' ? '' : parseFloat(e.target.value))}
              placeholder="उदा. 45.5"
              className={`w-full px-3 py-2.5 rounded-xl text-base font-mono font-bold tabular-nums border text-emerald-400 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                isDark ? 'bg-neutral-800 border-neutral-700' : 'bg-neutral-50 border-neutral-300'
              }`}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'date')}
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-sm font-mono tabular-nums border ${
                  isDark ? 'bg-neutral-800 border-neutral-700 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'moisturePercentage')}
              </label>
              <input
                type="number"
                step="0.5"
                min="0"
                max="100"
                placeholder="12%"
                value={moisturePercentage}
                onChange={(e) => setMoisturePercentage(e.target.value === '' ? '' : parseFloat(e.target.value))}
                className={`w-full px-3 py-2 rounded-xl text-sm font-mono tabular-nums border ${
                  isDark ? 'bg-neutral-800 border-neutral-700 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'grade')}
              </label>
              <select
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-sm border ${
                  isDark ? 'bg-neutral-800 border-neutral-700 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              >
                <option value="A-Grade (उत्कृष्ट)">A-Grade (उत्कृष्ट / Super)</option>
                <option value="B-Grade (मध्यम)">B-Grade (मध्यम / Medium)</option>
                <option value="C-Grade (सामान्य)">C-Grade (सामान्य / Fair)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                रखने का स्थान
              </label>
              <input
                type="text"
                value={storageLocation}
                onChange={(e) => setStorageLocation(e.target.value)}
                placeholder="मंडी / घर का गोदाम"
                className={`w-full px-3 py-2 rounded-xl text-sm border ${
                  isDark ? 'bg-neutral-800 border-neutral-700 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1">
              {getTranslation(lang, 'notes')}
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="थ्रेशर से कटाई, कट्टे भरे..."
              className={`w-full px-3 py-2 rounded-xl text-sm border ${
                isDark ? 'bg-neutral-800 border-neutral-700 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
              }`}
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-200 dark:border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-sm font-semibold text-neutral-400 hover:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className="btn-3d-primary px-6 py-2.5 rounded-xl text-white font-bold text-sm shadow-lg cursor-pointer"
            >
              {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface AddDiaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (entry: Partial<DiaryEntry>) => void;
  cropId: string;
  diaryToEdit?: DiaryEntry | null;
  lang: Language;
  theme: Theme;
}

export const AddDiaryModal: React.FC<AddDiaryModalProps> = ({
  isOpen,
  onClose,
  onSave,
  cropId,
  diaryToEdit,
  lang,
  theme
}) => {
  const isDark = theme === 'dark';

  const now = new Date();
  const [date, setDate] = useState(now.toISOString().split('T')[0]);
  const [time, setTime] = useState(now.toTimeString().slice(0, 5));
  const [activityType, setActivityType] = useState<DiaryEntry['activityType']>('irrigation');
  const [notes, setNotes] = useState('');
  const [weatherNote, setWeatherNote] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (diaryToEdit) {
      setDate(diaryToEdit.date || new Date().toISOString().split('T')[0]);
      setTime(diaryToEdit.time || new Date().toTimeString().slice(0, 5));
      setActivityType(diaryToEdit.activityType || 'irrigation');
      setNotes(diaryToEdit.notes || '');
      setWeatherNote(diaryToEdit.weatherNote || '');
    } else {
      const currentNow = new Date();
      setDate(currentNow.toISOString().split('T')[0]);
      setTime(currentNow.toTimeString().slice(0, 5));
      setActivityType('irrigation');
      setNotes('');
      setWeatherNote('');
    }
  }, [isOpen, diaryToEdit]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notes.trim()) return;

    onSave({
      id: diaryToEdit?.id,
      cropId,
      date,
      time,
      activityType,
      notes: notes.trim(),
      weatherNote: weatherNote.trim() || undefined
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md overflow-y-auto">
      <div
        className={`w-full max-w-md rounded-2xl border p-5 sm:p-6 shadow-2xl transition-all my-8 ${
          isDark
            ? 'bg-neutral-900 border-emerald-500/30 text-white'
            : 'bg-white border-emerald-300 text-neutral-900'
        }`}
      >
        <div className="flex items-center justify-between pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold">
              {diaryToEdit
                ? lang === 'hi'
                  ? 'खेत डायरी नोट संशोधित करें'
                  : 'Edit Diary Note'
                : getTranslation(lang, 'addDiary')}
            </h2>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-neutral-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1">
              {getTranslation(lang, 'activityType')}
            </label>
            <select
              value={activityType}
              onChange={(e) => setActivityType(e.target.value as any)}
              className={`w-full px-3 py-2 rounded-xl text-sm border ${
                isDark ? 'bg-neutral-800 border-neutral-700 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
              }`}
            >
              <option value="irrigation">{getTranslation(lang, 'activityIrrigation')}</option>
              <option value="fertilizer">{getTranslation(lang, 'activityFertilizer')}</option>
              <option value="spray">{getTranslation(lang, 'activitySpray')}</option>
              <option value="sowing">{getTranslation(lang, 'activitySowing')}</option>
              <option value="inspection">{getTranslation(lang, 'activityInspection')}</option>
              <option value="harvest">{getTranslation(lang, 'activityHarvest')}</option>
              <option value="weeding">{getTranslation(lang, 'activityWeeding')}</option>
              <option value="other">अन्य कार्य</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                {getTranslation(lang, 'date')}
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-sm font-mono tabular-nums border ${
                  isDark ? 'bg-neutral-800 border-neutral-700 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-400 block mb-1">
                मौसम की स्थिति
              </label>
              <input
                type="text"
                placeholder="साफ धूप, हल्की हवा"
                value={weatherNote}
                onChange={(e) => setWeatherNote(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-sm border ${
                  isDark ? 'bg-neutral-800 border-neutral-700 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                }`}
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1">
              कार्य का पूरा विवरण *
            </label>
            <textarea
              rows={3}
              required
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="उदा. 21 दिन पर पहली सिंचाई दी, 2 बैग यूरिया दिया, फसल का फुटाव अच्छा दिख रहा है..."
              className={`w-full px-3 py-2 rounded-xl text-sm border resize-none focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                isDark ? 'bg-neutral-800 border-neutral-700 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
              }`}
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-200 dark:border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-sm font-semibold text-neutral-400 hover:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className="btn-3d-primary px-6 py-2.5 rounded-xl text-white font-bold text-sm shadow-lg cursor-pointer"
            >
              {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
