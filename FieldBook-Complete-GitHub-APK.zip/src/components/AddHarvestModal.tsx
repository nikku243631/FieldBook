import React, { useState, useEffect } from 'react';
import { X, Scale, BookOpen, Calendar, CloudSun, Warehouse, FileText } from 'lucide-react';
import { HarvestEntry, DiaryEntry, Language, Theme } from '../types';
import { getTranslation } from '../utils/translations';

interface AddHarvestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (harvest: Partial<HarvestEntry>) => void;
  cropId: string;
  harvestToEdit?: HarvestEntry | null;
  lang: Language;
  theme: Theme;
}

export const AddHarvestModal: React.FC<AddHarvestModalProps> = ({
  isOpen,
  onClose,
  onSave,
  cropId,
  harvestToEdit,
  lang
}) => {
  const now = new Date();
  const [date, setDate] = useState(now.toISOString().split('T')[0]);
  const [time, setTime] = useState(now.toTimeString().slice(0, 5));
  const [quantityQuintal, setQuantityQuintal] = useState<number | ''>('');
  const [moisturePercentage, setMoisturePercentage] = useState<number | ''>('');
  const [grade, setGrade] = useState('A-Grade (उत्कृष्ट)');
  const [storageLocation, setStorageLocation] = useState('घर का गोदाम / कोठार');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (harvestToEdit) {
      setDate(harvestToEdit.date || new Date().toISOString().split('T')[0]);
      setTime(harvestToEdit.time || new Date().toTimeString().slice(0, 5));
      setQuantityQuintal(harvestToEdit.quantityQuintal ?? '');
      setMoisturePercentage(harvestToEdit.moisturePercentage ?? '');
      setGrade(harvestToEdit.grade || 'A-Grade (उत्कृष्ट)');
      setStorageLocation(harvestToEdit.storageLocation || 'घर का गोदाम / कोठार');
      setNotes(harvestToEdit.notes || '');
    } else {
      const currentNow = new Date();
      setDate(currentNow.toISOString().split('T')[0]);
      setTime(currentNow.toTimeString().slice(0, 5));
      setQuantityQuintal('');
      setMoisturePercentage('');
      setGrade('A-Grade (उत्कृष्ट)');
      setStorageLocation('घर का गोदाम / कोठार');
      setNotes('');
    }
  }, [isOpen, harvestToEdit]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quantityQuintal || Number(quantityQuintal) <= 0) return;

    onSave({
      id: harvestToEdit?.id,
      cropId,
      date,
      time,
      quantityQuintal: Number(Number(quantityQuintal).toFixed(2)),
      moisturePercentage:
        moisturePercentage && Number(moisturePercentage) >= 0
          ? Number(moisturePercentage)
          : undefined,
      grade,
      storageLocation,
      notes: notes.trim() || undefined
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/60 backdrop-blur-md overflow-y-auto">
      <div className="liquid-glass-modal w-full max-w-md rounded-3xl p-4 sm:p-5 my-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 mb-3.5 border-b-2 border-amber-500/35">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl btn-3d-amber text-white flex items-center justify-center shrink-0">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-950 dark:text-white leading-tight">
                {harvestToEdit
                  ? lang === 'hi'
                    ? 'कटाई वजन संशोधित करें'
                    : 'Edit Harvest Entry'
                  : getTranslation(lang, 'addHarvest')}
              </h2>
              <p className="text-xs font-bold text-amber-950 dark:text-amber-300">
                {lang === 'hi'
                  ? '✍️ पैदावार वजन और गोदाम का विवरण दर्ज करें'
                  : '✍️ Enter yield weight and storage details below'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="liquid-glass-income rounded-2xl p-3.5 space-y-3">
            <div>
              <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                🌾 {getTranslation(lang, 'quantityQuintal')} *
              </label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                required
                autoFocus
                value={quantityQuintal}
                onChange={(e) =>
                  setQuantityQuintal(e.target.value === '' ? '' : parseFloat(e.target.value))
                }
                placeholder="उदा. 45.5 क्विंटल"
                className="input-3d-amber w-full px-3.5 py-2.5 rounded-xl text-base font-mono font-extrabold tabular-nums text-slate-950 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{getTranslation(lang, 'date')}</span>
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="liquid-glass-input w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  💧 {getTranslation(lang, 'moisturePercentage')}
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  max="100"
                  placeholder="12%"
                  value={moisturePercentage}
                  onChange={(e) =>
                    setMoisturePercentage(e.target.value === '' ? '' : parseFloat(e.target.value))
                  }
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                />
              </div>
            </div>
          </div>

          <div className="liquid-glass-profit rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  ⭐ {getTranslation(lang, 'grade')}
                </label>
                <select
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  className="input-3d-amber w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-extrabold"
                >
                  <option value="A-Grade (उत्कृष्ट)">A-Grade (उत्कृष्ट / Super)</option>
                  <option value="B-Grade (मध्यम)">B-Grade (मध्यम / Medium)</option>
                  <option value="C-Grade (सामान्य)">C-Grade (सामान्य / Fair)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <Warehouse className="w-3.5 h-3.5 text-blue-700" />
                  <span>रखने का स्थान (Storage)</span>
                </label>
                <input
                  type="text"
                  value={storageLocation}
                  onChange={(e) => setStorageLocation(e.target.value)}
                  placeholder="मंडी / घर का गोदाम"
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-bold"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                <FileText className="w-3.5 h-3.5 text-emerald-700" />
                <span>{getTranslation(lang, 'notes')}</span>
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="थ्रेशर से कटाई, कट्टे भरे..."
                className="liquid-glass-input w-full px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="liquid-glass-pill px-5 py-2.5 rounded-full text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className="btn-3d-amber px-6 py-2.5 rounded-full text-white font-extrabold text-xs sm:text-sm shadow-md cursor-pointer"
            >
              ✓ {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface AddDiaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (entry: Partial<DiaryEntry>) => void;
  cropId: string;
  diaryToEdit?: DiaryEntry | null;
  lang: Language;
  theme: Theme;
}

export const AddDiaryModal: React.FC<AddDiaryModalProps> = ({
  isOpen,
  onClose,
  onSave,
  cropId,
  diaryToEdit,
  lang
}) => {
  const now = new Date();
  const [date, setDate] = useState(now.toISOString().split('T')[0]);
  const [time, setTime] = useState(now.toTimeString().slice(0, 5));
  const [activityType, setActivityType] = useState<DiaryEntry['activityType']>('irrigation');
  const [notes, setNotes] = useState('');
  const [weatherNote, setWeatherNote] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (diaryToEdit) {
      setDate(diaryToEdit.date || new Date().toISOString().split('T')[0]);
      setTime(diaryToEdit.time || new Date().toTimeString().slice(0, 5));
      setActivityType(diaryToEdit.activityType || 'irrigation');
      setNotes(diaryToEdit.notes || '');
      setWeatherNote(diaryToEdit.weatherNote || '');
    } else {
      const currentNow = new Date();
      setDate(currentNow.toISOString().split('T')[0]);
      setTime(currentNow.toTimeString().slice(0, 5));
      setActivityType('irrigation');
      setNotes('');
      setWeatherNote('');
    }
  }, [isOpen, diaryToEdit]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notes.trim()) return;

    onSave({
      id: diaryToEdit?.id,
      cropId,
      date,
      time,
      activityType,
      notes: notes.trim(),
      weatherNote: weatherNote.trim() || undefined
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/60 backdrop-blur-md overflow-y-auto">
      <div className="liquid-glass-modal w-full max-w-md rounded-3xl p-4 sm:p-5 my-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 mb-3.5 border-b-2 border-blue-500/35">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl btn-3d-blue text-white flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-950 dark:text-white leading-tight">
                {diaryToEdit
                  ? lang === 'hi'
                    ? 'खेत डायरी नोट संशोधित करें'
                    : 'Edit Diary Note'
                  : getTranslation(lang, 'addDiary')}
              </h2>
              <p className="text-xs font-bold text-blue-950 dark:text-blue-300">
                {lang === 'hi'
                  ? '✍️ खेत के कार्य और मौसम का नोट दर्ज करें'
                  : '✍️ Log field activity and weather observations'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="liquid-glass-profit rounded-2xl p-3.5 space-y-3">
            <div>
              <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                🚜 {getTranslation(lang, 'activityType')}
              </label>
              <select
                value={activityType}
                onChange={(e) => setActivityType(e.target.value as any)}
                className="input-3d-sky w-full px-3.5 py-2.5 rounded-xl text-sm font-extrabold"
              >
                <option value="irrigation">{getTranslation(lang, 'activityIrrigation')}</option>
                <option value="fertilizer">{getTranslation(lang, 'activityFertilizer')}</option>
                <option value="spray">{getTranslation(lang, 'activitySpray')}</option>
                <option value="sowing">{getTranslation(lang, 'activitySowing')}</option>
                <option value="inspection">{getTranslation(lang, 'activityInspection')}</option>
                <option value="harvest">{getTranslation(lang, 'activityHarvest')}</option>
                <option value="weeding">{getTranslation(lang, 'activityWeeding')}</option>
                <option value="other">अन्य कार्य</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-blue-700" />
                  <span>{getTranslation(lang, 'date')}</span>
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <CloudSun className="w-3.5 h-3.5 text-amber-600" />
                  <span>मौसम की स्थिति</span>
                </label>
                <input
                  type="text"
                  placeholder="साफ धूप, हल्की हवा"
                  value={weatherNote}
                  onChange={(e) => setWeatherNote(e.target.value)}
                  className="input-3d-amber w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-bold"
                />
              </div>
            </div>
          </div>

          <div className="liquid-glass-income rounded-2xl p-3.5">
            <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
              ✍️ कार्य का पूरा विवरण *
            </label>
            <textarea
              rows={3}
              required
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="उदा. 21 दिन पर पहली सिंचाई दी, 2 बैग यूरिया दिया, फसल का फुटाव अच्छा दिख रहा है..."
              className="liquid-glass-input w-full px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="liquid-glass-pill px-5 py-2.5 rounded-full text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className="btn-3d-blue px-6 py-2.5 rounded-full text-white font-extrabold text-xs sm:text-sm shadow-md cursor-pointer"
            >
              ✓ {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
