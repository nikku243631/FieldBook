import React, { useState } from 'react';
import {
  FileText,
  ShoppingBag,
  Plus,
  Search,
  Pin,
  Trash2,
  Edit2,
  Share2,
  CheckCircle2,
  Circle,
  Calendar,
  Clock,
  Tag,
  DollarSign,
  AlertCircle,
  Check,
  Package,
  Layers,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { Language, Theme, FarmNote, ShoppingItem } from '../types';
import { Storage } from '../utils/storage';
import { ConfirmModal } from './ConfirmModal';

interface NotesAndListsViewProps {
  lang: Language;
  theme: Theme;
  notes: FarmNote[];
  shoppingItems: ShoppingItem[];
  onUpdateNotes: (notes: FarmNote[]) => void;
  onUpdateShoppingItems: (items: ShoppingItem[]) => void;
  onOpenSimpleCalc?: () => void;
}

export const NotesAndListsView: React.FC<NotesAndListsViewProps> = ({
  lang,
  theme,
  notes,
  shoppingItems,
  onUpdateNotes,
  onUpdateShoppingItems,
  onOpenSimpleCalc
}) => {
  const isDark = theme === 'dark';
  const isHindi = lang === 'hi';

  const [activeSubTab, setActiveSubTab] = useState<'notes' | 'shopping'>('notes');

  // Notes state
  const [noteSearch, setNoteSearch] = useState('');
  const [selectedNoteCategory, setSelectedNoteCategory] = useState<string>('all');
  const [isAddNoteOpen, setIsAddNoteOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<FarmNote | null>(null);
  const [noteToDelete, setNoteToDelete] = useState<FarmNote | null>(null);

  // New/Edit Note Form
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [noteCategory, setNoteCategory] = useState<FarmNote['category']>('reminder');
  const [noteColor, setNoteColor] = useState<string>('emerald');
  const [noteIsPinned, setNoteIsPinned] = useState(false);
  const [noteDate, setNoteDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [noteTime, setNoteTime] = useState(() => new Date().toTimeString().slice(0, 5));

  // Shopping state
  const [shoppingFilter, setShoppingFilter] = useState<'all' | 'pending' | 'purchased'>('all');
  const [shoppingCategoryFilter, setShoppingCategoryFilter] = useState<string>('all');
  const [isAddShoppingOpen, setIsAddShoppingOpen] = useState(false);
  const [editingShoppingItem, setEditingShoppingItem] = useState<ShoppingItem | null>(null);
  const [itemToDelete, setItemToDelete] = useState<ShoppingItem | null>(null);

  // New/Edit Shopping Form
  const [itemName, setItemName] = useState('');
  const [itemCategory, setItemCategory] = useState<ShoppingItem['category']>('fertilizer');
  const [itemQuantity, setItemQuantity] = useState<number>(1);
  const [itemUnit, setItemUnit] = useState('बोरी (Bags)');
  const [itemEstimatedCost, setItemEstimatedCost] = useState<string>('');
  const [itemActualCost, setItemActualCost] = useState<string>('');
  const [itemNotes, setItemNotes] = useState('');

  // ---------------- NOTE HANDLERS ----------------
  const handleOpenAddNote = (noteToEdit?: FarmNote) => {
    if (noteToEdit) {
      setEditingNote(noteToEdit);
      setNoteTitle(noteToEdit.title);
      setNoteContent(noteToEdit.content);
      setNoteCategory(noteToEdit.category);
      setNoteColor(noteToEdit.color || 'emerald');
      setNoteIsPinned(noteToEdit.isPinned);
      setNoteDate(noteToEdit.date);
      setNoteTime(noteToEdit.time);
    } else {
      setEditingNote(null);
      setNoteTitle('');
      setNoteContent('');
      setNoteCategory('reminder');
      setNoteColor('emerald');
      setNoteIsPinned(false);
      setNoteDate(new Date().toISOString().split('T')[0]);
      setNoteTime(new Date().toTimeString().slice(0, 5));
    }
    setIsAddNoteOpen(true);
  };

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim() && !noteContent.trim()) return;

    if (editingNote) {
      const updated = notes.map((n) =>
        n.id === editingNote.id
          ? {
              ...n,
              title: noteTitle.trim() || (isHindi ? 'नोट' : 'Note'),
              content: noteContent.trim(),
              category: noteCategory,
              color: noteColor,
              isPinned: noteIsPinned,
              date: noteDate,
              time: noteTime,
              updatedAt: new Date().toISOString()
            }
          : n
      );
      onUpdateNotes(updated);
      Storage.saveNotes(updated);
    } else {
      const newNote: FarmNote = {
        id: `note-${Date.now()}`,
        title: noteTitle.trim() || (isHindi ? 'नया नोट' : 'New Note'),
        content: noteContent.trim(),
        category: noteCategory,
        color: noteColor,
        isPinned: noteIsPinned,
        date: noteDate,
        time: noteTime,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      const updated = [newNote, ...notes];
      onUpdateNotes(updated);
      Storage.saveNotes(updated);
    }

    setIsAddNoteOpen(false);
    setEditingNote(null);
  };

  const handleTogglePin = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = notes.map((n) => (n.id === id ? { ...n, isPinned: !n.isPinned } : n));
    onUpdateNotes(updated);
    Storage.saveNotes(updated);
  };

  const handleDeleteNoteConfirm = () => {
    if (!noteToDelete) return;
    const updated = notes.filter((n) => n.id !== noteToDelete.id);
    onUpdateNotes(updated);
    Storage.saveNotes(updated);
    setNoteToDelete(null);
  };

  const handleShareNoteWhatsApp = (note: FarmNote, e: React.MouseEvent) => {
    e.stopPropagation();
    const text = `*FieldBook खेत नोट: ${note.title}*\n\n${note.content}\n\nतारीख: ${note.date} ${note.time}\n(FieldBook - Mr Nikhil)`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // Filtered Notes
  const filteredNotes = notes
    .filter((n) => {
      const matchesSearch =
        n.title.toLowerCase().includes(noteSearch.toLowerCase()) ||
        n.content.toLowerCase().includes(noteSearch.toLowerCase());
      const matchesCat = selectedNoteCategory === 'all' || n.category === selectedNoteCategory;
      return matchesSearch && matchesCat;
    })
    .sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  // ---------------- SHOPPING LIST HANDLERS ----------------
  const handleOpenAddShopping = (itemToEdit?: ShoppingItem) => {
    if (itemToEdit) {
      setEditingShoppingItem(itemToEdit);
      setItemName(itemToEdit.name);
      setItemCategory(itemToEdit.category);
      setItemQuantity(itemToEdit.quantity);
      setItemUnit(itemToEdit.unit);
      setItemEstimatedCost(itemToEdit.estimatedCost ? String(itemToEdit.estimatedCost) : '');
      setItemActualCost(itemToEdit.actualCost ? String(itemToEdit.actualCost) : '');
      setItemNotes(itemToEdit.notes || '');
    } else {
      setEditingShoppingItem(null);
      setItemName('');
      setItemCategory('fertilizer');
      setItemQuantity(1);
      setItemUnit(isHindi ? 'बोरी' : 'Bags');
      setItemEstimatedCost('');
      setItemActualCost('');
      setItemNotes('');
    }
    setIsAddShoppingOpen(true);
  };

  const handleSaveShoppingItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName.trim()) return;

    const estCostNum = itemEstimatedCost ? parseFloat(itemEstimatedCost) : undefined;
    const actCostNum = itemActualCost ? parseFloat(itemActualCost) : undefined;

    if (editingShoppingItem) {
      const updated = shoppingItems.map((item) =>
        item.id === editingShoppingItem.id
          ? {
              ...item,
              name: itemName.trim(),
              category: itemCategory,
              quantity: itemQuantity || 1,
              unit: itemUnit,
              estimatedCost: estCostNum,
              actualCost: actCostNum,
              notes: itemNotes.trim() || undefined
            }
          : item
      );
      onUpdateShoppingItems(updated);
      Storage.saveShoppingItems(updated);
    } else {
      const newItem: ShoppingItem = {
        id: `shop-${Date.now()}`,
        name: itemName.trim(),
        category: itemCategory,
        quantity: itemQuantity || 1,
        unit: itemUnit,
        estimatedCost: estCostNum,
        actualCost: actCostNum,
        isPurchased: false,
        notes: itemNotes.trim() || undefined,
        date: new Date().toISOString().split('T')[0],
        createdAt: new Date().toISOString()
      };
      const updated = [newItem, ...shoppingItems];
      onUpdateShoppingItems(updated);
      Storage.saveShoppingItems(updated);
    }

    setIsAddShoppingOpen(false);
    setEditingShoppingItem(null);
  };

  const handleTogglePurchase = (id: string) => {
    const updated = shoppingItems.map((item) =>
      item.id === id ? { ...item, isPurchased: !item.isPurchased } : item
    );
    onUpdateShoppingItems(updated);
    Storage.saveShoppingItems(updated);
  };

  const handleDeleteShoppingItemConfirm = () => {
    if (!itemToDelete) return;
    const updated = shoppingItems.filter((i) => i.id !== itemToDelete.id);
    onUpdateShoppingItems(updated);
    Storage.saveShoppingItems(updated);
    setItemToDelete(null);
  };

  const handleClearCompletedShopping = () => {
    const updated = shoppingItems.filter((i) => !i.isPurchased);
    onUpdateShoppingItems(updated);
    Storage.saveShoppingItems(updated);
  };

  const handleShareShoppingWhatsApp = () => {
    const pending = shoppingItems.filter((i) => !i.isPurchased);
    const purchased = shoppingItems.filter((i) => i.isPurchased);
    
    let text = `*FieldBook कृषि खरीदारी लिस्ट (सामान की सूची)*\n\n`;
    
    if (pending.length > 0) {
      text += `*खरीदना बाकी (${pending.length}):*\n`;
      pending.forEach((item, index) => {
        text += `${index + 1}. ${item.name} - ${item.quantity} ${item.unit}${
          item.estimatedCost ? ` (लगभग ₹${item.estimatedCost})` : ''
        }\n`;
      });
    }

    if (purchased.length > 0) {
      text += `\n*खरीद लिया (${purchased.length}):*\n`;
      purchased.forEach((item, index) => {
        text += `✓ ${item.name} - ${item.quantity} ${item.unit}${
          item.actualCost ? ` (₹${item.actualCost})` : ''
        }\n`;
      });
    }

    const totalEst = shoppingItems.reduce((sum, item) => sum + (item.estimatedCost || 0), 0);
    text += `\n*कुल संभावित खर्च:* ₹${totalEst.toLocaleString('en-IN')}\n(FieldBook - Mr Nikhil)`;

    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // Filtered Shopping Items
  const filteredShopping = shoppingItems.filter((item) => {
    const matchesStatus =
      shoppingFilter === 'all'
        ? true
        : shoppingFilter === 'pending'
        ? !item.isPurchased
        : item.isPurchased;
    const matchesCategory =
      shoppingCategoryFilter === 'all' || item.category === shoppingCategoryFilter;
    return matchesStatus && matchesCategory;
  });

  const totalShoppingEstimated = shoppingItems.reduce((acc, item) => acc + (item.estimatedCost || 0), 0);
  const totalShoppingActual = shoppingItems.reduce((acc, item) => acc + (item.actualCost || 0), 0);
  const pendingCount = shoppingItems.filter((i) => !i.isPurchased).length;
  const purchasedCount = shoppingItems.filter((i) => i.isPurchased).length;

  const categoryLabels: Record<FarmNote['category'], { hi: string; en: string }> = {
    reminder: { hi: 'ज़रूरी याददाश्त', en: 'Reminder' },
    field_work: { hi: 'खेत काम / जुताई', en: 'Field Work' },
    payment: { hi: 'लेन-देन / उधारी', en: 'Payment / Debt' },
    spray: { hi: 'दवाई व स्प्रे', en: 'Spray & Medicine' },
    general: { hi: 'सामान्य', en: 'General' }
  };

  const shoppingCategoryLabels: Record<ShoppingItem['category'], { hi: string; en: string }> = {
    fertilizer: { hi: 'खाद (Fertilizer)', en: 'Fertilizer' },
    seeds: { hi: 'बीज (Seeds)', en: 'Seeds' },
    pesticide: { hi: 'कीटनाशक व दवाई', en: 'Pesticide' },
    machinery_tools: { hi: 'ट्रैक्टर / उपकरण', en: 'Machinery/Tools' },
    irrigation: { hi: 'सिंचाई व पाइप', en: 'Irrigation' },
    general: { hi: 'अन्य सामान', en: 'General' }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Page Header */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border ${
          isDark
            ? 'glass-card text-white border-emerald-900/30'
            : 'glass-card-light text-neutral-900 border-emerald-200/60'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
              <FileText className="w-4 h-4" />
              <span>{isHindi ? 'खेत नोट्स व सामान सूची' : 'Farm Notes & Shopping List'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {isHindi ? 'याददाश्त नोट्स व खरीदारी लिस्ट' : 'Daily Notes & Farm Purchases'}
            </h1>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl">
              {isHindi
                ? 'खाद-बीज की दुकान का हिसाब, ट्यूबवेल की बात, उधारी-बाकी और बाज़ार से लाने वाले सामान की पक्की लिस्ट बनाएं।'
                : 'Jot down field notes, fertilizer supplier reminders, and maintain an agri shopping checklist.'}
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 self-start sm:self-auto">
            {onOpenSimpleCalc && (
              <button
                onClick={onOpenSimpleCalc}
                className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 cursor-pointer ${
                  isDark
                    ? 'bg-neutral-900 border-neutral-800 text-emerald-400 hover:border-emerald-500'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-800 hover:border-emerald-400'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>{isHindi ? 'कैलकुलेटर खोलें' : 'Open Calc'}</span>
              </button>
            )}

            {activeSubTab === 'notes' ? (
              <button
                onClick={() => handleOpenAddNote()}
                className="btn-3d-primary px-4 py-2.5 rounded-xl text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-600/20"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? '+ नया नोट लिखें' : '+ Add Note'}</span>
              </button>
            ) : (
              <button
                onClick={() => handleOpenAddShopping()}
                className="btn-3d-primary px-4 py-2.5 rounded-xl text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-600/20"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? '+ सामान जोड़ें' : '+ Add Item'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Sub-Tab Navigation Bar */}
        <div className="flex items-center gap-2 mt-6 pt-4 border-t border-neutral-800/40">
          <button
            onClick={() => setActiveSubTab('notes')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'notes'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800/40'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>{isHindi ? 'खेत नोट्स (Diary Notes)' : 'Farm Notes'}</span>
            <span
              className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${
                activeSubTab === 'notes' ? 'bg-emerald-800 text-white' : 'bg-neutral-800 text-neutral-300'
              }`}
            >
              {notes.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('shopping')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'shopping'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800/40'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>{isHindi ? 'सामान / खरीदारी लिस्ट (Saman List)' : 'Shopping List'}</span>
            <span
              className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${
                activeSubTab === 'shopping' ? 'bg-emerald-800 text-white' : 'bg-neutral-800 text-neutral-300'
              }`}
            >
              {pendingCount > 0 ? `${pendingCount} बाकी` : `${shoppingItems.length}`}
            </span>
          </button>
        </div>
      </div>

      {/* ===================== TAB 1: NOTES SECTION ===================== */}
      {activeSubTab === 'notes' && (
        <div className="space-y-4">
          {/* Controls: Search & Category Pills */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="text"
                value={noteSearch}
                onChange={(e) => setNoteSearch(e.target.value)}
                placeholder={isHindi ? 'नोट्स में खोजें (उदा. यूरिया, बदायूं, पानी)...' : 'Search notes...'}
                className={`w-full pl-10 pr-4 py-2 rounded-xl border text-xs font-medium focus:outline-hidden focus:border-emerald-500 transition-colors ${
                  isDark
                    ? 'bg-neutral-900/80 border-neutral-800 text-white placeholder-neutral-500'
                    : 'bg-white border-neutral-300 text-neutral-900 placeholder-neutral-400'
                }`}
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {['all', 'reminder', 'field_work', 'payment', 'spray', 'general'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedNoteCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                    selectedNoteCategory === cat
                      ? 'bg-emerald-600 text-white'
                      : isDark
                      ? 'bg-neutral-900/60 text-neutral-400 border border-neutral-800 hover:text-white'
                      : 'bg-neutral-100 text-neutral-600 border border-neutral-200 hover:text-neutral-900'
                  }`}
                >
                  {cat === 'all'
                    ? isHindi
                      ? 'सभी'
                      : 'All'
                    : categoryLabels[cat as FarmNote['category']][lang]}
                </button>
              ))}
            </div>
          </div>

          {/* Notes Grid */}
          {filteredNotes.length === 0 ? (
            <div
              className={`rounded-3xl p-10 text-center border ${
                isDark ? 'glass-card border-neutral-800' : 'glass-card-light border-neutral-200'
              }`}
            >
              <FileText className="w-12 h-12 text-emerald-500/40 mx-auto mb-3" />
              <h3 className="text-base font-bold">
                {isHindi ? 'कोई नोट नहीं मिला' : 'No notes found'}
              </h3>
              <p className="text-xs text-neutral-400 mt-1 max-w-sm mx-auto">
                {isHindi
                  ? 'खेत से जुड़ी कोई भी बात, भाव, सलाह या उधारी लिखने के लिए ऊपर "+ नया नोट लिखें" पर क्लिक करें।'
                  : 'Start writing farm notes, field observations, or dealer transactions.'}
              </p>
              <button
                onClick={() => handleOpenAddNote()}
                className="btn-3d-primary mt-4 px-4 py-2 rounded-xl text-white font-bold text-xs cursor-pointer inline-flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? 'पहला नोट लिखें' : 'Write First Note'}</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredNotes.map((note) => {
                const colorBorder =
                  note.color === 'amber'
                    ? 'border-amber-500/40'
                    : note.color === 'rose'
                    ? 'border-rose-500/40'
                    : note.color === 'sky'
                    ? 'border-sky-500/40'
                    : 'border-emerald-500/40';

                return (
                  <div
                    key={note.id}
                    onClick={() => handleOpenAddNote(note)}
                    className={`rounded-3xl p-5 border transition-all hover:scale-[1.01] cursor-pointer flex flex-col justify-between group ${colorBorder} ${
                      isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
                    } ${note.isPinned ? 'ring-1 ring-emerald-500/50 shadow-md shadow-emerald-500/10' : ''}`}
                  >
                    <div>
                      {/* Top Meta Line */}
                      <div className="flex items-center justify-between gap-2 pb-2 border-b border-neutral-800/40">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                          {categoryLabels[note.category][lang]}
                        </span>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={(e) => handleTogglePin(note.id, e)}
                            className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                              note.isPinned
                                ? 'bg-emerald-500/20 text-emerald-400'
                                : 'text-neutral-500 hover:text-neutral-300'
                            }`}
                            title={note.isPinned ? 'Unpin' : 'Pin to top'}
                          >
                            <Pin className={`w-3.5 h-3.5 ${note.isPinned ? 'fill-emerald-400' : ''}`} />
                          </button>

                          <button
                            onClick={(e) => handleShareNoteWhatsApp(note, e)}
                            className="p-1.5 rounded-lg text-emerald-500 hover:bg-emerald-500/20 transition-colors cursor-pointer"
                            title="Share on WhatsApp"
                          >
                            <Share2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setNoteToDelete(note);
                            }}
                            className="p-1.5 rounded-lg text-neutral-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                            title="Delete Note"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Title */}
                      <h3 className="text-base font-bold mt-2.5 leading-snug group-hover:text-emerald-400 transition-colors">
                        {note.title}
                      </h3>

                      {/* Content */}
                      <p className="text-xs text-neutral-300 dark:text-neutral-300 whitespace-pre-line mt-2 line-clamp-6 leading-relaxed">
                        {note.content}
                      </p>
                    </div>

                    {/* Bottom Timestamp */}
                    <div className="flex items-center justify-between text-[10px] text-neutral-400 pt-3 mt-4 border-t border-neutral-800/30">
                      <div className="flex items-center gap-1 font-mono">
                        <Calendar className="w-3 h-3 text-neutral-500" />
                        <span>{note.date}</span>
                        <span className="opacity-40">•</span>
                        <Clock className="w-3 h-3 text-neutral-500" />
                        <span>{note.time}</span>
                      </div>
                      <span className="text-[10px] text-emerald-500 font-semibold group-hover:underline">
                        {isHindi ? 'संपादित करें' : 'Edit'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ===================== TAB 2: SHOPPING / SAMAN LIST ===================== */}
      {activeSubTab === 'shopping' && (
        <div className="space-y-4">
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div
              className={`rounded-2xl p-4 border ${
                isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
              }`}
            >
              <div className="text-[11px] text-neutral-400 font-medium">
                {isHindi ? 'कुल सामान (Items)' : 'Total Items'}
              </div>
              <div className="text-2xl font-extrabold font-mono mt-1 text-emerald-400">
                {shoppingItems.length}
              </div>
              <div className="text-[10px] text-neutral-500 mt-0.5">
                {pendingCount} {isHindi ? 'खरीदना बाकी' : 'pending'}
              </div>
            </div>

            <div
              className={`rounded-2xl p-4 border ${
                isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
              }`}
            >
              <div className="text-[11px] text-neutral-400 font-medium">
                {isHindi ? 'खरीद लिया (Purchased)' : 'Purchased'}
              </div>
              <div className="text-2xl font-extrabold font-mono mt-1 text-teal-400">
                {purchasedCount}
              </div>
              <div className="text-[10px] text-neutral-500 mt-0.5">
                {shoppingItems.length > 0 ? Math.round((purchasedCount / shoppingItems.length) * 100) : 0}%{' '}
                {isHindi ? 'पूर्ण' : 'completed'}
              </div>
            </div>

            <div
              className={`rounded-2xl p-4 border ${
                isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
              }`}
            >
              <div className="text-[11px] text-neutral-400 font-medium">
                {isHindi ? 'संभावित कुल खर्च (Est. Cost)' : 'Estimated Cost'}
              </div>
              <div className="text-2xl font-extrabold font-mono mt-1 text-amber-400">
                ₹{totalShoppingEstimated.toLocaleString('en-IN')}
              </div>
              <div className="text-[10px] text-neutral-500 mt-0.5">
                {isHindi ? 'बाज़ार जाने से पहले अनुमान' : 'Before visit estimate'}
              </div>
            </div>

            <div
              className={`rounded-2xl p-4 border ${
                isDark ? 'glass-card text-white' : 'glass-card-light text-neutral-900'
              }`}
            >
              <div className="text-[11px] text-neutral-400 font-medium">
                {isHindi ? 'वास्तविक खर्च (Spent)' : 'Actual Spent'}
              </div>
              <div className="text-2xl font-extrabold font-mono mt-1 text-emerald-500">
                ₹{totalShoppingActual.toLocaleString('en-IN')}
              </div>
              <div className="text-[10px] text-neutral-500 mt-0.5">
                {isHindi ? 'अब तक की खरीदारी' : 'Total spent so far'}
              </div>
            </div>
          </div>

          {/* Action and Filter Strip */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              <button
                onClick={() => setShoppingFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  shoppingFilter === 'all'
                    ? 'bg-emerald-600 text-white'
                    : isDark
                    ? 'bg-neutral-900 text-neutral-400 border border-neutral-800'
                    : 'bg-neutral-100 text-neutral-600 border border-neutral-200'
                }`}
              >
                {isHindi ? 'सभी सामान' : 'All'} ({shoppingItems.length})
              </button>
              <button
                onClick={() => setShoppingFilter('pending')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  shoppingFilter === 'pending'
                    ? 'bg-amber-600 text-white'
                    : isDark
                    ? 'bg-neutral-900 text-neutral-400 border border-neutral-800'
                    : 'bg-neutral-100 text-neutral-600 border border-neutral-200'
                }`}
              >
                {isHindi ? 'खरीदना बाकी' : 'Pending'} ({pendingCount})
              </button>
              <button
                onClick={() => setShoppingFilter('purchased')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  shoppingFilter === 'purchased'
                    ? 'bg-emerald-700 text-white'
                    : isDark
                    ? 'bg-neutral-900 text-neutral-400 border border-neutral-800'
                    : 'bg-neutral-100 text-neutral-600 border border-neutral-200'
                }`}
              >
                {isHindi ? 'खरीद लिया' : 'Purchased'} ({purchasedCount})
              </button>
            </div>

            <div className="flex items-center gap-2">
              {shoppingItems.length > 0 && (
                <button
                  onClick={handleShareShoppingWhatsApp}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-500 hover:bg-emerald-600 text-white flex items-center gap-1.5 cursor-pointer transition-colors"
                  title="Share shopping list on WhatsApp"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>{isHindi ? 'दुकानदार / WhatsApp पर भेजें' : 'Share List'}</span>
                </button>
              )}

              {purchasedCount > 0 && (
                <button
                  onClick={handleClearCompletedShopping}
                  className="px-3 py-1.5 rounded-xl text-xs font-medium text-rose-400 hover:bg-rose-500/10 border border-rose-500/20 cursor-pointer transition-colors"
                >
                  {isHindi ? 'खरीदे सामान हटाएं' : 'Clear Done'}
                </button>
              )}
            </div>
          </div>

          {/* Shopping Checklist Items */}
          {filteredShopping.length === 0 ? (
            <div
              className={`rounded-3xl p-10 text-center border ${
                isDark ? 'glass-card border-neutral-800' : 'glass-card-light border-neutral-200'
              }`}
            >
              <ShoppingBag className="w-12 h-12 text-emerald-500/40 mx-auto mb-3" />
              <h3 className="text-base font-bold">
                {isHindi ? 'इस सूची में कोई सामान नहीं है' : 'No items in this list'}
              </h3>
              <p className="text-xs text-neutral-400 mt-1 max-w-sm mx-auto">
                {isHindi
                  ? 'खाद, बीज, कीटनाशक दवा, सिंचाई पाइप या कोई भी सामान खरीदने के लिए ऊपर "+ सामान जोड़ें" बटन दबाएं।'
                  : 'Add items needed for your farm with expected quantity and cost.'}
              </p>
              <button
                onClick={() => handleOpenAddShopping()}
                className="btn-3d-primary mt-4 px-4 py-2 rounded-xl text-white font-bold text-xs cursor-pointer inline-flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? 'पहला सामान जोड़ें' : 'Add First Item'}</span>
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {filteredShopping.map((item) => (
                <div
                  key={item.id}
                  className={`rounded-2xl p-3.5 sm:p-4 border transition-all flex items-center justify-between gap-3 ${
                    item.isPurchased
                      ? isDark
                        ? 'bg-neutral-900/40 border-neutral-800/80 opacity-70'
                        : 'bg-neutral-100/60 border-neutral-200 opacity-70'
                      : isDark
                      ? 'glass-card border-emerald-900/30'
                      : 'glass-card-light border-emerald-200/60'
                  }`}
                >
                  {/* Left: Checkbox & Name */}
                  <div className="flex items-start sm:items-center gap-3 flex-1 min-w-0">
                    <button
                      onClick={() => handleTogglePurchase(item.id)}
                      className="mt-0.5 sm:mt-0 p-1 text-emerald-500 hover:scale-110 transition-transform cursor-pointer shrink-0"
                    >
                      {item.isPurchased ? (
                        <CheckCircle2 className="w-5 h-5 fill-emerald-500 text-neutral-950" />
                      ) : (
                        <Circle className="w-5 h-5 text-neutral-400 hover:text-emerald-500" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`text-sm sm:text-base font-bold truncate ${
                            item.isPurchased ? 'line-through text-neutral-500' : 'text-white dark:text-white'
                          }`}
                        >
                          {item.name}
                        </span>
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-neutral-800 text-neutral-300 border border-neutral-700">
                          {shoppingCategoryLabels[item.category][lang]}
                        </span>
                      </div>

                      {item.notes && (
                        <p className="text-xs text-neutral-400 mt-0.5 truncate">{item.notes}</p>
                      )}
                    </div>
                  </div>

                  {/* Middle: Quantity & Unit */}
                  <div className="text-right shrink-0">
                    <div className="text-xs sm:text-sm font-extrabold font-mono text-emerald-400">
                      {item.quantity} {item.unit}
                    </div>
                    {item.estimatedCost && (
                      <div className="text-[11px] text-neutral-400 font-mono">
                        ≈ ₹{item.estimatedCost.toLocaleString('en-IN')}
                      </div>
                    )}
                  </div>

                  {/* Right: Actions */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => handleOpenAddShopping(item)}
                      className="p-1.5 rounded-lg text-neutral-400 hover:text-emerald-400 hover:bg-neutral-800 transition-colors cursor-pointer"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setItemToDelete(item)}
                      className="p-1.5 rounded-lg text-neutral-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ===================== MODAL: ADD / EDIT NOTE ===================== */}
      {isAddNoteOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-neutral-950/80 backdrop-blur-md">
          <div
            className={`w-full max-w-lg rounded-3xl border p-5 sm:p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-200 ${
              isDark ? 'bg-neutral-950 border-emerald-900/40 text-white' : 'bg-white border-emerald-200 text-neutral-900'
            }`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-500" />
                <span>
                  {editingNote
                    ? isHindi
                      ? 'नोट संशोधित करें'
                      : 'Edit Note'
                    : isHindi
                    ? 'नया खेत नोट लिखें'
                    : 'New Farm Note'}
                </span>
              </h3>
              <button
                onClick={() => setIsAddNoteOpen(false)}
                className="p-1.5 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveNote} className="space-y-4 mt-4">
              {/* Title */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {isHindi ? 'शीर्षक (Title)' : 'Title'}
                </label>
                <input
                  type="text"
                  required
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  placeholder={isHindi ? 'उदा. आढ़ती से बात, ट्यूबवेल समय, खाद उधारी...' : 'Note title...'}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium focus:outline-hidden focus:border-emerald-500 ${
                    isDark ? 'bg-neutral-900 border-neutral-800 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                  }`}
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {isHindi ? 'वर्ग (Category)' : 'Category'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(['reminder', 'field_work', 'payment', 'spray', 'general'] as FarmNote['category'][]).map(
                    (cat) => (
                      <button
                        type="button"
                        key={cat}
                        onClick={() => setNoteCategory(cat)}
                        className={`p-2 rounded-xl text-xs font-bold border text-center transition-all cursor-pointer ${
                          noteCategory === cat
                            ? 'bg-emerald-600 text-white border-emerald-500'
                            : isDark
                            ? 'bg-neutral-900 border-neutral-800 text-neutral-400'
                            : 'bg-neutral-100 border-neutral-200 text-neutral-700'
                        }`}
                      >
                        {categoryLabels[cat][lang]}
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Note Content */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {isHindi ? 'विवरण (Note Details)' : 'Details'}
                </label>
                <textarea
                  rows={4}
                  required
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  placeholder={
                    isHindi
                      ? 'यहाँ पूरा हिसाब, भाव, रेट, फोन नंबर, या जो भी याद रखना हो वह लिखें...'
                      : 'Write details, rates, contacts, or reminders...'
                  }
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-normal focus:outline-hidden focus:border-emerald-500 ${
                    isDark ? 'bg-neutral-900 border-neutral-800 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                  }`}
                />
              </div>

              {/* Date & Time */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isHindi ? 'तारीख' : 'Date'}
                  </label>
                  <input
                    type="date"
                    value={noteDate}
                    onChange={(e) => setNoteDate(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs ${
                      isDark ? 'bg-neutral-900 border-neutral-800 text-white' : 'bg-neutral-50 border-neutral-300'
                    }`}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isHindi ? 'समय' : 'Time'}
                  </label>
                  <input
                    type="time"
                    value={noteTime}
                    onChange={(e) => setNoteTime(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs ${
                      isDark ? 'bg-neutral-900 border-neutral-800 text-white' : 'bg-neutral-50 border-neutral-300'
                    }`}
                  />
                </div>
              </div>

              {/* Pin Checkbox */}
              <label className="flex items-center gap-2 cursor-pointer select-none pt-1">
                <input
                  type="checkbox"
                  checked={noteIsPinned}
                  onChange={(e) => setNoteIsPinned(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-xs font-semibold text-neutral-300">
                  {isHindi ? 'सबसे ऊपर पिन करें (Pin to top)' : 'Pin to top'}
                </span>
              </label>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setIsAddNoteOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-neutral-400 hover:text-white cursor-pointer"
                >
                  {isHindi ? 'रद्द करें' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="btn-3d-primary px-5 py-2.5 rounded-xl text-white font-bold text-xs cursor-pointer shadow-md"
                >
                  {isHindi ? 'सुरक्षित करें' : 'Save Note'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================== MODAL: ADD / EDIT SHOPPING ITEM ===================== */}
      {isAddShoppingOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-neutral-950/80 backdrop-blur-md">
          <div
            className={`w-full max-w-lg rounded-3xl border p-5 sm:p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-200 ${
              isDark ? 'bg-neutral-950 border-emerald-900/40 text-white' : 'bg-white border-emerald-200 text-neutral-900'
            }`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-emerald-500" />
                <span>
                  {editingShoppingItem
                    ? isHindi
                      ? 'सामान बदलें'
                      : 'Edit Shopping Item'
                    : isHindi
                    ? 'खरीदारी लिस्ट में सामान जोड़ें'
                    : 'Add Item to Buy'}
                </span>
              </h3>
              <button
                onClick={() => setIsAddShoppingOpen(false)}
                className="p-1.5 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveShoppingItem} className="space-y-4 mt-4">
              {/* Item Name */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {isHindi ? 'सामान का नाम *' : 'Item Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  placeholder={isHindi ? 'उदा. यूरिया खाद, पोटाश, कीटनाशक दवा, ट्रैक्टर ऑयल...' : 'Item name...'}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium focus:outline-hidden focus:border-emerald-500 ${
                    isDark ? 'bg-neutral-900 border-neutral-800 text-white' : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                  }`}
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {isHindi ? 'श्रेणी (Category)' : 'Category'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(
                    [
                      'fertilizer',
                      'seeds',
                      'pesticide',
                      'machinery_tools',
                      'irrigation',
                      'general'
                    ] as ShoppingItem['category'][]
                  ).map((cat) => (
                    <button
                      type="button"
                      key={cat}
                      onClick={() => setItemCategory(cat)}
                      className={`p-2 rounded-xl text-xs font-bold border text-center transition-all cursor-pointer ${
                        itemCategory === cat
                          ? 'bg-emerald-600 text-white border-emerald-500'
                          : isDark
                          ? 'bg-neutral-900 border-neutral-800 text-neutral-400'
                          : 'bg-neutral-100 border-neutral-200 text-neutral-700'
                      }`}
                    >
                      {shoppingCategoryLabels[cat][lang]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity and Unit */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isHindi ? 'मात्रा (Quantity)' : 'Quantity'}
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    min="0.1"
                    required
                    value={itemQuantity}
                    onChange={(e) => setItemQuantity(parseFloat(e.target.value) || 1)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs font-mono font-bold ${
                      isDark ? 'bg-neutral-900 border-neutral-800 text-white' : 'bg-neutral-50 border-neutral-300'
                    }`}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isHindi ? 'इकाई (Unit)' : 'Unit'}
                  </label>
                  <select
                    value={itemUnit}
                    onChange={(e) => setItemUnit(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs ${
                      isDark ? 'bg-neutral-900 border-neutral-800 text-white' : 'bg-neutral-50 border-neutral-300'
                    }`}
                  >
                    <option value="बोरी">बोरी (Bags / बोरी)</option>
                    <option value="पैकेट">पैकेट (Packets)</option>
                    <option value="लीटर">लीटर (Liters)</option>
                    <option value="किलो">किलो (Kg)</option>
                    <option value="क्विंटल">क्विंटल (Quintal)</option>
                    <option value="नग">नग / पीस (Pcs)</option>
                    <option value="मीटर">मीटर (Meters)</option>
                    <option value="ड्रम">ड्रम (Drum)</option>
                  </select>
                </div>
              </div>

              {/* Estimated and Actual Cost */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isHindi ? 'अनुमानित खर्च (₹ Est.)' : 'Est. Cost (₹)'}
                  </label>
                  <input
                    type="number"
                    value={itemEstimatedCost}
                    onChange={(e) => setItemEstimatedCost(e.target.value)}
                    placeholder="उदा. 850"
                    className={`w-full px-3 py-2 rounded-xl border text-xs font-mono ${
                      isDark ? 'bg-neutral-900 border-neutral-800 text-white' : 'bg-neutral-50 border-neutral-300'
                    }`}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isHindi ? 'वास्तविक खर्च (₹ Actual)' : 'Actual Cost (₹)'}
                  </label>
                  <input
                    type="number"
                    value={itemActualCost}
                    onChange={(e) => setItemActualCost(e.target.value)}
                    placeholder="खरीदने के बाद"
                    className={`w-full px-3 py-2 rounded-xl border text-xs font-mono ${
                      isDark ? 'bg-neutral-900 border-neutral-800 text-white' : 'bg-neutral-50 border-neutral-300'
                    }`}
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {isHindi ? 'दुकान का नाम या विशेष नोट' : 'Shop or Details'}
                </label>
                <input
                  type="text"
                  value={itemNotes}
                  onChange={(e) => setItemNotes(e.target.value)}
                  placeholder={isHindi ? 'उदा. बदायूं मंडी वाली दुकान से लेना है' : 'Shop or note...'}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs ${
                    isDark ? 'bg-neutral-900 border-neutral-800 text-white' : 'bg-neutral-50 border-neutral-300'
                  }`}
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setIsAddShoppingOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-neutral-400 hover:text-white cursor-pointer"
                >
                  {isHindi ? 'रद्द करें' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="btn-3d-primary px-5 py-2.5 rounded-xl text-white font-bold text-xs cursor-pointer shadow-md"
                >
                  {isHindi ? 'लिस्ट में जोड़ें' : 'Save Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirm Delete Note Modal */}
      <ConfirmModal
        isOpen={Boolean(noteToDelete)}
        title={isHindi ? 'खेत नोट हटाएं?' : 'Delete Note?'}
        message={
          isHindi
            ? `क्या आप सचमुच "${noteToDelete?.title}" नोट को हटाना चाहते हैं?`
            : `Are you sure you want to delete note "${noteToDelete?.title}"?`
        }
        confirmLabel={isHindi ? 'हटाएं' : 'Delete'}
        cancelLabel={isHindi ? 'रद्द करें' : 'Cancel'}
        onConfirm={handleDeleteNoteConfirm}
        onCancel={() => setNoteToDelete(null)}
        theme={theme}
      />

      {/* Confirm Delete Shopping Item Modal */}
      <ConfirmModal
        isOpen={Boolean(itemToDelete)}
        title={isHindi ? 'सामान हटाएं?' : 'Delete Shopping Item?'}
        message={
          isHindi
            ? `क्या आप सचमुच "${itemToDelete?.name}" को लिस्ट से हटाना चाहते हैं?`
            : `Are you sure you want to delete "${itemToDelete?.name}" from list?`
        }
        confirmLabel={isHindi ? 'हटाएं' : 'Delete'}
        cancelLabel={isHindi ? 'रद्द करें' : 'Cancel'}
        onConfirm={handleDeleteShoppingItemConfirm}
        onCancel={() => setItemToDelete(null)}
        theme={theme}
      />
    </div>
  );
};

