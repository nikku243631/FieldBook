import React, { useState } from 'react';
import {
  FileText,
  ShoppingBag,
  Plus,
  Search,
  Pin,
  Trash2,
  Edit2,
  Share2,
  CheckCircle2,
  Circle,
  Calendar,
  Clock,
  Sparkles
} from 'lucide-react';
import { Language, Theme, FarmNote, ShoppingItem } from '../types';
import { Storage } from '../utils/storage';
import { ConfirmModal } from './ConfirmModal';
import { shareViaWhatsApp } from '../utils/export';

interface NotesAndListsViewProps {
  lang: Language;
  theme: Theme;
  notes: FarmNote[];
  shoppingItems: ShoppingItem[];
  onUpdateNotes: (notes: FarmNote[]) => void;
  onUpdateShoppingItems: (items: ShoppingItem[]) => void;
  onOpenSimpleCalc?: () => void;
}

export const NotesAndListsView: React.FC<NotesAndListsViewProps> = ({
  lang,
  theme,
  notes,
  shoppingItems,
  onUpdateNotes,
  onUpdateShoppingItems,
  onOpenSimpleCalc
}) => {
  const isHindi = lang === 'hi';
  const isDark = theme === 'dark';

  const [activeSubTab, setActiveSubTab] = useState<'notes' | 'shopping'>('notes');

  // Notes state
  const [noteSearch, setNoteSearch] = useState('');
  const [selectedNoteCategory, setSelectedNoteCategory] = useState<string>('all');
  const [isAddNoteOpen, setIsAddNoteOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<FarmNote | null>(null);
  const [noteToDelete, setNoteToDelete] = useState<FarmNote | null>(null);

  // New/Edit Note Form
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [noteCategory, setNoteCategory] = useState<FarmNote['category']>('reminder');
  const [noteColor, setNoteColor] = useState<string>('emerald');
  const [noteIsPinned, setNoteIsPinned] = useState(false);
  const [noteDate, setNoteDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [noteTime, setNoteTime] = useState(() => new Date().toTimeString().slice(0, 5));

  // Shopping state
  const [shoppingFilter, setShoppingFilter] = useState<'all' | 'pending' | 'purchased'>('all');
  const [shoppingCategoryFilter] = useState<string>('all');
  const [isAddShoppingOpen, setIsAddShoppingOpen] = useState(false);
  const [editingShoppingItem, setEditingShoppingItem] = useState<ShoppingItem | null>(null);
  const [itemToDelete, setItemToDelete] = useState<ShoppingItem | null>(null);

  // New/Edit Shopping Form
  const [itemName, setItemName] = useState('');
  const [itemCategory, setItemCategory] = useState<ShoppingItem['category']>('fertilizer');
  const [itemQuantity, setItemQuantity] = useState<number>(1);
  const [itemUnit, setItemUnit] = useState('बोरी');
  const [itemEstimatedCost, setItemEstimatedCost] = useState<string>('');
  const [itemActualCost, setItemActualCost] = useState<string>('');
  const [itemNotes, setItemNotes] = useState('');

  // ---------------- NOTE HANDLERS ----------------
  const handleOpenAddNote = (noteToEdit?: FarmNote) => {
    if (noteToEdit) {
      setEditingNote(noteToEdit);
      setNoteTitle(noteToEdit.title);
      setNoteContent(noteToEdit.content);
      setNoteCategory(noteToEdit.category);
      setNoteColor(noteToEdit.color || 'emerald');
      setNoteIsPinned(noteToEdit.isPinned);
      setNoteDate(noteToEdit.date);
      setNoteTime(noteToEdit.time);
    } else {
      setEditingNote(null);
      setNoteTitle('');
      setNoteContent('');
      setNoteCategory('reminder');
      setNoteColor('emerald');
      setNoteIsPinned(false);
      setNoteDate(new Date().toISOString().split('T')[0]);
      setNoteTime(new Date().toTimeString().slice(0, 5));
    }
    setIsAddNoteOpen(true);
  };

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim() && !noteContent.trim()) return;

    if (editingNote) {
      const updated = notes.map((n) =>
        n.id === editingNote.id
          ? {
              ...n,
              title: noteTitle.trim() || (isHindi ? 'नोट' : 'Note'),
              content: noteContent.trim(),
              category: noteCategory,
              color: noteColor,
              isPinned: noteIsPinned,
              date: noteDate,
              time: noteTime,
              updatedAt: new Date().toISOString()
            }
          : n
      );
      onUpdateNotes(updated);
      Storage.saveNotes(updated);
    } else {
      const newNote: FarmNote = {
        id: `note-${Date.now()}`,
        title: noteTitle.trim() || (isHindi ? 'नया नोट' : 'New Note'),
        content: noteContent.trim(),
        category: noteCategory,
        color: noteColor,
        isPinned: noteIsPinned,
        date: noteDate,
        time: noteTime,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      const updated = [newNote, ...notes];
      onUpdateNotes(updated);
      Storage.saveNotes(updated);
    }

    setIsAddNoteOpen(false);
    setEditingNote(null);
  };

  const handleTogglePin = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = notes.map((n) => (n.id === id ? { ...n, isPinned: !n.isPinned } : n));
    onUpdateNotes(updated);
    Storage.saveNotes(updated);
  };

  const handleDeleteNoteConfirm = () => {
    if (!noteToDelete) return;
    const updated = notes.filter((n) => n.id !== noteToDelete.id);
    onUpdateNotes(updated);
    Storage.saveNotes(updated);
    setNoteToDelete(null);
  };

  const handleShareNoteWhatsApp = (note: FarmNote, e: React.MouseEvent) => {
    e.stopPropagation();
    const text = `*FieldBook खेत नोट: ${note.title}*\n\n${note.content}\n\nतारीख: ${note.date} ${note.time}\n(FieldBook - Mr Nikhil)`;
    shareViaWhatsApp(text);
  };

  const filteredNotes = notes
    .filter((n) => {
      const matchesSearch =
        n.title.toLowerCase().includes(noteSearch.toLowerCase()) ||
        n.content.toLowerCase().includes(noteSearch.toLowerCase());
      const matchesCat = selectedNoteCategory === 'all' || n.category === selectedNoteCategory;
      return matchesSearch && matchesCat;
    })
    .sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  // ---------------- SHOPPING LIST HANDLERS ----------------
  const handleOpenAddShopping = (itemToEdit?: ShoppingItem) => {
    if (itemToEdit) {
      setEditingShoppingItem(itemToEdit);
      setItemName(itemToEdit.name);
      setItemCategory(itemToEdit.category);
      setItemQuantity(itemToEdit.quantity);
      setItemUnit(itemToEdit.unit);
      setItemEstimatedCost(itemToEdit.estimatedCost ? String(itemToEdit.estimatedCost) : '');
      setItemActualCost(itemToEdit.actualCost ? String(itemToEdit.actualCost) : '');
      setItemNotes(itemToEdit.notes || '');
    } else {
      setEditingShoppingItem(null);
      setItemName('');
      setItemCategory('fertilizer');
      setItemQuantity(1);
      setItemUnit('बोरी');
      setItemEstimatedCost('');
      setItemActualCost('');
      setItemNotes('');
    }
    setIsAddShoppingOpen(true);
  };

  const handleSaveShoppingItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName.trim()) return;

    const estCostNum = itemEstimatedCost ? parseFloat(itemEstimatedCost) : undefined;
    const actCostNum = itemActualCost ? parseFloat(itemActualCost) : undefined;

    if (editingShoppingItem) {
      const updated = shoppingItems.map((item) =>
        item.id === editingShoppingItem.id
          ? {
              ...item,
              name: itemName.trim(),
              category: itemCategory,
              quantity: itemQuantity || 1,
              unit: itemUnit,
              estimatedCost: estCostNum,
              actualCost: actCostNum,
              notes: itemNotes.trim() || undefined
            }
          : item
      );
      onUpdateShoppingItems(updated);
      Storage.saveShoppingItems(updated);
    } else {
      const newItem: ShoppingItem = {
        id: `shop-${Date.now()}`,
        name: itemName.trim(),
        category: itemCategory,
        quantity: itemQuantity || 1,
        unit: itemUnit,
        estimatedCost: estCostNum,
        actualCost: actCostNum,
        isPurchased: false,
        notes: itemNotes.trim() || undefined,
        date: new Date().toISOString().split('T')[0],
        createdAt: new Date().toISOString()
      };
      const updated = [newItem, ...shoppingItems];
      onUpdateShoppingItems(updated);
      Storage.saveShoppingItems(updated);
    }

    setIsAddShoppingOpen(false);
    setEditingShoppingItem(null);
  };

  const handleTogglePurchase = (id: string) => {
    const updated = shoppingItems.map((item) =>
      item.id === id ? { ...item, isPurchased: !item.isPurchased } : item
    );
    onUpdateShoppingItems(updated);
    Storage.saveShoppingItems(updated);
  };

  const handleDeleteShoppingItemConfirm = () => {
    if (!itemToDelete) return;
    const updated = shoppingItems.filter((i) => i.id !== itemToDelete.id);
    onUpdateShoppingItems(updated);
    Storage.saveShoppingItems(updated);
    setItemToDelete(null);
  };

  const handleClearCompletedShopping = () => {
    const updated = shoppingItems.filter((i) => !i.isPurchased);
    onUpdateShoppingItems(updated);
    Storage.saveShoppingItems(updated);
  };

  const handleShareShoppingWhatsApp = () => {
    const pending = shoppingItems.filter((i) => !i.isPurchased);
    const purchased = shoppingItems.filter((i) => i.isPurchased);

    let text = `*FieldBook कृषि खरीदारी लिस्ट (सामान की सूची)*\n\n`;

    if (pending.length > 0) {
      text += `*खरीदना बाकी (${pending.length}):*\n`;
      pending.forEach((item, index) => {
        text += `${index + 1}. ${item.name} - ${item.quantity} ${item.unit}${
          item.estimatedCost ? ` (लगभग ₹${item.estimatedCost})` : ''
        }\n`;
      });
    }

    if (purchased.length > 0) {
      text += `\n*खरीद लिया (${purchased.length}):*\n`;
      purchased.forEach((item, index) => {
        text += `✓ ${item.name} - ${item.quantity} ${item.unit}${
          item.actualCost ? ` (₹${item.actualCost})` : ''
        }\n`;
      });
    }

    const totalEst = shoppingItems.reduce((sum, item) => sum + (item.estimatedCost || 0), 0);
    text += `\n*कुल संभावित खर्च:* ₹${totalEst.toLocaleString('en-IN')}\n(FieldBook - Mr Nikhil)`;

    shareViaWhatsApp(text);
  };

  const filteredShopping = shoppingItems.filter((item) => {
    const matchesStatus =
      shoppingFilter === 'all'
        ? true
        : shoppingFilter === 'pending'
        ? !item.isPurchased
        : item.isPurchased;
    const matchesCategory =
      shoppingCategoryFilter === 'all' || item.category === shoppingCategoryFilter;
    return matchesStatus && matchesCategory;
  });

  const totalShoppingEstimated = shoppingItems.reduce((acc, item) => acc + (item.estimatedCost || 0), 0);
  const totalShoppingActual = shoppingItems.reduce((acc, item) => acc + (item.actualCost || 0), 0);
  const pendingCount = shoppingItems.filter((i) => !i.isPurchased).length;
  const purchasedCount = shoppingItems.filter((i) => i.isPurchased).length;

  const categoryLabels: Record<FarmNote['category'], { hi: string; en: string }> = {
    reminder: { hi: 'ज़रूरी याददाश्त', en: 'Reminder' },
    field_work: { hi: 'खेत काम / जुताई', en: 'Field Work' },
    payment: { hi: 'लेन-देन / उधारी', en: 'Payment / Debt' },
    spray: { hi: 'दवाई व स्प्रे', en: 'Spray & Medicine' },
    general: { hi: 'सामान्य', en: 'General' }
  };

  const shoppingCategoryLabels: Record<ShoppingItem['category'], { hi: string; en: string }> = {
    fertilizer: { hi: 'खाद (Fertilizer)', en: 'Fertilizer' },
    seeds: { hi: 'बीज (Seeds)', en: 'Seeds' },
    pesticide: { hi: 'कीटनाशक व दवाई', en: 'Pesticide' },
    machinery_tools: { hi: 'ट्रैक्टर / उपकरण', en: 'Machinery/Tools' },
    irrigation: { hi: 'सिंचाई व पाइप', en: 'Irrigation' },
    general: { hi: 'अन्य सामान', en: 'General' }
  };

  return (
    <div className="space-y-4 max-w-5xl mx-auto pb-20">
      {/* Page Header */}
      <div
        className={`rounded-2xl p-4 sm:p-5 border shadow-xs ${
          isDark
            ? 'bg-slate-900 border-slate-800 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 mb-1">
              <FileText className="w-3.5 h-3.5" />
              <span>{isHindi ? 'खेत नोट्स व सामान सूची' : 'Farm Notes & Shopping List'}</span>
            </div>
            <h1 className="text-base sm:text-lg font-bold tracking-tight">
              {isHindi ? 'याददाश्त नोट्स व खरीदारी लिस्ट' : 'Daily Notes & Farm Purchases'}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 max-w-xl">
              {isHindi
                ? 'खाद-बीज की दुकान का हिसाब, ट्यूबवेल की बात, उधारी-बाकी और बाज़ार से लाने वाले सामान की पक्की लिस्ट बनाएं।'
                : 'Jot down field notes, fertilizer supplier reminders, and maintain an agri shopping checklist.'}
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 self-start sm:self-auto">
            {onOpenSimpleCalc && (
              <button
                type="button"
                onClick={onOpenSimpleCalc}
                className="px-3 py-2 rounded-xl text-xs font-semibold border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-200 hover:bg-emerald-100 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>{isHindi ? 'कैलकुलेटर खोलें' : 'Open Calc'}</span>
              </button>
            )}

            {activeSubTab === 'notes' ? (
              <button
                type="button"
                onClick={() => handleOpenAddNote()}
                className="btn-3d-primary px-3.5 py-2 rounded-xl text-white font-semibold text-xs flex items-center gap-1 cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? 'नया नोट लिखें' : 'Add Note'}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleOpenAddShopping()}
                className="btn-3d-primary px-3.5 py-2 rounded-xl text-white font-semibold text-xs flex items-center gap-1 cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? 'सामान जोड़ें' : 'Add Item'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Sub-Tab Navigation Bar */}
        <div className="flex flex-wrap items-center gap-2 mt-3.5 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setActiveSubTab('notes')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
              activeSubTab === 'notes'
                ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs'
                : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-emerald-50'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{isHindi ? 'खेत नोट्स (Diary Notes)' : 'Farm Notes'}</span>
            <span
              className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                activeSubTab === 'notes'
                  ? 'bg-emerald-800 text-white'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
              }`}
            >
              {notes.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('shopping')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
              activeSubTab === 'shopping'
                ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs'
                : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-emerald-50'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>{isHindi ? 'सामान / खरीदारी लिस्ट' : 'Shopping List'}</span>
            <span
              className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                activeSubTab === 'shopping'
                  ? 'bg-emerald-800 text-white'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
              }`}
            >
              {pendingCount > 0 ? `${pendingCount} बाकी` : `${shoppingItems.length}`}
            </span>
          </button>
        </div>
      </div>

      {/* ===================== TAB 1: NOTES SECTION ===================== */}
      {activeSubTab === 'notes' && (
        <div className="space-y-3.5">
          {/* Controls: Search & Category Filter */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={noteSearch}
                onChange={(e) => setNoteSearch(e.target.value)}
                placeholder={isHindi ? 'नोट्स में खोजें (उदा. यूरिया, बदायूं, पानी)...' : 'Search notes...'}
                className="w-full pl-9 pr-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 scrollbar-none">
              {['all', 'reminder', 'field_work', 'payment', 'spray', 'general'].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedNoteCategory(cat)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors cursor-pointer border ${
                    selectedNoteCategory === cat
                      ? 'bg-emerald-600 text-white border-emerald-700'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-emerald-50'
                  }`}
                >
                  {cat === 'all'
                    ? isHindi
                      ? 'सभी'
                      : 'All'
                    : categoryLabels[cat as FarmNote['category']][lang]}
                </button>
              ))}
            </div>
          </div>

          {/* Notes Grid */}
          {filteredNotes.length === 0 ? (
            <div
              className={`rounded-2xl p-8 text-center border shadow-xs ${
                isDark
                  ? 'bg-slate-900 border-slate-800 text-slate-100'
                  : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              <FileText className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
              <h3 className="text-sm sm:text-base font-bold">
                {isHindi ? 'कोई नोट नहीं मिला' : 'No notes found'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                {isHindi
                  ? 'खेत से जुड़ी कोई भी बात, भाव, सलाह या उधारी लिखने के लिए ऊपर "नया नोट लिखें" पर क्लिक करें।'
                  : 'Start writing farm notes, field observations, or dealer transactions.'}
              </p>
              <button
                type="button"
                onClick={() => handleOpenAddNote()}
                className="btn-3d-primary mt-3.5 px-4 py-2 rounded-xl text-white font-semibold text-xs cursor-pointer inline-flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? 'पहला नोट लिखें' : 'Write First Note'}</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {filteredNotes.map((note) => (
                <div
                  key={note.id}
                  onClick={() => handleOpenAddNote(note)}
                  className={`rounded-2xl p-4 border transition-all hover:-translate-y-0.5 cursor-pointer flex flex-col justify-between group shadow-xs ${
                    isDark
                      ? 'bg-slate-900 border-slate-800 text-slate-100'
                      : 'bg-white border-slate-200 text-slate-900'
                  } ${note.isPinned ? 'ring-1 ring-amber-400 bg-amber-50/30 dark:bg-amber-950/20' : ''}`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-slate-100 dark:border-slate-800">
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                        {categoryLabels[note.category][lang]}
                      </span>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={(e) => handleTogglePin(note.id, e)}
                          className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer border ${
                            note.isPinned
                              ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                              : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                          }`}
                          title={note.isPinned ? 'Unpin' : 'Pin to top'}
                        >
                          <Pin className={`w-3.5 h-3.5 ${note.isPinned ? 'fill-amber-500 text-amber-600' : ''}`} />
                        </button>

                        <button
                          type="button"
                          onClick={(e) => handleShareNoteWhatsApp(note, e)}
                          className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors cursor-pointer"
                          title="Share on WhatsApp"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setNoteToDelete(note);
                          }}
                          className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 hover:bg-rose-100 transition-colors cursor-pointer"
                          title="Delete Note"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <h3 className="text-sm sm:text-base font-bold mt-2.5 leading-snug">
                      {note.title}
                    </h3>

                    <p className="text-xs text-slate-600 dark:text-slate-300 whitespace-pre-line mt-1.5 line-clamp-5 leading-relaxed">
                      {note.content}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-2.5 mt-3 border-t border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-1 font-mono">
                      <Calendar className="w-3 h-3 text-emerald-600" />
                      <span>{note.date}</span>
                      <span>•</span>
                      <Clock className="w-3 h-3 text-emerald-600" />
                      <span>{note.time}</span>
                    </div>
                    <span className="text-emerald-700 dark:text-emerald-400 font-semibold">
                      {isHindi ? 'बदलें ✎' : 'Edit ✎'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ===================== TAB 2: SHOPPING / SAMAN LIST ===================== */}
      {activeSubTab === 'shopping' && (
        <div className="space-y-3.5">
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div
              className={`rounded-xl p-3 border shadow-2xs ${
                isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                {isHindi ? 'कुल सामान (Items)' : 'Total Items'}
              </div>
              <div className="text-base sm:text-lg font-bold font-mono mt-0.5">
                {shoppingItems.length}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">
                {pendingCount} {isHindi ? 'खरीदना बाकी' : 'pending'}
              </div>
            </div>

            <div className="rounded-xl p-3 bg-emerald-50/80 dark:bg-emerald-950/35 border border-emerald-200 dark:border-emerald-800/70">
              <div className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-300">
                {isHindi ? 'खरीद लिया (Purchased)' : 'Purchased'}
              </div>
              <div className="text-base sm:text-lg font-bold font-mono mt-0.5 text-emerald-700 dark:text-emerald-400">
                {purchasedCount}
              </div>
              <div className="text-[10px] text-emerald-700 dark:text-emerald-300 mt-0.5">
                {shoppingItems.length > 0 ? Math.round((purchasedCount / shoppingItems.length) * 100) : 0}%{' '}
                {isHindi ? 'पूर्ण' : 'completed'}
              </div>
            </div>

            <div className="rounded-xl p-3 bg-amber-50/80 dark:bg-amber-950/35 border border-amber-200 dark:border-amber-800/70">
              <div className="text-[11px] font-semibold text-amber-800 dark:text-amber-300">
                {isHindi ? 'संभावित खर्च (Est.)' : 'Estimated Cost'}
              </div>
              <div className="text-base sm:text-lg font-bold font-mono mt-0.5 text-amber-800 dark:text-amber-300">
                ₹{totalShoppingEstimated.toLocaleString('en-IN')}
              </div>
              <div className="text-[10px] text-amber-700 dark:text-amber-400 mt-0.5">
                {isHindi ? 'अनुमानित बजट' : 'Estimated budget'}
              </div>
            </div>

            <div className="rounded-xl p-3 bg-blue-50/80 dark:bg-blue-950/35 border border-blue-200 dark:border-blue-800/70">
              <div className="text-[11px] font-semibold text-blue-800 dark:text-blue-300">
                {isHindi ? 'वास्तविक खर्च (Spent)' : 'Actual Spent'}
              </div>
              <div className="text-base sm:text-lg font-bold font-mono mt-0.5 text-blue-700 dark:text-blue-400">
                ₹{totalShoppingActual.toLocaleString('en-IN')}
              </div>
              <div className="text-[10px] text-blue-700 dark:text-blue-300 mt-0.5">
                {isHindi ? 'अब तक की खरीदारी' : 'Total spent'}
              </div>
            </div>
          </div>

          {/* Action and Filter Strip */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
              <button
                type="button"
                onClick={() => setShoppingFilter('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer border ${
                  shoppingFilter === 'all'
                    ? 'bg-emerald-600 text-white border-emerald-700'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                }`}
              >
                {isHindi ? 'सभी सामान' : 'All'} ({shoppingItems.length})
              </button>
              <button
                type="button"
                onClick={() => setShoppingFilter('pending')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer border ${
                  shoppingFilter === 'pending'
                    ? 'bg-amber-600 text-white border-amber-700'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                }`}
              >
                {isHindi ? 'खरीदना बाकी' : 'Pending'} ({pendingCount})
              </button>
              <button
                type="button"
                onClick={() => setShoppingFilter('purchased')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer border ${
                  shoppingFilter === 'purchased'
                    ? 'bg-emerald-600 text-white border-emerald-700'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                }`}
              >
                {isHindi ? 'खरीद लिया' : 'Purchased'} ({purchasedCount})
              </button>
            </div>

            <div className="flex items-center gap-2">
              {shoppingItems.length > 0 && (
                <button
                  type="button"
                  onClick={handleShareShoppingWhatsApp}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>{isHindi ? 'WhatsApp पर भेजें' : 'Share List'}</span>
                </button>
              )}

              {purchasedCount > 0 && (
                <button
                  type="button"
                  onClick={handleClearCompletedShopping}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 cursor-pointer transition-colors"
                >
                  {isHindi ? 'खरीदे सामान हटाएं' : 'Clear Done'}
                </button>
              )}
            </div>
          </div>

          {/* Shopping Checklist Items */}
          {filteredShopping.length === 0 ? (
            <div
              className={`rounded-2xl p-8 text-center border shadow-xs ${
                isDark
                  ? 'bg-slate-900 border-slate-800 text-slate-100'
                  : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              <ShoppingBag className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
              <h3 className="text-sm sm:text-base font-bold">
                {isHindi ? 'इस सूची में कोई सामान नहीं है' : 'No items in this list'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                {isHindi
                  ? 'खाद, बीज, कीटनाशक दवा या कोई भी सामान खरीदने के लिए ऊपर "सामान जोड़ें" बटन दबाएं।'
                  : 'Add items needed for your farm with expected quantity and cost.'}
              </p>
              <button
                type="button"
                onClick={() => handleOpenAddShopping()}
                className="btn-3d-primary mt-3.5 px-4 py-2 rounded-xl text-white font-semibold text-xs cursor-pointer inline-flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                <span>{isHindi ? 'पहला सामान जोड़ें' : 'Add First Item'}</span>
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredShopping.map((item) => (
                <div
                  key={item.id}
                  className={`rounded-xl p-3 border transition-all flex items-center justify-between gap-2.5 shadow-2xs ${
                    isDark
                      ? 'bg-slate-900 border-slate-800 text-slate-100'
                      : 'bg-white border-slate-200 text-slate-900'
                  } ${item.isPurchased ? 'opacity-75' : ''}`}
                >
                  <div className="flex items-start sm:items-center gap-2.5 flex-1 min-w-0">
                    <button
                      type="button"
                      onClick={() => handleTogglePurchase(item.id)}
                      className="mt-0.5 sm:mt-0 p-0.5 text-emerald-600 hover:scale-105 transition-transform cursor-pointer shrink-0"
                    >
                      {item.isPurchased ? (
                        <CheckCircle2 className="w-5 h-5 fill-emerald-600 text-white" />
                      ) : (
                        <Circle className="w-5 h-5 text-emerald-600" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span
                          className={`text-xs sm:text-sm font-bold truncate ${
                            item.isPurchased ? 'line-through text-slate-400' : ''
                          }`}
                        >
                          {item.name}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                          {shoppingCategoryLabels[item.category][lang]}
                        </span>
                      </div>

                      {item.notes && (
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">{item.notes}</p>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-xs sm:text-sm font-bold font-mono text-emerald-700 dark:text-emerald-400">
                      {item.quantity} {item.unit}
                    </div>
                    {item.estimatedCost && (
                      <div className="text-[11px] text-slate-500 font-mono">
                        ≈ ₹{item.estimatedCost.toLocaleString('en-IN')}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleOpenAddShopping(item)}
                      className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-emerald-50 transition-colors cursor-pointer"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setItemToDelete(item)}
                      className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 hover:bg-rose-100 transition-colors cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ===================== MODAL: ADD / EDIT NOTE ===================== */}
      {isAddNoteOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/65 backdrop-blur-xs">
          <div
            className={`w-full max-w-lg rounded-2xl border p-4 sm:p-5 shadow-xl animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto ${
              isDark
                ? 'bg-slate-900 border-slate-800 text-slate-100'
                : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-600" />
                <span>
                  {editingNote
                    ? isHindi
                      ? 'नोट संशोधित करें'
                      : 'Edit Note'
                    : isHindi
                    ? 'नया खेत नोट लिखें'
                    : 'New Farm Note'}
                </span>
              </h3>
              <button
                type="button"
                onClick={() => setIsAddNoteOpen(false)}
                className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveNote} className="space-y-3.5 mt-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'शीर्षक (Title) *' : 'Title *'}
                </label>
                <input
                  type="text"
                  required
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  placeholder={isHindi ? 'उदा. आढ़ती से बात, ट्यूबवेल समय, खाद उधारी...' : 'Note title...'}
                  className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'वर्ग (Category)' : 'Category'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {(['reminder', 'field_work', 'payment', 'spray', 'general'] as FarmNote['category'][]).map(
                    (cat) => (
                      <button
                        type="button"
                        key={cat}
                        onClick={() => setNoteCategory(cat)}
                        className={`p-2 rounded-lg text-xs font-medium border text-center transition-all cursor-pointer ${
                          noteCategory === cat
                            ? 'bg-emerald-600 text-white border-emerald-700'
                            : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                        }`}
                      >
                        {categoryLabels[cat][lang]}
                      </button>
                    )
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'विवरण (Note Details) *' : 'Details *'}
                </label>
                <textarea
                  rows={4}
                  required
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  placeholder={
                    isHindi
                      ? 'यहाँ पूरा हिसाब, भाव, रेट, फोन नंबर, या जो भी याद रखना हो वह लिखें...'
                      : 'Write details, rates, contacts, or reminders...'
                  }
                  className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'तारीख' : 'Date'}
                  </label>
                  <input
                    type="date"
                    value={noteDate}
                    onChange={(e) => setNoteDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'समय' : 'Time'}
                  </label>
                  <input
                    type="time"
                    value={noteTime}
                    onChange={(e) => setNoteTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-medium"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 cursor-pointer select-none pt-1">
                <input
                  type="checkbox"
                  checked={noteIsPinned}
                  onChange={(e) => setNoteIsPinned(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-xs font-semibold">
                  {isHindi ? 'सबसे ऊपर पिन करें (Pin to top)' : 'Pin to top'}
                </span>
              </label>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddNoteOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 cursor-pointer"
                >
                  {isHindi ? 'रद्द करें' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="btn-3d-primary px-5 py-2 rounded-xl text-white font-semibold text-xs sm:text-sm cursor-pointer shadow-xs"
                >
                  {isHindi ? 'सुरक्षित करें' : 'Save Note'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================== MODAL: ADD / EDIT SHOPPING ITEM ===================== */}
      {isAddShoppingOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/65 backdrop-blur-xs">
          <div
            className={`w-full max-w-lg rounded-2xl border p-4 sm:p-5 shadow-xl animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto ${
              isDark
                ? 'bg-slate-900 border-slate-800 text-slate-100'
                : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-emerald-600" />
                <span>
                  {editingShoppingItem
                    ? isHindi
                      ? 'सामान बदलें'
                      : 'Edit Shopping Item'
                    : isHindi
                    ? 'खरीदारी लिस्ट में सामान जोड़ें'
                    : 'Add Item to Buy'}
                </span>
              </h3>
              <button
                type="button"
                onClick={() => setIsAddShoppingOpen(false)}
                className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveShoppingItem} className="space-y-3.5 mt-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'सामान का नाम *' : 'Item Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  placeholder={isHindi ? 'उदा. यूरिया खाद, पोटाश, कीटनाशक दवा...' : 'Item name...'}
                  className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'श्रेणी (Category)' : 'Category'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {(
                    [
                      'fertilizer',
                      'seeds',
                      'pesticide',
                      'machinery_tools',
                      'irrigation',
                      'general'
                    ] as ShoppingItem['category'][]
                  ).map((cat) => (
                    <button
                      type="button"
                      key={cat}
                      onClick={() => setItemCategory(cat)}
                      className={`p-2 rounded-lg text-xs font-medium border text-center transition-all cursor-pointer ${
                        itemCategory === cat
                          ? 'bg-emerald-600 text-white border-emerald-700'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      {shoppingCategoryLabels[cat][lang]}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'मात्रा (Quantity)' : 'Quantity'}
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    min="0.1"
                    required
                    value={itemQuantity}
                    onChange={(e) => setItemQuantity(parseFloat(e.target.value) || 1)}
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'इकाई (Unit)' : 'Unit'}
                  </label>
                  <select
                    value={itemUnit}
                    onChange={(e) => setItemUnit(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
                  >
                    <option value="बोरी">बोरी (Bags / बोरी)</option>
                    <option value="पैकेट">पैकेट (Packets)</option>
                    <option value="लीटर">लीटर (Liters)</option>
                    <option value="किलो">किलो (Kg)</option>
                    <option value="क्विंटल">क्विंटल (Quintal)</option>
                    <option value="नग">नग / पीस (Pcs)</option>
                    <option value="मीटर">मीटर (Meters)</option>
                    <option value="ड्रम">ड्रम (Drum)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'अनुमानित खर्च (₹ Est.)' : 'Est. Cost (₹)'}
                  </label>
                  <input
                    type="number"
                    value={itemEstimatedCost}
                    onChange={(e) => setItemEstimatedCost(e.target.value)}
                    placeholder="उदा. 850"
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {isHindi ? 'वास्तविक खर्च (₹ Actual)' : 'Actual Cost (₹)'}
                  </label>
                  <input
                    type="number"
                    value={itemActualCost}
                    onChange={(e) => setItemActualCost(e.target.value)}
                    placeholder="खरीदने के बाद"
                    className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {isHindi ? 'दुकान का नाम या विशेष नोट' : 'Shop or Details'}
                </label>
                <input
                  type="text"
                  value={itemNotes}
                  onChange={(e) => setItemNotes(e.target.value)}
                  placeholder={isHindi ? 'उदा. बदायूं मंडी वाली दुकान से लेना है' : 'Shop or note...'}
                  className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddShoppingOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 cursor-pointer"
                >
                  {isHindi ? 'रद्द करें' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="btn-3d-primary px-5 py-2 rounded-xl text-white font-semibold text-xs sm:text-sm cursor-pointer shadow-xs"
                >
                  {isHindi ? 'लिस्ट में जोड़ें' : 'Save Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirm Delete Note Modal */}
      <ConfirmModal
        isOpen={Boolean(noteToDelete)}
        title={isHindi ? 'खेत नोट हटाएं?' : 'Delete Note?'}
        message={
          isHindi
            ? `क्या आप सचमुच "${noteToDelete?.title}" नोट को हटाना चाहते हैं?`
            : `Are you sure you want to delete note "${noteToDelete?.title}"?`
        }
        confirmLabel={isHindi ? 'हटाएं' : 'Delete'}
        cancelLabel={isHindi ? 'रद्द करें' : 'Cancel'}
        onConfirm={handleDeleteNoteConfirm}
        onCancel={() => setNoteToDelete(null)}
        theme={theme}
      />

      {/* Confirm Delete Shopping Item Modal */}
      <ConfirmModal
        isOpen={Boolean(itemToDelete)}
        title={isHindi ? 'सामान हटाएं?' : 'Delete Shopping Item?'}
        message={
          isHindi
            ? `क्या आप सचमुच "${itemToDelete?.name}" को लिस्ट से हटाना चाहते हैं?`
            : `Are you sure you want to delete "${itemToDelete?.name}" from list?`
        }
        confirmLabel={isHindi ? 'हटाएं' : 'Delete'}
        cancelLabel={isHindi ? 'रद्द करें' : 'Cancel'}
        onConfirm={handleDeleteShoppingItemConfirm}
        onCancel={() => setItemToDelete(null)}
        theme={theme}
      />
    </div>
  );
};
