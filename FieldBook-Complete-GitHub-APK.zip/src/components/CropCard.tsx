import React from 'react';
import { CropCycle, Transaction, HarvestEntry, Language, Theme } from '../types';
import { formatCurrency, formatNumber, getTranslation } from '../utils/translations';
import { calculateCropFinancials } from '../utils/calculations';
import { Sprout, TrendingUp, TrendingDown, Calendar, ArrowRight, ShieldCheck, Scale, DollarSign, Trash2 } from 'lucide-react';

interface CropCardProps {
  crop: CropCycle;
  transactions: Transaction[];
  harvests: HarvestEntry[];
  lang: Language;
  theme: Theme;
  onSelect: (cropId: string) => void;
  onDelete?: (cropId: string, cropName: string) => void;
}

export const CropCard: React.FC<CropCardProps> = ({
  crop,
  transactions,
  harvests,
  lang,
  theme,
  onSelect,
  onDelete
}) => {
  const isDark = theme === 'dark';

  const financials = calculateCropFinancials(crop, transactions, harvests);
  const totalLagat = financials.totalExpenses;
  const totalKamai = financials.totalIncome;
  const netProfit = financials.netProfit;
  const isProfit = financials.isProfit;
  const totalYield = financials.totalHarvestQuintal;
  const profitPerUnit = financials.profitPerUnit;
  const areaUnitLabel = getTranslation(lang, crop.areaUnit);

  return (
    <div
      onClick={() => onSelect(crop.id)}
      className={`group relative rounded-2xl p-5 border transition-all duration-200 cursor-pointer overflow-hidden ${
        isDark ? 'glass-card hover:border-emerald-500/50' : 'glass-card-light hover:border-emerald-500'
      } hover:-translate-y-1 shadow-md hover:shadow-xl`}
    >
      {/* Top Bar with Season & Status */}
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
          <Sprout className="w-4 h-4" />
          <span>
            {crop.season === 'rabi'
              ? 'रबी (Rabi)'
              : crop.season === 'kharif'
              ? 'खरीफ (Kharif)'
              : crop.season === 'zaid'
              ? 'जायद (Zaid)'
              : 'वार्षिक (Annual)'}
          </span>
          <span className="text-neutral-400">·</span>
          <span>
            {crop.landArea} {getTranslation(lang, crop.areaUnit)}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <span
            className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
              crop.status === 'active'
                ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 border border-emerald-500/30'
                : crop.status === 'harvested'
                ? 'bg-amber-500/20 text-amber-600 dark:text-amber-300 border border-amber-500/30'
                : 'bg-neutral-500/20 text-neutral-400'
            }`}
          >
            {crop.status === 'active'
              ? getTranslation(lang, 'active')
              : crop.status === 'harvested'
              ? getTranslation(lang, 'harvested')
              : getTranslation(lang, 'archived')}
          </span>

          {onDelete && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onDelete(crop.id, crop.hindiName || crop.name);
              }}
              title={lang === 'hi' ? 'फसल हटाएं' : 'Delete Crop'}
              className="p-1 rounded-md text-neutral-400 hover:text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Crop Title & Variety */}
      <div className="mb-4">
        <h3
          className={`text-xl font-extrabold tracking-tight group-hover:text-emerald-500 transition-colors ${
            isDark ? 'text-white' : 'text-neutral-900'
          }`}
        >
          {lang === 'hi' ? crop.hindiName || crop.name : crop.name}
        </h3>
        {crop.variety && (
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5 font-medium">
            वैरायटी: {crop.variety}
          </p>
        )}
      </div>

      {/* Financial Matrix (Lagat vs Kamai vs Net Profit) */}
      <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-neutral-100/70 dark:bg-neutral-900/70 border border-neutral-200/60 dark:border-neutral-800/80 mb-4">
        {/* Lagat */}
        <div>
          <span className="text-[10px] uppercase font-semibold text-neutral-500 dark:text-neutral-400 block truncate">
            {getTranslation(lang, 'expenses')}
          </span>
          <span className="text-sm font-bold font-mono text-rose-500 dark:text-rose-400 block tabular-nums">
            {formatCurrency(totalLagat)}
          </span>
        </div>

        {/* Kamai */}
        <div>
          <span className="text-[10px] uppercase font-semibold text-neutral-500 dark:text-neutral-400 block truncate">
            {getTranslation(lang, 'income')}
          </span>
          <span className="text-sm font-bold font-mono text-emerald-600 dark:text-emerald-400 block tabular-nums">
            {formatCurrency(totalKamai)}
          </span>
        </div>

        {/* Net Profit */}
        <div>
          <span className="text-[10px] uppercase font-semibold text-neutral-500 dark:text-neutral-400 block truncate">
            {isProfit ? getTranslation(lang, 'netProfit') : getTranslation(lang, 'netLoss')}
          </span>
          <div className="flex items-center gap-0.5">
            {isProfit ? (
              <TrendingUp className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            ) : (
              <TrendingDown className="w-3.5 h-3.5 text-rose-500 shrink-0" />
            )}
            <span
              className={`text-sm font-bold font-mono tabular-nums truncate ${
                isProfit ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500'
              }`}
            >
              {isProfit ? '+' : ''}
              {formatCurrency(netProfit)}
            </span>
          </div>
          <span className="text-[9px] text-neutral-500 dark:text-neutral-400 font-mono block truncate mt-0.5">
            {profitPerUnit >= 0 ? '+' : ''}
            {formatCurrency(profitPerUnit)}/{areaUnitLabel}
          </span>
        </div>
      </div>

      {/* Bottom Metadata & Click Action */}
      <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 pt-1">
        <div className="flex items-center gap-1.5 font-mono">
          <Calendar className="w-3.5 h-3.5" />
          <span>बुवाई: {crop.sowingDate}</span>
          {totalYield > 0 && (
            <>
              <span>·</span>
              <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                {totalYield} क्विंटल
              </span>
            </>
          )}
        </div>

        <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold group-hover:translate-x-1 transition-transform">
          <span>{lang === 'hi' ? 'खाता खोलें' : 'Open Ledger'}</span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
};
