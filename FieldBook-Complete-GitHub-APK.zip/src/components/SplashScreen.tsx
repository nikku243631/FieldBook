import React, { useEffect, useState } from 'react';
import { Sprout, ArrowRight, ShieldCheck, Sparkles, UserCheck } from 'lucide-react';
import { Language } from '../types';

interface SplashScreenProps {
  onDismiss: () => void;
  lang: Language;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onDismiss, lang }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        return prev + 12;
      });
    }, 120);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between p-6 bg-gradient-to-b from-neutral-950 via-emerald-950/90 to-neutral-950 text-white select-none overflow-hidden">
      {/* Background Liquid Glass Glows */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-teal-500/15 rounded-full blur-3xl pointer-events-none" />

      {/* Top Status */}
      <div className="w-full flex items-center justify-between max-w-md pt-4 text-xs text-emerald-400/80 font-mono tracking-wider">
        <span className="flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          {lang === 'hi' ? '100% सुरक्षित व ऑफलाइन' : '100% Offline & Secure'}
        </span>
        <span className="bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded text-[11px] text-emerald-300">
          v2.4 Agri-Ledger
        </span>
      </div>

      {/* Center Branding Lockup */}
      <div className="flex flex-col items-center text-center my-auto px-4 max-w-sm">
        {/* Animated 3D Glass Emblem */}
        <div className="relative mb-6">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-emerald-600 via-emerald-500 to-teal-400 p-[2px] shadow-2xl shadow-emerald-500/40">
            <div className="w-full h-full bg-neutral-950/90 rounded-[22px] backdrop-blur-xl flex items-center justify-center border border-emerald-400/30">
              <Sprout className="w-12 h-12 text-emerald-400 animate-pulse" />
            </div>
          </div>
          <div className="absolute -top-1.5 -right-1.5 p-1 bg-amber-400 rounded-full text-neutral-950 shadow-md">
            <Sparkles className="w-3.5 h-3.5 fill-current" />
          </div>
        </div>

        {/* Brand Name */}
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight bg-gradient-to-r from-emerald-200 via-emerald-400 to-teal-200 bg-clip-text text-transparent mb-2">
          FieldBook
        </h1>

        <p className="text-base text-neutral-300 font-medium mb-5">
          {lang === 'hi'
            ? 'डिजिटल खेत लेजर व फसल हिसाब-किताब'
            : 'Digital Farm Ledger & Crop Accounting'}
        </p>

        {/* Developer Credit Tag as specifically requested */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-900/40 border border-emerald-500/30 backdrop-blur-md shadow-lg shadow-emerald-950/50 mb-6">
          <UserCheck className="w-4 h-4 text-emerald-400" />
          <span className="text-xs uppercase tracking-wider text-emerald-300/80 font-mono">
            {lang === 'hi' ? 'डेवलपर:' : 'Developer:'}
          </span>
          <span className="text-sm font-bold text-white tracking-wide">
            Mr Nikhil
          </span>
        </div>

        {/* Feature Highlights Pills */}
        <div className="text-xs text-neutral-400 flex flex-wrap justify-center gap-2 mb-6">
          <span className="px-2.5 py-1 rounded-md bg-neutral-900/60 border border-neutral-800">लागत व कमाई</span>
          <span className="px-2.5 py-1 rounded-md bg-neutral-900/60 border border-neutral-800">मंडी भाव</span>
          <span className="px-2.5 py-1 rounded-md bg-neutral-900/60 border border-neutral-800">शुद्ध मुनाफा</span>
          <span className="px-2.5 py-1 rounded-md bg-neutral-900/60 border border-neutral-800">मौसम अलर्ट</span>
        </div>

        {/* Loading Bar */}
        <div className="w-full max-w-xs bg-neutral-800/80 h-1.5 rounded-full overflow-hidden mb-6 border border-neutral-700">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-200 rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Bottom Action CTA */}
      <div className="w-full max-w-md pb-6 flex flex-col items-center gap-3">
        <button
          onClick={onDismiss}
          className="btn-3d-primary w-full py-3.5 px-6 rounded-2xl text-white font-bold text-base flex items-center justify-center gap-2.5 shadow-xl cursor-pointer"
        >
          <span>{lang === 'hi' ? 'लेजर शुरू करें' : 'Open FieldBook'}</span>
          <ArrowRight className="w-5 h-5" />
        </button>

        <p className="text-[11px] text-neutral-400 font-mono text-center">
          {lang === 'hi'
            ? 'बिना इंटरनेट खेत में भी काम करता है • डेटा आपके फोन में सुरक्षित'
            : 'Works completely offline in fields • Data stored securely on device'}
        </p>
      </div>
    </div>
  );
};
