import JSZip from 'jszip';

const lazySourceFiles = import.meta.glob(
  [
    '/src/**/*.{ts,tsx}',
    '/scripts/**/*.ts'
  ],
  {
    query: '?raw',
    import: 'default',
    eager: false
  }
) as Record<string, () => Promise<string>>;

export const GITHUB_WORKFLOW_YAML = `name: Build FieldBook APK

'on':
  workflow_dispatch:
  push:
    branches:
      - main
      - master
    tags-ignore:
      - '*'
  pull_request:
    branches:
      - main
      - master

permissions:
  contents: write

jobs:
  build-apk:
    name: Build FieldBook Android Debug APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Extract FieldBook project
        shell: bash
        run: |
          set -euo pipefail
          ZIP_FILE=""
          if [ -f "FieldBook-Complete-GitHub-APK.zip" ]; then
            ZIP_FILE="FieldBook-Complete-GitHub-APK.zip"
          elif [ ! -f "package.json" ]; then
            ZIP_FILE="$(find . -maxdepth 1 -type f -name '*.zip' | head -n 1 || true)"
          fi
          if [ -n "$ZIP_FILE" ]; then
            echo "Extracting $ZIP_FILE into workspace..."
            rm -rf _extracted_zip
            mkdir -p _extracted_zip
            unzip -q "$ZIP_FILE" -d _extracted_zip
            PKG_JSON="$(find _extracted_zip -type f -name 'package.json' -not -path '*/node_modules/*' | head -n 1 || true)"
            if [ -n "$PKG_JSON" ]; then
              SRC_ROOT="$(dirname "$PKG_JSON")"
              rm -rf "$SRC_ROOT/.github"
              cp -af "$SRC_ROOT"/. .
            fi
            rm -rf _extracted_zip
          fi
          test -f package.json
          test -f package-lock.json
          test -f android/gradlew
          test -f android/settings.gradle
          test -f src/utils/zipExporter.ts
          test -f public/logo.png

      - name: Setup Node.js 22
        uses: actions/setup-node@v4
        with:
          node-version: '22'

      - name: Setup Java JDK 21
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '21'

      - name: Install Dependencies
        run: npm ci

      - name: TypeScript Validation
        run: npm run lint

      - name: Run Verification Tests
        run: npm run test

      - name: Build Web Application
        run: npm run build

      - name: Sync Capacitor Android
        run: npx cap sync android

      - name: Build Android Debug APK
        shell: bash
        run: |
          set -euo pipefail
          cd android
          chmod +x gradlew
          ./gradlew assembleDebug --no-daemon --stacktrace
          test -s app/build/outputs/apk/debug/app-debug.apk
          cp app/build/outputs/apk/debug/app-debug.apk "$GITHUB_WORKSPACE/FieldBook-Kisan-App.apk"
          ls -lh "$GITHUB_WORKSPACE/FieldBook-Kisan-App.apk"

      - name: Upload FieldBook-Kisan-App-APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: FieldBook-Kisan-App-APK
          path: FieldBook-Kisan-App.apk
          if-no-files-found: error
          retention-days: 30

      - name: Publish APK to GitHub Releases
        if: github.event_name != 'pull_request'
        uses: softprops/action-gh-release@v2
        continue-on-error: true
        with:
          tag_name: latest-apk
          name: "FieldBook Android App (v2.4.0 Debug APK)"
          fail_on_unmatched_files: false
          files: FieldBook-Kisan-App.apk
          prerelease: false
`;

const SELF_ZIP_EXPORTER_SOURCE = `import JSZip from 'jszip';

export const GITHUB_WORKFLOW_YAML = ${JSON.stringify(GITHUB_WORKFLOW_YAML)};

export function downloadWorkflowYaml(): void {
  const blob = new Blob([GITHUB_WORKFLOW_YAML], { type: 'text/yaml;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'build-apk.yml';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function downloadProjectZip(
  onProgress?: (status: string) => void
): Promise<number> {
  onProgress?.('Fetching complete project archive...');
  const res = await fetch('/FieldBook-Complete-GitHub-APK.zip', { cache: 'no-store' });
  if (res.ok) {
    const blob = await res.blob();
    if (blob.size > 50000) {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'FieldBook-Complete-GitHub-APK.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return 177;
    }
  }
  const zip = new JSZip();
  zip.file('.github/workflows/build-apk.yml', GITHUB_WORKFLOW_YAML);
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'FieldBook-Complete-GitHub-APK.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  return 1;
}
`;

export function downloadWorkflowYaml(): void {
  const blob = new Blob([GITHUB_WORKFLOW_YAML], { type: 'text/yaml;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'build-apk.yml';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function downloadDirectApk(
  onProgress?: (status: string) => void
): Promise<boolean> {
  onProgress?.('Downloading FieldBook-Kisan-App.apk...');
  const response = await fetch('/FieldBook-Kisan-App.apk', { cache: 'no-store' });
  if (!response.ok) {
    throw new Error('APK file not found on server');
  }
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('text/html')) {
    throw new Error('APK file returned HTML fallback');
  }
  const blob = await response.blob();
  if (blob.size < 100000) {
    throw new Error('Invalid APK size');
  }
  const apkBlob = new Blob([blob], { type: 'application/vnd.android.package-archive' });
  const url = URL.createObjectURL(apkBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'FieldBook-Kisan-App.apk';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  return true;
}

export async function downloadProjectZip(
  onProgress?: (status: string) => void
): Promise<number> {
  try {
    onProgress?.('पैकेज तैयार किया जा रहा है (Preparing complete ZIP)...');

    try {
      const response = await fetch('/FieldBook-Complete-GitHub-APK.zip', { cache: 'no-store' });
      if (response.ok) {
        const contentType = response.headers.get('content-type') || '';
        const blob = await response.blob();
        if (blob.size > 50000 && !contentType.includes('text/html')) {
          onProgress?.('ZIP डाउनलोड शुरू हो रहा है...');
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'FieldBook-Complete-GitHub-APK.zip';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          setTimeout(() => URL.revokeObjectURL(url), 3000);
          return 177;
        }
      }
    } catch {
      // Proceed to client-side JSZip generation fallback if offline
    }

    const zip = new JSZip();
    let count = 0;

    onProgress?.('सोर्स कोड फाइल्स पैक हो रही हैं...');

    for (const [fullPath, loader] of Object.entries(lazySourceFiles)) {
      try {
        const content = await loader();
        const cleanPath = fullPath.startsWith('/') ? fullPath.slice(1) : fullPath;
        if (typeof content === 'string') {
          zip.file(cleanPath, content);
          count++;
        }
      } catch {
        // Ignore individual module fetch error in fallback mode
      }
    }

    if (!zip.file('src/utils/zipExporter.ts')) {
      zip.file('src/utils/zipExporter.ts', SELF_ZIP_EXPORTER_SOURCE);
      count++;
    }

    zip.file('.github/workflows/build-apk.yml', GITHUB_WORKFLOW_YAML);
    zip.file('build-apk.yml', GITHUB_WORKFLOW_YAML);
    count += 2;

    onProgress?.('आइकॉन और पब्लिक एसेट्स जोड़े जा रहे हैं...');
    const publicAssets = [
      'logo.png',
      'farm-bg.jpg',
      'icon.svg',
      'pwa-192x192.png',
      'pwa-512x512.png',
      'pwa-maskable-512x512.png',
      'apple-touch-icon.png',
      'favicon.ico'
    ];

    for (const asset of publicAssets) {
      try {
        const res = await fetch(`/${asset}`);
        if (res.ok) {
          const blob = await res.blob();
          zip.file(`public/${asset}`, blob);
          count++;
        }
      } catch {
        // Ignore individual asset fetch error in offline fallback
      }
    }

    onProgress?.('ZIP फ़ाइल कंप्रेस हो रही है...');
    const zipBlob = await zip.generateAsync({
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 }
    });

    const downloadUrl = URL.createObjectURL(zipBlob);
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = 'FieldBook-Complete-GitHub-APK.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(downloadUrl), 3000);

    return count;
  } catch (err) {
    console.error('Failed to generate project ZIP:', err);
    onProgress?.('ZIP बनाने में त्रुटि आई (Failed to generate ZIP)');
    throw err;
  }
}
