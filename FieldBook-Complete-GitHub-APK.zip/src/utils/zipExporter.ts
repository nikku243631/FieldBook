import JSZip from 'jszip';

// Lazy raw loaders for source files (only invoked if pre-built ZIP fetch falls back to client-side JSZip)
const lazySourceFiles = import.meta.glob(
  [
    '/src/**/*.{ts,tsx}',
    '/scripts/**/*.ts'
  ],
  {
    query: '?raw',
    import: 'default',
    eager: false
  }
) as Record<string, () => Promise<string>>;

export const GITHUB_WORKFLOW_YAML = `name: Build Android APK

on:
  push:
    branches:
      - main
      - master
    tags-ignore:
      - '*'
  pull_request:
    branches:
      - main
      - master
  workflow_dispatch:

permissions:
  contents: write

jobs:
  build-apk:
    name: Build FieldBook Android Debug APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Node.js 22
        uses: actions/setup-node@v4
        with:
          node-version: '22'
          cache: 'npm'

      - name: Setup Java JDK 21
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '21'
          cache: 'gradle'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Dependencies Reproducibly from Lockfile
        run: npm ci

      - name: Run TypeScript Validation
        run: npm run lint

      - name: Run Automated Functional & Accounting Verification Suite
        run: npm run test

      - name: Run Production Web Build (Vite + PWA)
        run: npm run build

      - name: Sync Capacitor Android Project (Pinned Capacitor v7.2.0)
        run: |
          if [ ! -d "android" ]; then
            npx cap add android
          fi
          npx cap sync android

      - name: Generate Custom FieldBook Android Icons & Splash Screens
        run: |
          test -f public/pwa-512x512.png
          mkdir -p resources
          cp public/pwa-512x512.png resources/icon.png
          cp public/pwa-512x512.png resources/splash.png
          npx capacitor-assets generate --android --iconBackgroundColor '#065f46' --splashBackgroundColor '#064e3b' --splashBackgroundColorDark '#022c22'
          rm -rf resources

      - name: Build Installable Android Debug APK via Gradle
        run: |
          cd android
          chmod +x gradlew
          ./gradlew assembleDebug --no-daemon --stacktrace
          test -s app/build/outputs/apk/debug/app-debug.apk
          cp app/build/outputs/apk/debug/app-debug.apk ../FieldBook-Kisan-App.apk
          ls -lh ../FieldBook-Kisan-App.apk

      - name: Upload FieldBook-Kisan-App.apk Build Artifact
        uses: actions/upload-artifact@v4
        with:
          name: FieldBook-Kisan-App-APK
          path: FieldBook-Kisan-App.apk
          if-no-files-found: error

      - name: Publish Verified APK to GitHub Releases (Push / Manual Dispatch Only)
        if: github.event_name != 'pull_request'
        uses: softprops/action-gh-release@v2
        with:
          tag_name: latest-apk
          name: "FieldBook Android App (v2.4.0 Debug APK)"
          fail_on_unmatched_files: true
          body: |
            ### 🌾 FieldBook — Khet Ledger & Krishi Hisab (Android Debug APK)
            Download **\`FieldBook-Kisan-App.apk\`** from **Assets** below and install on your Android device.
            - **Package ID:** \`com.fieldbook.kisan\`
            - **Architecture:** React 19 + TypeScript + Vite 6 + Capacitor 7.2.0 Android WebView
            - **Offline Support:** Crop ledger, expenses/income, harvests, calculators, notes, shopping lists, and cached weather work offline via local storage. Live weather forecasts require internet connectivity.
          files: FieldBook-Kisan-App.apk
          prerelease: false
`;

const SELF_ZIP_EXPORTER_SOURCE = `import JSZip from 'jszip';

export const GITHUB_WORKFLOW_YAML = ${JSON.stringify(GITHUB_WORKFLOW_YAML)};

export function downloadWorkflowYaml(): void {
  const blob = new Blob([GITHUB_WORKFLOW_YAML], { type: 'text/yaml;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'build-apk.yml';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function downloadProjectZip(
  onProgress?: (status: string) => void
): Promise<number> {
  onProgress?.('Fetching complete project archive...');
  const res = await fetch('/FieldBook-Complete-GitHub-APK.zip', { cache: 'no-store' });
  if (res.ok) {
    const blob = await res.blob();
    if (blob.size > 50000) {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'FieldBook-Complete-GitHub-APK.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return 158;
    }
  }
  const zip = new JSZip();
  zip.file('.github/workflows/build-apk.yml', GITHUB_WORKFLOW_YAML);
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'FieldBook-Complete-GitHub-APK.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  return 1;
}
`;

export function downloadWorkflowYaml(): void {
  const blob = new Blob([GITHUB_WORKFLOW_YAML], { type: 'text/yaml;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'build-apk.yml';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function downloadProjectZip(
  onProgress?: (status: string) => void
): Promise<number> {
  try {
    onProgress?.('पैकेज तैयार किया जा रहा है (Preparing complete ZIP)...');

    // 1. Prefer the pre-built complete repository ZIP (which includes src/utils/zipExporter.ts,
    // package-lock.json, .github/workflows/build-apk.yml, and the complete Capacitor android/ folder + Gradle wrapper)
    try {
      const response = await fetch('/FieldBook-Complete-GitHub-APK.zip', { cache: 'no-store' });
      if (response.ok) {
        const contentType = response.headers.get('content-type') || '';
        const blob = await response.blob();
        if (blob.size > 50000 && !contentType.includes('text/html')) {
          onProgress?.('ZIP डाउनलोड शुरू हो रहा है...');
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'FieldBook-Complete-GitHub-APK.zip';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          setTimeout(() => URL.revokeObjectURL(url), 3000);
          return 158;
        }
      }
    } catch {
      // Proceed to client-side JSZip generation fallback if offline or static asset missing
    }

    // 2. Fallback: Build complete source ZIP in-memory via JSZip, ensuring src/utils/zipExporter.ts is ALWAYS included
    const zip = new JSZip();
    let count = 0;

    onProgress?.('सोर्स कोड फाइल्स पैक हो रही हैं...');

    for (const [fullPath, loader] of Object.entries(lazySourceFiles)) {
      try {
        const content = await loader();
        const cleanPath = fullPath.startsWith('/') ? fullPath.slice(1) : fullPath;
        if (typeof content === 'string') {
          zip.file(cleanPath, content);
          count++;
        }
      } catch {
        // Ignore individual module fetch error in fallback mode
      }
    }

    // Explicitly ensure src/utils/zipExporter.ts is present in the ZIP
    if (!zip.file('src/utils/zipExporter.ts')) {
      zip.file('src/utils/zipExporter.ts', SELF_ZIP_EXPORTER_SOURCE);
      count++;
    }

    // Include GitHub Actions workflow in both .github/workflows/ and backup root copy
    zip.file('.github/workflows/build-apk.yml', GITHUB_WORKFLOW_YAML);
    zip.file('build-apk.yml', GITHUB_WORKFLOW_YAML);
    count += 2;

    onProgress?.('आइकॉन और पब्लिक एसेट्स जोड़े जा रहे हैं...');
    const publicAssets = [
      'icon.svg',
      'pwa-192x192.png',
      'pwa-512x512.png',
      'apple-touch-icon.png'
    ];

    for (const asset of publicAssets) {
      try {
        const res = await fetch(`/${asset}`);
        if (res.ok) {
          const blob = await res.blob();
          zip.file(`public/${asset}`, blob);
          count++;
        }
      } catch {
        // Ignore individual asset fetch error in offline fallback
      }
    }

    onProgress?.('ZIP फ़ाइल कंप्रेस हो रही है...');
    const zipBlob = await zip.generateAsync({
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 }
    });

    const downloadUrl = URL.createObjectURL(zipBlob);
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = 'FieldBook-Complete-GitHub-APK.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(downloadUrl), 3000);

    return count;
  } catch (err) {
    console.error('Failed to generate project ZIP:', err);
    onProgress?.('ZIP बनाने में त्रुटि आई (Failed to generate ZIP)');
    throw err;
  }
}
