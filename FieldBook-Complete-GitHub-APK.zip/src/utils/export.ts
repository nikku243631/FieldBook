import { CropCycle, Transaction, HarvestEntry, Language } from '../types';
import { formatCurrency, getTranslation } from './translations';

export function generateWhatsAppSummary(
  crop: CropCycle,
  transactions: Transaction[],
  harvests: HarvestEntry[],
  lang: Language
): string {
  const cropTx = transactions.filter((t) => t.cropId === crop.id);
  const totalLagat = cropTx
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);
  const totalKamai = cropTx
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
  const netProfit = totalKamai - totalLagat;
  const totalHarvest = harvests
    .filter((h) => h.cropId === crop.id)
    .reduce((sum, h) => sum + h.quantityQuintal, 0);

  const profitText =
    netProfit >= 0
      ? `🟢 *${getTranslation(lang, 'netProfit')}:* ${formatCurrency(netProfit)}`
      : `🔴 *${getTranslation(lang, 'netLoss')}:* ${formatCurrency(Math.abs(netProfit))}`;

  const message = `🌾 *FieldBook - Khet Ledger Report* 🌾
_Developer: Mr Nikhil_
━━━━━━━━━━━━━━━━━━
🌱 *${getTranslation(lang, 'cropName')}:* ${crop.hindiName || crop.name}
📍 *${getTranslation(lang, 'landArea')}:* ${crop.landArea} ${getTranslation(lang, crop.areaUnit)}
📅 *${getTranslation(lang, 'sowingDate')}:* ${crop.sowingDate}
🌾 *${getTranslation(lang, 'totalHarvest')}:* ${totalHarvest} ${getTranslation(lang, 'quintal')}
━━━━━━━━━━━━━━━━━━
💰 *${getTranslation(lang, 'totalLagat')}:* ${formatCurrency(totalLagat)}
💵 *${getTranslation(lang, 'totalKamai')}:* ${formatCurrency(totalKamai)}
${profitText}
━━━━━━━━━━━━━━━━━━
📱 _FieldBook digital farm ledger_`;

  return encodeURIComponent(message);
}

export function exportTransactionsToCSV(
  crops: CropCycle[],
  transactions: Transaction[],
  lang: Language
): void {
  const cropMap = new Map(crops.map((c) => [c.id, c.name]));

  const headers = [
    'Crop Name',
    'Date',
    'Time',
    'Type (Expense/Income)',
    'Category',
    'Item Description',
    'Amount (INR)',
    'Quantity',
    'Unit',
    'Rate Per Unit',
    'Vendor / Buyer',
    'Payment Status',
    'Notes'
  ];

  const rows = transactions.map((t) => [
    `"${cropMap.get(t.cropId) || 'Unknown'}"`,
    `"${t.date}"`,
    `"${t.time}"`,
    `"${t.type}"`,
    `"${getTranslation(lang, t.category as any)}"`,
    `"${t.title.replace(/"/g, '""')}"`,
    t.amount,
    t.quantity || '',
    `"${t.unit || ''}"`,
    t.ratePerUnit || '',
    `"${(t.vendorOrBuyer || '').replace(/"/g, '""')}"`,
    `"${t.paymentStatus}"`,
    `"${(t.notes || '').replace(/"/g, '""')}"`
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `FieldBook_Agri_Ledger_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function printCropReportPDF(
  crop: CropCycle,
  transactions: Transaction[],
  harvests: HarvestEntry[],
  farmerName = 'Kisan Bhai',
  lang: Language = 'hi'
): void {
  const cropTx = transactions.filter((t) => t.cropId === crop.id);
  const expenses = cropTx.filter((t) => t.type === 'expense');
  const incomes = cropTx.filter((t) => t.type === 'income');

  const totalLagat = expenses.reduce((s, t) => s + t.amount, 0);
  const totalKamai = incomes.reduce((s, t) => s + t.amount, 0);
  const netProfit = totalKamai - totalLagat;
  const totalYield = harvests
    .filter((h) => h.cropId === crop.id)
    .reduce((s, h) => s + h.quantityQuintal, 0);

  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('Please allow popups to generate and print PDF statement.');
    return;
  }

  const printHtml = `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8" />
    <title>FieldBook Statement - ${crop.hindiName || crop.name}</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        color: #1a202c;
        margin: 24px;
        line-height: 1.4;
      }
      .header {
        border-bottom: 2px solid #059669;
        padding-bottom: 12px;
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
      }
      .brand-title {
        font-size: 26px;
        font-weight: bold;
        color: #065f46;
        margin: 0;
      }
      .dev-tag {
        font-size: 13px;
        color: #4b5563;
        font-weight: 500;
        margin-top: 4px;
      }
      .meta-box {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        background: #f0fdf4;
        border: 1px solid #bbf7d0;
        padding: 12px;
        border-radius: 6px;
        margin-bottom: 20px;
      }
      .meta-item {
        font-size: 13px;
      }
      .meta-label {
        color: #4b5563;
        font-size: 11px;
        text-transform: uppercase;
      }
      .meta-val {
        font-weight: bold;
        font-size: 14px;
        color: #064e3b;
      }
      .summary-cards {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
        margin-bottom: 24px;
      }
      .card {
        padding: 12px;
        border-radius: 6px;
        text-align: center;
      }
      .card-lagat {
        background: #fef2f2;
        border: 1px solid #fecaca;
      }
      .card-kamai {
        background: #ecfdf5;
        border: 1px solid #a7f3d0;
      }
      .card-profit {
        background: #f0fdf4;
        border: 2px solid #059669;
      }
      .card-title {
        font-size: 12px;
        color: #4b5563;
      }
      .card-amt {
        font-size: 20px;
        font-weight: bold;
      }
      table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
        font-size: 12px;
      }
      th {
        background: #065f46;
        color: #ffffff;
        text-align: left;
        padding: 8px;
      }
      td {
        padding: 8px;
        border-bottom: 1px solid #e5e7eb;
      }
      tr:nth-child(even) {
        background: #f9fafb;
      }
      .footer {
        margin-top: 36px;
        border-top: 1px solid #d1d5db;
        padding-top: 12px;
        font-size: 12px;
        color: #6b7280;
        display: flex;
        justify-content: space-between;
      }
      @media print {
        body { margin: 0; }
        .no-print { display: none; }
      }
    </style>
  </head>
  <body>
    <div class="header">
      <div>
        <h1 class="brand-title">FieldBook — कृषि लेजर व हिसाब-किताब</h1>
        <div class="dev-tag">डेवलपर: श्री निखिल (Developer: Mr Nikhil)</div>
      </div>
      <div style="text-align: right;">
        <div style="font-size: 12px; color: #6b7280;">स्टेटमेंट दिनांक: ${new Date().toLocaleDateString('en-IN')}</div>
        <div style="font-weight: bold; font-size: 14px;">किसान: ${farmerName}</div>
      </div>
    </div>

    <div class="meta-box">
      <div class="meta-item">
        <div class="meta-label">फसल (Crop)</div>
        <div class="meta-val">${crop.hindiName || crop.name}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">रकबा (Area)</div>
        <div class="meta-val">${crop.landArea} ${crop.areaUnit}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">बुवाई तिथि</div>
        <div class="meta-val">${crop.sowingDate}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">कुल पैदावार</div>
        <div class="meta-val">${totalYield} क्विंटल</div>
      </div>
    </div>

    <div class="summary-cards">
      <div class="card card-lagat">
        <div class="card-title">कुल लागत (खर्च)</div>
        <div class="card-amt" style="color: #dc2626;">${formatCurrency(totalLagat)}</div>
      </div>
      <div class="card card-kamai">
        <div class="card-title">कुल आमदनी (बिक्री)</div>
        <div class="card-amt" style="color: #059669;">${formatCurrency(totalKamai)}</div>
      </div>
      <div class="card card-profit">
        <div class="card-title">शुद्ध परिणाम (Profit/Loss)</div>
        <div class="card-amt" style="color: ${netProfit >= 0 ? '#047857' : '#b91c1c'};">
          ${netProfit >= 0 ? '+' : ''}${formatCurrency(netProfit)}
        </div>
      </div>
    </div>

    <h3 style="color: #065f46; margin-bottom: 8px;">1. मंडी बिक्री व आमदनी विवरण (Sales/Income)</h3>
    <table>
      <thead>
        <tr>
          <th>तारीख</th>
          <th>विवरण / आढ़ती</th>
          <th>मात्रा (क्विंटल)</th>
          <th>भाव प्रति क्विंटल</th>
          <th>कटौती</th>
          <th>कुल जमा (₹)</th>
        </tr>
      </thead>
      <tbody>
        ${
          incomes.length > 0
            ? incomes
                .map(
                  (i) => `
          <tr>
            <td>${i.date}</td>
            <td>${i.title} ${i.vendorOrBuyer ? `(${i.vendorOrBuyer})` : ''}</td>
            <td>${i.quantity || i.mandiDetails?.netWeightQuintal || '-'}</td>
            <td>₹${i.ratePerUnit || i.mandiDetails?.ratePerQuintal || '-'}</td>
            <td>₹${i.mandiDetails?.totalPalledari || 0}</td>
            <td style="font-weight: bold; color: #047857;">${formatCurrency(i.amount)}</td>
          </tr>`
                )
                .join('')
            : '<tr><td colspan="6" style="text-align:center; color:#9ca3af;">कोई बिक्री दर्ज नहीं है</td></tr>'
        }
      </tbody>
    </table>

    <h3 style="color: #991b1b; margin-bottom: 8px;">2. लागत व खर्च विवरण (Expenses)</h3>
    <table>
      <thead>
        <tr>
          <th>तारीख</th>
          <th>मद / श्रेणी</th>
          <th>खर्च विवरण</th>
          <th>मात्रा / दर</th>
          <th>दुकानदार / मजदूर</th>
          <th>रकम (₹)</th>
        </tr>
      </thead>
      <tbody>
        ${
          expenses.length > 0
            ? expenses
                .map(
                  (e) => `
          <tr>
            <td>${e.date}</td>
            <td>${getTranslation(lang, e.category as any)}</td>
            <td>${e.title}</td>
            <td>${e.quantity ? `${e.quantity} ${e.unit || ''}` : '-'}</td>
            <td>${e.vendorOrBuyer || '-'}</td>
            <td style="font-weight: bold; color: #dc2626;">${formatCurrency(e.amount)}</td>
          </tr>`
                )
                .join('')
            : '<tr><td colspan="6" style="text-align:center; color:#9ca3af;">कोई खर्च दर्ज नहीं है</td></tr>'
        }
      </tbody>
    </table>

    <div class="footer">
      <div>FieldBook — Smart Farm Accounting App | डेवलपर: श्री निखिल (Mr Nikhil)</div>
      <div>हस्ताक्षर / मोहर: ____________________</div>
    </div>

    <script>
      window.onload = function() {
        window.print();
      };
    </script>
  </body>
  </html>
  `;

  printWindow.document.write(printHtml);
  printWindow.document.close();
}
