import { Language } from '../types';

export const translations = {
  hi: {
    appTitle: 'FieldBook',
    appSubtitle: 'खेत लेजर व कृषि हिसाब-किताब',
    developerCredit: 'डेवलपर: श्री निखिल',
    devBy: 'डेवलपर',
    devName: 'श्री निखिल (Mr Nikhil)',
    allCrops: 'सभी फसलें',
    addCrop: 'नई फसल जोड़ें',
    editCrop: 'फसल विवरण बदलें',
    cropName: 'फसल का नाम',
    cropVariety: 'किस्म / वैरायटी',
    landArea: 'खेत का रकबा (क्षेत्रफल)',
    areaUnit: 'इकाई',
    season: 'सीज़न / मौसम',
    sowingDate: 'बुवाई की तारीख',
    harvestDate: 'अनुमानित कटाई तारीख',
    targetYield: 'लक्ष्य पैदावार (क्विंटल)',
    status: 'स्थिति',
    active: 'खेत में चालू',
    harvested: 'कटाई पूर्ण',
    archived: 'अभिलेखागार',
    notes: 'टिप्पणी / विवरण',
    save: 'सुरक्षित करें',
    cancel: 'रद्द करें',
    delete: 'हटाएं',
    confirmDeleteCrop: 'क्या आप सचमुच इस फसल का पूरा हिसाब हटाना चाहते हैं?',
    
    // Ledger sections
    dashboard: 'डैशबोर्ड व मुनाफा',
    expenses: 'लागत (खर्च)',
    income: 'कमाई (आमदनी)',
    harvest: 'तुड़ाई / कटाई',
    diary: 'खेत डायरी',
    calculators: 'कृषि कैलकुलेटर',
    notesAndLists: 'नोट्स व सामान लिस्ट',
    weather: 'मौसम व छिड़काव अलर्ट',
    reports: 'मासिक रिपोर्ट व बैकअप',
    
    // Metrics
    totalLagat: 'कुल लागत (खर्च)',
    totalKamai: 'कुल कमाई (बिक्री)',
    netProfit: 'शुद्ध मुनाफा',
    netLoss: 'शुद्ध नुकसान',
    profitMargin: 'मुनाफा दर',
    costPerAcre: 'लागत प्रति एकड़',
    profitPerAcre: 'मुनाफा प्रति एकड़',
    totalHarvest: 'कुल पैदावार',
    avgRate: 'औसत मंडी भाव',
    
    // Expense Categories
    fertilizer: 'खाद (उर्वरक/यूरिया/DAP)',
    seeds: 'बीज (सीड्स)',
    pesticide: 'कीटनाशक / दवाई / स्प्रे',
    irrigation: 'पानी / सिंचाई / डीजल',
    labour: 'मजदूरी / लेबर खर्च',
    machinery: 'ट्रैक्टर / जुताई / कंबाइन',
    other: 'अन्य विविध खर्च',
    
    // Income Categories
    mandi_sale: 'मंडी में बिक्री',
    local_sale: 'गांव / स्थानीय बिक्री',
    subsidy: 'सरकारी अनुदान / सब्सिडी',
    byproduct: 'भूसा / पराली बिक्री',
    
    // Add Transaction
    addExpense: 'खर्च जोड़ें',
    addIncome: 'कमाई जोड़ें',
    transactionTitle: 'विवरण / मद',
    amount: 'रकम (₹)',
    date: 'तारीख',
    time: 'समय',
    quantity: 'मात्रा',
    ratePerUnit: 'दर प्रति इकाई',
    vendorOrBuyer: 'दुकानदार / आढ़ती / खरीदार',
    paymentStatus: 'भुगतान स्थिति',
    paid: 'भुगतान हो गया',
    pending: 'बकाया (उधारी)',
    
    // Mandi specifics
    mandiRate: 'मंडी भाव (₹ प्रति क्विंटल)',
    grossWeight: 'कुल वजन (क्विंटल या किलो)',
    netWeight: 'शुद्ध वजन (क्विंटल)',
    palledariDeduction: 'पल्लेदारी / तुलाई कटौती (₹)',
    buyerName: 'आढ़ती / फर्म का नाम',
    slipNumber: 'पर्ची / बिल नंबर',
    
    // Harvest logging
    addHarvest: 'कटाई वजन दर्ज करें',
    quantityQuintal: 'वजन (क्विंटल में)',
    moisturePercentage: 'नमी %',
    grade: 'क्वालिटी / ग्रेड',
    storageLocation: 'रखने का स्थान (मंडी/घर/गोदाम)',
    
    // Diary
    addDiary: 'खेत डायरी में लिखें',
    activityType: 'कार्य का प्रकार',
    activitySowing: 'बुवाई कार्य',
    activityIrrigation: 'पानी / सिंचाई लगाई',
    activityFertilizer: 'खाद डाली',
    activitySpray: 'दवा का छिड़काव किया',
    activityInspection: 'खेत निरीक्षण / रोग जांच',
    activityHarvest: 'कटाई / तुड़ाई कार्य',
    activityWeeding: 'निराई-गुड़ाई',
    
    // Units
    acre: 'एकड़ (Acre)',
    bigha: 'बीघा (Bigha)',
    hectare: 'हेक्टेयर (Hectare)',
    marla: 'मरला (Marla)',
    kanal: 'कनाल (Kanal)',
    guntha: 'गुंठा (Guntha)',
    quintal: 'क्विंटल (100 किलो)',
    mann: 'मन (40 किलो)',
    kg: 'किलोग्राम (Kg)',
    bori: 'बोरी (50 किलो)',
    
    // Backup & Export
    exportPdf: 'PDF रिपोर्ट बनाएं (प्रिंट)',
    exportCsv: 'Excel / CSV डाउनलोड करें',
    backupJson: 'पूरा डेटा फोन में बैकअप करें',
    restoreJson: 'बैकअप फाइल से डेटा वापस लाएं',
    shareWhatsapp: 'व्हाट्सएप पर शेयर करें',
    dataSavedOffline: 'सारा डेटा आपके फोन में सुरक्षित और ऑफलाइन सेव है',
    
    // Weather
    sprayAdvisory: 'छिड़काव सलाह',
    safeSpray: 'मौसम छिड़काव के लिए बहुत अनुकूल है',
    cautionSpray: 'सावधानी: तेज हवा है, दवा उड़ सकती है',
    rainWarning: 'अलर्ट: बारिश की संभावना है, छिड़काव अभी न करें',
    temperature: 'तापमान',
    humidity: 'हवा में नमी',
    windSpeed: 'हवा की गति',
    forecast7Days: 'अगले 7 दिनों का मौसम पूर्वानुमान',
    
    // Calculators
    calcMandi: 'मंडी भाव व वजन कैलकुलेटर',
    calcFertilizer: 'खाद (NPK/यूरिया) मात्रा कैलकुलेटर',
    calcSeedRate: 'बीज मात्रा कैलकुलेटर',
    calcLandArea: 'जमीन क्षेत्रफल परिवर्तक',
    calcDieselPump: 'ट्यूबवेल डीजल / सिंचाई खर्च',
  },
  en: {
    appTitle: 'FieldBook',
    appSubtitle: 'Digital Farm Ledger & Crop Accounting',
    developerCredit: 'Developer: Mr Nikhil',
    devBy: 'Developer',
    devName: 'Mr Nikhil',
    allCrops: 'All Crops',
    addCrop: 'Add New Crop',
    editCrop: 'Edit Crop Info',
    cropName: 'Crop Name',
    cropVariety: 'Variety',
    landArea: 'Land Area',
    areaUnit: 'Unit',
    season: 'Season',
    sowingDate: 'Sowing Date',
    harvestDate: 'Expected Harvest Date',
    targetYield: 'Target Yield (Quintal)',
    status: 'Status',
    active: 'In Field (Active)',
    harvested: 'Harvested',
    archived: 'Archived',
    notes: 'Notes / Remarks',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    confirmDeleteCrop: 'Are you sure you want to permanently delete this crop ledger?',
    
    // Ledger sections
    dashboard: 'P&L Dashboard',
    expenses: 'Expenses (Lagat)',
    income: 'Income (Kamai)',
    harvest: 'Harvest (Tudai)',
    diary: 'Farm Diary',
    calculators: 'Agri Calculators',
    notesAndLists: 'Notes & Lists',
    weather: 'Weather & Spray Alerts',
    reports: 'Reports & Backup',
    
    // Metrics
    totalLagat: 'Total Expenses (Lagat)',
    totalKamai: 'Total Income (Kamai)',
    netProfit: 'Net Profit',
    netLoss: 'Net Loss',
    profitMargin: 'Profit Margin',
    costPerAcre: 'Cost per Acre',
    profitPerAcre: 'Profit per Acre',
    totalHarvest: 'Total Harvest',
    avgRate: 'Avg Mandi Rate',
    
    // Expense Categories
    fertilizer: 'Fertilizer (Khad / Urea / DAP)',
    seeds: 'Seeds (Beej)',
    pesticide: 'Pesticide / Spray / Medicine',
    irrigation: 'Water / Irrigation / Diesel',
    labour: 'Labour / Mazdoori Wages',
    machinery: 'Tractor / Plowing / Harvester',
    other: 'Other Miscellaneous Expenses',
    
    // Income Categories
    mandi_sale: 'Mandi Sales',
    local_sale: 'Local / Farm Gate Sales',
    subsidy: 'Government Subsidy',
    byproduct: 'Straw / Fodder Sales',
    
    // Add Transaction
    addExpense: 'Add Expense',
    addIncome: 'Add Income',
    transactionTitle: 'Item / Description',
    amount: 'Amount (₹)',
    date: 'Date',
    time: 'Time',
    quantity: 'Quantity',
    ratePerUnit: 'Rate per Unit',
    vendorOrBuyer: 'Vendor / Buyer / Trader',
    paymentStatus: 'Payment Status',
    paid: 'Paid',
    pending: 'Pending / Due',
    
    // Mandi specifics
    mandiRate: 'Mandi Rate (₹ per Quintal)',
    grossWeight: 'Gross Weight (Quintal / Kg)',
    netWeight: 'Net Weight (Quintal)',
    palledariDeduction: 'Palledari / Weight Deductions (₹)',
    buyerName: 'Trader / Arhatiya Name',
    slipNumber: 'Receipt / Slip No.',
    
    // Harvest logging
    addHarvest: 'Log Harvest Weight',
    quantityQuintal: 'Weight (Quintals)',
    moisturePercentage: 'Moisture %',
    grade: 'Grade / Quality',
    storageLocation: 'Storage Location',
    
    // Diary
    addDiary: 'Add Diary Note',
    activityType: 'Activity Type',
    activitySowing: 'Sowing Work',
    activityIrrigation: 'Irrigation / Watering',
    activityFertilizer: 'Fertilizer Application',
    activitySpray: 'Pesticide / Foliar Spray',
    activityInspection: 'Field Inspection / Pest Check',
    activityHarvest: 'Harvesting / Picking',
    activityWeeding: 'Weeding / Interculture',
    
    // Units
    acre: 'Acre',
    bigha: 'Bigha',
    hectare: 'Hectare',
    marla: 'Marla',
    kanal: 'Kanal',
    guntha: 'Guntha',
    quintal: 'Quintal (100 kg)',
    mann: 'Mann (40 kg)',
    kg: 'Kilogram (Kg)',
    bori: 'Bag (50 kg)',
    
    // Backup & Export
    exportPdf: 'Generate PDF Report (Print)',
    exportCsv: 'Download Excel / CSV',
    backupJson: 'Backup All Data to Phone',
    restoreJson: 'Restore Data from Backup',
    shareWhatsapp: 'Share via WhatsApp',
    dataSavedOffline: 'All data is securely stored offline on your device',
    
    // Weather
    sprayAdvisory: 'Spray Advisory',
    safeSpray: 'Weather is excellent for spray application',
    cautionSpray: 'Caution: Windy conditions, spray drift possible',
    rainWarning: 'Alert: Rain forecasted within 24h, postpone spray',
    temperature: 'Temperature',
    humidity: 'Humidity',
    windSpeed: 'Wind Speed',
    forecast7Days: '7-Day Weather Forecast',
    
    // Calculators
    calcMandi: 'Mandi Rate & Weight Calculator',
    calcFertilizer: 'Fertilizer (NPK/Urea) Dosage Calculator',
    calcSeedRate: 'Seed Rate Calculator',
    calcLandArea: 'Land Area Unit Converter',
    calcDieselPump: 'Tube-well Diesel & Irrigation Cost',
  }
};

export function getTranslation(lang: Language, key: keyof typeof translations['hi']): string {
  return translations[lang][key] || translations['hi'][key] || key;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(amount);
}

export function formatNumber(num: number, decimals = 1): string {
  return new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: decimals,
    minimumFractionDigits: Number.isInteger(num) ? 0 : 1
  }).format(num);
}
