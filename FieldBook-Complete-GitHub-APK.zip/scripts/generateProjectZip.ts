import fs from 'node:fs';
import path from 'node:path';
import JSZip from 'jszip';

const ROOT_DIR = process.cwd();

const EXCLUDE_DIRS = new Set([
  'node_modules',
  '.git',
  '.aistudio',
  'dist',
  'dev-dist',
  'build',
  '.gradle'
]);

const EXCLUDE_FILES = new Set([
  'FieldBook-Complete-GitHub-APK.zip',
  'bun.lock',
  '.DS_Store'
]);

function addDirectoryToZip(zip: JSZip, absDir: string, relDir = ''): number {
  let count = 0;
  const entries = fs.readdirSync(absDir, { withFileTypes: true });

  for (const entry of entries) {
    if (EXCLUDE_DIRS.has(entry.name) || EXCLUDE_FILES.has(entry.name)) {
      continue;
    }

    const absPath = path.join(absDir, entry.name);
    const zipPath = relDir ? `${relDir}/${entry.name}` : entry.name;

    if (entry.isDirectory()) {
      count += addDirectoryToZip(zip, absPath, zipPath);
    } else if (entry.isFile()) {
      const buffer = fs.readFileSync(absPath);
      const isExecutable = entry.name === 'gradlew';
      zip.file(zipPath, buffer, {
        unixPermissions: isExecutable ? '755' : '644'
      });
      count++;
    }
  }

  return count;
}

async function main() {
  console.log('=== Packaging FieldBook-Complete-GitHub-APK.zip ===');
  const zip = new JSZip();

  const totalFiles = addDirectoryToZip(zip, ROOT_DIR);

  // Verify critical required files exist inside the generated ZIP
  const requiredFiles = [
    'src/utils/zipExporter.ts',
    'src/utils/calculations.ts',
    'src/App.tsx',
    'src/components/InstallModal.tsx',
    'src/components/ReportsBackupView.tsx',
    'package.json',
    'package-lock.json',
    'capacitor.config.json',
    '.github/workflows/build-apk.yml',
    'android/gradlew',
    'android/gradlew.bat',
    'android/gradle/wrapper/gradle-wrapper.jar',
    'android/gradle/wrapper/gradle-wrapper.properties',
    'android/app/build.gradle',
    'android/app/src/main/AndroidManifest.xml',
    'android/app/src/main/res/values/strings.xml',
    'README.md',
    'AUDIT-REPORT.md'
  ];

  for (const reqFile of requiredFiles) {
    if (!zip.file(reqFile)) {
      throw new Error(`CRITICAL: Required file "${reqFile}" is missing from the generated ZIP!`);
    }
  }

  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
    platform: 'UNIX'
  });

  const rootZipPath = path.join(ROOT_DIR, 'FieldBook-Complete-GitHub-APK.zip');
  const publicZipPath = path.join(ROOT_DIR, 'public', 'FieldBook-Complete-GitHub-APK.zip');

  fs.writeFileSync(rootZipPath, buffer);
  fs.writeFileSync(publicZipPath, buffer);

  const sizeMB = (buffer.length / (1024 * 1024)).toFixed(2);
  console.log(`✓ Packed ${totalFiles} files (${sizeMB} MB) into:`);
  console.log(`  1. ${rootZipPath}`);
  console.log(`  2. ${publicZipPath}`);
  console.log(`✓ Verified all ${requiredFiles.length} critical files (including src/utils/zipExporter.ts, android/gradlew, and .github/workflows/build-apk.yml) inside the archive.`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
