/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "0d1bc1c80fde4df60d85e53a233ec9a7"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e72ba9fca3cdcbe274286fa0a42cba96"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f2321851d8cc83a93a6ae9666657751f"
  }, {
    "url": "logo.png",
    "revision": "e72ba9fca3cdcbe274286fa0a42cba96"
  }, {
    "url": "index.html",
    "revision": "df22ae9dd57811ea6d2ccf696fd799b4"
  }, {
    "url": "icon.svg",
    "revision": "9fa8396e6dfdd0e1aa84caf132014edb"
  }, {
    "url": "favicon.ico",
    "revision": "18590afee9a6cbfbad204528dacdeaf8"
  }, {
    "url": "farm-bg.jpg",
    "revision": "b6b7c3a2e030cd87630ef7d7c78e255a"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "18e597183d3bd23d8febaaa6dada9584"
  }, {
    "url": "assets/web-CUeOY4y4.js",
    "revision": null
  }, {
    "url": "assets/weather-DPkAPT-m.js",
    "revision": null
  }, {
    "url": "assets/verify-fieldbook-CPddEVch.js",
    "revision": null
  }, {
    "url": "assets/usePWAInstall-DEfDqIaX.js",
    "revision": null
  }, {
    "url": "assets/translations-DScnemuC.js",
    "revision": null
  }, {
    "url": "assets/storage-Bh86lqtE.js",
    "revision": null
  }, {
    "url": "assets/platform-DoczFQez.js",
    "revision": null
  }, {
    "url": "assets/main-crRLAEKx.js",
    "revision": null
  }, {
    "url": "assets/index-xFemAm1G.css",
    "revision": null
  }, {
    "url": "assets/index-npPw7w-g.js",
    "revision": null
  }, {
    "url": "assets/index-CMKib-bH.js",
    "revision": null
  }, {
    "url": "assets/generateProjectZip-DVll7ewc.js",
    "revision": null
  }, {
    "url": "assets/export-BNV2G8TK.js",
    "revision": null
  }, {
    "url": "assets/calculations-D6MBEKuq.js",
    "revision": null
  }, {
    "url": "assets/WeatherView-ALHyctA_.js",
    "revision": null
  }, {
    "url": "assets/SplashScreen-CY-7arrb.js",
    "revision": null
  }, {
    "url": "assets/SimpleCalculator-Dnf2R4s-.js",
    "revision": null
  }, {
    "url": "assets/ReportsBackupView-CGROmWE6.js",
    "revision": null
  }, {
    "url": "assets/NotesAndListsView-bki5bvzU.js",
    "revision": null
  }, {
    "url": "assets/InstallModal-DHL6Tq5a.js",
    "revision": null
  }, {
    "url": "assets/Header-4NzXnJ_m.js",
    "revision": null
  }, {
    "url": "assets/CropList-BG-vUvlI.js",
    "revision": null
  }, {
    "url": "assets/CropDetailView-Bq0PLesP.js",
    "revision": null
  }, {
    "url": "assets/CropCard-CtQ9U1Cq.js",
    "revision": null
  }, {
    "url": "assets/ConfirmModal-BCcDd3Yb.js",
    "revision": null
  }, {
    "url": "assets/CalculatorsView-Bzlz9al7.js",
    "revision": null
  }, {
    "url": "assets/App-D_NFPa95.js",
    "revision": null
  }, {
    "url": "assets/AddTransactionModal-CItJYnDH.js",
    "revision": null
  }, {
    "url": "assets/AddHarvestModal-DXgekTJV.js",
    "revision": null
  }, {
    "url": "assets/AddCropModal-Coh6mm_S.js",
    "revision": null
  }, {
    "url": "assets/aistudio/file_00000000f47c82079b852527a6333f06_b9cf6c96.png",
    "revision": null
  }, {
    "url": "assets/aistudio/file_00000000e0c882078d5d4d41aa5bd556_b54e998b.png",
    "revision": null
  }, {
    "url": "assets/aistudio/file_00000000044082118bbcf620d0d4a50a_0c4b7329.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_2026-10-20-07-37-19-96_40deb401b9ffe8e1df2f1cc5ba480b12_d722205d.jpg",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_2026-10-20-07-04-07-44_40deb401b9ffe8e1df2f1cc5ba480b12_1f3cfffe.jpg",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_2026-10-20-07-02-52-65_40deb401b9ffe8e1df2f1cc5ba480b12_2b605a11.jpg",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_2026-10-20-07-01-47-36_40deb401b9ffe8e1df2f1cc5ba480b12_21d70a23.jpg",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "18e597183d3bd23d8febaaa6dada9584"
  }, {
    "url": "farm-bg.jpg",
    "revision": "b6b7c3a2e030cd87630ef7d7c78e255a"
  }, {
    "url": "favicon.ico",
    "revision": "18590afee9a6cbfbad204528dacdeaf8"
  }, {
    "url": "icon.svg",
    "revision": "9fa8396e6dfdd0e1aa84caf132014edb"
  }, {
    "url": "logo.png",
    "revision": "e72ba9fca3cdcbe274286fa0a42cba96"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f2321851d8cc83a93a6ae9666657751f"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e72ba9fca3cdcbe274286fa0a42cba96"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "0d1bc1c80fde4df60d85e53a233ec9a7"
  }, {
    "url": "manifest.webmanifest",
    "revision": "b7b2eac79f0fdbd27938ba72e7819958"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
