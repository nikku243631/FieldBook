/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "6b16c770aee3de406cb1a04f33379ad1"
  }, {
    "url": "pwa-512x512.png",
    "revision": "6b16c770aee3de406cb1a04f33379ad1"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1aa34622d3a63f1678d31371fcc86e67"
  }, {
    "url": "index.html",
    "revision": "4ed1f5c711181b8cc9cd6288126e672f"
  }, {
    "url": "icon.svg",
    "revision": "08c7a24e6c19e16658c90cb814c8200d"
  }, {
    "url": "favicon.ico",
    "revision": "1aa34622d3a63f1678d31371fcc86e67"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "995cbf5c4c88e70733823141f567ed17"
  }, {
    "url": "assets/web-Ice0wa0Y.js",
    "revision": null
  }, {
    "url": "assets/index-Cv6d-lsY.css",
    "revision": null
  }, {
    "url": "assets/index-Bp5anH5G.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "995cbf5c4c88e70733823141f567ed17"
  }, {
    "url": "favicon.ico",
    "revision": "1aa34622d3a63f1678d31371fcc86e67"
  }, {
    "url": "icon.svg",
    "revision": "08c7a24e6c19e16658c90cb814c8200d"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1aa34622d3a63f1678d31371fcc86e67"
  }, {
    "url": "pwa-512x512.png",
    "revision": "6b16c770aee3de406cb1a04f33379ad1"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "6b16c770aee3de406cb1a04f33379ad1"
  }, {
    "url": "manifest.webmanifest",
    "revision": "308aaf584fc6a012e051b9442e36a1c8"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
