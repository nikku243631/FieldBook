const e=`import React from 'react';
import {
  Sun,
  Moon,
  Globe,
  Calculator,
  Download,
  ArrowLeft,
  ChevronDown,
  Sprout,
  FileText,
  CloudSun,
  BarChart3,
  User
} from 'lucide-react';
import { Language, Theme } from '../types';
import { getTranslation } from '../utils/translations';
import { isCapacitorNative, isInstalledApp } from '../utils/platform';

export type ActiveMainTab = 'crops' | 'reports' | 'calculators' | 'weather' | 'notes';

interface HeaderProps {
  currentTab?: ActiveMainTab;
  activeTab?: ActiveMainTab;
  onSelectTab?: (tab: ActiveMainTab) => void;
  setActiveTab?: (tab: ActiveMainTab) => void;
  lang: Language;
  onToggleLang?: () => void;
  setLang?: (lang: Language) => void;
  theme: Theme;
  onToggleTheme?: () => void;
  setTheme?: (theme: Theme) => void;
  onOpenAddCrop?: () => void;
  onAddCropClick?: () => void;
  onOpenQuickCalc?: () => void;
  onOpenSimpleCalc?: () => void;
  onOpenInstallModal?: () => void;
  selectedCropId?: string | null;
  onBackToCrops?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  activeTab,
  onSelectTab,
  setActiveTab,
  lang,
  onToggleLang,
  setLang,
  theme,
  onToggleTheme,
  setTheme,
  onOpenQuickCalc,
  onOpenSimpleCalc,
  onOpenInstallModal,
  selectedCropId,
  onBackToCrops,
}) => {
  const t = (key: any) => getTranslation(lang, key);
  const resolvedTab: ActiveMainTab = currentTab || activeTab || 'crops';
  const isNativeOrInstalled = isCapacitorNative() || isInstalledApp();

  const handleTabChange = (tab: ActiveMainTab) => {
    if (onSelectTab) {
      onSelectTab(tab);
    } else if (setActiveTab) {
      setActiveTab(tab);
    }
  };

  const handleThemeToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onToggleTheme) {
      onToggleTheme();
    } else if (setTheme) {
      setTheme(theme === 'dark' ? 'light' : 'dark');
    }
  };

  const handleLangToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onToggleLang) {
      onToggleLang();
    } else if (setLang) {
      setLang(lang === 'hi' ? 'en' : 'hi');
    }
  };

  const handleOpenCalc = () => {
    if (onOpenQuickCalc) {
      onOpenQuickCalc();
    } else if (onOpenSimpleCalc) {
      onOpenSimpleCalc();
    }
  };

  return (
    <header
      className="sticky top-0 z-40 w-full transition-all"
      style={{
        paddingTop: isCapacitorNative()
          ? 'max(env(safe-area-inset-top, 0px), 8px)'
          : 'env(safe-area-inset-top, 0px)'
      }}
    >
      <div className="max-w-5xl mx-auto px-2.5 sm:px-5 pt-2 pb-1.5">
        {/* Top Row: Floating 3D Liquid Glass Brand Capsule + Fully Visible Utility Controls */}
        <div className="flex items-center justify-between gap-1.5 sm:gap-2.5 w-full">
          {/* Left: Back Button (if inside crop ledger) + Floating Frosted Brand Pill */}
          <div className="flex items-center gap-1.5 min-w-0 shrink">
            {selectedCropId && onBackToCrops && (
              <button
                type="button"
                onClick={onBackToCrops}
                className="liquid-glass-sky w-10 h-10 sm:w-11 sm:h-11 rounded-2xl flex items-center justify-center shrink-0 cursor-pointer"
                title={lang === 'hi' ? 'वापस जाएं' : 'Back'}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}

            {/* Brand Logo Capsule matching Reference Image */}
            <div
              onClick={() => handleTabChange('crops')}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') handleTabChange('crops');
              }}
              className="liquid-glass-sky rounded-[20px] sm:rounded-[22px] px-2.5 sm:px-3.5 py-1.5 flex items-center gap-2 sm:gap-2.5 cursor-pointer min-w-0 shrink"
            >
              <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl overflow-hidden border border-white/80 shadow-md bg-emerald-950 shrink-0 flex items-center justify-center">
                <img
                  src="/logo.png"
                  alt="FieldBook Logo"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="min-w-0 pr-0.5">
                <div className="flex items-center leading-none">
                  <span
                    className={\`text-base sm:text-xl font-black tracking-tight \${
                      theme === 'dark' ? 'text-white' : 'text-slate-950'
                    }\`}
                  >
                    Field
                  </span>
                  <span className="text-base sm:text-xl font-black tracking-tight text-emerald-700 dark:text-emerald-400">
                    Book
                  </span>
                  <Sprout className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 -mt-2 ml-0.5 shrink-0" />
                </div>
                <p
                  className={\`text-[10px] sm:text-xs font-semibold italic leading-tight truncate mt-0.5 \${
                    theme === 'dark' ? 'text-slate-200' : 'text-slate-800'
                  }\`}
                >
                  By Mr Nikhil
                </p>
              </div>
            </div>
          </div>

          {/* Right Utility Controls: Every Button Guaranteed 100% Visible & Unclipped */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* 1. Language Selector Pill (🌐 हिंदी ⌄) */}
            <button
              type="button"
              onClick={handleLangToggle}
              className="liquid-glass-sky h-10 sm:h-11 px-2.5 sm:px-3.5 rounded-2xl inline-flex items-center gap-1 sm:gap-1.5 text-xs sm:text-sm font-extrabold cursor-pointer shrink-0"
              title="Change Language / भाषा बदलें"
            >
              <Globe className="w-4 h-4 shrink-0 text-slate-800 dark:text-slate-100" />
              <span>{lang === 'hi' ? 'हिंदी' : 'EN'}</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-80 shrink-0" />
            </button>

            {/* 2. Dark / Light Mode Toggle Button */}
            <button
              type="button"
              onClick={handleThemeToggle}
              aria-label={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              className="liquid-glass-sky w-10 h-10 sm:w-11 sm:h-11 rounded-2xl inline-flex items-center justify-center cursor-pointer shrink-0"
              title={theme === 'dark' ? 'Light Mode (दिन मोड)' : 'Dark Mode (रात मोड)'}
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5 text-amber-300 shrink-0" />
              ) : (
                <Moon className="w-5 h-5 text-slate-900 shrink-0" />
              )}
            </button>

            {/* 3. Quick Calculator Button — Unclipped & Fully Visible */}
            <button
              type="button"
              onClick={handleOpenCalc}
              aria-label={t('simpleCalc')}
              className="liquid-glass-sky w-10 h-10 sm:w-11 sm:h-11 rounded-2xl inline-flex items-center justify-center cursor-pointer shrink-0"
              title={t('simpleCalc')}
            >
              <Calculator className="w-5 h-5 text-slate-900 dark:text-white shrink-0" />
            </button>

            {/* 4. Farmer Profile / Reports & APK Utility Button (Green 3D Glass Circle) */}
            <button
              type="button"
              onClick={() => {
                if (!isNativeOrInstalled && onOpenInstallModal) {
                  onOpenInstallModal();
                } else {
                  handleTabChange('reports');
                }
              }}
              aria-label={lang === 'hi' ? 'किसान प्रोफाइल व बैकअप' : 'Farmer Profile & Backup'}
              className="liquid-glass-emerald w-10 h-10 sm:w-11 sm:h-11 rounded-full inline-flex items-center justify-center cursor-pointer shrink-0"
              title={
                !isNativeOrInstalled
                  ? lang === 'hi'
                    ? 'किसान प्रोफाइल / नया ZIP व APK'
                    : 'Farmer Profile / Download ZIP & APK'
                  : lang === 'hi'
                  ? 'किसान प्रोफाइल व रिपोर्ट'
                  : 'Farmer Profile & Reports'
              }
            >
              {!isNativeOrInstalled ? (
                <User className="w-5 h-5 text-white shrink-0" />
              ) : (
                <User className="w-5 h-5 text-white shrink-0" />
              )}
            </button>

            {/* Optional Web-Only Desktop ZIP Shortcut */}
            {!isNativeOrInstalled && onOpenInstallModal && (
              <button
                type="button"
                onClick={onOpenInstallModal}
                className="hidden md:inline-flex liquid-glass-sky h-11 px-3 rounded-2xl items-center gap-1.5 font-extrabold text-xs cursor-pointer shrink-0"
                title={lang === 'hi' ? 'नया ZIP व APK डाउनलोड करें' : 'Download New ZIP & APK'}
              >
                <Download className="w-4 h-4 shrink-0 text-emerald-800 dark:text-emerald-300" />
                <span>{lang === 'hi' ? 'ZIP / APK' : 'ZIP / APK'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Second Row: 5 Floating 3D Liquid Glass Navigation Tabs matching Reference Image */}
        <nav
          aria-label="Main Navigation"
          className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2.5 px-0.5 mt-0.5"
        >
          {/* Tab 1: All Crops */}
          <button
            type="button"
            onClick={() => handleTabChange('crops')}
            className={\`px-3.5 py-2 text-xs sm:text-sm font-bold rounded-2xl transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer shrink-0 \${
              resolvedTab === 'crops'
                ? 'liquid-glass-emerald text-white'
                : 'liquid-glass-pill text-slate-900 dark:text-slate-100'
            }\`}
          >
            <Sprout
              className={\`w-4 h-4 shrink-0 \${
                resolvedTab === 'crops'
                  ? 'text-white'
                  : 'text-emerald-700 dark:text-emerald-400'
              }\`}
            />
            <span>{lang === 'hi' ? 'सभी फसलें' : 'All Crops'}</span>
          </button>

          {/* Tab 2: Agri Calculators */}
          <button
            type="button"
            onClick={() => handleTabChange('calculators')}
            className={\`px-3.5 py-2 text-xs sm:text-sm font-bold rounded-2xl transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer shrink-0 \${
              resolvedTab === 'calculators'
                ? 'liquid-glass-emerald text-white'
                : 'liquid-glass-pill text-slate-900 dark:text-slate-100'
            }\`}
          >
            <Calculator
              className={\`w-4 h-4 shrink-0 \${
                resolvedTab === 'calculators'
                  ? 'text-white'
                  : 'text-slate-800 dark:text-slate-200'
              }\`}
            />
            <span>{lang === 'hi' ? 'कृषि कैलकुलेटर' : 'Agri Calculators'}</span>
          </button>

          {/* Tab 3: Notes/List */}
          <button
            type="button"
            onClick={() => handleTabChange('notes')}
            className={\`px-3.5 py-2 text-xs sm:text-sm font-bold rounded-2xl transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer shrink-0 \${
              resolvedTab === 'notes'
                ? 'liquid-glass-emerald text-white'
                : 'liquid-glass-pill text-slate-900 dark:text-slate-100'
            }\`}
          >
            <FileText
              className={\`w-4 h-4 shrink-0 \${
                resolvedTab === 'notes'
                  ? 'text-white'
                  : 'text-slate-800 dark:text-slate-200'
              }\`}
            />
            <span>{lang === 'hi' ? 'नोट्स / लिस्ट' : 'Notes/List'}</span>
          </button>

          {/* Tab 4: Weather */}
          <button
            type="button"
            onClick={() => handleTabChange('weather')}
            className={\`px-3.5 py-2 text-xs sm:text-sm font-bold rounded-2xl transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer shrink-0 \${
              resolvedTab === 'weather'
                ? 'liquid-glass-emerald text-white'
                : 'liquid-glass-pill text-slate-900 dark:text-slate-100'
            }\`}
          >
            <CloudSun
              className={\`w-4 h-4 shrink-0 \${
                resolvedTab === 'weather'
                  ? 'text-white'
                  : 'text-amber-500 dark:text-amber-300'
              }\`}
            />
            <span>{lang === 'hi' ? 'मौसम' : 'Weather'}</span>
          </button>

          {/* Tab 5: Reports & Backup */}
          <button
            type="button"
            onClick={() => handleTabChange('reports')}
            className={\`px-3.5 py-2 text-xs sm:text-sm font-bold rounded-2xl transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer shrink-0 \${
              resolvedTab === 'reports'
                ? 'liquid-glass-emerald text-white'
                : 'liquid-glass-pill text-slate-900 dark:text-slate-100'
            }\`}
          >
            <BarChart3
              className={\`w-4 h-4 shrink-0 \${
                resolvedTab === 'reports'
                  ? 'text-white'
                  : 'text-slate-800 dark:text-slate-200'
              }\`}
            />
            <span>{lang === 'hi' ? 'रिपोर्ट व बैकअप' : 'Reports & Backup'}</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
`;export{e as default};
