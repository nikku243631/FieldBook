const t=`import { CropCycle, Transaction, HarvestEntry, Language } from '../types';
import { formatCurrency, getTranslation } from './translations';
import { calculateCropFinancials } from './calculations';

export interface PdfPreviewPayload {
  title: string;
  fileName: string;
  htmlDocument: string;
  pdfBlob: Blob | null;
  pageDataUrls: string[];
  whatsappText?: string;
}

export function shareViaWhatsApp(rawMessage: string, title = 'FieldBook Report'): void {
  if (typeof window !== 'undefined' && window.AndroidBridge?.shareText) {
    window.AndroidBridge.shareText(rawMessage, title);
    return;
  }
  const encoded = encodeURIComponent(rawMessage);
  const url = \`https://api.whatsapp.com/send?text=\${encoded}\`;
  const a = document.createElement('a');
  a.href = url;
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

export function generateWhatsAppSummary(
  crop: CropCycle,
  transactions: Transaction[],
  harvests: HarvestEntry[],
  lang: Language
): string {
  const financials = calculateCropFinancials(crop, transactions, harvests);
  const totalLagat = financials.totalExpenses;
  const totalKamai = financials.totalIncome;
  const netProfit = financials.netProfit;
  const totalHarvest = financials.totalHarvestQuintal;

  const profitText =
    netProfit >= 0
      ? \`🟢 *\${getTranslation(lang, 'netProfit')}:* \${formatCurrency(netProfit)}\`
      : \`🔴 *\${getTranslation(lang, 'netLoss')}:* \${formatCurrency(Math.abs(netProfit))}\`;

  const message = \`🌾 *FieldBook - Khet Ledger Report* 🌾
_Developer: Mr Nikhil_
━━━━━━━━━━━━━━━━━━
🌱 *\${getTranslation(lang, 'cropName')}:* \${crop.hindiName || crop.name}
📍 *\${getTranslation(lang, 'landArea')}:* \${crop.landArea} \${getTranslation(lang, crop.areaUnit)}
📅 *\${getTranslation(lang, 'sowingDate')}:* \${crop.sowingDate}
🌾 *\${getTranslation(lang, 'totalHarvest')}:* \${totalHarvest} \${getTranslation(lang, 'quintal')}
━━━━━━━━━━━━━━━━━━
💰 *\${getTranslation(lang, 'totalLagat')}:* \${formatCurrency(totalLagat)}
💵 *\${getTranslation(lang, 'totalKamai')}:* \${formatCurrency(totalKamai)}
\${profitText}
━━━━━━━━━━━━━━━━━━
📱 _FieldBook digital farm ledger_\`;

  return encodeURIComponent(message);
}

export function downloadTextOrSaveNative(
  content: string,
  fileName: string,
  mimeType: string
): boolean {
  if (typeof window !== 'undefined' && window.AndroidBridge?.saveFileToDownloads) {
    try {
      const ok = window.AndroidBridge.saveFileToDownloads(content, fileName, mimeType);
      if (ok) return true;
    } catch {
      // Fallback to standard browser download
    }
  }

  try {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return true;
  } catch {
    return false;
  }
}

export function downloadPdfBlobOrSaveNative(pdfBlob: Blob, fileName: string): boolean {
  const safeName = fileName.endsWith('.pdf') ? fileName : \`\${fileName}.pdf\`;

  if (typeof window !== 'undefined' && window.AndroidBridge?.saveBase64FileToDownloads) {
    try {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        if (base64 && window.AndroidBridge?.saveBase64FileToDownloads) {
          window.AndroidBridge.saveBase64FileToDownloads(base64, safeName, 'application/pdf');
        }
      };
      reader.readAsDataURL(pdfBlob);
      return true;
    } catch {
      // Continue to browser download fallback
    }
  }

  try {
    const url = URL.createObjectURL(pdfBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = safeName;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 8000);
    return true;
  } catch {
    return false;
  }
}

export function exportTransactionsToCSV(
  crops: CropCycle[],
  transactions: Transaction[],
  lang: Language
): boolean {
  const cropMap = new Map(crops.map((c) => [c.id, c.hindiName || c.name]));

  const headers = [
    'Crop Name',
    'Date',
    'Time',
    'Type (Expense/Income)',
    'Category',
    'Item Description',
    'Amount (INR)',
    'Quantity',
    'Unit',
    'Rate Per Unit',
    'Vendor / Buyer',
    'Payment Status',
    'Notes'
  ];

  const rows = transactions.map((t) => [
    \`"\${(cropMap.get(t.cropId) || 'Unknown').replace(/"/g, '""')}"\`,
    \`"\${t.date}"\`,
    \`"\${t.time}"\`,
    \`"\${t.type}"\`,
    \`"\${getTranslation(lang, t.category as any)}"\`,
    \`"\${(t.title || '').replace(/"/g, '""')}"\`,
    t.amount,
    t.quantity || '',
    \`"\${(t.unit || '').replace(/"/g, '""')}"\`,
    t.ratePerUnit || '',
    \`"\${(t.vendorOrBuyer || '').replace(/"/g, '""')}"\`,
    \`"\${t.paymentStatus}"\`,
    \`"\${(t.notes || '').replace(/"/g, '""')}"\`
  ]);

  const csvContent = '\\ufeff' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\\n');
  const fileName = \`FieldBook_Agri_Ledger_\${new Date().toISOString().split('T')[0]}.csv\`;
  return downloadTextOrSaveNative(csvContent, fileName, 'text/csv;charset=utf-8;');
}

/**
 * Pure TypeScript PDF 1.4 binary builder from one or more A4 JPEG Data URLs.
 * Produces a 100% standards-compliant .pdf file (application/pdf) that opens
 * in all Android, iOS, and desktop PDF viewers with full Hindi/Devanagari clarity.
 */
function buildPdfFromJpegDataUrls(
  jpegDataUrls: { dataUrl: string; width: number; height: number }[]
): Blob | null {
  try {
    if (!jpegDataUrls.length) return null;

    const encoder = new TextEncoder();
    const chunks: Uint8Array[] = [];
    const offsets: number[] = [0]; // 1-indexed PDF object offsets
    let currentOffset = 0;

    const pushBytes = (bytes: Uint8Array) => {
      chunks.push(bytes);
      currentOffset += bytes.byteLength;
    };

    const pushStr = (str: string) => {
      pushBytes(encoder.encode(str));
    };

    const startObj = (id: number) => {
      offsets[id] = currentOffset;
      pushStr(\`\${id} 0 obj\\n\`);
    };

    const endObj = () => {
      pushStr('\\nendobj\\n');
    };

    // PDF Header with binary comment marker
    pushBytes(new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x34, 0x0a, 0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a]));

    // Object IDs:
    // 1 = Catalog
    // 2 = Pages
    // For each page i (0..N-1):
    //   pageObjId = 3 + i * 3
    //   contentObjId = 4 + i * 3
    //   imgObjId = 5 + i * 3
    const pageCount = jpegDataUrls.length;
    const pageObjIds: number[] = [];

    for (let i = 0; i < pageCount; i++) {
      pageObjIds.push(3 + i * 3);
    }

    // 1: Catalog
    startObj(1);
    pushStr('<< /Type /Catalog /Pages 2 0 R >>');
    endObj();

    // 2: Pages
    startObj(2);
    pushStr(\`<< /Type /Pages /Kids [\${pageObjIds.map((id) => \`\${id} 0 R\`).join(' ')}] /Count \${pageCount} >>\`);
    endObj();

    // Standard A4 in PDF points (72 dpi): 595.28 x 841.89
    const pdfW = 595.28;
    const pdfH = 841.89;

    for (let i = 0; i < pageCount; i++) {
      const pageObjId = 3 + i * 3;
      const contentObjId = 4 + i * 3;
      const imgObjId = 5 + i * 3;
      const page = jpegDataUrls[i];

      const base64Part = page.dataUrl.split(',')[1] || '';
      const binaryString = atob(base64Part);
      const imgBytes = new Uint8Array(binaryString.length);
      for (let b = 0; b < binaryString.length; b++) {
        imgBytes[b] = binaryString.charCodeAt(b);
      }

      // Page Object
      startObj(pageObjId);
      pushStr(
        \`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 \${pdfW} \${pdfH}] /Resources << /XObject << /Im\${i} \${imgObjId} 0 R >> >> /Contents \${contentObjId} 0 R >>\`
      );
      endObj();

      // Page Content Stream (draws image full page)
      const contentStream = \`q\\n\${pdfW} 0 0 \${pdfH} 0 0 cm\\n/Im\${i} Do\\nQ\\n\`;
      const contentBytes = encoder.encode(contentStream);
      startObj(contentObjId);
      pushStr(\`<< /Length \${contentBytes.byteLength} >>\\nstream\\n\`);
      pushBytes(contentBytes);
      pushStr('\\nendstream');
      endObj();

      // Image XObject Stream
      startObj(imgObjId);
      pushStr(
        \`<< /Type /XObject /Subtype /Image /Width \${page.width} /Height \${page.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length \${imgBytes.byteLength} >>\\nstream\\n\`
      );
      pushBytes(imgBytes);
      pushStr('\\nendstream');
      endObj();
    }

    const totalObjs = 2 + pageCount * 3;
    const xrefOffset = currentOffset;
    pushStr(\`xref\\n0 \${totalObjs + 1}\\n\`);
    pushStr('0000000000 65535 f \\n');
    for (let id = 1; id <= totalObjs; id++) {
      const padded = String(offsets[id] || 0).padStart(10, '0');
      pushStr(\`\${padded} 00000 n \\n\`);
    }
    pushStr(\`trailer\\n<< /Size \${totalObjs + 1} /Root 1 0 R >>\\nstartxref\\n\${xrefOffset}\\n%%EOF\`);

    return new Blob(chunks as BlobPart[], { type: 'application/pdf' });
  } catch {
    return null;
  }
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
  fill: string,
  stroke?: string,
  lineWidth = 2
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  if (stroke) {
    ctx.lineWidth = lineWidth;
    ctx.strokeStyle = stroke;
    ctx.stroke();
  }
}

function truncateCanvasText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string {
  const str = String(text || '-');
  if (ctx.measureText(str).width <= maxWidth) return str;
  let truncated = str;
  while (truncated.length > 1 && ctx.measureText(truncated + '…').width > maxWidth) {
    truncated = truncated.slice(0, -1);
  }
  return truncated + '…';
}

function renderCropReportToCanvases(
  crop: CropCycle,
  transactions: Transaction[],
  harvests: HarvestEntry[],
  farmerName: string,
  lang: Language
): { dataUrl: string; width: number; height: number }[] {
  if (typeof document === 'undefined') return [];

  const W = 1240;
  const H = 1754;
  const pages: { dataUrl: string; width: number; height: number }[] = [];

  const cropTx = transactions.filter((t) => t.cropId === crop.id);
  const expenses = cropTx.filter((t) => t.type === 'expense');
  const incomes = cropTx.filter((t) => t.type === 'income');
  const financials = calculateCropFinancials(crop, transactions, harvests);
  const areaUnitLabel = getTranslation(lang, crop.areaUnit);

  const createPage = (pageNum: number): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D; y: number } | null => {
    const canvas = document.createElement('canvas');
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // White A4 background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, W, H);

    // Top decorative emerald banner
    const grad = ctx.createLinearGradient(0, 0, W, 0);
    grad.addColorStop(0, '#064e3b');
    grad.addColorStop(0.5, '#059669');
    grad.addColorStop(1, '#047857');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, 135);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 36px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText('FieldBook — कृषि लेजर व फसल हिसाब रिपोर्ट', 56, 62);

    ctx.fillStyle = '#d1fae5';
    ctx.font = '600 20px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText('Digital Khet Ledger | डेवलपर: श्री निखिल (Mr Nikhil)', 56, 102);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText(\`किसान: \${farmerName}\`, W - 56, 62);
    ctx.fillStyle = '#ecfdf5';
    ctx.font = '600 18px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText(\`दिनांक: \${new Date().toLocaleDateString('en-IN')} | पृष्ठ \${pageNum}\`, W - 56, 100);
    ctx.textAlign = 'left';

    // Footer
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(56, H - 78);
    ctx.lineTo(W - 56, H - 78);
    ctx.stroke();

    ctx.fillStyle = '#334155';
    ctx.font = '600 17px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText('FieldBook — Smart Farm Accounting App | डेवलपर: श्री निखिल (Mr Nikhil)', 56, H - 42);
    ctx.textAlign = 'right';
    ctx.fillText('हस्ताक्षर / मोहर: ________________________', W - 56, H - 42);
    ctx.textAlign = 'left';

    return { canvas, ctx, y: 165 };
  };

  let pageNum = 1;
  let current = createPage(pageNum);
  if (!current) return [];
  let { canvas, ctx, y } = current;

  // Crop Metadata Box
  drawRoundedRect(ctx, 56, y, W - 112, 118, 16, '#f0fdf4', '#34d399', 2.5);
  const metaCols = [
    { label: 'फसल (CROP)', val: \`\${crop.hindiName || crop.name}\${crop.variety ? \` (\${crop.variety})\` : ''}\` },
    { label: 'रकबा (LAND AREA)', val: \`\${crop.landArea} \${areaUnitLabel}\` },
    { label: 'बुवाई तिथि (SOWN)', val: crop.sowingDate },
    { label: 'कुल पैदावार (YIELD)', val: \`\${financials.totalHarvestQuintal} क्विंटल\` }
  ];
  const colW = (W - 152) / 4;
  metaCols.forEach((m, idx) => {
    const mx = 76 + idx * colW;
    ctx.fillStyle = '#065f46';
    ctx.font = 'bold 16px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText(m.label, mx, y + 42);
    ctx.fillStyle = '#090d16';
    ctx.font = 'bold 23px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText(truncateCanvasText(ctx, m.val, colW - 16), mx, y + 84);
  });
  y += 142;

  // 3 Summary Cards (Expenses, Income, Net Profit/Loss)
  const cardW = (W - 112 - 32) / 3;
  // Card 1: Total Expenses
  drawRoundedRect(ctx, 56, y, cardW, 120, 16, '#fff1f2', '#fb7185', 2.5);
  ctx.fillStyle = '#881337';
  ctx.font = 'bold 19px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText('कुल लागत (खर्च / Expenses)', 80, y + 44);
  ctx.fillStyle = '#be123c';
  ctx.font = 'bold 34px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText(formatCurrency(financials.totalExpenses), 80, y + 92);

  // Card 2: Total Income
  drawRoundedRect(ctx, 56 + cardW + 16, y, cardW, 120, 16, '#ecfdf5', '#34d399', 2.5);
  ctx.fillStyle = '#064e3b';
  ctx.font = 'bold 19px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText('कुल आमदनी (बिक्री / Income)', 80 + cardW + 16, y + 44);
  ctx.fillStyle = '#047857';
  ctx.font = 'bold 34px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText(formatCurrency(financials.totalIncome), 80 + cardW + 16, y + 92);

  // Card 3: Net Profit / Loss
  const isProf = financials.netProfit >= 0;
  drawRoundedRect(
    ctx,
    56 + (cardW + 16) * 2,
    y,
    cardW,
    120,
    16,
    isProf ? '#eff6ff' : '#fff1f2',
    isProf ? '#38bdf8' : '#fb7185',
    2.5
  );
  ctx.fillStyle = isProf ? '#1e3a8a' : '#881337';
  ctx.font = 'bold 19px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText(isProf ? 'शुद्ध मुनाफा (Net Profit)' : 'शुद्ध घाटा (Net Loss)', 80 + (cardW + 16) * 2, y + 44);
  ctx.fillStyle = isProf ? '#1d4ed8' : '#be123c';
  ctx.font = 'bold 34px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText(
    \`\${isProf ? '+' : '-'}\${formatCurrency(Math.abs(financials.netProfit))}\`,
    80 + (cardW + 16) * 2,
    y + 92
  );

  y += 152;

  const ensureSpace = (neededHeight: number) => {
    if (y + neededHeight > H - 105) {
      pages.push({ dataUrl: canvas.toDataURL('image/jpeg', 0.92), width: W, height: H });
      pageNum += 1;
      const next = createPage(pageNum);
      if (next) {
        canvas = next.canvas;
        ctx = next.ctx;
        y = next.y;
      }
    }
  };

  // Section 1: Income / Sales Table
  ensureSpace(120);
  ctx.fillStyle = '#065f46';
  ctx.font = 'bold 24px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText(\`1. मंडी बिक्री व आमदनी विवरण (Sales & Income — \${incomes.length})\`, 56, y);
  y += 18;

  // Table Header
  drawRoundedRect(ctx, 56, y, W - 112, 46, 8, '#065f46');
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 17px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText('तारीख', 74, y + 30);
  ctx.fillText('विवरण / आढ़ती', 230, y + 30);
  ctx.fillText('वजन (क्विं.)', 650, y + 30);
  ctx.fillText('भाव/दर', 820, y + 30);
  ctx.fillText('कुल रकम (₹)', 1000, y + 30);
  y += 48;

  if (incomes.length === 0) {
    drawRoundedRect(ctx, 56, y, W - 112, 48, 6, '#f8fafc', '#e2e8f0', 1);
    ctx.fillStyle = '#475569';
    ctx.font = '600 17px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText('कोई बिक्री प्रविष्टि दर्ज नहीं है (No income entries logged yet)', 74, y + 31);
    y += 56;
  } else {
    incomes.forEach((inc, idx) => {
      ensureSpace(50);
      drawRoundedRect(ctx, 56, y, W - 112, 46, 4, idx % 2 === 0 ? '#f0fdf4' : '#ffffff', '#d1fae5', 1);
      ctx.fillStyle = '#090d16';
      ctx.font = '600 17px "Inter", "Noto Sans Devanagari", sans-serif';
      ctx.fillText(inc.date, 74, y + 30);
      const desc = \`\${inc.title}\${inc.vendorOrBuyer ? \` (\${inc.vendorOrBuyer})\` : ''}\`;
      ctx.fillText(truncateCanvasText(ctx, desc, 400), 230, y + 30);
      ctx.fillText(String(inc.quantity || inc.mandiDetails?.netWeightQuintal || '-'), 650, y + 30);
      ctx.fillText(
        inc.ratePerUnit || inc.mandiDetails?.ratePerQuintal
          ? \`₹\${inc.ratePerUnit || inc.mandiDetails?.ratePerQuintal}\`
          : '-',
        820,
        y + 30
      );
      ctx.fillStyle = '#047857';
      ctx.font = 'bold 18px "Inter", "Noto Sans Devanagari", sans-serif';
      ctx.fillText(formatCurrency(inc.amount), 1000, y + 30);
      y += 48;
    });
    y += 16;
  }

  // Section 2: Expenses Table
  ensureSpace(120);
  ctx.fillStyle = '#9f1239';
  ctx.font = 'bold 24px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText(\`2. लागत व खर्च विवरण (Expenses — \${expenses.length})\`, 56, y + 16);
  y += 32;

  drawRoundedRect(ctx, 56, y, W - 112, 46, 8, '#9f1239');
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 17px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText('तारीख', 74, y + 30);
  ctx.fillText('मद (Category)', 220, y + 30);
  ctx.fillText('खर्च विवरण', 430, y + 30);
  ctx.fillText('मात्रा / दुकानदार', 760, y + 30);
  ctx.fillText('लागत रकम (₹)', 1010, y + 30);
  y += 48;

  if (expenses.length === 0) {
    drawRoundedRect(ctx, 56, y, W - 112, 48, 6, '#f8fafc', '#e2e8f0', 1);
    ctx.fillStyle = '#475569';
    ctx.font = '600 17px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText('कोई खर्च प्रविष्टि दर्ज नहीं है (No expense entries logged yet)', 74, y + 31);
    y += 56;
  } else {
    expenses.forEach((exp, idx) => {
      ensureSpace(50);
      drawRoundedRect(ctx, 56, y, W - 112, 46, 4, idx % 2 === 0 ? '#fff1f2' : '#ffffff', '#fecdd3', 1);
      ctx.fillStyle = '#090d16';
      ctx.font = '600 17px "Inter", "Noto Sans Devanagari", sans-serif';
      ctx.fillText(exp.date, 74, y + 30);
      ctx.fillText(truncateCanvasText(ctx, getTranslation(lang, exp.category as any), 195), 220, y + 30);
      ctx.fillText(truncateCanvasText(ctx, exp.title, 315), 430, y + 30);
      const qtyVendor = [
        exp.quantity ? \`\${exp.quantity} \${exp.unit || ''}\` : '',
        exp.vendorOrBuyer || ''
      ]
        .filter(Boolean)
        .join(' • ');
      ctx.fillText(truncateCanvasText(ctx, qtyVendor || '-', 235), 760, y + 30);
      ctx.fillStyle = '#be123c';
      ctx.font = 'bold 18px "Inter", "Noto Sans Devanagari", sans-serif';
      ctx.fillText(formatCurrency(exp.amount), 1010, y + 30);
      y += 48;
    });
  }

  pages.push({ dataUrl: canvas.toDataURL('image/jpeg', 0.92), width: W, height: H });
  return pages;
}

function renderFarmMasterReportToCanvases(
  crops: CropCycle[],
  transactions: Transaction[],
  harvests: HarvestEntry[],
  farmerName: string,
  lang: Language
): { dataUrl: string; width: number; height: number }[] {
  if (typeof document === 'undefined') return [];

  const W = 1240;
  const H = 1754;
  const pages: { dataUrl: string; width: number; height: number }[] = [];

  const totalExpenses = transactions
    .filter((t) => t.type === 'expense')
    .reduce((s, t) => s + t.amount, 0);
  const totalIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((s, t) => s + t.amount, 0);
  const netProfit = totalIncome - totalExpenses;

  const createPage = (pageNum: number): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D; y: number } | null => {
    const canvas = document.createElement('canvas');
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, W, H);

    const grad = ctx.createLinearGradient(0, 0, W, 0);
    grad.addColorStop(0, '#064e3b');
    grad.addColorStop(0.5, '#059669');
    grad.addColorStop(1, '#047857');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, 135);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 36px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText('FieldBook — संपूर्ण कृषि खाता व मास्टर रिपोर्ट', 56, 62);

    ctx.fillStyle = '#d1fae5';
    ctx.font = '600 20px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText(\`कुल फसलें: \${crops.length} | डेवलपर: श्री निखिल (Mr Nikhil)\`, 56, 102);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText(\`किसान: \${farmerName}\`, W - 56, 62);
    ctx.fillStyle = '#ecfdf5';
    ctx.font = '600 18px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText(\`दिनांक: \${new Date().toLocaleDateString('en-IN')} | पृष्ठ \${pageNum}\`, W - 56, 100);
    ctx.textAlign = 'left';

    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(56, H - 78);
    ctx.lineTo(W - 56, H - 78);
    ctx.stroke();

    ctx.fillStyle = '#334155';
    ctx.font = '600 17px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText('FieldBook — Smart Farm Accounting App | डेवलपर: श्री निखिल (Mr Nikhil)', 56, H - 42);
    ctx.textAlign = 'right';
    ctx.fillText('हस्ताक्षर / मोहर: ________________________', W - 56, H - 42);
    ctx.textAlign = 'left';

    return { canvas, ctx, y: 165 };
  };

  let pageNum = 1;
  let current = createPage(pageNum);
  if (!current) return [];
  let { canvas, ctx, y } = current;

  const cardW = (W - 112 - 32) / 3;
  drawRoundedRect(ctx, 56, y, cardW, 120, 16, '#fff1f2', '#fb7185', 2.5);
  ctx.fillStyle = '#881337';
  ctx.font = 'bold 19px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText('कुल लागत (Total Expenses)', 80, y + 44);
  ctx.fillStyle = '#be123c';
  ctx.font = 'bold 34px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText(formatCurrency(totalExpenses), 80, y + 92);

  drawRoundedRect(ctx, 56 + cardW + 16, y, cardW, 120, 16, '#ecfdf5', '#34d399', 2.5);
  ctx.fillStyle = '#064e3b';
  ctx.font = 'bold 19px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText('कुल आमदनी (Total Income)', 80 + cardW + 16, y + 44);
  ctx.fillStyle = '#047857';
  ctx.font = 'bold 34px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText(formatCurrency(totalIncome), 80 + cardW + 16, y + 92);

  const isProf = netProfit >= 0;
  drawRoundedRect(
    ctx,
    56 + (cardW + 16) * 2,
    y,
    cardW,
    120,
    16,
    isProf ? '#eff6ff' : '#fff1f2',
    isProf ? '#38bdf8' : '#fb7185',
    2.5
  );
  ctx.fillStyle = isProf ? '#1e3a8a' : '#881337';
  ctx.font = 'bold 19px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText(isProf ? 'कुल शुद्ध मुनाफा (Net Profit)' : 'कुल शुद्ध घाटा (Net Loss)', 80 + (cardW + 16) * 2, y + 44);
  ctx.fillStyle = isProf ? '#1d4ed8' : '#be123c';
  ctx.font = 'bold 34px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText(\`\${isProf ? '+' : '-'}\${formatCurrency(Math.abs(netProfit))}\`, 80 + (cardW + 16) * 2, y + 92);

  y += 155;

  const ensureSpace = (neededHeight: number) => {
    if (y + neededHeight > H - 105) {
      pages.push({ dataUrl: canvas.toDataURL('image/jpeg', 0.92), width: W, height: H });
      pageNum += 1;
      const next = createPage(pageNum);
      if (next) {
        canvas = next.canvas;
        ctx = next.ctx;
        y = next.y;
      }
    }
  };

  ctx.fillStyle = '#065f46';
  ctx.font = 'bold 24px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText(\`1. फसलवार पूरा सारांश (Crop-wise Summary — \${crops.length})\`, 56, y);
  y += 18;

  drawRoundedRect(ctx, 56, y, W - 112, 46, 8, '#065f46');
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 17px "Inter", "Noto Sans Devanagari", sans-serif';
  ctx.fillText('फसल का नाम', 74, y + 30);
  ctx.fillText('रकबा', 370, y + 30);
  ctx.fillText('बुवाई तिथि', 510, y + 30);
  ctx.fillText('कुल खर्च (₹)', 680, y + 30);
  ctx.fillText('कुल आमदनी (₹)', 850, y + 30);
  ctx.fillText('शुद्ध परिणाम (₹)', 1030, y + 30);
  y += 48;

  crops.forEach((c, idx) => {
    ensureSpace(50);
    const fin = calculateCropFinancials(c, transactions, harvests);
    drawRoundedRect(ctx, 56, y, W - 112, 46, 4, idx % 2 === 0 ? '#f0fdf4' : '#ffffff', '#d1fae5', 1);
    ctx.fillStyle = '#090d16';
    ctx.font = 'bold 17px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText(truncateCanvasText(ctx, c.hindiName || c.name, 280), 74, y + 30);
    ctx.font = '600 17px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText(\`\${c.landArea} \${getTranslation(lang, c.areaUnit)}\`, 370, y + 30);
    ctx.fillText(c.sowingDate, 510, y + 30);
    ctx.fillStyle = '#be123c';
    ctx.font = 'bold 17px "Inter", "Noto Sans Devanagari", sans-serif';
    ctx.fillText(formatCurrency(fin.totalExpenses), 680, y + 30);
    ctx.fillStyle = '#047857';
    ctx.fillText(formatCurrency(fin.totalIncome), 850, y + 30);
    ctx.fillStyle = fin.isProfit ? '#1d4ed8' : '#be123c';
    ctx.fillText(\`\${fin.isProfit ? '+' : '-'}\${formatCurrency(Math.abs(fin.netProfit))}\`, 1030, y + 30);
    y += 48;
  });

  pages.push({ dataUrl: canvas.toDataURL('image/jpeg', 0.92), width: W, height: H });
  return pages;
}

export function triggerSystemHtmlPrint(htmlDocument: string, jobName: string): void {
  if (typeof window !== 'undefined' && window.AndroidBridge?.printHtml) {
    window.AndroidBridge.printHtml(htmlDocument, jobName);
    return;
  }

  const existingFrame = document.getElementById('fieldbook-print-frame');
  if (existingFrame) {
    existingFrame.remove();
  }

  const iframe = document.createElement('iframe');
  iframe.id = 'fieldbook-print-frame';
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (doc) {
    doc.open();
    doc.write(htmlDocument);
    doc.close();
    setTimeout(() => {
      try {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
      } catch {
        // Handled by PDF binary download
      }
    }, 300);
  }
}

function dispatchPdfPreviewEvent(payload: PdfPreviewPayload): void {
  if (typeof window !== 'undefined' && typeof CustomEvent !== 'undefined') {
    window.dispatchEvent(new CustomEvent('fieldbook:pdf-preview', { detail: payload }));
  }
}

export function printCropReportPDF(
  crop: CropCycle,
  transactions: Transaction[],
  harvests: HarvestEntry[],
  farmerName = 'Kisan Bhai',
  lang: Language = 'hi'
): boolean {
  const cropTx = transactions.filter((t) => t.cropId === crop.id);
  const expenses = cropTx.filter((t) => t.type === 'expense');
  const incomes = cropTx.filter((t) => t.type === 'income');

  const financials = calculateCropFinancials(crop, transactions, harvests);
  const totalLagat = financials.totalExpenses;
  const totalKamai = financials.totalIncome;
  const netProfit = financials.netProfit;
  const totalYield = financials.totalHarvestQuintal;
  const areaUnitLabel = getTranslation(lang, crop.areaUnit);

  const printHtml = \`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>FieldBook Statement - \${crop.hindiName || crop.name}</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      color: #111827;
      margin: 24px;
      line-height: 1.45;
      background: #ffffff;
    }
    .header {
      border-bottom: 2px solid #059669;
      padding-bottom: 12px;
      margin-bottom: 20px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
    }
    .brand-title {
      font-size: 24px;
      font-weight: bold;
      color: #065f46;
      margin: 0;
    }
    .dev-tag {
      font-size: 13px;
      color: #374151;
      font-weight: 600;
      margin-top: 4px;
    }
    .meta-box {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      background: #f0fdf4;
      border: 1px solid #86efac;
      padding: 12px;
      border-radius: 8px;
      margin-bottom: 20px;
      gap: 10px;
    }
    .meta-label {
      color: #374151;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
    }
    .meta-val {
      font-weight: bold;
      font-size: 14px;
      color: #064e3b;
      margin-top: 2px;
    }
    .summary-cards {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 14px;
      margin-bottom: 24px;
    }
    .card {
      padding: 12px;
      border-radius: 8px;
      text-align: center;
    }
    .card-lagat {
      background: #fef2f2;
      border: 1px solid #fca5a5;
    }
    .card-kamai {
      background: #ecfdf5;
      border: 1px solid #6ee7b7;
    }
    .card-profit {
      background: #f0fdf4;
      border: 2px solid #059669;
    }
    .card-title {
      font-size: 12px;
      font-weight: 600;
      color: #374151;
    }
    .card-amt {
      font-size: 20px;
      font-weight: bold;
      margin-top: 4px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      font-size: 12px;
    }
    th {
      background: #065f46;
      color: #ffffff;
      text-align: left;
      padding: 8px;
    }
    td {
      padding: 8px;
      border-bottom: 1px solid #d1d5db;
      color: #111827;
    }
    tr:nth-child(even) {
      background: #f9fafb;
    }
    .footer {
      margin-top: 32px;
      border-top: 1px solid #9ca3af;
      padding-top: 12px;
      font-size: 12px;
      color: #374151;
      display: flex;
      justify-content: space-between;
    }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <h1 class="brand-title">FieldBook — कृषि लेजर व हिसाब-किताब</h1>
      <div class="dev-tag">डेवलपर: श्री निखिल (Developer: Mr Nikhil)</div>
    </div>
    <div style="text-align: right;">
      <div style="font-size: 12px; color: #374151;">दिनांक: \${new Date().toLocaleDateString('en-IN')}</div>
      <div style="font-weight: bold; font-size: 14px; color: #064e3b;">किसान: \${farmerName}</div>
    </div>
  </div>

  <div class="meta-box">
    <div>
      <div class="meta-label">फसल (Crop)</div>
      <div class="meta-val">\${crop.hindiName || crop.name}\${crop.variety ? \` (\${crop.variety})\` : ''}</div>
    </div>
    <div>
      <div class="meta-label">रकबा (Area)</div>
      <div class="meta-val">\${crop.landArea} \${areaUnitLabel}</div>
    </div>
    <div>
      <div class="meta-label">बुवाई तिथि</div>
      <div class="meta-val">\${crop.sowingDate}</div>
    </div>
    <div>
      <div class="meta-label">कुल पैदावार</div>
      <div class="meta-val">\${totalYield} क्विंटल</div>
    </div>
  </div>

  <div class="summary-cards">
    <div class="card card-lagat">
      <div class="card-title">कुल लागत (खर्च)</div>
      <div class="card-amt" style="color: #b91c1c;">\${formatCurrency(totalLagat)}</div>
    </div>
    <div class="card card-kamai">
      <div class="card-title">कुल आमदनी (बिक्री)</div>
      <div class="card-amt" style="color: #047857;">\${formatCurrency(totalKamai)}</div>
    </div>
    <div class="card card-profit">
      <div class="card-title">शुद्ध परिणाम (Profit/Loss)</div>
      <div class="card-amt" style="color: \${netProfit >= 0 ? '#047857' : '#b91c1c'};">
        \${netProfit >= 0 ? '+' : ''}\${formatCurrency(netProfit)}
      </div>
    </div>
  </div>

  <h3 style="color: #065f46; margin-bottom: 8px;">1. मंडी बिक्री व आमदनी विवरण (Sales/Income)</h3>
  <table>
    <thead>
      <tr>
        <th>तारीख</th>
        <th>विवरण / आढ़ती</th>
        <th>मात्रा (क्विंटल)</th>
        <th>भाव प्रति क्विंटल</th>
        <th>कटौती</th>
        <th>कुल जमा (₹)</th>
      </tr>
    </thead>
    <tbody>
      \${
        incomes.length > 0
          ? incomes
              .map(
                (i) => \`
        <tr>
          <td>\${i.date}</td>
          <td>\${i.title} \${i.vendorOrBuyer ? \`(\${i.vendorOrBuyer})\` : ''}</td>
          <td>\${i.quantity || i.mandiDetails?.netWeightQuintal || '-'}</td>
          <td>₹\${i.ratePerUnit || i.mandiDetails?.ratePerQuintal || '-'}</td>
          <td>₹\${i.mandiDetails?.totalPalledari || 0}</td>
          <td style="font-weight: bold; color: #047857;">\${formatCurrency(i.amount)}</td>
        </tr>\`
              )
              .join('')
          : '<tr><td colspan="6" style="text-align:center; color:#4b5563;">कोई बिक्री दर्ज नहीं है</td></tr>'
      }
    </tbody>
  </table>

  <h3 style="color: #991b1b; margin-bottom: 8px;">2. लागत व खर्च विवरण (Expenses)</h3>
  <table>
    <thead>
      <tr>
        <th>तारीख</th>
        <th>मद / श्रेणी</th>
        <th>खर्च विवरण</th>
        <th>मात्रा / दर</th>
        <th>दुकानदार / मजदूर</th>
        <th>रकम (₹)</th>
      </tr>
    </thead>
    <tbody>
      \${
        expenses.length > 0
          ? expenses
              .map(
                (e) => \`
        <tr>
          <td>\${e.date}</td>
          <td>\${getTranslation(lang, e.category as any)}</td>
          <td>\${e.title}</td>
          <td>\${e.quantity ? \`\${e.quantity} \${e.unit || ''}\` : '-'}</td>
          <td>\${e.vendorOrBuyer || '-'}</td>
          <td style="font-weight: bold; color: #b91c1c;">\${formatCurrency(e.amount)}</td>
        </tr>\`
              )
              .join('')
          : '<tr><td colspan="6" style="text-align:center; color:#4b5563;">कोई खर्च दर्ज नहीं है</td></tr>'
      }
    </tbody>
  </table>

  <div class="footer">
    <div>FieldBook — Smart Farm Accounting App | डेवलपर: श्री निखिल (Mr Nikhil)</div>
    <div>हस्ताक्षर / मोहर: ____________________</div>
  </div>
</body>
</html>\`;

  const cleanCropSlug = (crop.name || 'Crop').replace(/[^a-zA-Z0-9_-]/g, '_');
  const fileName = \`FieldBook_\${cleanCropSlug}_\${new Date().toISOString().split('T')[0]}.pdf\`;

  const renderedPages = renderCropReportToCanvases(crop, transactions, harvests, farmerName, lang);
  const pdfBlob = buildPdfFromJpegDataUrls(renderedPages);

  if (pdfBlob) {
    downloadPdfBlobOrSaveNative(pdfBlob, fileName);
  } else {
    triggerSystemHtmlPrint(printHtml, fileName.replace(/\\.pdf$/, ''));
  }

  const whatsappDecoded = decodeURIComponent(
    generateWhatsAppSummary(crop, transactions, harvests, lang)
  );

  dispatchPdfPreviewEvent({
    title: \`\${crop.hindiName || crop.name} — PDF लेजर रिपोर्ट\`,
    fileName,
    htmlDocument: printHtml,
    pdfBlob,
    pageDataUrls: renderedPages.map((p) => p.dataUrl),
    whatsappText: whatsappDecoded
  });

  return true;
}

export function printFarmMonthlyReportPDF(
  crops: CropCycle[],
  transactions: Transaction[],
  harvests: HarvestEntry[],
  farmerName = 'Kisan Bhai',
  lang: Language = 'hi'
): boolean {
  const totalExpenses = transactions
    .filter((t) => t.type === 'expense')
    .reduce((s, t) => s + t.amount, 0);
  const totalIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((s, t) => s + t.amount, 0);
  const netProfit = totalIncome - totalExpenses;

  const monthlyData: Record<string, { expenses: number; income: number; txCount: number }> = {};
  transactions.forEach((tx) => {
    const monthKey = tx.date.slice(0, 7);
    if (!monthlyData[monthKey]) {
      monthlyData[monthKey] = { expenses: 0, income: 0, txCount: 0 };
    }
    if (tx.type === 'expense') monthlyData[monthKey].expenses += tx.amount;
    else monthlyData[monthKey].income += tx.amount;
    monthlyData[monthKey].txCount += 1;
  });
  const sortedMonths = Object.keys(monthlyData).sort().reverse();

  const printHtml = \`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>FieldBook Complete Farm Statement</title>
  <style>
    body { font-family: Arial, sans-serif; color: #111827; margin: 24px; line-height: 1.45; background: #fff; }
    .header { border-bottom: 2px solid #059669; padding-bottom: 12px; margin-bottom: 20px; display: flex; justify-content: space-between; }
    .brand-title { font-size: 24px; font-weight: bold; color: #065f46; margin: 0; }
    .summary-cards { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; margin-bottom: 24px; }
    .card { padding: 12px; border-radius: 8px; text-align: center; border: 1px solid #d1d5db; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 12px; }
    th { background: #065f46; color: #fff; text-align: left; padding: 8px; }
    td { padding: 8px; border-bottom: 1px solid #d1d5db; }
    .footer { margin-top: 32px; border-top: 1px solid #9ca3af; padding-top: 12px; font-size: 12px; color: #374151; display: flex; justify-content: space-between; }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <h1 class="brand-title">FieldBook — संपूर्ण कृषि खाता व मासिक रिपोर्ट</h1>
      <div style="font-size: 13px; color: #374151; font-weight: 600;">डेवलपर: श्री निखिल (Developer: Mr Nikhil)</div>
    </div>
    <div style="text-align: right;">
      <div style="font-size: 12px;">दिनांक: \${new Date().toLocaleDateString('en-IN')}</div>
      <div style="font-weight: bold; font-size: 14px; color: #064e3b;">किसान: \${farmerName}</div>
    </div>
  </div>

  <div class="summary-cards">
    <div class="card" style="background:#fef2f2;border-color:#fca5a5;">
      <div style="font-size:12px;font-weight:600;">कुल लागत (Expenses)</div>
      <div style="font-size:20px;font-weight:bold;color:#b91c1c;">\${formatCurrency(totalExpenses)}</div>
    </div>
    <div class="card" style="background:#ecfdf5;border-color:#6ee7b7;">
      <div style="font-size:12px;font-weight:600;">कुल आमदनी (Income)</div>
      <div style="font-size:20px;font-weight:bold;color:#047857;">\${formatCurrency(totalIncome)}</div>
    </div>
    <div class="card" style="background:#f0fdf4;border:2px solid #059669;">
      <div style="font-size:12px;font-weight:600;">कुल शुद्ध परिणाम (Net P&L)</div>
      <div style="font-size:20px;font-weight:bold;color:\${netProfit >= 0 ? '#047857' : '#b91c1c'};">
        \${netProfit >= 0 ? '+' : ''}\${formatCurrency(netProfit)}
      </div>
    </div>
  </div>

  <h3 style="color: #065f46; margin-bottom: 8px;">1. फसलवार सारांश (Crop-wise Summary)</h3>
  <table>
    <thead>
      <tr>
        <th>फसल (Crop)</th>
        <th>रकबा</th>
        <th>बुवाई</th>
        <th>पैदावार</th>
        <th>कुल लागत</th>
        <th>कुल आमदनी</th>
        <th>शुद्ध लाभ/हानि</th>
      </tr>
    </thead>
    <tbody>
      \${crops
        .map((c) => {
          const fin = calculateCropFinancials(c, transactions, harvests);
          return \`<tr>
            <td><strong>\${c.hindiName || c.name}</strong></td>
            <td>\${c.landArea} \${getTranslation(lang, c.areaUnit)}</td>
            <td>\${c.sowingDate}</td>
            <td>\${fin.totalHarvestQuintal} क्विंटल</td>
            <td style="color:#b91c1c;">\${formatCurrency(fin.totalExpenses)}</td>
            <td style="color:#047857;">\${formatCurrency(fin.totalIncome)}</td>
            <td style="font-weight:bold;color:\${fin.isProfit ? '#047857' : '#b91c1c'};">
              \${fin.isProfit ? '+' : ''}\${formatCurrency(fin.netProfit)}
            </td>
          </tr>\`;
        })
        .join('')}
    </tbody>
  </table>

  <h3 style="color: #065f46; margin-bottom: 8px;">2. महीनेवार हिसाब (Monthly Breakdown)</h3>
  <table>
    <thead>
      <tr>
        <th>माह (Month)</th>
        <th>प्रविष्टियां (Entries)</th>
        <th>मासिक लागत (Expense)</th>
        <th>मासिक कमाई (Income)</th>
        <th>मासिक शुद्ध बचत (Net)</th>
      </tr>
    </thead>
    <tbody>
      \${sortedMonths
        .map((m) => {
          const d = monthlyData[m];
          const net = d.income - d.expenses;
          return \`<tr>
            <td><strong>\${m}</strong></td>
            <td>\${d.txCount}</td>
            <td style="color:#b91c1c;">\${formatCurrency(d.expenses)}</td>
            <td style="color:#047857;">\${formatCurrency(d.income)}</td>
            <td style="font-weight:bold;color:\${net >= 0 ? '#047857' : '#b91c1c'};">
              \${net >= 0 ? '+' : ''}\${formatCurrency(net)}
            </td>
          </tr>\`;
        })
        .join('')}
    </tbody>
  </table>

  <div class="footer">
    <div>FieldBook — डिजिटल खेत लेजर | डेवलपर: श्री निखिल (Mr Nikhil)</div>
    <div>हस्ताक्षर: ____________________</div>
  </div>
</body>
</html>\`;

  const fileName = \`FieldBook_Master_Report_\${new Date().toISOString().split('T')[0]}.pdf\`;
  const renderedPages = renderFarmMasterReportToCanvases(crops, transactions, harvests, farmerName, lang);
  const pdfBlob = buildPdfFromJpegDataUrls(renderedPages);

  if (pdfBlob) {
    downloadPdfBlobOrSaveNative(pdfBlob, fileName);
  } else {
    triggerSystemHtmlPrint(printHtml, fileName.replace(/\\.pdf$/, ''));
  }

  dispatchPdfPreviewEvent({
    title: 'संपूर्ण कृषि खाता मास्टर रिपोर्ट (PDF)',
    fileName,
    htmlDocument: printHtml,
    pdfBlob,
    pageDataUrls: renderedPages.map((p) => p.dataUrl)
  });

  return true;
}
`;export{t as default};
