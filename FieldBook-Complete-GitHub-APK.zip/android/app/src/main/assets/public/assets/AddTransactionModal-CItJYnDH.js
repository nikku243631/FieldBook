const e=`import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, ShoppingCart, IndianRupee, Tag, User, FileText } from 'lucide-react';
import { Transaction, Language, Theme } from '../types';
import { getTranslation } from '../utils/translations';

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (tx: Partial<Transaction>) => void;
  cropId: string;
  defaultType?: 'expense' | 'income';
  txToEdit?: Transaction | null;
  lang: Language;
  theme: Theme;
}

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  cropId,
  defaultType = 'expense',
  txToEdit,
  lang
}) => {
  const [type, setType] = useState<'expense' | 'income'>(defaultType);
  const [category, setCategory] = useState<string>(
    defaultType === 'expense' ? 'fertilizer' : 'mandi_sale'
  );
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState<number | ''>('');

  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const timeStr = now.toTimeString().slice(0, 5);
  const [date, setDate] = useState(todayStr);
  const [time, setTime] = useState(timeStr);

  const [quantity, setQuantity] = useState<number | ''>('');
  const [unit, setUnit] = useState('');
  const [ratePerUnit, setRatePerUnit] = useState<number | ''>('');
  const [vendorOrBuyer, setVendorOrBuyer] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<'paid' | 'pending'>('paid');

  // Mandi specific fields
  const [mandiGrossWeightKg, setMandiGrossWeightKg] = useState<number | ''>('');
  const [mandiTareWeightKg, setMandiTareWeightKg] = useState<number | ''>('');
  const [mandiNetWeightQuintal, setMandiNetWeightQuintal] = useState<number | ''>('');
  const [mandiRatePerQuintal, setMandiRatePerQuintal] = useState<number | ''>('');
  const [mandiPalledariPerQuintal, setMandiPalledariPerQuintal] = useState<number | ''>('');
  const [mandiBuyerName, setMandiBuyerName] = useState('');
  const [mandiReceiptNumber, setMandiReceiptNumber] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (txToEdit) {
      setType(txToEdit.type);
      setCategory(txToEdit.category);
      setTitle(txToEdit.title || '');
      setAmount(txToEdit.amount ?? '');
      setDate(txToEdit.date || new Date().toISOString().split('T')[0]);
      setTime(txToEdit.time || new Date().toTimeString().slice(0, 5));
      setQuantity(txToEdit.quantity ?? '');
      setUnit(txToEdit.unit || '');
      setRatePerUnit(txToEdit.ratePerUnit ?? '');
      setVendorOrBuyer(txToEdit.vendorOrBuyer || '');
      setNotes(txToEdit.notes || '');
      setPaymentStatus(txToEdit.paymentStatus || 'paid');
      setMandiGrossWeightKg(txToEdit.mandiDetails?.grossWeightKg ?? '');
      setMandiTareWeightKg(txToEdit.mandiDetails?.tareWeightKg ?? '');
      setMandiNetWeightQuintal(txToEdit.mandiDetails?.netWeightQuintal ?? '');
      setMandiRatePerQuintal(txToEdit.mandiDetails?.ratePerQuintal ?? '');
      setMandiPalledariPerQuintal(txToEdit.mandiDetails?.palledariPerQuintal ?? '');
      setMandiBuyerName(txToEdit.mandiDetails?.buyerName || txToEdit.vendorOrBuyer || '');
      setMandiReceiptNumber(txToEdit.mandiDetails?.receiptNumber || '');
    } else {
      const currentNow = new Date();
      setType(defaultType);
      setCategory(defaultType === 'expense' ? 'fertilizer' : 'mandi_sale');
      setTitle('');
      setAmount('');
      setDate(currentNow.toISOString().split('T')[0]);
      setTime(currentNow.toTimeString().slice(0, 5));
      setQuantity('');
      setUnit('');
      setRatePerUnit('');
      setVendorOrBuyer('');
      setNotes('');
      setPaymentStatus('paid');
      setMandiGrossWeightKg('');
      setMandiTareWeightKg('');
      setMandiNetWeightQuintal('');
      setMandiRatePerQuintal('');
      setMandiPalledariPerQuintal('');
      setMandiBuyerName('');
      setMandiReceiptNumber('');
    }
  }, [isOpen, defaultType, txToEdit]);

  if (!isOpen) return null;

  const calculateMandiTotal = (netQ: number, rateQ: number, palledariQ: number) => {
    if (!netQ || !rateQ || netQ <= 0 || rateQ <= 0) return;
    const grossVal = netQ * rateQ;
    const palledariDeduction = Math.max(0, palledariQ || 0) * netQ;
    const netPayout = Math.max(0, grossVal - palledariDeduction);
    setAmount(Math.round(netPayout));
  };

  const handleMandiWeightChange = (grossKg: number, tareKg: number) => {
    const netKg = Math.max(0, grossKg - tareKg);
    const netQ = Number((netKg / 100).toFixed(2));
    setMandiNetWeightQuintal(netQ);
    if (mandiRatePerQuintal) {
      calculateMandiTotal(netQ, Number(mandiRatePerQuintal), Number(mandiPalledariPerQuintal));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || Number(amount) <= 0) return;

    const defaultTitle =
      title.trim() ||
      (type === 'expense'
        ? getTranslation(lang, category as any)
        : getTranslation(lang, category as any));

    const txData: Partial<Transaction> = {
      id: txToEdit?.id,
      cropId,
      type,
      category: category as any,
      title: defaultTitle,
      amount: Math.round(Number(amount)),
      date,
      time,
      quantity: quantity && Number(quantity) > 0 ? Number(quantity) : undefined,
      unit: unit.trim() || undefined,
      ratePerUnit: ratePerUnit && Number(ratePerUnit) > 0 ? Number(ratePerUnit) : undefined,
      vendorOrBuyer: (vendorOrBuyer || mandiBuyerName).trim() || undefined,
      notes: notes.trim() || undefined,
      paymentStatus
    };

    if (category === 'mandi_sale') {
      const netQ = Number(mandiNetWeightQuintal) || (quantity ? Number(quantity) : 0);
      const rateQ = Number(mandiRatePerQuintal) || (ratePerUnit ? Number(ratePerUnit) : 0);
      const palledariQ = Math.max(0, Number(mandiPalledariPerQuintal) || 0);
      txData.mandiDetails = {
        grossWeightKg: mandiGrossWeightKg ? Number(mandiGrossWeightKg) : undefined,
        tareWeightKg: mandiTareWeightKg ? Number(mandiTareWeightKg) : undefined,
        netWeightQuintal: netQ,
        ratePerQuintal: rateQ,
        palledariPerQuintal: palledariQ,
        totalPalledari: Math.round(palledariQ * netQ),
        buyerName: mandiBuyerName.trim() || undefined,
        receiptNumber: mandiReceiptNumber.trim() || undefined
      };
    }

    onSave(txData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/60 backdrop-blur-md overflow-y-auto">
      <div className="liquid-glass-modal w-full max-w-lg rounded-3xl p-4 sm:p-5 my-4 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 mb-3 border-b-2 border-emerald-500/30">
          <div className="flex items-center gap-2.5">
            <div
              className={\`w-10 h-10 rounded-2xl flex items-center justify-center text-white shrink-0 \${
                type === 'expense' ? 'btn-3d-rose' : 'liquid-glass-emerald'
              }\`}
            >
              <IndianRupee className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-950 dark:text-white leading-tight">
                {txToEdit
                  ? lang === 'hi'
                    ? 'प्रविष्टि संशोधित करें (Edit Entry)'
                    : 'Edit Transaction'
                  : type === 'expense'
                  ? getTranslation(lang, 'addExpense')
                  : getTranslation(lang, 'addIncome')}
              </h2>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-300">
                {lang === 'hi'
                  ? '✍️ नीचे दिए रंगीन बॉक्स में रकम और विवरण दर्ज करें'
                  : '✍️ Enter amount and item details in the 3D boxes below'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        {/* 3D Liquid Glass Type Switcher (लागत vs कमाई) */}
        <div className="grid grid-cols-2 gap-2.5 p-1.5 mb-3.5 rounded-2xl liquid-glass-pill">
          <button
            type="button"
            onClick={() => {
              setType('expense');
              setCategory('fertilizer');
            }}
            className={\`py-2.5 text-xs sm:text-sm font-extrabold rounded-xl transition-all cursor-pointer \${
              type === 'expense'
                ? 'btn-3d-rose text-white'
                : 'bg-white/85 dark:bg-slate-900/80 text-rose-900 dark:text-rose-200 border border-rose-300'
            }\`}
          >
            🔴 {getTranslation(lang, 'expenses')}
          </button>
          <button
            type="button"
            onClick={() => {
              setType('income');
              setCategory('mandi_sale');
            }}
            className={\`py-2.5 text-xs sm:text-sm font-extrabold rounded-xl transition-all cursor-pointer \${
              type === 'income'
                ? 'liquid-glass-emerald text-white'
                : 'bg-white/85 dark:bg-slate-900/80 text-emerald-950 dark:text-emerald-200 border border-emerald-300'
            }\`}
          >
            🟢 {getTranslation(lang, 'income')}
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* Primary Section: Category, Description & Amount */}
          <div
            className={\`rounded-2xl p-3.5 space-y-3 \${
              type === 'expense' ? 'liquid-glass-expense' : 'liquid-glass-income'
            }\`}
          >
            {/* Category Dropdown */}
            <div>
              <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1.5 mb-1.5">
                <Tag className="w-3.5 h-3.5 text-rose-700 dark:text-rose-300" />
                <span>
                  {type === 'expense' ? 'खर्च की श्रेणी (Category)' : 'कमाई का जरिया (Source)'}
                </span>
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className={\`w-full px-3.5 py-2.5 rounded-xl text-sm font-extrabold text-slate-950 dark:text-white \${
                  type === 'expense' ? 'input-3d-rose' : 'liquid-glass-input'
                }\`}
              >
                {type === 'expense' ? (
                  <>
                    <option value="fertilizer">{getTranslation(lang, 'fertilizer')}</option>
                    <option value="seeds">{getTranslation(lang, 'seeds')}</option>
                    <option value="pesticide">{getTranslation(lang, 'pesticide')}</option>
                    <option value="irrigation">{getTranslation(lang, 'irrigation')}</option>
                    <option value="labour">{getTranslation(lang, 'labour')}</option>
                    <option value="machinery">{getTranslation(lang, 'machinery')}</option>
                    <option value="other">{getTranslation(lang, 'other')}</option>
                  </>
                ) : (
                  <>
                    <option value="mandi_sale">{getTranslation(lang, 'mandi_sale')}</option>
                    <option value="local_sale">{getTranslation(lang, 'local_sale')}</option>
                    <option value="subsidy">{getTranslation(lang, 'subsidy')}</option>
                    <option value="byproduct">{getTranslation(lang, 'byproduct')}</option>
                  </>
                )}
              </select>
            </div>

            {/* Description Title & Amount */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  ✍️ {getTranslation(lang, 'transactionTitle')}
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={
                    type === 'expense'
                      ? lang === 'hi'
                        ? 'जैसे: 2 बोरी DAP खाद'
                        : 'e.g. 2 Bags DAP'
                      : lang === 'hi'
                      ? 'जैसे: 20 क्विंटल बिक्री'
                      : 'e.g. 20 Quintal Sale'
                  }
                  className="liquid-glass-input w-full px-3.5 py-2.5 rounded-xl text-sm font-bold text-slate-950 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-rose-950 dark:text-rose-200 block mb-1.5">
                  💰 {getTranslation(lang, 'amount')} *
                </label>
                <input
                  type="number"
                  step="1"
                  required
                  value={amount}
                  onChange={(e) =>
                    setAmount(e.target.value === '' ? '' : parseFloat(e.target.value))
                  }
                  placeholder="₹ 2500"
                  className={\`w-full px-3.5 py-2.5 rounded-xl text-base font-mono font-extrabold tabular-nums text-slate-950 dark:text-white \${
                    type === 'expense' ? 'input-3d-rose' : 'liquid-glass-input'
                  }\`}
                />
              </div>
            </div>
          </div>

          {/* Special Mandi Calculator Section */}
          {category === 'mandi_sale' && (
            <div className="p-3.5 rounded-2xl liquid-glass-income space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-extrabold text-emerald-950 dark:text-emerald-200">
                <ShoppingCart className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                <span>मंडी तौल व भाव कैलकुलेटर (Mandi Weighing & Rate)</span>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-extrabold text-slate-950 dark:text-white block mb-1">
                    कांटा कुल वजन (Gross Kg)
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="उदा. 4250"
                    value={mandiGrossWeightKg}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiGrossWeightKg(val);
                      handleMandiWeightChange(Number(val) || 0, Number(mandiTareWeightKg) || 0);
                    }}
                    className="liquid-glass-input w-full px-3 py-2 text-xs sm:text-sm rounded-xl font-mono font-bold tabular-nums"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-extrabold text-slate-950 dark:text-white block mb-1">
                    ट्रॉली/खाली वजन (Tare Kg)
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="उदा. 1250"
                    value={mandiTareWeightKg}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiTareWeightKg(val);
                      handleMandiWeightChange(Number(mandiGrossWeightKg) || 0, Number(val) || 0);
                    }}
                    className="liquid-glass-input w-full px-3 py-2 text-xs sm:text-sm rounded-xl font-mono font-bold tabular-nums"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[11px] text-slate-950 dark:text-white font-extrabold block mb-1">
                    शुद्ध वजन (क्विं.) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="30.00"
                    value={mandiNetWeightQuintal}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiNetWeightQuintal(val);
                      if (mandiRatePerQuintal) {
                        calculateMandiTotal(
                          Number(val),
                          Number(mandiRatePerQuintal),
                          Number(mandiPalledariPerQuintal)
                        );
                      }
                    }}
                    className="input-3d-amber w-full px-2.5 py-2 text-xs sm:text-sm rounded-xl font-mono font-extrabold tabular-nums"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-950 dark:text-white font-extrabold block mb-1">
                    भाव/क्विं. (₹) *
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="2275"
                    value={mandiRatePerQuintal}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiRatePerQuintal(val);
                      if (mandiNetWeightQuintal) {
                        calculateMandiTotal(
                          Number(mandiNetWeightQuintal),
                          Number(val),
                          Number(mandiPalledariPerQuintal)
                        );
                      }
                    }}
                    className="liquid-glass-input w-full px-2.5 py-2 text-xs sm:text-sm rounded-xl font-mono font-extrabold tabular-nums"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-950 dark:text-white font-extrabold block mb-1">
                    पल्लेदारी (₹)
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="15"
                    value={mandiPalledariPerQuintal}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                      setMandiPalledariPerQuintal(val);
                      if (mandiNetWeightQuintal && mandiRatePerQuintal) {
                        calculateMandiTotal(
                          Number(mandiNetWeightQuintal),
                          Number(mandiRatePerQuintal),
                          Number(val)
                        );
                      }
                    }}
                    className="input-3d-rose w-full px-2.5 py-2 text-xs sm:text-sm rounded-xl font-mono font-bold tabular-nums"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] text-slate-950 dark:text-white font-extrabold block mb-1">
                    आढ़ती / फर्म नाम
                  </label>
                  <input
                    type="text"
                    placeholder="उदा. राधेश्याम ट्रेडिंग"
                    value={mandiBuyerName}
                    onChange={(e) => setMandiBuyerName(e.target.value)}
                    className="input-3d-sky w-full px-3 py-2 text-xs sm:text-sm rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-950 dark:text-white font-extrabold block mb-1">
                    पर्ची / बिल नंबर
                  </label>
                  <input
                    type="text"
                    placeholder="उदा. MND-450"
                    value={mandiReceiptNumber}
                    onChange={(e) => setMandiReceiptNumber(e.target.value)}
                    className="input-3d-sky w-full px-3 py-2 text-xs sm:text-sm rounded-xl font-mono font-bold"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Date, Time, Quantity, Unit & Rate */}
          <div className="liquid-glass-profit rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{getTranslation(lang, 'date')} *</span>
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                  <Clock className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{getTranslation(lang, 'time')} *</span>
                </label>
                <input
                  type="time"
                  required
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="input-3d-sky w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                />
              </div>
            </div>

            {category !== 'mandi_sale' && (
              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label className="text-[11px] font-extrabold text-amber-950 dark:text-amber-300 block mb-1">
                    📦 {getTranslation(lang, 'quantity')}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={quantity}
                    onChange={(e) =>
                      setQuantity(e.target.value === '' ? '' : parseFloat(e.target.value))
                    }
                    placeholder="2"
                    className="input-3d-amber w-full px-2.5 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-extrabold text-amber-950 dark:text-amber-300 block mb-1">
                    ⚖️ इकाई (Unit)
                  </label>
                  <input
                    type="text"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    placeholder="बोरी / kg"
                    className="input-3d-amber w-full px-2.5 py-2 rounded-xl text-xs sm:text-sm font-bold"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-extrabold text-amber-950 dark:text-amber-300 block mb-1">
                    🏷️ दर (Rate)
                  </label>
                  <input
                    type="number"
                    step="1"
                    value={ratePerUnit}
                    onChange={(e) =>
                      setRatePerUnit(e.target.value === '' ? '' : parseFloat(e.target.value))
                    }
                    placeholder="₹1350"
                    className="input-3d-amber w-full px-2.5 py-2 rounded-xl text-xs sm:text-sm font-mono font-extrabold tabular-nums"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Vendor / Buyer & Payment Status & Notes */}
          <div className="liquid-glass-income rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {category !== 'mandi_sale' && (
                <div>
                  <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                    <User className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{getTranslation(lang, 'vendorOrBuyer')}</span>
                  </label>
                  <input
                    type="text"
                    value={vendorOrBuyer}
                    onChange={(e) => setVendorOrBuyer(e.target.value)}
                    placeholder={lang === 'hi' ? 'दुकानदार या मजदूर का नाम' : 'Vendor/Labour name'}
                    className="liquid-glass-input w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-bold"
                  />
                </div>
              )}

              <div>
                <label className="text-xs font-extrabold text-slate-950 dark:text-white block mb-1.5">
                  💳 {getTranslation(lang, 'paymentStatus')}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentStatus('paid')}
                    className={\`py-2 text-xs font-extrabold rounded-xl transition-all cursor-pointer \${
                      paymentStatus === 'paid'
                        ? 'liquid-glass-emerald text-white'
                        : 'bg-white/90 dark:bg-slate-900/90 text-slate-950 dark:text-white border-2 border-emerald-500/60'
                    }\`}
                  >
                    ✓ {getTranslation(lang, 'paid')}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentStatus('pending')}
                    className={\`py-2 text-xs font-extrabold rounded-xl transition-all cursor-pointer \${
                      paymentStatus === 'pending'
                        ? 'btn-3d-amber text-white'
                        : 'bg-white/90 dark:bg-slate-900/90 text-slate-950 dark:text-white border-2 border-amber-500/60'
                    }\`}
                  >
                    ⏳ {getTranslation(lang, 'pending')}
                  </button>
                </div>
              </div>
            </div>

            <div>
              <label className="text-xs font-extrabold text-slate-950 dark:text-white flex items-center gap-1 mb-1.5">
                <FileText className="w-3.5 h-3.5 text-blue-700" />
                <span>{getTranslation(lang, 'notes')}</span>
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={
                  lang === 'hi' ? 'कोई विशेष बात या बिल नंबर यहां लिखें...' : 'Bill number, notes...'
                }
                className="input-3d-sky w-full px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="liquid-glass-pill px-5 py-2.5 rounded-full text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white cursor-pointer"
            >
              {getTranslation(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className={\`\${
                type === 'expense' ? 'btn-3d-rose' : 'liquid-glass-emerald'
              } px-6 py-2.5 rounded-full text-white font-extrabold text-xs sm:text-sm cursor-pointer shadow-md\`}
            >
              ✓ {getTranslation(lang, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
`;export{e as default};
