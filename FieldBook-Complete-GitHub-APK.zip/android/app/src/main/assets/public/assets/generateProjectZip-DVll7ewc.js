const n=`import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const ROOT_DIR = process.cwd();
const OUTPUT_ZIP_ROOT = path.join(ROOT_DIR, 'FieldBook-Complete-GitHub-APK.zip');
const OUTPUT_ZIP_PUBLIC = path.join(ROOT_DIR, 'public', 'FieldBook-Complete-GitHub-APK.zip');

const EXCLUDED_DIRS = new Set([
  'node_modules',
  'dist',
  '.git',
  '.gradle',
  'build',
  '.idea',
  '.aistudio',
  'artifacts'
]);

const EXCLUDED_FILES = new Set([
  'FieldBook-Complete-GitHub-APK.zip',
  'FieldBook-Kisan-App.apk',
  '.DS_Store'
]);

function addDirectoryToZip(zip: JSZip, dirPath: string, relativePrefix = ''): number {
  let count = 0;
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    if (EXCLUDED_FILES.has(entry.name)) continue;

    const fullPath = path.join(dirPath, entry.name);
    const relPath = relativePrefix ? \`\${relativePrefix}/\${entry.name}\` : entry.name;

    // Skip uploaded raw AI Studio media folder inside public/assets/aistudio to keep ZIP compact
    if (relPath === 'public/assets/aistudio') continue;

    if (entry.isDirectory()) {
      if (EXCLUDED_DIRS.has(entry.name)) continue;
      if (relPath.startsWith('android/app/build')) continue;
      count += addDirectoryToZip(zip, fullPath, relPath);
    } else if (entry.isFile()) {
      const data = fs.readFileSync(fullPath);
      const isExecutable =
        entry.name === 'gradlew' ||
        entry.name.endsWith('.sh');
      zip.file(relPath, data, {
        unixPermissions: isExecutable ? '755' : '644'
      });
      count++;
    }
  }
  return count;
}

async function main() {
  console.log('=== Packaging FieldBook-Complete-GitHub-APK.zip ===');
  const zip = new JSZip();

  const totalFiles = addDirectoryToZip(zip, ROOT_DIR);

  const requiredFiles = [
    'package.json',
    'package-lock.json',
    'index.html',
    'vite.config.ts',
    'tsconfig.json',
    'capacitor.config.json',
    'public/logo.png',
    'public/farm-bg.jpg',
    'public/pwa-192x192.png',
    'public/pwa-512x512.png',
    '.github/workflows/build-apk.yml',
    'src/App.tsx',
    'src/main.tsx',
    'src/index.css',
    'src/utils/zipExporter.ts',
    'src/utils/export.ts',
    'src/utils/platform.ts',
    'android/gradlew',
    'android/build.gradle',
    'android/app/build.gradle',
    'android/app/src/main/AndroidManifest.xml',
    'android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png',
    'android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.png'
  ];

  for (const reqFile of requiredFiles) {
    if (!zip.file(reqFile)) {
      throw new Error(\`CRITICAL MISSING FILE IN ZIP: \${reqFile}\`);
    }
  }

  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
    platform: 'UNIX'
  });

  fs.writeFileSync(OUTPUT_ZIP_ROOT, buffer);
  fs.mkdirSync(path.dirname(OUTPUT_ZIP_PUBLIC), { recursive: true });
  fs.writeFileSync(OUTPUT_ZIP_PUBLIC, buffer);

  const sizeMB = (buffer.length / (1024 * 1024)).toFixed(2);
  console.log(\`✓ Packed \${totalFiles} files (\${sizeMB} MB) into:\`);
  console.log(\`  1. \${OUTPUT_ZIP_ROOT}\`);
  console.log(\`  2. \${OUTPUT_ZIP_PUBLIC}\`);
  console.log(\`✓ Verified all \${requiredFiles.length} critical files (including public/logo.png, Android launcher icons, src/utils/zipExporter.ts, android/gradlew, and .github/workflows/build-apk.yml) inside the archive.\`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
`;export{n as default};
