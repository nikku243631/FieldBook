const n=`import { CropCycle, Transaction, HarvestEntry, DiaryEntry, FarmNote, ShoppingItem } from '../types';

const CROPS_KEY = 'fieldbook_crops_v1';
const TRANSACTIONS_KEY = 'fieldbook_transactions_v1';
const HARVESTS_KEY = 'fieldbook_harvests_v1';
const DIARY_KEY = 'fieldbook_diary_v1';
const SETTINGS_KEY = 'fieldbook_settings_v1';
const WEATHER_LOC_KEY = 'fieldbook_weather_location_v1';
const NOTES_KEY = 'fieldbook_notes_v1';
const SHOPPING_KEY = 'fieldbook_shopping_v1';
const CALC_HISTORY_KEY = 'fieldbook_calc_history_v1';

export interface SavedLocation {
  name: string;
  lat: number;
  lon: number;
  district?: string;
  state?: string;
  pincode?: string;
}

export const DEFAULT_USER_LOCATION: SavedLocation = {
  name: 'चितौरा / धनौरा, ज़िला बदायूं (243631)',
  district: 'बदायूं (Budaun)',
  state: 'उत्तर प्रदेश (UP)',
  pincode: '243631',
  lat: 28.0381,
  lon: 79.1267
};

export interface AppSettings {
  language: 'hi' | 'en';
  theme: 'dark' | 'light';
  farmerName: string;
  phone?: string;
  village?: string;
  defaultAreaUnit: 'acre' | 'bigha' | 'hectare';
  hasSeenSplash?: boolean;
}

// Initial realistic seed data for an Indian farmer's ledger
const SEED_CROPS: CropCycle[] = [
  {
    id: 'crop-wheat-2024',
    name: 'Wheat (गेहूं - HD 2967)',
    hindiName: 'गेहूं (Wheat)',
    variety: 'HD 2967 (पूसा)',
    landArea: 4,
    areaUnit: 'acre',
    season: 'rabi',
    sowingDate: '2024-11-12',
    expectedHarvestDate: '2025-04-10',
    status: 'active',
    targetYieldQuintal: 80,
    notes: '4 एकड़ चक रोड वाला खेत, 2 बोरी DAP बुवाई के समय दी।',
    createdAt: '2024-11-12T09:30:00.000Z',
    updatedAt: '2024-11-12T09:30:00.000Z'
  },
  {
    id: 'crop-mustard-2024',
    name: 'Mustard (सरसों - पायनियर 45S46)',
    hindiName: 'सरसों (Mustard)',
    variety: 'Pioneer 45S46',
    landArea: 2.5,
    areaUnit: 'acre',
    season: 'rabi',
    sowingDate: '2024-10-20',
    expectedHarvestDate: '2025-03-05',
    status: 'harvested',
    targetYieldQuintal: 25,
    notes: 'नहर के किनारे वाला खेत, तेल की मात्रा अच्छी रही।',
    createdAt: '2024-10-20T10:15:00.000Z',
    updatedAt: '2025-03-10T14:20:00.000Z'
  }
];

const SEED_TRANSACTIONS: Transaction[] = [
  // Wheat expenses
  {
    id: 'tx-w-1',
    cropId: 'crop-wheat-2024',
    type: 'expense',
    category: 'seeds',
    title: 'गेहूं बीज 4 एकड़ (160 kg)',
    amount: 5600,
    date: '2024-11-10',
    time: '11:00',
    quantity: 160,
    unit: 'kg',
    ratePerUnit: 35,
    vendorOrBuyer: 'किसान सेवा केंद्र, मंडी',
    paymentStatus: 'paid',
    notes: 'उपचारित बीज HD 2967',
    createdAt: '2024-11-10T11:00:00.000Z'
  },
  {
    id: 'tx-w-2',
    cropId: 'crop-wheat-2024',
    type: 'expense',
    category: 'fertilizer',
    title: 'DAP खाद (4 कट्टे)',
    amount: 5400,
    date: '2024-11-11',
    time: '15:30',
    quantity: 4,
    unit: 'कट्टे (50kg)',
    ratePerUnit: 1350,
    vendorOrBuyer: 'IFFCO सोसायटी',
    paymentStatus: 'paid',
    createdAt: '2024-11-11T15:30:00.000Z'
  },
  {
    id: 'tx-w-3',
    cropId: 'crop-wheat-2024',
    type: 'expense',
    category: 'machinery',
    title: 'रोटावेटर व सीड ड्रिल जुताई',
    amount: 6800,
    date: '2024-11-12',
    time: '17:00',
    quantity: 4,
    unit: 'एकड़',
    ratePerUnit: 1700,
    vendorOrBuyer: 'रामू ट्रैक्टर वाला',
    paymentStatus: 'paid',
    createdAt: '2024-11-12T17:00:00.000Z'
  },
  {
    id: 'tx-w-4',
    cropId: 'crop-wheat-2024',
    type: 'expense',
    category: 'irrigation',
    title: 'पहली सिंचाई (कोरवा पानी) डीजल',
    amount: 3200,
    date: '2024-12-05',
    time: '08:30',
    quantity: 36,
    unit: 'लीटर डीजल',
    ratePerUnit: 89,
    vendorOrBuyer: 'भारत पेट्रोलियम',
    paymentStatus: 'paid',
    createdAt: '2024-12-05T08:30:00.000Z'
  },
  {
    id: 'tx-w-5',
    cropId: 'crop-wheat-2024',
    type: 'expense',
    category: 'fertilizer',
    title: 'यूरिया (4 बैग) + जिंक 33%',
    amount: 1980,
    date: '2024-12-08',
    time: '10:00',
    quantity: 4,
    unit: 'कट्टे (45kg)',
    ratePerUnit: 266,
    vendorOrBuyer: 'सोसायटी खाद गोदाम',
    paymentStatus: 'paid',
    createdAt: '2024-12-08T10:00:00.000Z'
  },
  {
    id: 'tx-w-6',
    cropId: 'crop-wheat-2024',
    type: 'expense',
    category: 'pesticide',
    title: 'गुल्ली डंडा (मण्डूसी) खरपतवार नाशक दवा',
    amount: 2400,
    date: '2024-12-22',
    time: '14:00',
    vendorOrBuyer: 'अग्रवाल पेस्टीसाइड्स',
    paymentStatus: 'paid',
    notes: 'क्लोडिनाफॉप + मेटसल्फ्यूरॉन स्प्रे',
    createdAt: '2024-12-22T14:00:00.000Z'
  },
  {
    id: 'tx-w-7',
    cropId: 'crop-wheat-2024',
    type: 'expense',
    category: 'labour',
    title: 'दवा स्प्रे व खाद बखेरने की मजदूरी (2 मजदूर)',
    amount: 1200,
    date: '2024-12-23',
    time: '17:30',
    quantity: 2,
    unit: 'दिहाड़ी',
    ratePerUnit: 600,
    vendorOrBuyer: 'मजदूर - कल्लू व सोनू',
    paymentStatus: 'paid',
    createdAt: '2024-12-23T17:30:00.000Z'
  },
  
  // Mustard expenses & income (Harvested crop with full profit/loss math)
  {
    id: 'tx-m-1',
    cropId: 'crop-mustard-2024',
    type: 'expense',
    category: 'seeds',
    title: 'सरसों पायनियर 45S46 बीज 3 kg',
    amount: 2850,
    date: '2024-10-18',
    time: '10:00',
    quantity: 3,
    unit: 'kg',
    vendorOrBuyer: 'श्री श्याम बीज भंडार',
    paymentStatus: 'paid',
    createdAt: '2024-10-18T10:00:00.000Z'
  },
  {
    id: 'tx-m-2',
    cropId: 'crop-mustard-2024',
    type: 'expense',
    category: 'fertilizer',
    title: 'SSP (सिंगल सुपर फास्फेट) + सल्फर 90%',
    amount: 3200,
    date: '2024-10-19',
    time: '12:00',
    vendorOrBuyer: 'IFFCO केंद्र',
    paymentStatus: 'paid',
    createdAt: '2024-10-19T12:00:00.000Z'
  },
  {
    id: 'tx-m-3',
    cropId: 'crop-mustard-2024',
    type: 'expense',
    category: 'machinery',
    title: 'जुताई, हैरो व कल्टीवेटर',
    amount: 4500,
    date: '2024-10-20',
    time: '16:00',
    vendorOrBuyer: 'ट्रैक्टर भाड़ा',
    paymentStatus: 'paid',
    createdAt: '2024-10-20T16:00:00.000Z'
  },
  {
    id: 'tx-m-4',
    cropId: 'crop-mustard-2024',
    type: 'expense',
    category: 'pesticide',
    title: 'चेपा (माहू) रोकथाम स्प्रे दवा',
    amount: 1450,
    date: '2025-01-14',
    time: '11:00',
    vendorOrBuyer: 'किसान दवा केंद्र',
    paymentStatus: 'paid',
    createdAt: '2025-01-14T11:00:00.000Z'
  },
  {
    id: 'tx-m-5',
    cropId: 'crop-mustard-2024',
    type: 'expense',
    category: 'labour',
    title: 'सरसों कटाई व बंधाई मजदूरी',
    amount: 6000,
    date: '2025-02-28',
    time: '18:00',
    vendorOrBuyer: 'कालू मिस्त्री लेबर ग्रुप',
    paymentStatus: 'paid',
    createdAt: '2025-02-28T18:00:00.000Z'
  },
  {
    id: 'tx-m-6',
    cropId: 'crop-mustard-2024',
    type: 'expense',
    category: 'machinery',
    title: 'थ्रेशर कढ़वाई भाड़ा (22 क्विंटल)',
    amount: 3300,
    date: '2025-03-04',
    time: '15:00',
    ratePerUnit: 150,
    quantity: 22,
    unit: 'क्विंटल',
    vendorOrBuyer: 'थ्रेशर वाले सुरेन्द्र',
    paymentStatus: 'paid',
    createdAt: '2025-03-04T15:00:00.000Z'
  },
  // Income for Mustard
  {
    id: 'tx-m-sale-1',
    cropId: 'crop-mustard-2024',
    type: 'income',
    category: 'mandi_sale',
    title: 'मंडी में सरसों बिक्री (22 क्विंटल)',
    amount: 124300,
    date: '2025-03-08',
    time: '13:30',
    quantity: 22,
    unit: 'क्विंटल',
    ratePerUnit: 5650,
    vendorOrBuyer: 'मैसर्स राधेश्याम ट्रेडिंग कंपनी, अनाज मंडी',
    paymentStatus: 'paid',
    notes: '42% तेल लैब रिपोर्ट पास। 22 क्विंटल @ ₹5,650। पल्लेदारी कटौती ₹400 बाद नेट पेमेंट।',
    mandiDetails: {
      grossWeightKg: 2240,
      tareWeightKg: 40,
      netWeightQuintal: 22,
      ratePerQuintal: 5650,
      palledariPerQuintal: 18,
      totalPalledari: 396,
      buyerName: 'राधेश्याम ट्रेडिंग कंपनी, आढ़त नं. 42',
      receiptNumber: 'MND-8821'
    },
    createdAt: '2025-03-08T13:30:00.000Z'
  }
];

const SEED_HARVESTS: HarvestEntry[] = [
  {
    id: 'hrv-m-1',
    cropId: 'crop-mustard-2024',
    date: '2025-03-04',
    time: '16:00',
    quantityQuintal: 22,
    grade: 'A-Grade (42% Oil Content)',
    storageLocation: 'सीधा अनाज मंडी ले गए',
    notes: 'मौसम साफ होने पर तुरंत थ्रेसिंग करवाई गई।'
  }
];

const SEED_DIARY: DiaryEntry[] = [
  {
    id: 'dir-w-1',
    cropId: 'crop-wheat-2024',
    date: '2024-11-12',
    time: '16:30',
    activityType: 'sowing',
    notes: 'गेहूं की बुवाई सुहागा फेरकर अच्छी नमी में पूरी की। प्रति एकड़ 40 किलो बीज प्रयोग किया।',
    weatherNote: 'मौसम सुहावना, हल्की धूप'
  },
  {
    id: 'dir-w-2',
    cropId: 'crop-wheat-2024',
    date: '2024-12-05',
    time: '09:00',
    activityType: 'irrigation',
    notes: '21 दिन पर पहली हल्की सिंचाई (CRI स्टेज) लगाई गई। जड़ें बहुत मजबूत निकल रही हैं।',
    weatherNote: 'सुबह कोहरा, बाद में खिली धूप'
  },
  {
    id: 'dir-w-3',
    cropId: 'crop-wheat-2024',
    date: '2024-12-22',
    time: '15:00',
    activityType: 'spray',
    notes: 'खरपतवार नाशक का छिड़काव फ्लैट फैन नोजल से किया। खेत में पर्याप्त नमी थी।',
    weatherNote: 'हवा शांत, धूप खिली'
  }
];

const SEED_NOTES: FarmNote[] = [
  {
    id: 'note-1',
    title: 'बदायूं मंडी आढ़ती रामकिशन जी से गेहूं बात',
    content: 'मंडी में भाव ₹2400+ मिलने की संभावना है। 12 तारीख को 50 बोरी गेहूं लोड करके ले जाना है। धर्मकांटा रसीद साथ रखनी है।',
    category: 'payment',
    isPinned: true,
    date: '2025-03-01',
    time: '11:30',
    color: 'emerald',
    createdAt: '2025-03-01T11:30:00.000Z',
    updatedAt: '2025-03-01T11:30:00.000Z'
  },
  {
    id: 'note-2',
    title: 'सोमवार ट्यूबवेल बिजली व पानी लगाना',
    content: 'सोमवार सुबह 6 बजे से दोपहर 12 बजे तक 3 फेस बिजली आएगी। चक रोड वाले 4 एकड़ गेहूं में दूसरा पानी लगाना है।',
    category: 'reminder',
    isPinned: true,
    date: '2025-03-03',
    time: '08:00',
    color: 'amber',
    createdAt: '2025-03-03T08:00:00.000Z',
    updatedAt: '2025-03-03T08:00:00.000Z'
  },
  {
    id: 'note-3',
    title: 'उर्वरक दुकान का बकाया हिसाब',
    content: 'दुकानदार से 2 बोरी यूरिया का ₹540 देना बाकी है। अगली बार मंडी से आकर चुकता करना है।',
    category: 'payment',
    isPinned: false,
    date: '2025-03-05',
    time: '17:15',
    color: 'rose',
    createdAt: '2025-03-05T17:15:00.000Z',
    updatedAt: '2025-03-05T17:15:00.000Z'
  }
];

const SEED_SHOPPING: ShoppingItem[] = [
  {
    id: 'shop-1',
    name: 'यूरिया खाद (IFFCO)',
    category: 'fertilizer',
    quantity: 3,
    unit: 'बोरी',
    estimatedCost: 810,
    isPurchased: false,
    notes: 'दूसरे पानी के साथ छिड़काव करना है',
    date: '2025-03-04',
    createdAt: '2025-03-04T10:00:00.000Z'
  },
  {
    id: 'shop-2',
    name: 'सल्फर 90% WDG (दानेदार)',
    category: 'fertilizer',
    quantity: 2,
    unit: 'पैकेट',
    estimatedCost: 500,
    isPurchased: false,
    notes: 'सरसों व गेहूं के लिए',
    date: '2025-03-04',
    createdAt: '2025-03-04T10:05:00.000Z'
  },
  {
    id: 'shop-3',
    name: 'ट्रैक्टर इंजन ऑयल (20W40)',
    category: 'machinery_tools',
    quantity: 5,
    unit: 'लीटर',
    estimatedCost: 1650,
    actualCost: 1600,
    isPurchased: true,
    notes: 'सर्विसिंग के लिए दुकान से ले लिया',
    date: '2025-03-02',
    createdAt: '2025-03-02T15:20:00.000Z'
  },
  {
    id: 'shop-4',
    name: 'डिलीवरी पाइप क्लैंप',
    category: 'irrigation',
    quantity: 4,
    unit: 'नग',
    estimatedCost: 120,
    actualCost: 120,
    isPurchased: true,
    notes: 'ट्यूबवेल पाइप लीकेज रोकने हेतु',
    date: '2025-03-02',
    createdAt: '2025-03-02T15:25:00.000Z'
  }
];

const WEATHER_CACHE_KEY = 'fieldbook_weather_cache_v1';

function safeSetItem(key: string, value: string): boolean {
  try {
    if (typeof localStorage === 'undefined') return false;
    localStorage.setItem(key, value);
    return true;
  } catch (err) {
    console.error(\`Storage write failed for \${key} (possible quota limit):\`, err);
    return false;
  }
}

function safeGetArray<T>(key: string, seedFallback: T[]): T[] {
  try {
    if (typeof localStorage === 'undefined') return seedFallback;
    const raw = localStorage.getItem(key);
    if (!raw) {
      safeSetItem(key, JSON.stringify(seedFallback));
      return seedFallback;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      console.warn(\`Malformed non-array data in \${key}, recovering with fallback.\`);
      safeSetItem(key, JSON.stringify(seedFallback));
      return seedFallback;
    }
    return parsed as T[];
  } catch (err) {
    console.warn(\`Corrupted JSON in \${key}, recovering with fallback:\`, err);
    return seedFallback;
  }
}

export interface BackupImportResult {
  success: boolean;
  errorHi?: string;
  errorEn?: string;
  counts?: {
    crops: number;
    transactions: number;
    harvests: number;
    notes: number;
  };
}

export const Storage = {
  getCrops(): CropCycle[] {
    return safeGetArray<CropCycle>(CROPS_KEY, SEED_CROPS).filter(
      (c) => c && typeof c === 'object' && typeof c.id === 'string' && typeof c.name === 'string'
    );
  },

  saveCrops(crops: CropCycle[]): boolean {
    return safeSetItem(CROPS_KEY, JSON.stringify(Array.isArray(crops) ? crops : []));
  },

  getTransactions(): Transaction[] {
    return safeGetArray<Transaction>(TRANSACTIONS_KEY, SEED_TRANSACTIONS).filter(
      (t) =>
        t &&
        typeof t === 'object' &&
        typeof t.id === 'string' &&
        typeof t.cropId === 'string' &&
        (t.type === 'expense' || t.type === 'income') &&
        Number.isFinite(Number(t.amount))
    );
  },

  saveTransactions(transactions: Transaction[]): boolean {
    return safeSetItem(
      TRANSACTIONS_KEY,
      JSON.stringify(Array.isArray(transactions) ? transactions : [])
    );
  },

  getHarvests(): HarvestEntry[] {
    return safeGetArray<HarvestEntry>(HARVESTS_KEY, SEED_HARVESTS).filter(
      (h) =>
        h &&
        typeof h === 'object' &&
        typeof h.id === 'string' &&
        typeof h.cropId === 'string' &&
        Number.isFinite(Number(h.quantityQuintal))
    );
  },

  saveHarvests(harvests: HarvestEntry[]): boolean {
    return safeSetItem(HARVESTS_KEY, JSON.stringify(Array.isArray(harvests) ? harvests : []));
  },

  getDiary(): DiaryEntry[] {
    return safeGetArray<DiaryEntry>(DIARY_KEY, SEED_DIARY).filter(
      (d) => d && typeof d === 'object' && typeof d.id === 'string' && typeof d.cropId === 'string'
    );
  },

  saveDiary(diary: DiaryEntry[]): boolean {
    return safeSetItem(DIARY_KEY, JSON.stringify(Array.isArray(diary) ? diary : []));
  },

  getSettings(): AppSettings {
    try {
      if (typeof localStorage !== 'undefined') {
        const data = localStorage.getItem(SETTINGS_KEY);
        if (data) {
          const parsed = JSON.parse(data);
          if (parsed && typeof parsed === 'object') {
            return {
              language: parsed.language === 'en' ? 'en' : 'hi',
              theme: 'light',
              farmerName:
                typeof parsed.farmerName === 'string' && parsed.farmerName.trim()
                  ? parsed.farmerName
                  : 'किसान भाई (Farmer)',
              phone: parsed.phone,
              village: parsed.village,
              defaultAreaUnit:
                parsed.defaultAreaUnit === 'bigha' || parsed.defaultAreaUnit === 'hectare'
                  ? parsed.defaultAreaUnit
                  : 'acre',
              hasSeenSplash: Boolean(parsed.hasSeenSplash)
            };
          }
        }
      }
    } catch {
      // fallback
    }
    return {
      language: 'hi',
      theme: 'light',
      farmerName: 'किसान भाई (Farmer)',
      defaultAreaUnit: 'acre',
      hasSeenSplash: false
    };
  },

  saveSettings(settings: AppSettings): boolean {
    return safeSetItem(SETTINGS_KEY, JSON.stringify(settings));
  },

  getWeatherLocation(): SavedLocation {
    try {
      if (typeof localStorage !== 'undefined') {
        const data = localStorage.getItem(WEATHER_LOC_KEY);
        if (data) {
          const parsed = JSON.parse(data);
          if (
            parsed &&
            typeof parsed.name === 'string' &&
            Number.isFinite(Number(parsed.lat)) &&
            Number.isFinite(Number(parsed.lon))
          ) {
            return {
              ...parsed,
              lat: Number(parsed.lat),
              lon: Number(parsed.lon)
            };
          }
        }
      }
    } catch {}
    return DEFAULT_USER_LOCATION;
  },

  saveWeatherLocation(loc: SavedLocation): boolean {
    return safeSetItem(WEATHER_LOC_KEY, JSON.stringify(loc));
  },

  getCachedWeather(lat: number, lon: number): Record<string, any> | null {
    try {
      if (typeof localStorage === 'undefined') return null;
      const raw = localStorage.getItem(WEATHER_CACHE_KEY);
      if (!raw) return null;
      const cacheMap = JSON.parse(raw);
      if (!cacheMap || typeof cacheMap !== 'object') return null;
      const key = \`\${lat.toFixed(3)},\${lon.toFixed(3)}\`;
      return cacheMap[key] || cacheMap['last'] || null;
    } catch {
      return null;
    }
  },

  saveCachedWeather(lat: number, lon: number, payload: Record<string, any>): void {
    try {
      if (typeof localStorage === 'undefined') return;
      const raw = localStorage.getItem(WEATHER_CACHE_KEY);
      const cacheMap = raw ? JSON.parse(raw) : {};
      const key = \`\${lat.toFixed(3)},\${lon.toFixed(3)}\`;
      cacheMap[key] = payload;
      cacheMap['last'] = payload;
      safeSetItem(WEATHER_CACHE_KEY, JSON.stringify(cacheMap));
    } catch {}
  },

  getNotes(): FarmNote[] {
    return safeGetArray<FarmNote>(NOTES_KEY, SEED_NOTES).filter(
      (n) => n && typeof n === 'object' && typeof n.id === 'string' && typeof n.title === 'string'
    );
  },

  saveNotes(notes: FarmNote[]): boolean {
    return safeSetItem(NOTES_KEY, JSON.stringify(Array.isArray(notes) ? notes : []));
  },

  getShoppingItems(): ShoppingItem[] {
    return safeGetArray<ShoppingItem>(SHOPPING_KEY, SEED_SHOPPING).filter(
      (s) => s && typeof s === 'object' && typeof s.id === 'string' && typeof s.name === 'string'
    );
  },

  saveShoppingItems(items: ShoppingItem[]): boolean {
    return safeSetItem(SHOPPING_KEY, JSON.stringify(Array.isArray(items) ? items : []));
  },

  getCalcHistory(): { id: string; expression: string; result: string; timestamp: string }[] {
    try {
      if (typeof localStorage !== 'undefined') {
        const data = localStorage.getItem(CALC_HISTORY_KEY);
        if (data) {
          const parsed = JSON.parse(data);
          if (Array.isArray(parsed)) return parsed;
        }
      }
    } catch {}
    return [
      { id: 'ch-1', expression: '2450 × 12', result: '29,400', timestamp: 'आज, 10:30 AM' },
      { id: 'ch-2', expression: '4 × 1350 + 2 × 270', result: '5,940', timestamp: 'कल, 04:15 PM' }
    ];
  },

  saveCalcHistory(history: { id: string; expression: string; result: string; timestamp: string }[]): boolean {
    return safeSetItem(
      CALC_HISTORY_KEY,
      JSON.stringify(Array.isArray(history) ? history.slice(0, 50) : [])
    );
  },

  // Export full JSON backup
  exportFullBackup(): string {
    const backup = {
      version: '1.2',
      exportedAt: new Date().toISOString(),
      branding: 'FieldBook by Mr Nikhil',
      crops: this.getCrops(),
      transactions: this.getTransactions(),
      harvests: this.getHarvests(),
      diary: this.getDiary(),
      notes: this.getNotes(),
      shoppingItems: this.getShoppingItems(),
      settings: this.getSettings()
    };
    return JSON.stringify(backup, null, 2);
  },

  // Detailed restore with strict schema check so corrupted backups never overwrite existing data
  importFullBackupWithDetails(jsonString: string): BackupImportResult {
    try {
      if (!jsonString || typeof jsonString !== 'string' || !jsonString.trim()) {
        return {
          success: false,
          errorHi: 'बैकअप फाइल खाली है। कृपया मान्य FieldBook JSON बैकअप फाइल चुनें।',
          errorEn: 'Backup file is empty. Please select a valid FieldBook JSON backup file.'
        };
      }

      const parsed = JSON.parse(jsonString);
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        return {
          success: false,
          errorHi: 'अमान्य JSON प्रारूप। फाइल में FieldBook का डेटा ऑब्जेक्ट नहीं मिला।',
          errorEn: 'Invalid JSON format. Root object not found in backup file.'
        };
      }

      if (!Array.isArray(parsed.crops) || !Array.isArray(parsed.transactions)) {
        return {
          success: false,
          errorHi: 'अमान्य बैकअप फाइल: इसमें फसलों (crops) या लेन-देन (transactions) की सूची नहीं है। मौजूदा डेटा सुरक्षित रखा गया है।',
          errorEn: 'Invalid backup file: missing crops or transactions arrays. Existing data was not modified.'
        };
      }

      const validCrops = parsed.crops.every(
        (c: any) =>
          c &&
          typeof c === 'object' &&
          typeof c.id === 'string' &&
          typeof c.name === 'string' &&
          Number.isFinite(Number(c.landArea))
      );

      const validTransactions = parsed.transactions.every(
        (t: any) =>
          t &&
          typeof t === 'object' &&
          typeof t.id === 'string' &&
          typeof t.cropId === 'string' &&
          (t.type === 'expense' || t.type === 'income') &&
          Number.isFinite(Number(t.amount))
      );

      if (!validCrops || !validTransactions) {
        return {
          success: false,
          errorHi: 'बैकअप फाइल का डेटा क्षतिग्रस्त (Corrupted) है। सुरक्षा के लिए आपका मौजूदा हिसाब नहीं बदला गया।',
          errorEn: 'Backup records are malformed or corrupted. Existing data was preserved.'
        };
      }

      this.saveCrops(parsed.crops);
      this.saveTransactions(parsed.transactions);
      if (Array.isArray(parsed.harvests)) this.saveHarvests(parsed.harvests);
      if (Array.isArray(parsed.diary)) this.saveDiary(parsed.diary);
      if (Array.isArray(parsed.notes)) this.saveNotes(parsed.notes);
      if (Array.isArray(parsed.shoppingItems)) this.saveShoppingItems(parsed.shoppingItems);
      if (parsed.settings && typeof parsed.settings === 'object') {
        this.saveSettings({
          ...this.getSettings(),
          ...parsed.settings
        });
      }

      return {
        success: true,
        counts: {
          crops: parsed.crops.length,
          transactions: parsed.transactions.length,
          harvests: Array.isArray(parsed.harvests) ? parsed.harvests.length : 0,
          notes: Array.isArray(parsed.notes) ? parsed.notes.length : 0
        }
      };
    } catch (e) {
      console.error('Failed to import backup:', e);
      return {
        success: false,
        errorHi: 'यह मान्य JSON फाइल नहीं है। कृपया सही FieldBook बैकअप (.json) फाइल चुनें।',
        errorEn: 'Failed to parse JSON file. Please select a valid FieldBook (.json) backup.'
      };
    }
  },

  // Restore full backup (boolean return for backward compatibility)
  importFullBackup(jsonString: string): boolean {
    return this.importFullBackupWithDetails(jsonString).success;
  },

  // Reset to default seed data
  resetToSampleData(): void {
    this.saveCrops(SEED_CROPS);
    this.saveTransactions(SEED_TRANSACTIONS);
    this.saveHarvests(SEED_HARVESTS);
    this.saveDiary(SEED_DIARY);
    this.saveNotes(SEED_NOTES);
    this.saveShoppingItems(SEED_SHOPPING);
  },

  // Clear all data completely
  clearAllData(): void {
    this.saveCrops([]);
    this.saveTransactions([]);
    this.saveHarvests([]);
    this.saveDiary([]);
    this.saveNotes([]);
    this.saveShoppingItems([]);
  }
};


`;export{n as default};
