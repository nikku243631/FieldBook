const e=`/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { App as CapApp } from '@capacitor/app';
import {
  CropCycle,
  Transaction,
  HarvestEntry,
  DiaryEntry,
  FarmNote,
  ShoppingItem
} from './types';
import { Storage, AppSettings } from './utils/storage';
import { ReceiptStorage, buildSyncedReceiptAttachment } from './utils/receiptStorage';
import { SplashScreen } from './components/SplashScreen';
import { Header } from './components/Header';
import { CropList } from './components/CropList';
import { CropDetailView } from './components/CropDetailView';
import { AddCropModal } from './components/AddCropModal';
import { AddTransactionModal } from './components/AddTransactionModal';
import { AddHarvestModal, AddDiaryModal } from './components/AddHarvestModal';
import { CalculatorsView } from './components/CalculatorsView';
import { WeatherView } from './components/WeatherView';
import { ReportsBackupView } from './components/ReportsBackupView';
import { NotesAndListsView } from './components/NotesAndListsView';
import { SimpleCalculator } from './components/SimpleCalculator';
import { InstallModal } from './components/InstallModal';
import { downloadProjectZip, downloadWorkflowYaml, GITHUB_WORKFLOW_YAML } from './utils/zipExporter';
import {
  PdfPreviewPayload,
  downloadPdfBlobOrSaveNative,
  triggerSystemHtmlPrint,
  shareViaWhatsApp
} from './utils/export';
import { isInstalledApp } from './utils/platform';
import {
  Smartphone,
  X,
  Loader2,
  Copy,
  Check,
  FileCode,
  Download,
  Printer,
  Share2,
  CheckCircle2,
  FileText
} from 'lucide-react';

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(() => Storage.getSettings());
  const [showSplash, setShowSplash] = useState<boolean>(true);

  const [crops, setCrops] = useState<CropCycle[]>(() => Storage.getCrops());
  const [transactions, setTransactions] = useState<Transaction[]>(() => Storage.getTransactions());
  const [harvests, setHarvests] = useState<HarvestEntry[]>(() => Storage.getHarvests());
  const [diary, setDiary] = useState<DiaryEntry[]>(() => Storage.getDiary());
  const [notes, setNotes] = useState<FarmNote[]>(() => Storage.getNotes());
  const [shoppingItems, setShoppingItems] = useState<ShoppingItem[]>(() => Storage.getShoppingItems());

  const [currentTab, setCurrentTab] = useState<'crops' | 'calculators' | 'notes' | 'weather' | 'reports'>('crops');
  const [selectedCropId, setSelectedCropId] = useState<string | null>(null);
  const [isQuickCalcOpen, setIsQuickCalcOpen] = useState(false);

  // Modals state
  const [isAddCropOpen, setIsAddCropOpen] = useState(false);
  const [cropToEdit, setCropToEdit] = useState<CropCycle | null>(null);
  const [isAddTxOpen, setIsAddTxOpen] = useState(false);
  const [addTxType, setAddTxType] = useState<'expense' | 'income'>('expense');
  const [txToEdit, setTxToEdit] = useState<Transaction | null>(null);
  const [isAddHarvestOpen, setIsAddHarvestOpen] = useState(false);
  const [harvestToEdit, setHarvestToEdit] = useState<HarvestEntry | null>(null);
  const [isAddDiaryOpen, setIsAddDiaryOpen] = useState(false);
  const [diaryToEdit, setDiaryToEdit] = useState<DiaryEntry | null>(null);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [pdfPreview, setPdfPreview] = useState<PdfPreviewPayload | null>(null);
  const [dismissInstallBanner, setDismissInstallBanner] = useState(false);
  const [isBannerZipping, setIsBannerZipping] = useState(false);
  const [bannerZipDone, setBannerZipDone] = useState(false);
  const [bannerYamlCopied, setBannerYamlCopied] = useState(false);

  useEffect(() => {
    ReceiptStorage.hydrateCache().catch(() => {});
  }, []);

  useEffect(() => {
    const handlePdfPreview = (event: Event) => {
      const customEvent = event as CustomEvent<PdfPreviewPayload>;
      if (customEvent.detail) {
        setPdfPreview(customEvent.detail);
      }
    };
    window.addEventListener('fieldbook:pdf-preview', handlePdfPreview);
    return () => window.removeEventListener('fieldbook:pdf-preview', handlePdfPreview);
  }, []);

  // Keep latest navigation state in ref for Android hardware back-button listener
  const navStateRef = useRef({
    isInstallModalOpen,
    isQuickCalcOpen,
    isAddDiaryOpen,
    isAddHarvestOpen,
    isAddTxOpen,
    isAddCropOpen,
    selectedCropId,
    currentTab
  });

  useEffect(() => {
    navStateRef.current = {
      isInstallModalOpen,
      isQuickCalcOpen,
      isAddDiaryOpen,
      isAddHarvestOpen,
      isAddTxOpen,
      isAddCropOpen,
      selectedCropId,
      currentTab
    };
  }, [
    isInstallModalOpen,
    isQuickCalcOpen,
    isAddDiaryOpen,
    isAddHarvestOpen,
    isAddTxOpen,
    isAddCropOpen,
    selectedCropId,
    currentTab
  ]);

  // Android Capacitor hardware back button & app lifecycle handling
  useEffect(() => {
    let listenerHandle: { remove: () => Promise<void> } | null = null;

    const setupBackListener = async () => {
      try {
        listenerHandle = await CapApp.addListener('backButton', () => {
          const s = navStateRef.current;
          if (s.isInstallModalOpen) {
            setIsInstallModalOpen(false);
          } else if (s.isQuickCalcOpen) {
            setIsQuickCalcOpen(false);
          } else if (s.isAddDiaryOpen) {
            setIsAddDiaryOpen(false);
            setDiaryToEdit(null);
          } else if (s.isAddHarvestOpen) {
            setIsAddHarvestOpen(false);
            setHarvestToEdit(null);
          } else if (s.isAddTxOpen) {
            setIsAddTxOpen(false);
            setTxToEdit(null);
          } else if (s.isAddCropOpen) {
            setIsAddCropOpen(false);
            setCropToEdit(null);
          } else if (s.selectedCropId) {
            setSelectedCropId(null);
          } else if (s.currentTab !== 'crops') {
            setCurrentTab('crops');
          } else {
            CapApp.exitApp();
          }
        });
      } catch {
        // Ignore in standard web browsers where Capacitor native bridge is not active
      }
    };

    setupBackListener();

    return () => {
      if (listenerHandle) {
        listenerHandle.remove().catch(() => {});
      }
    };
  }, []);

  const handleQuickZipDownload = async () => {
    setIsBannerZipping(true);
    try {
      await downloadProjectZip();
      setBannerZipDone(true);
      setTimeout(() => setBannerZipDone(false), 4000);
    } finally {
      setIsBannerZipping(false);
    }
  };

  const handleCopyBannerYaml = async () => {
    try {
      await navigator.clipboard.writeText(GITHUB_WORKFLOW_YAML);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = GITHUB_WORKFLOW_YAML;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    setBannerYamlCopied(true);
    setTimeout(() => setBannerYamlCopied(false), 3500);
  };

  // Sync light/dark theme class to document root and persist settings
  useEffect(() => {
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.body.className = 'text-slate-100 min-h-screen antialiased';
    } else {
      document.documentElement.classList.remove('dark');
      document.body.className = 'text-slate-950 min-h-screen antialiased';
    }
    Storage.saveSettings(settings);
  }, [settings]);

  // Sync database updates to offline Storage
  const reloadFromStorage = () => {
    setCrops(Storage.getCrops());
    setTransactions(Storage.getTransactions());
    setHarvests(Storage.getHarvests());
    setDiary(Storage.getDiary());
    setNotes(Storage.getNotes());
    setShoppingItems(Storage.getShoppingItems());
    setSettings(Storage.getSettings());
  };

  const handleToggleLang = () => {
    setSettings((prev) => ({
      ...prev,
      language: prev.language === 'hi' ? 'en' : 'hi'
    }));
  };

  const handleToggleTheme = () => {
    setSettings((prev) => ({
      ...prev,
      theme: prev.theme === 'dark' ? 'light' : 'dark'
    }));
  };

  const handleUpdateFarmerName = (name: string) => {
    setSettings((prev) => ({
      ...prev,
      farmerName: name
    }));
  };

  // ==================== CROP ACTIONS ====================
  const handleSaveCrop = (cropData: Partial<CropCycle>) => {
    if (cropToEdit) {
      const updated = crops.map((c) =>
        c.id === cropToEdit.id
          ? {
              ...c,
              ...cropData,
              updatedAt: new Date().toISOString()
            }
          : c
      );
      setCrops(updated);
      Storage.saveCrops(updated);
      setCropToEdit(null);
    } else {
      const newCrop: CropCycle = {
        id: \`crop-\${Date.now()}\`,
        name: cropData.name || 'New Crop',
        hindiName: cropData.hindiName || cropData.name || 'नई फसल',
        variety: cropData.variety || '',
        landArea: cropData.landArea || 1,
        areaUnit: cropData.areaUnit || 'acre',
        season: cropData.season || 'rabi',
        sowingDate: cropData.sowingDate || new Date().toISOString().split('T')[0],
        expectedHarvestDate: cropData.expectedHarvestDate,
        status: cropData.status || 'active',
        targetYieldQuintal: cropData.targetYieldQuintal,
        notes: cropData.notes,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      const updated = [newCrop, ...crops];
      setCrops(updated);
      Storage.saveCrops(updated);
      setSelectedCropId(newCrop.id);
    }
  };

  const handleDeleteCrop = (cropId: string) => {
    const updatedCrops = crops.filter((c) => c.id !== cropId);
    const removedTxs = transactions.filter((t) => t.cropId === cropId);
    const updatedTx = transactions.filter((t) => t.cropId !== cropId);
    const updatedHarvests = harvests.filter((h) => h.cropId !== cropId);
    const updatedDiary = diary.filter((d) => d.cropId !== cropId);

    for (const tx of removedTxs) {
      if (tx.receiptAttachment?.storageRef) {
        ReceiptStorage.deleteReceipt(tx.receiptAttachment.storageRef).catch(() => {});
      }
    }

    setCrops(updatedCrops);
    setTransactions(updatedTx);
    setHarvests(updatedHarvests);
    setDiary(updatedDiary);

    Storage.saveCrops(updatedCrops);
    Storage.saveTransactions(updatedTx);
    Storage.saveHarvests(updatedHarvests);
    Storage.saveDiary(updatedDiary);

    setSelectedCropId(null);
  };

  const handleClearAllData = () => {
    Storage.clearAllData();
    setCrops([]);
    setTransactions([]);
    setHarvests([]);
    setDiary([]);
    setNotes([]);
    setShoppingItems([]);
    setSelectedCropId(null);
  };

  // ==================== TRANSACTION ACTIONS ====================
  const handleSaveTransaction = (txData: Partial<Transaction>) => {
    const candidateId = txToEdit?.id || txData.id;
    const isExistingTx = Boolean(
      txToEdit || (candidateId && transactions.some((t) => t.id === candidateId))
    );

    if (isExistingTx && candidateId) {
      const updated = transactions.map((t) => {
        if (t.id !== candidateId) return t;
        const merged: Transaction = {
          ...t,
          ...txData,
          id: candidateId,
          cropId: txData.cropId || t.cropId
        };
        // Keep receipt metadata strictly synced with the transaction's actual date, amount, title, and category
        if (merged.receiptAttachment) {
          merged.receiptAttachment = buildSyncedReceiptAttachment(merged, {
            id: merged.receiptAttachment.id,
            storageRef: merged.receiptAttachment.storageRef,
            fileName: merged.receiptAttachment.fileName,
            mimeType: merged.receiptAttachment.mimeType,
            fileSize: merged.receiptAttachment.fileSize,
            createdAt: merged.receiptAttachment.createdAt
          });
          ReceiptStorage.syncStoredReceiptMetadata(merged).catch(() => {});
        }
        return merged;
      });
      setTransactions(updated);
      Storage.saveTransactions(updated);
      setTxToEdit(null);
    } else {
      const resolvedId = candidateId || \`tx-\${Date.now()}\`;
      const newTx: Transaction = {
        id: resolvedId,
        cropId: txData.cropId || selectedCropId || '',
        type: txData.type || 'expense',
        category: txData.category || 'other',
        title: txData.title || '',
        amount: txData.amount || 0,
        date: txData.date || new Date().toISOString().split('T')[0],
        time: txData.time || new Date().toTimeString().slice(0, 5),
        quantity: txData.quantity,
        unit: txData.unit,
        ratePerUnit: txData.ratePerUnit,
        vendorOrBuyer: txData.vendorOrBuyer,
        notes: txData.notes,
        paymentStatus: txData.paymentStatus || 'paid',
        mandiDetails: txData.mandiDetails,
        receiptAttachment: txData.receiptAttachment,
        createdAt: new Date().toISOString()
      };

      if (newTx.receiptAttachment) {
        newTx.receiptAttachment = buildSyncedReceiptAttachment(newTx, {
          id: newTx.receiptAttachment.id,
          storageRef: newTx.receiptAttachment.storageRef,
          fileName: newTx.receiptAttachment.fileName,
          mimeType: newTx.receiptAttachment.mimeType,
          fileSize: newTx.receiptAttachment.fileSize,
          createdAt: newTx.receiptAttachment.createdAt
        });
        ReceiptStorage.syncStoredReceiptMetadata(newTx).catch(() => {});
      }

      const updated = [newTx, ...transactions];
      setTransactions(updated);
      Storage.saveTransactions(updated);
    }
  };

  const handleDeleteTransaction = (txId: string) => {
    const target = transactions.find((t) => t.id === txId);
    if (target?.receiptAttachment?.storageRef) {
      ReceiptStorage.deleteReceipt(target.receiptAttachment.storageRef).catch(() => {});
    }
    const updated = transactions.filter((t) => t.id !== txId);
    setTransactions(updated);
    Storage.saveTransactions(updated);
  };

  // ==================== HARVEST ACTIONS ====================
  const handleSaveHarvest = (hrvData: Partial<HarvestEntry>) => {
    if (harvestToEdit || hrvData.id) {
      const targetId = harvestToEdit?.id || hrvData.id!;
      const updated = harvests.map((h) =>
        h.id === targetId
          ? {
              ...h,
              ...hrvData,
              id: targetId,
              cropId: hrvData.cropId || h.cropId
            }
          : h
      );
      setHarvests(updated);
      Storage.saveHarvests(updated);
      setHarvestToEdit(null);
    } else {
      const newHrv: HarvestEntry = {
        id: \`hrv-\${Date.now()}\`,
        cropId: hrvData.cropId || selectedCropId || '',
        date: hrvData.date || new Date().toISOString().split('T')[0],
        time: hrvData.time || new Date().toTimeString().slice(0, 5),
        quantityQuintal: hrvData.quantityQuintal || 0,
        moisturePercentage: hrvData.moisturePercentage,
        grade: hrvData.grade,
        storageLocation: hrvData.storageLocation,
        notes: hrvData.notes
      };

      const updated = [newHrv, ...harvests];
      setHarvests(updated);
      Storage.saveHarvests(updated);
    }
  };

  const handleDeleteHarvest = (hrvId: string) => {
    const updated = harvests.filter((h) => h.id !== hrvId);
    setHarvests(updated);
    Storage.saveHarvests(updated);
  };

  // ==================== DIARY ACTIONS ====================
  const handleSaveDiary = (entryData: Partial<DiaryEntry>) => {
    if (diaryToEdit || entryData.id) {
      const targetId = diaryToEdit?.id || entryData.id!;
      const updated = diary.map((d) =>
        d.id === targetId
          ? {
              ...d,
              ...entryData,
              id: targetId,
              cropId: entryData.cropId || d.cropId
            }
          : d
      );
      setDiary(updated);
      Storage.saveDiary(updated);
      setDiaryToEdit(null);
    } else {
      const newEntry: DiaryEntry = {
        id: \`dir-\${Date.now()}\`,
        cropId: entryData.cropId || selectedCropId || '',
        date: entryData.date || new Date().toISOString().split('T')[0],
        time: entryData.time || new Date().toTimeString().slice(0, 5),
        activityType: entryData.activityType || 'other',
        notes: entryData.notes || '',
        weatherNote: entryData.weatherNote
      };

      const updated = [newEntry, ...diary];
      setDiary(updated);
      Storage.saveDiary(updated);
    }
  };

  const handleDeleteDiary = (diaryId: string) => {
    const updated = diary.filter((d) => d.id !== diaryId);
    setDiary(updated);
    Storage.saveDiary(updated);
  };

  const activeSelectedCrop = crops.find((c) => c.id === selectedCropId);

  return (
    <div className="relative min-h-screen flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* 0. Real Agricultural Landscape Background Layer (/farm-bg.jpg) */}
      <div
        aria-hidden="true"
        className="farm-bg-layer fixed inset-0 -z-10 pointer-events-none select-none overflow-hidden"
      >
        <img
          src="/farm-bg.jpg"
          alt=""
          decoding="async"
          className="w-full h-full object-cover object-center transform-gpu scale-[1.01]"
        />
        {/* Subtle readability atmosphere overlay */}
        <div
          className={\`absolute inset-0 transition-colors duration-300 \${
            settings.theme === 'dark'
              ? 'bg-slate-950/72'
              : 'bg-gradient-to-b from-sky-100/10 via-amber-50/10 to-emerald-950/20'
          }\`}
        />
      </div>

      {/* 1. Splash Screen on Launch */}
      {showSplash && (
        <SplashScreen
          lang={settings.language}
          onDismiss={() => setShowSplash(false)}
        />
      )}

      {/* 2. Top Header with 3D Liquid Glass Brand Pill, Unclipped Utility Controls & Nav Tabs */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setSelectedCropId(null);
          setCurrentTab(tab);
        }}
        lang={settings.language}
        onToggleLang={handleToggleLang}
        theme={settings.theme}
        onToggleTheme={handleToggleTheme}
        onOpenAddCrop={() => {
          setCropToEdit(null);
          setIsAddCropOpen(true);
        }}
        selectedCropId={selectedCropId}
        onBackToCrops={() => setSelectedCropId(null)}
        onOpenQuickCalc={() => setIsQuickCalcOpen(true)}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
      />

      {/* 3. Main Workspace Canvas */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-2.5 sm:px-5 pt-2 sm:pt-3">
        {selectedCropId && activeSelectedCrop ? (
          <CropDetailView
            crop={activeSelectedCrop}
            transactions={transactions}
            harvests={harvests}
            diary={diary}
            lang={settings.language}
            theme={settings.theme}
            farmerName={settings.farmerName}
            onBack={() => setSelectedCropId(null)}
            onEditCrop={(crop) => {
              setCropToEdit(crop);
              setIsAddCropOpen(true);
            }}
            onDeleteCrop={handleDeleteCrop}
            onAddTransaction={(type) => {
              setTxToEdit(null);
              setAddTxType(type);
              setIsAddTxOpen(true);
            }}
            onEditTransaction={(tx) => {
              setTxToEdit(tx);
              setAddTxType(tx.type);
              setIsAddTxOpen(true);
            }}
            onDeleteTransaction={handleDeleteTransaction}
            onAddHarvest={() => {
              setHarvestToEdit(null);
              setIsAddHarvestOpen(true);
            }}
            onEditHarvest={(hrv) => {
              setHarvestToEdit(hrv);
              setIsAddHarvestOpen(true);
            }}
            onDeleteHarvest={handleDeleteHarvest}
            onAddDiary={() => {
              setDiaryToEdit(null);
              setIsAddDiaryOpen(true);
            }}
            onEditDiary={(entry) => {
              setDiaryToEdit(entry);
              setIsAddDiaryOpen(true);
            }}
            onDeleteDiary={handleDeleteDiary}
          />
        ) : currentTab === 'crops' ? (
          <CropList
            crops={crops}
            transactions={transactions}
            harvests={harvests}
            lang={settings.language}
            theme={settings.theme}
            onSelectCrop={(id) => setSelectedCropId(id)}
            onOpenAddCrop={() => {
              setCropToEdit(null);
              setIsAddCropOpen(true);
            }}
            onDeleteCrop={handleDeleteCrop}
          />
        ) : currentTab === 'calculators' ? (
          <CalculatorsView lang={settings.language} theme={settings.theme} />
        ) : currentTab === 'notes' ? (
          <NotesAndListsView
            lang={settings.language}
            theme={settings.theme}
            notes={notes}
            shoppingItems={shoppingItems}
            onUpdateNotes={(updated) => {
              setNotes(updated);
              Storage.saveNotes(updated);
            }}
            onUpdateShoppingItems={(updated) => {
              setShoppingItems(updated);
              Storage.saveShoppingItems(updated);
            }}
            onOpenSimpleCalc={() => setIsQuickCalcOpen(true)}
          />
        ) : currentTab === 'weather' ? (
          <WeatherView lang={settings.language} theme={settings.theme} />
        ) : (
          <ReportsBackupView
            crops={crops}
            transactions={transactions}
            harvests={harvests}
            lang={settings.language}
            theme={settings.theme}
            farmerName={settings.farmerName}
            onUpdateFarmerName={handleUpdateFarmerName}
            onReloadData={reloadFromStorage}
            onClearAllData={handleClearAllData}
            onOpenInstallModal={() => setIsInstallModalOpen(true)}
          />
        )}

        {/* Bottom of Home ("All Crops") 1-Click Download ZIP & Copy YAML Section (Hidden inside compiled Android APK) */}
        {!isInstalledApp() && currentTab === 'crops' && !selectedCropId && (
          <div className="mb-12 mt-2 p-4 sm:p-5 rounded-3xl liquid-glass-card space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-9 h-9 rounded-2xl liquid-glass-emerald text-white flex items-center justify-center shrink-0">
                  <Download className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs sm:text-sm font-extrabold text-slate-950 dark:text-white">
                    {settings.language === 'hi'
                      ? '📦 1-Click डाउनलोड सोर्स ZIP व कॉपी YAML फाइल'
                      : '📦 1-Click Download Source ZIP & Copy YAML File'}
                  </p>
                  <p className="text-[11px] font-bold text-slate-800 dark:text-slate-300">
                    {settings.language === 'hi'
                      ? '1-क्लिक में पूरी ZIP डाउनलोड करें और YAML फाइल कॉपी करें — GitHub पर अपलोड करते ही सीधा APK बनेगा'
                      : 'Download complete ZIP in 1 click & copy YAML file to build APK directly on GitHub'}
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <a
                href="/FieldBook-Complete-GitHub-APK.zip"
                download="FieldBook-Complete-GitHub-APK.zip"
                onClick={() => {
                  setBannerZipDone(true);
                  setTimeout(() => setBannerZipDone(false), 4500);
                }}
                className="w-full py-3.5 px-4 rounded-2xl liquid-glass-emerald text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer no-underline"
              >
                <Download className="w-4 h-4 shrink-0" />
                <span>
                  {bannerZipDone
                    ? settings.language === 'hi'
                      ? '✓ ZIP डाउनलोड शुरू हो गया!'
                      : '✓ ZIP Download Started!'
                    : settings.language === 'hi'
                    ? '📥 1-Click Download ZIP (पूरी फाइल)'
                    : '📥 1-Click Download ZIP (Complete)'}
                </span>
              </a>

              <button
                type="button"
                onClick={handleCopyBannerYaml}
                className="w-full py-3.5 px-4 rounded-2xl btn-3d-blue text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer"
              >
                {bannerYamlCopied ? (
                  <>
                    <Check className="w-4 h-4 shrink-0" />
                    <span>{settings.language === 'hi' ? '✓ YAML फाइल कॉपी हो गई!' : '✓ YAML File Copied!'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 shrink-0" />
                    <span>{settings.language === 'hi' ? '📋 Copy YAML File (build-apk.yml)' : '📋 Copy YAML File (build-apk.yml)'}</span>
                  </>
                )}
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleQuickZipDownload}
                disabled={isBannerZipping}
                className="flex-1 py-2 px-3 rounded-xl liquid-glass-pill font-extrabold text-xs text-slate-950 dark:text-white cursor-pointer flex items-center justify-center gap-1.5"
              >
                {isBannerZipping ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-700" />
                    <span>{settings.language === 'hi' ? 'पैक हो रहा...' : 'Packing...'}</span>
                  </>
                ) : (
                  <>
                    <Download className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{settings.language === 'hi' ? '📦 विकल्प 2: जनरेट ZIP' : '📦 Option 2: Generate ZIP'}</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => downloadWorkflowYaml()}
                className="flex-1 py-2 px-3 rounded-xl liquid-glass-pill font-extrabold text-xs text-slate-950 dark:text-white cursor-pointer flex items-center justify-center gap-1.5"
              >
                <FileCode className="w-3.5 h-3.5 text-blue-700" />
                <span>{settings.language === 'hi' ? '📄 डाउनलोड build-apk.yml' : '📄 Download build-apk.yml'}</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Quick General Calculator Modal (Opened from top Header Calculator button) */}
      {isQuickCalcOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-md animate-in fade-in zoom-in-95 duration-200">
            <SimpleCalculator
              lang={settings.language}
              theme={settings.theme}
              isModal={true}
              onClose={() => setIsQuickCalcOpen(false)}
              onSendToNotes={(calcText) => {
                const newNote: FarmNote = {
                  id: \`note-\${Date.now()}\`,
                  title: settings.language === 'hi' ? 'कैलकुलेटर हिसाब' : 'Calculation Note',
                  content: calcText,
                  category: 'payment',
                  isPinned: true,
                  date: new Date().toISOString().split('T')[0],
                  time: new Date().toTimeString().slice(0, 5),
                  color: 'emerald',
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString()
                };
                const updated = [newNote, ...notes];
                setNotes(updated);
                Storage.saveNotes(updated);
                setIsQuickCalcOpen(false);
                setCurrentTab('notes');
              }}
            />
          </div>
        </div>
      )}

      {/* 4. Compact Frosted Liquid Glass Footer with Developer Attribution */}
      <footer className="w-full py-3 mt-auto text-center text-xs font-semibold liquid-glass-card rounded-none border-x-0 border-b-0">
        <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-1.5 text-slate-900 dark:text-slate-200">
          <span>FieldBook — डिजिटल खेत लेजर व फसल हिसाब-किताब</span>
          <span>
            {settings.language === 'hi' ? 'डेवलपर:' : 'Developer:'}{' '}
            <strong className="text-emerald-800 dark:text-emerald-400 font-extrabold">Mr Nikhil</strong>
          </span>
          <span className="text-[11px] font-mono text-slate-700 dark:text-slate-300">
            100% Offline-First Local Storage
          </span>
        </div>
      </footer>

      {/* ==================== INTERACTIVE MODALS ==================== */}

      {/* Add / Edit Crop Modal */}
      <AddCropModal
        isOpen={isAddCropOpen}
        onClose={() => {
          setIsAddCropOpen(false);
          setCropToEdit(null);
        }}
        onSaveCrop={handleSaveCrop}
        lang={settings.language}
        theme={settings.theme}
        cropToEdit={cropToEdit}
      />

      {/* Add / Edit Expense / Income Modal */}
      {selectedCropId && (
        <AddTransactionModal
          isOpen={isAddTxOpen}
          onClose={() => {
            setIsAddTxOpen(false);
            setTxToEdit(null);
          }}
          onSave={handleSaveTransaction}
          cropId={selectedCropId}
          defaultType={addTxType}
          lang={settings.language}
          theme={settings.theme}
          txToEdit={txToEdit}
        />
      )}

      {/* Add / Edit Harvest Modal */}
      {selectedCropId && (
        <AddHarvestModal
          isOpen={isAddHarvestOpen}
          onClose={() => {
            setIsAddHarvestOpen(false);
            setHarvestToEdit(null);
          }}
          onSave={handleSaveHarvest}
          cropId={selectedCropId}
          lang={settings.language}
          theme={settings.theme}
          harvestToEdit={harvestToEdit}
        />
      )}

      {/* Add / Edit Diary Modal */}
      {selectedCropId && (
        <AddDiaryModal
          isOpen={isAddDiaryOpen}
          onClose={() => {
            setIsAddDiaryOpen(false);
            setDiaryToEdit(null);
          }}
          onSave={handleSaveDiary}
          cropId={selectedCropId}
          lang={settings.language}
          theme={settings.theme}
          diaryToEdit={diaryToEdit}
        />
      )}

      {/* Install App / APK Guide Modal (Only on Web, never inside installed Android APK) */}
      {!isInstalledApp() && (
        <InstallModal
          isOpen={isInstallModalOpen}
          onClose={() => setIsInstallModalOpen(false)}
          lang={settings.language}
          theme={settings.theme}
          onGoToAccountReports={() => {
            setSelectedCropId(null);
            setCurrentTab('reports');
          }}
        />
      )}

      {/* 3D Liquid Glass PDF Statement Preview & Instant Download Modal */}
      {pdfPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/65 backdrop-blur-md overflow-y-auto">
          <div className="liquid-glass-modal w-full max-w-2xl rounded-3xl p-4 sm:p-5 my-4 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b-2 border-emerald-500/30 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl btn-3d-blue text-white flex items-center justify-center shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-slate-950 dark:text-white leading-tight">
                    {pdfPreview.title}
                  </h3>
                  <p className="text-[11px] font-bold text-emerald-900 dark:text-emerald-300 flex items-center gap-1 mt-0.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                    <span>
                      {settings.language === 'hi'
                        ? \`PDF फाइल (\${pdfPreview.fileName}) तैयार और डाउनलोड हो गई है!\`
                        : \`PDF file (\${pdfPreview.fileName}) generated and downloaded!\`}
                    </span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPdfPreview(null)}
                aria-label="Close"
                className="w-9 h-9 rounded-full liquid-glass-danger flex items-center justify-center cursor-pointer shrink-0"
              >
                <X className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>

            {/* Action Bar */}
            <div className="flex flex-wrap items-center gap-2 mb-3 shrink-0">
              {pdfPreview.pdfBlob && (
                <button
                  type="button"
                  onClick={() => downloadPdfBlobOrSaveNative(pdfPreview.pdfBlob!, pdfPreview.fileName)}
                  className="liquid-glass-emerald flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-extrabold text-white cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>
                    {settings.language === 'hi'
                      ? '📥 PDF फाइल फिर से डाउनलोड करें (.PDF)'
                      : '📥 Download PDF Again (.PDF)'}
                  </span>
                </button>
              )}

              <button
                type="button"
                onClick={() =>
                  triggerSystemHtmlPrint(
                    pdfPreview.htmlDocument,
                    pdfPreview.fileName.replace(/\\.pdf$/, '')
                  )
                }
                className="btn-3d-blue flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-extrabold text-white cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>
                  {settings.language === 'hi' ? '🖨️ सिस्टम प्रिंट (Print)' : '🖨️ System Print'}
                </span>
              </button>

              {pdfPreview.whatsappText && (
                <button
                  type="button"
                  onClick={() => shareViaWhatsApp(pdfPreview.whatsappText!, pdfPreview.title)}
                  className="btn-3d-amber flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-extrabold text-white cursor-pointer"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </button>
              )}
            </div>

            {/* Rendered A4 PDF Pages Preview */}
            <div className="overflow-y-auto space-y-3 rounded-2xl bg-slate-900/15 dark:bg-slate-950/50 p-2.5 border border-white/60 flex-1">
              {pdfPreview.pageDataUrls.map((dataUrl, index) => (
                <div
                  key={index}
                  className="bg-white rounded-xl overflow-hidden shadow-lg border border-slate-300"
                >
                  <img
                    src={dataUrl}
                    alt={\`PDF Page \${index + 1}\`}
                    className="w-full h-auto block"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
`;export{e as default};
