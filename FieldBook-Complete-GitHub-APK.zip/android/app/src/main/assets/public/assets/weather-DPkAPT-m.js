const n=`import { Storage } from './storage';

export interface DailyForecast {
  date: string;
  dayName: string;
  maxTemp: number;
  minTemp: number;
  precipitationMm: number;
  rainProbability: number;
  windSpeedKmh: number;
  weatherCode: number;
  sprayCondition: 'safe' | 'caution' | 'rain_warning';
}

export interface WeatherData {
  city: string;
  latitude: number;
  longitude: number;
  currentTemp: number;
  humidity: number;
  windSpeedKmh: number;
  weatherCode: number;
  isRaining: boolean;
  sprayStatus: 'safe' | 'caution' | 'rain_warning';
  sprayAdvisoryHi: string;
  sprayAdvisoryEn: string;
  dailyForecast: DailyForecast[];
  updatedAt: string;
  fetchedAtISO: string;
  dataSource: 'live' | 'cached';
  isCached: boolean;
  networkWarningHi?: string;
  networkWarningEn?: string;
}

export interface LocationSearchResult {
  id: string;
  name: string;
  displayName: string;
  district?: string;
  state?: string;
  country: string;
  latitude: number;
  longitude: number;
}

// Map WMO codes to human readable text
export function getWeatherDescription(code: number, lang: 'hi' | 'en'): string {
  if (code === 0) return lang === 'hi' ? 'साफ धूप' : 'Clear Sky';
  if (code === 1 || code === 2) return lang === 'hi' ? 'हल्के बादल' : 'Partly Cloudy';
  if (code === 3) return lang === 'hi' ? 'बादल छाए हैं' : 'Overcast';
  if (code === 45 || code === 48) return lang === 'hi' ? 'कोहरा / धुंध' : 'Foggy';
  if (code >= 51 && code <= 55) return lang === 'hi' ? 'हल्की बूंदाबांदी' : 'Drizzle';
  if (code >= 61 && code <= 65) return lang === 'hi' ? 'बारिश' : 'Rain';
  if (code >= 80 && code <= 82) return lang === 'hi' ? 'मूसलाधार बारिश' : 'Heavy Showers';
  if (code >= 95) return lang === 'hi' ? 'आंधी व गरज' : 'Thunderstorm';
  return lang === 'hi' ? 'सामान्य मौसम' : 'Normal Weather';
}

// Default coordinates centered on User's farm location:
// Badaun / Budaun district, Gaon Chitaura / Dhanaura, PIN 243631, Uttar Pradesh
export const BUDAUN_COORDINATES = {
  city: 'चितौरा / धनौरा, ज़िला बदायूं (243631)',
  lat: 28.0381,
  lon: 79.1267
};

export async function fetchLiveWeather(
  lat = BUDAUN_COORDINATES.lat,
  lon = BUDAUN_COORDINATES.lon,
  cityName = BUDAUN_COORDINATES.city
): Promise<WeatherData | null> {
  try {
    const url = \`https://api.open-meteo.com/v1/forecast?latitude=\${lat}&longitude=\${lon}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,precipitation&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max&timezone=auto\`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(\`Weather API status \${res.status}\`);
    }
    const data = await res.json();
    if (!data || !data.current || !data.daily) {
      throw new Error('Invalid weather API response structure');
    }

    const currentTemp = Math.round(Number(data.current.temperature_2m));
    const humidity = Math.round(Number(data.current.relative_humidity_2m));
    const windSpeedKmh = Math.round(Number(data.current.wind_speed_10m));
    const weatherCode = Number(data.current.weather_code) || 0;
    const isRaining = Number(data.current.precipitation) > 0 || weatherCode >= 50;

    let sprayStatus: 'safe' | 'caution' | 'rain_warning' = 'safe';
    let sprayAdvisoryHi = \`\${cityName} में मौसम साफ और शांत है। दवा छिड़काव के लिए बहुत उत्तम समय है।\`;
    let sprayAdvisoryEn = \`Weather in \${cityName} is clear with calm wind. Ideal conditions for foliar spray.\`;

    if (
      isRaining ||
      (data.daily.precipitation_probability_max && data.daily.precipitation_probability_max[0] > 60)
    ) {
      sprayStatus = 'rain_warning';
      sprayAdvisoryHi = \`अलर्ट: \${cityName} में बारिश होने की संभावना है! अभी कीटनाशक या खाद का छिड़काव न करें, दवा धुल सकती है।\`;
      sprayAdvisoryEn = \`Alert: Rain anticipated in \${cityName}! Postpone spray application as chemicals will wash away.\`;
    } else if (windSpeedKmh > 18) {
      sprayStatus = 'caution';
      sprayAdvisoryHi = \`सावधानी: हवा तेज है (>18 km/h)। स्प्रे का बहाव पास के खेतों में हो सकता है, सुबह या शाम छिड़कें।\`;
      sprayAdvisoryEn = \`Caution: High wind speeds (>18 km/h). Spray drift likely; wait for morning/evening calm.\`;
    } else if (humidity > 85) {
      sprayStatus = 'caution';
      sprayAdvisoryHi = \`नमी अधिक है (>85%)। फफूंद (Fungus/Blight) का खतरा हो सकता है, फसल की नियमित जांच करें।\`;
      sprayAdvisoryEn = \`High atmospheric humidity (>85%). Monitor crops for early signs of fungal infection or rust.\`;
    }

    const dayLabels = ['आज', 'कल', 'परसों', 'दिन 4', 'दिन 5', 'दिन 6', 'दिन 7'];
    const dailyForecast: DailyForecast[] = (data.daily.time || []).slice(0, 7).map((d: string, idx: number) => {
      const code = Number(data.daily.weather_code?.[idx]) || 0;
      const rainProb = Number(data.daily.precipitation_probability_max?.[idx] ?? 0);
      const windMax = Math.round(Number(data.daily.wind_speed_10m_max?.[idx] ?? 10));
      let condition: 'safe' | 'caution' | 'rain_warning' = 'safe';
      if (rainProb > 60 || code >= 61) condition = 'rain_warning';
      else if (windMax > 18 || rainProb > 30) condition = 'caution';

      return {
        date: d,
        dayName: dayLabels[idx] || \`दिन \${idx + 1}\`,
        maxTemp: Math.round(Number(data.daily.temperature_2m_max?.[idx] ?? currentTemp)),
        minTemp: Math.round(Number(data.daily.temperature_2m_min?.[idx] ?? currentTemp)),
        precipitationMm: Number(data.daily.precipitation_sum?.[idx] ?? 0),
        rainProbability: rainProb,
        windSpeedKmh: windMax,
        weatherCode: code,
        sprayCondition: condition
      };
    });

    const now = new Date();
    const liveData: WeatherData = {
      city: cityName,
      latitude: lat,
      longitude: lon,
      currentTemp,
      humidity,
      windSpeedKmh,
      weatherCode,
      isRaining,
      sprayStatus,
      sprayAdvisoryHi,
      sprayAdvisoryEn,
      dailyForecast,
      updatedAt: now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      fetchedAtISO: now.toISOString(),
      dataSource: 'live',
      isCached: false
    };

    Storage.saveCachedWeather(lat, lon, liveData);
    return liveData;
  } catch (err) {
    console.warn('Live weather fetch failed, checking local cache:', err);
    const cached = Storage.getCachedWeather(lat, lon);
    if (cached && typeof cached.currentTemp === 'number' && Array.isArray(cached.dailyForecast)) {
      const cachedTime = cached.fetchedAtISO
        ? new Date(cached.fetchedAtISO).toLocaleString('en-IN', {
            day: 'numeric',
            month: 'short',
            hour: '2-digit',
            minute: '2-digit'
          })
        : cached.updatedAt || 'पूर्व सहेजा गया';

      return {
        ...(cached as WeatherData),
        city: cityName || cached.city,
        dataSource: 'cached',
        isCached: true,
        networkWarningHi: \`इंटरनेट कनेक्शन उपलब्ध नहीं है। यह \${cachedTime} का सहेजा गया (Cached) मौसम डेटा है। ताज़ा मौसम के लिए इंटरनेट चालू करके रीफ्रेश करें।\`,
        networkWarningEn: \`Offline / Network unreachable. Showing cached weather data from \${cachedTime}. Connect to the internet and refresh for live weather.\`
      };
    }

    // Never fabricate weather temperatures or forecasts when offline with no cache
    return null;
  }
}

/**
 * Search locations across India by Village, District, Town, or PIN code
 */
export async function searchLocationApi(query: string): Promise<LocationSearchResult[]> {
  const trimmed = query.trim().toLowerCase();
  if (!trimmed) return [];

  const localPresets: LocationSearchResult[] = [];
  if (
    trimmed.includes('243631') ||
    trimmed.includes('chitaura') ||
    trimmed.includes('dhanaura') ||
    trimmed.includes('चितौरा') ||
    trimmed.includes('धनौरा')
  ) {
    localPresets.push({
      id: 'local-chitaura-243631',
      name: 'चितौरा / धनौरा',
      displayName: 'गांव चितौरा / धनौरा, ज़िला बदायूं (PIN: 243631)',
      district: 'बदायूं (Budaun)',
      state: 'उत्तर प्रदेश (UP)',
      country: 'India',
      latitude: 28.0381,
      longitude: 79.1267
    });
  }

  if (trimmed.includes('budaun') || trimmed.includes('badaun') || trimmed.includes('बदायूं')) {
    localPresets.push({
      id: 'local-budaun-city',
      name: 'बदायूं (Budaun)',
      displayName: 'बदायूं ज़िला मुख्यालय (Budaun District, UP)',
      district: 'Budaun',
      state: 'Uttar Pradesh',
      country: 'India',
      latitude: 28.0381,
      longitude: 79.1267
    });
  }

  try {
    const searchQuery = /^\\d{6}$/.test(trimmed)
      ? trimmed === '243631'
        ? 'Budaun'
        : trimmed
      : query;

    const res = await fetch(
      \`https://geocoding-api.open-meteo.com/v1/search?name=\${encodeURIComponent(
        searchQuery
      )}&count=8&language=en&format=json\`
    );

    if (res.ok) {
      const data = await res.json();
      if (data.results && Array.isArray(data.results)) {
        const apiResults: LocationSearchResult[] = data.results.map((r: any) => ({
          id: \`loc-\${r.id}\`,
          name: r.name,
          displayName: \`\${r.name}\${r.admin2 ? \`, \${r.admin2}\` : ''}\${
            r.admin1 ? \`, \${r.admin1}\` : ''
          }\`,
          district: r.admin2,
          state: r.admin1,
          country: r.country || 'India',
          latitude: r.latitude,
          longitude: r.longitude
        }));

        const combined = [...localPresets];
        for (const r of apiResults) {
          if (
            !combined.some(
              (c) =>
                Math.abs(c.latitude - r.latitude) < 0.05 &&
                Math.abs(c.longitude - r.longitude) < 0.05
            )
          ) {
            combined.push(r);
          }
        }
        return combined;
      }
    }
  } catch (err) {
    console.warn('Geocoding search failed:', err);
  }

  return localPresets;
}
`;export{n as default};
