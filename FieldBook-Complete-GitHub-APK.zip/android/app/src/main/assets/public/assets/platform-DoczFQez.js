const n=`import { Capacitor } from '@capacitor/core';

export interface AndroidBridgeInterface {
  printHtml?: (htmlContent: string, jobName: string) => void;
  saveFileToDownloads?: (content: string, fileName: string, mimeType: string) => boolean;
  saveBase64FileToDownloads?: (base64Data: string, fileName: string, mimeType: string) => boolean;
  shareText?: (text: string, title: string) => void;
}

declare global {
  interface Window {
    AndroidBridge?: AndroidBridgeInterface;
  }
}

/**
 * Reliably detects if the app is running inside the native Capacitor Android APK container.
 * Never returns true on web preview hosts (*.run.app, aistudio.google.com).
 */
export function isCapacitorNative(): boolean {
  try {
    if (typeof window !== 'undefined') {
      const host = window.location.hostname || '';
      if (host.includes('run.app') || host.includes('google.com')) {
        return false;
      }
      if (window.AndroidBridge) {
        return true;
      }
    }
    if (Capacitor.isNativePlatform()) {
      return true;
    }
    const platform = Capacitor.getPlatform();
    if (platform === 'android' || platform === 'ios') {
      return true;
    }
    if (typeof window !== 'undefined') {
      if (window.location.protocol === 'capacitor:' || window.location.protocol === 'file:') {
        return true;
      }
      const ua = window.navigator?.userAgent || '';
      if (
        (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') &&
        /; wv\\)|Capacitor/i.test(ua)
      ) {
        return true;
      }
    }
  } catch {
    // Ignore errors in non-browser environments
  }
  return false;
}

/**
 * Detects if FieldBook is running inside the compiled native Android APK.
 * Note: We intentionally do NOT check matchMedia('(display-mode: standalone)') because
 * Google AI Studio's mobile preview runs in standalone mode and would falsely hide the
 * GitHub ZIP & YAML download tools during preview.
 */
export function isInstalledApp(): boolean {
  return isCapacitorNative();
}
`;export{n as default};
