const e=`import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  calculateCropFinancials,
  calculateMandiPayout,
  calculateFertilizerRequirement,
  calculateSeedRequirement,
  convertLandAreaAllUnits,
  calculateDieselIrrigationCost
} from '../src/utils/calculations';
import { Storage } from '../src/utils/storage';
import {
  ReceiptStorage,
  buildSyncedReceiptAttachment,
  validateReceiptFile
} from '../src/utils/receiptStorage';
import { generateWhatsAppSummary } from '../src/utils/export';
import { CropCycle, Transaction, HarvestEntry } from '../src/types';

// Polyfill in-memory localStorage for Node verification
class MemoryStorage {
  private store = new Map<string, string>();
  get length() {
    return this.store.size;
  }
  clear() {
    this.store.clear();
  }
  getItem(key: string): string | null {
    return this.store.has(key) ? this.store.get(key)! : null;
  }
  key(index: number): string | null {
    return Array.from(this.store.keys())[index] ?? null;
  }
  removeItem(key: string): void {
    this.store.delete(key);
  }
  setItem(key: string, value: string): void {
    this.store.set(key, String(value));
  }
}

(globalThis as any).localStorage = new MemoryStorage();

async function runVerification() {
  console.log('=== FieldBook Automated Audit & Functional Verification Suite ===');

  // 1. Verify relative imports across all src/**/*.ts(x) files & confirm Growth Chart is removed
  const srcDir = path.resolve(process.cwd(), 'src');
  assert.equal(
    fs.existsSync(path.join(srcDir, 'components', 'CropGrowthProgressChart.tsx')),
    false,
    'CropGrowthProgressChart.tsx must be completely removed'
  );

  function getAllSourceFiles(dir: string): string[] {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    const files: string[] = [];
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        files.push(...getAllSourceFiles(full));
      } else if (entry.isFile() && /\\.(ts|tsx)$/.test(entry.name)) {
        files.push(full);
      }
    }
    return files;
  }

  const sourceFiles = getAllSourceFiles(srcDir);
  let checkedImports = 0;
  for (const file of sourceFiles) {
    const content = fs.readFileSync(file, 'utf8');
    assert.equal(
      content.includes('CropGrowthProgressChart'),
      false,
      \`File \${path.relative(process.cwd(), file)} must not reference CropGrowthProgressChart\`
    );
    const importRegex = /from\\s+['"](\\.[^'"]+)['"]/g;
    let match: RegExpExecArray | null;
    while ((match = importRegex.exec(content)) !== null) {
      const relPath = match[1];
      const resolvedBase = path.resolve(path.dirname(file), relPath);
      const candidates = [
        resolvedBase,
        \`\${resolvedBase}.ts\`,
        \`\${resolvedBase}.tsx\`,
        path.join(resolvedBase, 'index.ts'),
        path.join(resolvedBase, 'index.tsx')
      ];
      const exists = candidates.some((c) => fs.existsSync(c) && fs.statSync(c).isFile());
      assert.ok(
        exists,
        \`Missing relative import "\${relPath}" in \${path.relative(process.cwd(), file)}\`
      );
      checkedImports++;
    }
  }
  console.log(\`✓ [1/10] Verified \${checkedImports} relative imports across \${sourceFiles.length} TypeScript files and confirmed CropGrowthProgressChart is removed.\`);

  // 2. Test Crop Financials: Total expenses, total income, net profit/loss, profit per land-area unit, harvest quantities
  const testCrop: CropCycle = {
    id: 'crop-test-1',
    name: 'Wheat (HD-3226)',
    hindiName: 'गेहूं (HD-3226)',
    variety: 'HD-3226',
    landArea: 4,
    areaUnit: 'acre',
    season: 'rabi',
    sowingDate: '2025-11-10',
    status: 'active',
    createdAt: '2025-11-10T00:00:00Z',
    updatedAt: '2025-11-10T00:00:00Z'
  };

  const testTx: Transaction[] = [
    {
      id: 't1',
      cropId: 'crop-test-1',
      type: 'expense',
      category: 'seeds',
      title: 'Certified Wheat Seeds',
      amount: 6400,
      date: '2025-11-10',
      time: '09:00',
      paymentStatus: 'paid',
      createdAt: '2025-11-10T09:00:00Z'
    },
    {
      id: 't2',
      cropId: 'crop-test-1',
      type: 'expense',
      category: 'fertilizer',
      title: 'DAP & Urea',
      amount: 8600,
      date: '2025-11-12',
      time: '10:00',
      paymentStatus: 'paid',
      createdAt: '2025-11-12T10:00:00Z'
    },
    {
      id: 't3',
      cropId: 'crop-test-1',
      type: 'income',
      category: 'mandi_sale',
      title: 'Karnal Mandi Sale',
      amount: 95000,
      date: '2026-04-05',
      time: '15:00',
      paymentStatus: 'paid',
      createdAt: '2026-04-05T15:00:00Z'
    }
  ];

  const testHarvests: HarvestEntry[] = [
    {
      id: 'h1',
      cropId: 'crop-test-1',
      date: '2026-04-02',
      time: '14:00',
      quantityQuintal: 38.5
    },
    {
      id: 'h2',
      cropId: 'crop-test-1',
      date: '2026-04-03',
      time: '16:00',
      quantityQuintal: 41.5
    }
  ];

  const fin = calculateCropFinancials(testCrop, testTx, testHarvests);
  assert.equal(fin.totalExpenses, 15000, 'Total expenses should be 15000');
  assert.equal(fin.totalIncome, 95000, 'Total income should be 95000');
  assert.equal(fin.netProfit, 80000, 'Net profit should be 80000');
  assert.equal(fin.isProfit, true, 'Should be profitable');
  assert.equal(fin.costPerUnit, 3750, 'Cost per acre should be 3750');
  assert.equal(fin.profitPerUnit, 20000, 'Profit per acre should be 20000');
  assert.equal(fin.totalHarvestQuintal, 80, 'Total harvest should be 80 quintals');
  assert.equal(fin.yieldPerUnit, 20, 'Yield per acre should be 20 quintals');
  assert.equal(fin.costPerQuintal, 188, 'Cost per quintal should be Math.round(15000/80) = 188');

  // Edge case: zero land area & zero harvest & net loss
  const zeroAreaCrop: CropCycle = { ...testCrop, landArea: 0, areaUnit: 'bigha' };
  const lossTx: Transaction[] = [testTx[0]]; // Only 6400 expense, 0 income
  const finZero = calculateCropFinancials(zeroAreaCrop, lossTx, []);
  assert.equal(finZero.totalExpenses, 6400);
  assert.equal(finZero.totalIncome, 0);
  assert.equal(finZero.netProfit, -6400);
  assert.equal(finZero.isProfit, false);
  assert.equal(finZero.costPerUnit, 0, 'Division by zero landArea must safely return 0');
  assert.equal(finZero.profitPerUnit, 0, 'Division by zero landArea must safely return 0');
  assert.equal(finZero.costPerQuintal, 0, 'Division by zero harvest must safely return 0');
  console.log('✓ [2/10] Verified Crop Financials (total expenses, income, net P&L, per-area-unit profit, harvest yield, division-by-zero guards).');

  // 3. Test Mandi Calculator
  const mandi1 = calculateMandiPayout({
    grossWeightKg: 3500,
    tareWeightKg: 1000,
    ratePerQuintal: 2325,
    bagsCount: 50,
    palledariPerBag: 14
  });
  assert.equal(mandi1.netWeightKg, 2500);
  assert.equal(mandi1.netWeightQuintal, 25);
  assert.equal(mandi1.netWeightMann, 62.5);
  assert.equal(mandi1.grossAmount, 58125);
  assert.equal(mandi1.totalDeductions, 700);
  assert.equal(mandi1.netPayableAmount, 57425);

  const mandiEdge = calculateMandiPayout({
    grossWeightKg: 800,
    tareWeightKg: 1000,
    ratePerQuintal: 2325,
    bagsCount: 10,
    palledariPerBag: 15
  });
  assert.equal(mandiEdge.netWeightKg, 0);
  assert.equal(mandiEdge.netPayableAmount, 0);
  console.log('✓ [3/10] Verified Mandi Calculator (gross/tare/net weight, quintals, mann, palledari deductions, net payable).');

  // 4. Test Fertilizer & Seed Calculators
  const fertWheat = calculateFertilizerRequirement('wheat', 2.5, 'acre');
  assert.equal(fertWheat.ureaBags, 6.3);
  assert.equal(fertWheat.dapBags, 2.5);
  assert.equal(fertWheat.mopBags, 1.3);
  assert.equal(fertWheat.zincKg, 12.5);

  const fertBigha = calculateFertilizerRequirement('wheat', 5, 'bigha');
  assert.equal(fertBigha.areaInAcres, 2);
  assert.equal(fertBigha.ureaBags, 5);
  assert.equal(fertBigha.dapBags, 2);

  const seedWheat = calculateSeedRequirement('wheat', 3, 40, 'acre');
  assert.equal(seedWheat.totalSeedRequiredKg, 120);
  assert.equal(seedWheat.totalSeedCost, 4800);
  console.log('✓ [4/10] Verified Fertilizer & Seed Calculators across acre and bigha units.');

  // 5. Test Land-Area Unit Converter & Diesel Calculator
  const area1Acre = convertLandAreaAllUnits(1, 'acre');
  assert.equal(area1Acre.sqFt, 43560);
  assert.equal(area1Acre.kanal, 8);
  assert.equal(area1Acre.marla, 160);
  assert.equal(area1Acre.guntha, 40);
  assert.equal(area1Acre.bighaPucca, 1.6);
  assert.equal(area1Acre.bighaKaccha, 4.8);

  const diesel = calculateDieselIrrigationCost(6, 2.5, 89, 2);
  assert.equal(diesel.totalDieselLiters, 15);
  assert.equal(diesel.totalDieselCost, 1335);
  assert.equal(diesel.costPerAcre, 668);
  console.log('✓ [5/10] Verified Land-Area Unit Converter and Diesel Irrigation Cost Calculator.');

  // 6. Test Record Creation, Editing, Deletion & Local Persistence
  const initialCrops = Storage.getCrops();
  assert.ok(initialCrops.length >= 2, 'Should initialize with seed crops');

  const addedCrop: CropCycle = {
    ...testCrop,
    id: 'crop-custom-99',
    name: 'Basmati Paddy'
  };
  Storage.saveCrops([addedCrop, ...initialCrops]);
  assert.equal(Storage.getCrops()[0].id, 'crop-custom-99');

  const editedCrops = Storage.getCrops().map((c) =>
    c.id === 'crop-custom-99' ? { ...c, landArea: 6.5 } : c
  );
  Storage.saveCrops(editedCrops);
  assert.equal(Storage.getCrops().find((c) => c.id === 'crop-custom-99')?.landArea, 6.5);

  Storage.saveCrops(Storage.getCrops().filter((c) => c.id !== 'crop-custom-99'));
  assert.equal(Storage.getCrops().some((c) => c.id === 'crop-custom-99'), false);
  console.log('✓ [6/10] Verified creating, editing, and deleting records in Storage.');

  // 7. Test JSON Backup Export, Valid Restore, and Invalid Backup Rejection
  const backupJson = Storage.exportFullBackup();
  assert.ok(backupJson.includes('FieldBook'), 'Exported JSON should include FieldBook branding');

  const cropsBeforeInvalid = Storage.getCrops().length;
  const badResult1 = Storage.importFullBackupWithDetails('{not valid json');
  assert.equal(badResult1.success, false, 'Malformed JSON must be rejected');
  assert.ok(badResult1.errorEn, 'Malformed JSON must return an understandable error message');
  assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Malformed JSON must not corrupt existing data');

  const badResult2 = Storage.importFullBackupWithDetails(JSON.stringify({ randomKey: 123 }));
  assert.equal(badResult2.success, false, 'Unrelated JSON object must be rejected');
  assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Unrelated JSON must not corrupt existing data');

  const badResult3 = Storage.importFullBackupWithDetails(
    JSON.stringify({ crops: [{ invalidCropWithoutIdOrName: true }], transactions: [] })
  );
  assert.equal(badResult3.success, false, 'JSON with invalid crop schema must be rejected');
  assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Invalid crop schema must not corrupt existing data');

  Storage.clearAllData();
  assert.equal(Storage.getCrops().length, 0, 'Crops should be empty after clearAllData');
  const goodResult = Storage.importFullBackupWithDetails(backupJson);
  assert.equal(goodResult.success, true, 'Valid backup should restore cleanly');
  assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Restored crop count should match backup');
  console.log('✓ [7/10] Verified JSON Backup Export/Restore and confirmed invalid backup files produce clear errors without corrupting data.');

  // 8. Test WhatsApp Summary Generation
  const waText = decodeURIComponent(generateWhatsAppSummary(testCrop, testTx, testHarvests, 'hi'));
  assert.ok(waText.includes('FieldBook'), 'WhatsApp summary should include FieldBook header');
  assert.ok(waText.includes('80 क्विंटल'), 'WhatsApp summary should include total harvest');
  console.log('✓ [8/10] Verified Report Summary & Export formatting.');

  // 9. Verify Malformed localStorage Recovery
  (globalThis as any).localStorage.setItem('fieldbook_crops_v1', '<<<corrupted_json>>>');
  const recoveredCrops = Storage.getCrops();
  assert.ok(Array.isArray(recoveredCrops) && recoveredCrops.length > 0, 'Storage must safely recover from corrupted localStorage entries');
  console.log('✓ [9/10] Verified automatic recovery from corrupted localStorage entries.');

  // 10. Test Expense & Income Bill/Receipt Attachments, Transaction Linking, Edits, Validation & Backup Restore
  const invalidCheck = validateReceiptFile({ name: 'malware.exe', type: 'application/x-msdownload', size: 1024 });
  assert.equal(invalidCheck.valid, false, 'Invalid file type must be rejected');
  const oversizedCheck = validateReceiptFile({ name: 'huge.pdf', type: 'application/pdf', size: 25 * 1024 * 1024 });
  assert.equal(oversizedCheck.valid, false, 'Oversized PDF must be rejected');
  const validImgCheck = validateReceiptFile({ name: 'dap_bill.jpg', type: 'image/jpeg', size: 145000 });
  assert.equal(validImgCheck.valid, true);
  assert.equal(validImgCheck.kind, 'image');
  const validPdfCheck = validateReceiptFile({ name: 'mandi_slip.pdf', type: 'application/pdf', size: 210000 });
  assert.equal(validPdfCheck.valid, true);
  assert.equal(validPdfCheck.kind, 'pdf');

  // Attach image bill to an Expense transaction
  const expenseWithBill: Transaction = {
    id: 'tx-exp-bill-1',
    cropId: 'crop-wheat-2024',
    type: 'expense',
    category: 'fertilizer',
    title: 'IFFCO DAP 3 Bags',
    amount: 4050,
    date: '2025-11-15',
    time: '11:20',
    notes: 'Cash memo #402',
    paymentStatus: 'paid',
    createdAt: '2025-11-15T11:20:00Z'
  };
  const expAttachment = buildSyncedReceiptAttachment(expenseWithBill, {
    fileName: 'iffco_dap_bill.jpg',
    mimeType: 'image/jpeg',
    fileSize: 82000
  });
  expenseWithBill.receiptAttachment = expAttachment;
  const sampleImageDataUrl = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
  const savedExpBill = await ReceiptStorage.saveReceipt(expAttachment, sampleImageDataUrl);
  assert.equal(savedExpBill, true, 'Expense receipt attachment should save cleanly');

  // Attach PDF receipt to an Income transaction
  const incomeWithBill: Transaction = {
    id: 'tx-inc-bill-2',
    cropId: 'crop-mustard-2024',
    type: 'income',
    category: 'mandi_sale',
    title: 'Mandi Sale 15 Quintal',
    amount: 84750,
    date: '2025-03-10',
    time: '14:45',
    notes: 'Slip #MND-901',
    paymentStatus: 'paid',
    createdAt: '2025-03-10T14:45:00Z'
  };
  const incAttachment = buildSyncedReceiptAttachment(incomeWithBill, {
    fileName: 'mandi_slip_901.pdf',
    mimeType: 'application/pdf',
    fileSize: 124000
  });
  incomeWithBill.receiptAttachment = incAttachment;
  const samplePdfDataUrl = 'data:application/pdf;base64,JVBERi0xLjQK';
  const savedIncBill = await ReceiptStorage.saveReceipt(incAttachment, samplePdfDataUrl);
  assert.equal(savedIncBill, true, 'Income receipt attachment should save cleanly');

  // Verify reopening both attachments and checking linked metadata
  const reopenedExp = await ReceiptStorage.getReceipt(expAttachment.storageRef);
  assert.ok(reopenedExp, 'Expense receipt should be retrievable');
  assert.equal(reopenedExp.transactionId, 'tx-exp-bill-1');
  assert.equal(reopenedExp.transactionType, 'expense');
  assert.equal(reopenedExp.cropId, 'crop-wheat-2024');
  assert.equal(reopenedExp.amount, 4050);
  assert.equal(reopenedExp.date, '2025-11-15');
  assert.equal(reopenedExp.dataUrl, sampleImageDataUrl);

  const reopenedInc = await ReceiptStorage.getReceipt(incAttachment.storageRef);
  assert.ok(reopenedInc, 'Income receipt should be retrievable');
  assert.equal(reopenedInc.transactionId, 'tx-inc-bill-2');
  assert.equal(reopenedInc.transactionType, 'income');
  assert.equal(reopenedInc.cropId, 'crop-mustard-2024');
  assert.equal(reopenedInc.amount, 84750);
  assert.equal(reopenedInc.date, '2025-03-10');
  assert.equal(reopenedInc.dataUrl, samplePdfDataUrl);

  // Edit the expense transaction (change amount, date, title, notes) and verify receipt stays linked & synced
  const editedExpense: Transaction = {
    ...expenseWithBill,
    title: 'IFFCO DAP 4 Bags (Updated)',
    amount: 5400,
    date: '2025-11-16',
    notes: 'Cash memo #402 - updated to 4 bags'
  };
  const syncedTxAfterEdit = await ReceiptStorage.syncStoredReceiptMetadata(editedExpense);
  assert.equal(syncedTxAfterEdit.receiptAttachment?.amount, 5400, 'Receipt amount must sync with edited transaction');
  assert.equal(syncedTxAfterEdit.receiptAttachment?.date, '2025-11-16', 'Receipt date must sync with edited transaction');
  assert.equal(syncedTxAfterEdit.receiptAttachment?.title, 'IFFCO DAP 4 Bags (Updated)');
  assert.equal(syncedTxAfterEdit.notes, 'Cash memo #402 - updated to 4 bags', 'Notes field must remain intact');

  const reopenedAfterEdit = await ReceiptStorage.getReceipt(expAttachment.storageRef);
  assert.equal(reopenedAfterEdit?.amount, 5400, 'Stored receipt payload amount must reflect edited transaction');
  assert.equal(reopenedAfterEdit?.date, '2025-11-16', 'Stored receipt payload date must reflect edited transaction');

  // Verify full backup export/restore preserves receipts
  Storage.saveTransactions([syncedTxAfterEdit, incomeWithBill, ...Storage.getTransactions()]);
  const fullBackupWithReceipts = Storage.exportFullBackup();
  await ReceiptStorage.clearAllReceipts();
  assert.equal(await ReceiptStorage.getReceipt(expAttachment.storageRef), null);

  const restoreRes = Storage.importFullBackupWithDetails(fullBackupWithReceipts);
  assert.equal(restoreRes.success, true);
  const restoredExpReceipt = await ReceiptStorage.getReceipt(expAttachment.storageRef);
  assert.ok(restoredExpReceipt, 'Receipt must be restored from backup');
  assert.equal(restoredExpReceipt.amount, 5400);
  assert.equal(restoredExpReceipt.dataUrl, sampleImageDataUrl);

  console.log('✓ [10/10] Verified Expense & Income Bill/Receipt Attachments, transaction linking, edits sync, validation, and backup persistence.');
  console.log('=== ALL 10 AUTOMATED VERIFICATION SUITES PASSED ===');
}

runVerification().catch((err) => {
  console.error(err);
  process.exit(1);
});

`;export{e as default};
