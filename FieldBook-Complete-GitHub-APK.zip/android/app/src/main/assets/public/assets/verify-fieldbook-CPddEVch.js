const e=`import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  calculateCropFinancials,
  calculateMandiPayout,
  calculateFertilizerRequirement,
  calculateSeedRequirement,
  convertLandAreaAllUnits,
  calculateDieselIrrigationCost
} from '../src/utils/calculations';
import { Storage } from '../src/utils/storage';
import { generateWhatsAppSummary } from '../src/utils/export';
import { CropCycle, Transaction, HarvestEntry } from '../src/types';

// Polyfill in-memory localStorage for Node verification
class MemoryStorage {
  private store = new Map<string, string>();
  get length() {
    return this.store.size;
  }
  clear() {
    this.store.clear();
  }
  getItem(key: string): string | null {
    return this.store.has(key) ? this.store.get(key)! : null;
  }
  key(index: number): string | null {
    return Array.from(this.store.keys())[index] ?? null;
  }
  removeItem(key: string): void {
    this.store.delete(key);
  }
  setItem(key: string, value: string): void {
    this.store.set(key, String(value));
  }
}

(globalThis as any).localStorage = new MemoryStorage();

console.log('=== FieldBook Automated Audit & Functional Verification Suite ===');

// 1. Verify relative imports across all src/**/*.ts(x) files
const srcDir = path.resolve(process.cwd(), 'src');
function getAllSourceFiles(dir: string): string[] {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files: string[] = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...getAllSourceFiles(full));
    } else if (entry.isFile() && /\\.(ts|tsx)$/.test(entry.name)) {
      files.push(full);
    }
  }
  return files;
}

const sourceFiles = getAllSourceFiles(srcDir);
let checkedImports = 0;
for (const file of sourceFiles) {
  const content = fs.readFileSync(file, 'utf8');
  const importRegex = /from\\s+['"](\\.[^'"]+)['"]/g;
  let match: RegExpExecArray | null;
  while ((match = importRegex.exec(content)) !== null) {
    const relPath = match[1];
    const resolvedBase = path.resolve(path.dirname(file), relPath);
    const candidates = [
      resolvedBase,
      \`\${resolvedBase}.ts\`,
      \`\${resolvedBase}.tsx\`,
      path.join(resolvedBase, 'index.ts'),
      path.join(resolvedBase, 'index.tsx')
    ];
    const exists = candidates.some((c) => fs.existsSync(c) && fs.statSync(c).isFile());
    assert.ok(
      exists,
      \`Missing relative import "\${relPath}" in \${path.relative(process.cwd(), file)}\`
    );
    checkedImports++;
  }
}
console.log(\`✓ [1/9] Verified \${checkedImports} relative imports across \${sourceFiles.length} TypeScript files (including src/utils/zipExporter.ts).\`);

// 2. Test Crop Financials: Total expenses, total income, net profit/loss, profit per land-area unit, harvest quantities
const testCrop: CropCycle = {
  id: 'crop-test-1',
  name: 'Wheat (HD-3226)',
  hindiName: 'गेहूं (HD-3226)',
  variety: 'HD-3226',
  landArea: 4,
  areaUnit: 'acre',
  season: 'rabi',
  sowingDate: '2025-11-10',
  status: 'active',
  createdAt: '2025-11-10T00:00:00Z',
  updatedAt: '2025-11-10T00:00:00Z'
};

const testTx: Transaction[] = [
  {
    id: 't1',
    cropId: 'crop-test-1',
    type: 'expense',
    category: 'seeds',
    title: 'Certified Wheat Seeds',
    amount: 6400,
    date: '2025-11-10',
    time: '09:00',
    paymentStatus: 'paid',
    createdAt: '2025-11-10T09:00:00Z'
  },
  {
    id: 't2',
    cropId: 'crop-test-1',
    type: 'expense',
    category: 'fertilizer',
    title: 'DAP & Urea',
    amount: 8600,
    date: '2025-11-12',
    time: '10:00',
    paymentStatus: 'paid',
    createdAt: '2025-11-12T10:00:00Z'
  },
  {
    id: 't3',
    cropId: 'crop-test-1',
    type: 'income',
    category: 'mandi_sale',
    title: 'Karnal Mandi Sale',
    amount: 95000,
    date: '2026-04-05',
    time: '15:00',
    paymentStatus: 'paid',
    createdAt: '2026-04-05T15:00:00Z'
  }
];

const testHarvests: HarvestEntry[] = [
  {
    id: 'h1',
    cropId: 'crop-test-1',
    date: '2026-04-02',
    time: '14:00',
    quantityQuintal: 38.5
  },
  {
    id: 'h2',
    cropId: 'crop-test-1',
    date: '2026-04-03',
    time: '16:00',
    quantityQuintal: 41.5
  }
];

const fin = calculateCropFinancials(testCrop, testTx, testHarvests);
assert.equal(fin.totalExpenses, 15000, 'Total expenses should be 15000');
assert.equal(fin.totalIncome, 95000, 'Total income should be 95000');
assert.equal(fin.netProfit, 80000, 'Net profit should be 80000');
assert.equal(fin.isProfit, true, 'Should be profitable');
assert.equal(fin.costPerUnit, 3750, 'Cost per acre should be 3750');
assert.equal(fin.profitPerUnit, 20000, 'Profit per acre should be 20000');
assert.equal(fin.totalHarvestQuintal, 80, 'Total harvest should be 80 quintals');
assert.equal(fin.yieldPerUnit, 20, 'Yield per acre should be 20 quintals');
assert.equal(fin.costPerQuintal, 188, 'Cost per quintal should be Math.round(15000/80) = 188');

// Edge case: zero land area & zero harvest & net loss
const zeroAreaCrop: CropCycle = { ...testCrop, landArea: 0, areaUnit: 'bigha' };
const lossTx: Transaction[] = [testTx[0]]; // Only 6400 expense, 0 income
const finZero = calculateCropFinancials(zeroAreaCrop, lossTx, []);
assert.equal(finZero.totalExpenses, 6400);
assert.equal(finZero.totalIncome, 0);
assert.equal(finZero.netProfit, -6400);
assert.equal(finZero.isProfit, false);
assert.equal(finZero.costPerUnit, 0, 'Division by zero landArea must safely return 0');
assert.equal(finZero.profitPerUnit, 0, 'Division by zero landArea must safely return 0');
assert.equal(finZero.costPerQuintal, 0, 'Division by zero harvest must safely return 0');
console.log('✓ [2/9] Verified Crop Financials (total expenses, income, net P&L, per-area-unit profit, harvest yield, division-by-zero guards).');

// 3. Test Mandi Calculator
const mandi1 = calculateMandiPayout({
  grossWeightKg: 3500,
  tareWeightKg: 1000,
  ratePerQuintal: 2325,
  bagsCount: 50,
  palledariPerBag: 14
});
assert.equal(mandi1.netWeightKg, 2500);
assert.equal(mandi1.netWeightQuintal, 25);
assert.equal(mandi1.netWeightMann, 62.5);
assert.equal(mandi1.grossAmount, 58125);
assert.equal(mandi1.totalDeductions, 700);
assert.equal(mandi1.netPayableAmount, 57425);

// Edge case: tare > gross
const mandiEdge = calculateMandiPayout({
  grossWeightKg: 800,
  tareWeightKg: 1000,
  ratePerQuintal: 2325,
  bagsCount: 10,
  palledariPerBag: 15
});
assert.equal(mandiEdge.netWeightKg, 0);
assert.equal(mandiEdge.netPayableAmount, 0);
console.log('✓ [3/9] Verified Mandi Calculator (gross/tare/net weight, quintals, mann, palledari deductions, net payable).');

// 4. Test Fertilizer & Seed Calculators
const fertWheat = calculateFertilizerRequirement('wheat', 2.5, 'acre');
assert.equal(fertWheat.ureaBags, 6.3);
assert.equal(fertWheat.dapBags, 2.5);
assert.equal(fertWheat.mopBags, 1.3);
assert.equal(fertWheat.zincKg, 12.5);

const fertBigha = calculateFertilizerRequirement('wheat', 5, 'bigha'); // 5 bigha / 2.5 = 2 acres
assert.equal(fertBigha.areaInAcres, 2);
assert.equal(fertBigha.ureaBags, 5);
assert.equal(fertBigha.dapBags, 2);

const seedWheat = calculateSeedRequirement('wheat', 3, 40, 'acre');
assert.equal(seedWheat.totalSeedRequiredKg, 120);
assert.equal(seedWheat.totalSeedCost, 4800);
console.log('✓ [4/9] Verified Fertilizer & Seed Calculators across acre and bigha units.');

// 5. Test Land-Area Unit Converter & Diesel Calculator
const area1Acre = convertLandAreaAllUnits(1, 'acre');
assert.equal(area1Acre.sqFt, 43560);
assert.equal(area1Acre.kanal, 8);
assert.equal(area1Acre.marla, 160);
assert.equal(area1Acre.guntha, 40);
assert.equal(area1Acre.bighaPucca, 1.6);
assert.equal(area1Acre.bighaKaccha, 4.8);

const diesel = calculateDieselIrrigationCost(6, 2.5, 89, 2);
assert.equal(diesel.totalDieselLiters, 15);
assert.equal(diesel.totalDieselCost, 1335);
assert.equal(diesel.costPerAcre, 668);
console.log('✓ [5/9] Verified Land-Area Unit Converter and Diesel Irrigation Cost Calculator.');

// 6. Test Record Creation, Editing, Deletion & Local Persistence
const initialCrops = Storage.getCrops();
assert.ok(initialCrops.length >= 2, 'Should initialize with seed crops');

// Create new crop
const addedCrop: CropCycle = {
  ...testCrop,
  id: 'crop-custom-99',
  name: 'Basmati Paddy'
};
Storage.saveCrops([addedCrop, ...initialCrops]);
assert.equal(Storage.getCrops()[0].id, 'crop-custom-99');

// Edit crop
const editedCrops = Storage.getCrops().map((c) =>
  c.id === 'crop-custom-99' ? { ...c, landArea: 6.5 } : c
);
Storage.saveCrops(editedCrops);
assert.equal(Storage.getCrops().find((c) => c.id === 'crop-custom-99')?.landArea, 6.5);

// Delete crop
Storage.saveCrops(Storage.getCrops().filter((c) => c.id !== 'crop-custom-99'));
assert.equal(Storage.getCrops().some((c) => c.id === 'crop-custom-99'), false);
console.log('✓ [6/9] Verified creating, editing, and deleting records in Storage.');

// 7. Test JSON Backup Export, Valid Restore, and Invalid Backup Rejection
const backupJson = Storage.exportFullBackup();
assert.ok(backupJson.includes('FieldBook'), 'Exported JSON should include FieldBook branding');

// Attempt invalid JSON restore -> must fail cleanly and NOT corrupt existing data
const cropsBeforeInvalid = Storage.getCrops().length;
const badResult1 = Storage.importFullBackupWithDetails('{not valid json');
assert.equal(badResult1.success, false, 'Malformed JSON must be rejected');
assert.ok(badResult1.errorEn, 'Malformed JSON must return an understandable error message');
assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Malformed JSON must not corrupt existing data');

const badResult2 = Storage.importFullBackupWithDetails(JSON.stringify({ randomKey: 123 }));
assert.equal(badResult2.success, false, 'Unrelated JSON object must be rejected');
assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Unrelated JSON must not corrupt existing data');

const badResult3 = Storage.importFullBackupWithDetails(
  JSON.stringify({ crops: [{ invalidCropWithoutIdOrName: true }], transactions: [] })
);
assert.equal(badResult3.success, false, 'JSON with invalid crop schema must be rejected');
assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Invalid crop schema must not corrupt existing data');

// Clear data and restore valid backup
Storage.clearAllData();
assert.equal(Storage.getCrops().length, 0, 'Crops should be empty after clearAllData');
const goodResult = Storage.importFullBackupWithDetails(backupJson);
assert.equal(goodResult.success, true, 'Valid backup should restore cleanly');
assert.equal(Storage.getCrops().length, cropsBeforeInvalid, 'Restored crop count should match backup');
console.log('✓ [7/9] Verified JSON Backup Export/Restore and confirmed invalid backup files produce clear errors without corrupting data.');

// 8. Test WhatsApp Summary Generation
const waText = decodeURIComponent(generateWhatsAppSummary(testCrop, testTx, testHarvests, 'hi'));
assert.ok(waText.includes('FieldBook'), 'WhatsApp summary should include FieldBook header');
assert.ok(waText.includes('80 क्विंटल'), 'WhatsApp summary should include total harvest');
console.log('✓ [8/9] Verified Report Summary & Export formatting.');

// 9. Verify Malformed localStorage Recovery
(globalThis as any).localStorage.setItem('fieldbook_crops_v1', '<<<corrupted_json>>>');
const recoveredCrops = Storage.getCrops();
assert.ok(Array.isArray(recoveredCrops) && recoveredCrops.length > 0, 'Storage must safely recover from corrupted localStorage entries');
console.log('✓ [9/9] Verified automatic recovery from corrupted localStorage entries.');
console.log('=== ALL 9 AUTOMATED VERIFICATION SUITES PASSED ===');
`;export{e as default};
