const e=`import { ReceiptAttachment, Transaction } from '../types';

const DB_NAME = 'fieldbook_receipts_idb_v1';
const DB_VERSION = 1;
const STORE_NAME = 'receipt_files';

export const MAX_IMAGE_RAW_BYTES = 15 * 1024 * 1024; // 15 MB raw camera photo limit before compression
export const MAX_PDF_BYTES = 10 * 1024 * 1024; // 10 MB PDF limit

export interface StoredReceiptPayload {
  storageRef: string;
  transactionId: string;
  cropId: string;
  transactionType: 'expense' | 'income';
  category: string;
  title: string;
  date: string;
  amount: number;
  fileName: string;
  mimeType: string;
  fileSize: number;
  dataUrl: string;
  updatedAt: string;
}

export interface FileProcessResult {
  success: boolean;
  dataUrl?: string;
  mimeType?: string;
  fileName?: string;
  fileSize?: number;
  errorHi?: string;
  errorEn?: string;
}

// In-memory mirror for fast access, backup export, and Node.js test environments
const memoryReceiptMap = new Map<string, StoredReceiptPayload>();

function isIndexedDBAvailable(): boolean {
  return typeof indexedDB !== 'undefined' && indexedDB !== null;
}

function openReceiptDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!isIndexedDBAvailable()) {
      reject(new Error('IndexedDB not available in this environment'));
      return;
    }
    try {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'storageRef' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('Failed to open IndexedDB'));
    } catch (err) {
      reject(err);
    }
  });
}

export function validateReceiptFile(file: {
  name: string;
  type: string;
  size: number;
}): { valid: boolean; kind: 'image' | 'pdf' | 'invalid'; errorHi?: string; errorEn?: string } {
  if (!file || !file.name) {
    return {
      valid: false,
      kind: 'invalid',
      errorHi: 'कोई फाइल नहीं चुनी गई।',
      errorEn: 'No file selected.'
    };
  }

  const lowerName = file.name.toLowerCase();
  const mime = (file.type || '').toLowerCase();

  const isPdf = mime === 'application/pdf' || lowerName.endsWith('.pdf');
  const isImage =
    mime.startsWith('image/') ||
    /\\.(jpg|jpeg|png|webp|gif|bmp|heic|heif)$/i.test(lowerName);

  if (!isPdf && !isImage) {
    return {
      valid: false,
      kind: 'invalid',
      errorHi: 'अमान्य फाइल! कृपया केवल बिल का फोटो (JPG, PNG, WEBP) या PDF फाइल चुनें।',
      errorEn: 'Invalid file type! Please select an image (JPG, PNG, WEBP) or a PDF bill.'
    };
  }

  if (file.size <= 0) {
    return {
      valid: false,
      kind: 'invalid',
      errorHi: 'चुनी गई फाइल खाली (0 KB) है। कृपया सही बिल फाइल चुनें।',
      errorEn: 'The selected file is empty (0 KB). Please select a valid receipt file.'
    };
  }

  if (isPdf && file.size > MAX_PDF_BYTES) {
    return {
      valid: false,
      kind: 'invalid',
      errorHi: 'PDF फाइल बहुत बड़ी है (अधिकतम 10 MB अनुमत है)। कृपया छोटी PDF या बिल का फोटो चुनें।',
      errorEn: 'PDF file is too large (max 10 MB allowed). Please select a smaller PDF or photo.'
    };
  }

  if (isImage && file.size > MAX_IMAGE_RAW_BYTES) {
    return {
      valid: false,
      kind: 'invalid',
      errorHi: 'फोटो बहुत बड़ा है (अधिकतम 15 MB अनुमत है)। कृपया दूसरा फोटो चुनें।',
      errorEn: 'Image file is too large (max 15 MB allowed). Please select a smaller image.'
    };
  }

  return {
    valid: true,
    kind: isPdf ? 'pdf' : 'image'
  };
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to read file data'));
      }
    };
    reader.onerror = () => reject(reader.error || new Error('File read error'));
    reader.readAsDataURL(file);
  });
}

function compressImageDataUrl(rawDataUrl: string, originalMime: string): Promise<string> {
  return new Promise((resolve) => {
    if (typeof Image === 'undefined' || typeof document === 'undefined') {
      resolve(rawDataUrl);
      return;
    }
    const img = new Image();
    img.onload = () => {
      try {
        const maxDim = 1600;
        let width = img.naturalWidth || img.width;
        let height = img.naturalHeight || img.height;

        if (!width || !height) {
          resolve(rawDataUrl);
          return;
        }

        if (width > maxDim || height > maxDim) {
          if (width >= height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(rawDataUrl);
          return;
        }
        // Fill white background for transparent PNGs converted to JPEG
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const outputMime = originalMime === 'image/png' ? 'image/jpeg' : 'image/jpeg';
        const compressed = canvas.toDataURL(outputMime, 0.82);
        // Keep whichever is smaller
        resolve(compressed.length < rawDataUrl.length ? compressed : rawDataUrl);
      } catch {
        resolve(rawDataUrl);
      }
    };
    img.onerror = () => resolve(rawDataUrl);
    img.src = rawDataUrl;
  });
}

export async function processSelectedReceiptFile(file: File): Promise<FileProcessResult> {
  const check = validateReceiptFile(file);
  if (!check.valid) {
    return {
      success: false,
      errorHi: check.errorHi,
      errorEn: check.errorEn
    };
  }

  try {
    const rawDataUrl = await readFileAsDataUrl(file);
    if (check.kind === 'image') {
      const optimizedDataUrl = await compressImageDataUrl(rawDataUrl, file.type || 'image/jpeg');
      const approxBytes = Math.round((optimizedDataUrl.length * 3) / 4);
      const resolvedMime = optimizedDataUrl.startsWith('data:image/jpeg')
        ? 'image/jpeg'
        : file.type || 'image/jpeg';
      return {
        success: true,
        dataUrl: optimizedDataUrl,
        mimeType: resolvedMime,
        fileName: file.name,
        fileSize: approxBytes
      };
    }

    return {
      success: true,
      dataUrl: rawDataUrl,
      mimeType: 'application/pdf',
      fileName: file.name,
      fileSize: file.size
    };
  } catch (err) {
    console.error('Failed to process receipt file:', err);
    return {
      success: false,
      errorHi: 'फाइल पढ़ने में त्रुटि हुई। कृपया दोबारा प्रयास करें।',
      errorEn: 'Failed to read the selected file. Please try again.'
    };
  }
}

export function buildSyncedReceiptAttachment(
  tx: {
    id: string;
    cropId: string;
    type: 'expense' | 'income';
    category: any;
    title: string;
    amount: number;
    date: string;
  },
  fileMeta: {
    id?: string;
    storageRef?: string;
    fileName: string;
    mimeType: string;
    fileSize: number;
    createdAt?: string;
  }
): ReceiptAttachment {
  const nowIso = new Date().toISOString();
  const storageRef = fileMeta.storageRef || \`rcpt-\${tx.id}\`;
  return {
    id: fileMeta.id || storageRef,
    transactionId: tx.id,
    transactionType: tx.type,
    cropId: tx.cropId,
    category: tx.category,
    title: tx.title,
    date: tx.date,
    amount: Math.round(Number(tx.amount) || 0),
    fileName: fileMeta.fileName,
    mimeType: fileMeta.mimeType,
    fileSize: fileMeta.fileSize,
    storageRef,
    createdAt: fileMeta.createdAt || nowIso,
    updatedAt: nowIso
  };
}

export const ReceiptStorage = {
  /**
   * Hydrate in-memory cache from IndexedDB on app start
   */
  async hydrateCache(): Promise<void> {
    if (!isIndexedDBAvailable()) return;
    try {
      const db = await openReceiptDB();
      await new Promise<void>((resolve) => {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const req = store.getAll();
        req.onsuccess = () => {
          const items = Array.isArray(req.result) ? (req.result as StoredReceiptPayload[]) : [];
          for (const item of items) {
            if (item && item.storageRef && item.dataUrl) {
              memoryReceiptMap.set(item.storageRef, item);
            }
          }
          resolve();
        };
        req.onerror = () => resolve();
      });
      db.close();
    } catch {
      // Ignore if IndexedDB is blocked
    }
  },

  /**
   * Save receipt binary/dataURL payload linked to its exact transaction
   */
  async saveReceipt(
    attachment: ReceiptAttachment,
    dataUrl: string
  ): Promise<boolean> {
    if (!attachment || !attachment.storageRef || !dataUrl) {
      return false;
    }

    const payload: StoredReceiptPayload = {
      storageRef: attachment.storageRef,
      transactionId: attachment.transactionId,
      cropId: attachment.cropId,
      transactionType: attachment.transactionType,
      category: attachment.category,
      title: attachment.title,
      date: attachment.date,
      amount: attachment.amount,
      fileName: attachment.fileName,
      mimeType: attachment.mimeType,
      fileSize: attachment.fileSize,
      dataUrl,
      updatedAt: new Date().toISOString()
    };

    memoryReceiptMap.set(attachment.storageRef, payload);

    if (!isIndexedDBAvailable()) {
      return true;
    }

    try {
      const db = await openReceiptDB();
      const ok = await new Promise<boolean>((resolve) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const req = store.put(payload);
        req.onsuccess = () => resolve(true);
        req.onerror = () => resolve(false);
      });
      db.close();
      return ok;
    } catch (err) {
      console.error('IndexedDB saveReceipt error:', err);
      return false;
    }
  },

  /**
   * Synchronize stored receipt metadata whenever a transaction's date, amount, title, or category is edited
   */
  async syncStoredReceiptMetadata(tx: Transaction): Promise<Transaction> {
    if (!tx.receiptAttachment) return tx;

    const syncedMeta = buildSyncedReceiptAttachment(tx, {
      id: tx.receiptAttachment.id,
      storageRef: tx.receiptAttachment.storageRef,
      fileName: tx.receiptAttachment.fileName,
      mimeType: tx.receiptAttachment.mimeType,
      fileSize: tx.receiptAttachment.fileSize,
      createdAt: tx.receiptAttachment.createdAt
    });

    const updatedTx: Transaction = {
      ...tx,
      receiptAttachment: syncedMeta
    };

    const existing = await this.getReceipt(syncedMeta.storageRef);
    if (existing && existing.dataUrl) {
      await this.saveReceipt(syncedMeta, existing.dataUrl);
    }

    return updatedTx;
  },

  /**
   * Retrieve a stored receipt payload by storageRef (checks memory cache first, then IndexedDB)
   */
  async getReceipt(storageRef: string): Promise<StoredReceiptPayload | null> {
    if (!storageRef) return null;
    if (memoryReceiptMap.has(storageRef)) {
      return memoryReceiptMap.get(storageRef)!;
    }
    if (!isIndexedDBAvailable()) {
      return null;
    }
    try {
      const db = await openReceiptDB();
      const result = await new Promise<StoredReceiptPayload | null>((resolve) => {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const req = store.get(storageRef);
        req.onsuccess = () => {
          const item = (req.result as StoredReceiptPayload) || null;
          if (item && item.dataUrl) {
            memoryReceiptMap.set(storageRef, item);
          }
          resolve(item);
        };
        req.onerror = () => resolve(null);
      });
      db.close();
      return result;
    } catch {
      return null;
    }
  },

  /**
   * Synchronous read from hydrated cache (used by backup exporter and tests)
   */
  getReceiptSync(storageRef: string): StoredReceiptPayload | null {
    return memoryReceiptMap.get(storageRef) || null;
  },

  /**
   * Delete a receipt by storageRef
   */
  async deleteReceipt(storageRef: string): Promise<void> {
    if (!storageRef) return;
    memoryReceiptMap.delete(storageRef);
    if (!isIndexedDBAvailable()) return;
    try {
      const db = await openReceiptDB();
      await new Promise<void>((resolve) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const req = store.delete(storageRef);
        req.onsuccess = () => resolve();
        req.onerror = () => resolve();
      });
      db.close();
    } catch {
      // ignore
    }
  },

  /**
   * Delete all receipts belonging to a specific cropId
   */
  async deleteReceiptsByCropId(cropId: string): Promise<void> {
    for (const [key, val] of Array.from(memoryReceiptMap.entries())) {
      if (val.cropId === cropId) {
        await this.deleteReceipt(key);
      }
    }
  },

  /**
   * Clear all stored receipts
   */
  async clearAllReceipts(): Promise<void> {
    memoryReceiptMap.clear();
    if (!isIndexedDBAvailable()) return;
    try {
      const db = await openReceiptDB();
      await new Promise<void>((resolve) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const req = store.clear();
        req.onsuccess = () => resolve();
        req.onerror = () => resolve();
      });
      db.close();
    } catch {
      // ignore
    }
  },

  /**
   * Export all cached receipt blobs for full JSON backup
   */
  exportAllReceiptsMap(): Record<string, StoredReceiptPayload> {
    const out: Record<string, StoredReceiptPayload> = {};
    for (const [key, val] of memoryReceiptMap.entries()) {
      out[key] = val;
    }
    return out;
  },

  /**
   * Import receipt blobs from backup JSON without breaking older backups
   */
  importReceiptsMap(receiptsMap?: Record<string, StoredReceiptPayload>): void {
    if (!receiptsMap || typeof receiptsMap !== 'object') return;
    for (const [storageRef, payload] of Object.entries(receiptsMap)) {
      if (payload && typeof payload === 'object' && typeof payload.dataUrl === 'string') {
        memoryReceiptMap.set(storageRef, payload);
        if (isIndexedDBAvailable()) {
          openReceiptDB()
            .then((db) => {
              const tx = db.transaction(STORE_NAME, 'readwrite');
              tx.objectStore(STORE_NAME).put({ ...payload, storageRef });
              tx.oncomplete = () => db.close();
            })
            .catch(() => {});
        }
      }
    }
  }
};
`;export{e as default};
