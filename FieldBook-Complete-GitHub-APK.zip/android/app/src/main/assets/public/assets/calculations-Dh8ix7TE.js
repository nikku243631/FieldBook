const n=`import { AreaUnit, CropCycle, HarvestEntry, Transaction } from '../types';

export type LandConverterUnit =
  | 'acre'
  | 'bigha_pucca'
  | 'bigha_kaccha'
  | 'bigha'
  | 'hectare'
  | 'kanal'
  | 'marla'
  | 'guntha'
  | 'sqft';

// Base conversion table in Square Feet (Standard North/Central India Revenue Norms)
export const SQFT_PER_UNIT: Record<LandConverterUnit, number> = {
  acre: 43560, // 1 Acre = 43,560 sq.ft (4,840 sq.yd)
  bigha_pucca: 27225, // 1 Pucca Bigha = 3,025 sq.yd = 27,225 sq.ft (1 Acre = 1.6 Pucca Bigha)
  bigha: 17424, // Standard UP/Budaun regional ledger average (1 Acre = 2.5 Bigha = 17,424 sq.ft)
  bigha_kaccha: 9075, // 1 Kaccha Bigha = 1,008.33 sq.yd = 9,075 sq.ft (1 Pucca Bigha = 3 Kaccha Bigha)
  hectare: 107639.1, // 1 Hectare = 10,000 sq.m = 107,639.1 sq.ft (2.47105 Acres)
  kanal: 5445, // 8 Kanal = 1 Acre (5,445 sq.ft)
  marla: 272.25, // 20 Marla = 1 Kanal (272.25 sq.ft)
  guntha: 1089, // 40 Guntha = 1 Acre (1,089 sq.ft)
  sqft: 1
};

export function sanitizePositiveNumber(value: unknown, fallback = 0): number {
  const num = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(num) || num < 0) return fallback;
  return num;
}

export function convertAreaToAcres(area: number, unit: AreaUnit | LandConverterUnit): number {
  const cleanArea = sanitizePositiveNumber(area, 0);
  if (cleanArea === 0) return 0;
  const sqFtPerUnit = SQFT_PER_UNIT[unit] ?? SQFT_PER_UNIT.acre;
  return Number(((cleanArea * sqFtPerUnit) / SQFT_PER_UNIT.acre).toFixed(4));
}

export interface LandAreaConversionResult {
  inputValue: number;
  fromUnit: LandConverterUnit;
  sqFt: number;
  acre: number;
  bighaPucca: number;
  bighaStandard: number;
  bighaKaccha: number;
  hectare: number;
  kanal: number;
  marla: number;
  guntha: number;
}

export function convertLandAreaAllUnits(
  value: number,
  fromUnit: LandConverterUnit
): LandAreaConversionResult {
  const cleanVal = sanitizePositiveNumber(value, 0);
  const factor = SQFT_PER_UNIT[fromUnit] ?? SQFT_PER_UNIT.acre;
  const totalSqFt = cleanVal * factor;

  return {
    inputValue: cleanVal,
    fromUnit,
    sqFt: Math.round(totalSqFt),
    acre: Number((totalSqFt / SQFT_PER_UNIT.acre).toFixed(3)),
    bighaPucca: Number((totalSqFt / SQFT_PER_UNIT.bigha_pucca).toFixed(3)),
    bighaStandard: Number((totalSqFt / SQFT_PER_UNIT.bigha).toFixed(3)),
    bighaKaccha: Number((totalSqFt / SQFT_PER_UNIT.bigha_kaccha).toFixed(2)),
    hectare: Number((totalSqFt / SQFT_PER_UNIT.hectare).toFixed(3)),
    kanal: Number((totalSqFt / SQFT_PER_UNIT.kanal).toFixed(2)),
    marla: Number((totalSqFt / SQFT_PER_UNIT.marla).toFixed(2)),
    guntha: Number((totalSqFt / SQFT_PER_UNIT.guntha).toFixed(2))
  };
}

export interface CropFinancialSummary {
  totalExpenses: number;
  totalIncome: number;
  netProfit: number;
  isProfit: boolean;
  profitMarginPercent: number;
  roiPercent: number;
  landArea: number;
  areaUnit: AreaUnit;
  landAreaInAcres: number;
  costPerUnit: number;
  profitPerUnit: number;
  costPerAcre: number;
  profitPerAcre: number;
  totalHarvestQuintal: number;
  yieldPerUnit: number;
  yieldPerAcre: number;
  costPerQuintal: number;
  expenseByCategory: Record<string, number>;
}

export function calculateCropFinancials(
  crop: CropCycle,
  transactions: Transaction[],
  harvests: HarvestEntry[]
): CropFinancialSummary {
  const cropTx = transactions.filter((t) => t.cropId === crop.id);
  const expenses = cropTx.filter((t) => t.type === 'expense');
  const incomes = cropTx.filter((t) => t.type === 'income');
  const cropHarvests = harvests.filter((h) => h.cropId === crop.id);

  const totalExpenses = Math.round(
    expenses.reduce((sum, t) => sum + sanitizePositiveNumber(t.amount, 0), 0)
  );
  const totalIncome = Math.round(
    incomes.reduce((sum, t) => sum + sanitizePositiveNumber(t.amount, 0), 0)
  );
  const netProfit = totalIncome - totalExpenses;
  const isProfit = netProfit >= 0;

  const profitMarginPercent =
    totalIncome > 0 ? Number(((netProfit / totalIncome) * 100).toFixed(1)) : 0;
  const roiPercent =
    totalExpenses > 0 ? Number(((netProfit / totalExpenses) * 100).toFixed(1)) : 0;

  const cleanArea = sanitizePositiveNumber(crop.landArea, 0);
  const areaInAcres = convertAreaToAcres(cleanArea, crop.areaUnit);

  const costPerUnit = cleanArea > 0 ? Math.round(totalExpenses / cleanArea) : 0;
  const profitPerUnit = cleanArea > 0 ? Math.round(netProfit / cleanArea) : 0;

  const costPerAcre = areaInAcres > 0 ? Math.round(totalExpenses / areaInAcres) : 0;
  const profitPerAcre = areaInAcres > 0 ? Math.round(netProfit / areaInAcres) : 0;

  const totalHarvestQuintal = Number(
    cropHarvests
      .reduce((sum, h) => sum + sanitizePositiveNumber(h.quantityQuintal, 0), 0)
      .toFixed(2)
  );

  const yieldPerUnit =
    cleanArea > 0 ? Number((totalHarvestQuintal / cleanArea).toFixed(2)) : 0;
  const yieldPerAcre =
    areaInAcres > 0 ? Number((totalHarvestQuintal / areaInAcres).toFixed(2)) : 0;

  const costPerQuintal =
    totalHarvestQuintal > 0 ? Math.round(totalExpenses / totalHarvestQuintal) : 0;

  const expenseByCategory: Record<string, number> = {};
  for (const e of expenses) {
    const amt = sanitizePositiveNumber(e.amount, 0);
    expenseByCategory[e.category] = Math.round((expenseByCategory[e.category] || 0) + amt);
  }

  return {
    totalExpenses,
    totalIncome,
    netProfit,
    isProfit,
    profitMarginPercent,
    roiPercent,
    landArea: cleanArea,
    areaUnit: crop.areaUnit,
    landAreaInAcres: areaInAcres,
    costPerUnit,
    profitPerUnit,
    costPerAcre,
    profitPerAcre,
    totalHarvestQuintal,
    yieldPerUnit,
    yieldPerAcre,
    costPerQuintal,
    expenseByCategory
  };
}

export interface MandiCalculationInput {
  grossWeightKg: number;
  tareWeightKg: number;
  ratePerQuintal: number;
  bagsCount?: number;
  palledariPerBag?: number;
  palledariPerQuintal?: number;
  mandiCessPercent?: number;
}

export interface MandiCalculationResult {
  isValidWeight: boolean;
  weightError?: string;
  netWeightKg: number;
  netWeightQuintal: number;
  netWeightMann: number;
  grossAmount: number;
  totalPalledari: number;
  mandiCessAmount: number;
  totalDeductions: number;
  netPayableAmount: number;
}

export function calculateMandiPayout(input: MandiCalculationInput): MandiCalculationResult {
  const grossKg = sanitizePositiveNumber(input.grossWeightKg, 0);
  const tareKg = sanitizePositiveNumber(input.tareWeightKg, 0);
  const rateQuintal = sanitizePositiveNumber(input.ratePerQuintal, 0);
  const bags = sanitizePositiveNumber(input.bagsCount, 0);
  const palledariBag = sanitizePositiveNumber(input.palledariPerBag, 0);
  const palledariQtl = sanitizePositiveNumber(input.palledariPerQuintal, 0);
  const cessPercent = sanitizePositiveNumber(input.mandiCessPercent, 0);

  const isValidWeight = tareKg <= grossKg;
  const weightError = !isValidWeight
    ? 'खाली ट्रॉली का वजन (Tare) कुल कांटा वजन (Gross) से अधिक नहीं हो सकता।'
    : undefined;

  const netWeightKg = isValidWeight ? Number((grossKg - tareKg).toFixed(2)) : 0;
  const netWeightQuintal = Number((netWeightKg / 100).toFixed(2));
  const netWeightMann = Number((netWeightKg / 40).toFixed(2)); // 1 Mann = 40 Kg

  const grossAmount = Number((netWeightQuintal * rateQuintal).toFixed(2));
  const bagPalledari = bags * palledariBag;
  const quintalPalledari = netWeightQuintal * palledariQtl;
  const totalPalledari = Math.round(bagPalledari + quintalPalledari);
  const mandiCessAmount = Math.round((grossAmount * cessPercent) / 100);
  const totalDeductions = totalPalledari + mandiCessAmount;
  const netPayableAmount = Math.max(0, Math.round(grossAmount - totalDeductions));

  return {
    isValidWeight,
    weightError,
    netWeightKg,
    netWeightQuintal,
    netWeightMann,
    grossAmount: Math.round(grossAmount),
    totalPalledari,
    mandiCessAmount,
    totalDeductions,
    netPayableAmount
  };
}

export interface FertilizerDosageConfig {
  name: string;
  ureaBagsPerAcre: number; // 45kg bag
  dapBagsPerAcre: number; // 50kg bag
  mopBagsPerAcre: number; // 50kg bag
  zincKgPerAcre: number;
  tips: string;
}

export const FERTILIZER_RECOMMENDATIONS: Record<string, FertilizerDosageConfig> = {
  wheat: {
    name: 'गेहूं (Wheat)',
    ureaBagsPerAcre: 2.5,
    dapBagsPerAcre: 1,
    mopBagsPerAcre: 0.5,
    zincKgPerAcre: 5,
    tips: '1 बैग DAP + 1/3 यूरिया बुवाई पर। बाकी यूरिया 21 दिन व 42 दिन पर दो बराबर हिस्सों में दें।'
  },
  paddy: {
    name: 'धान (Paddy/Rice)',
    ureaBagsPerAcre: 3,
    dapBagsPerAcre: 1,
    mopBagsPerAcre: 0.6,
    zincKgPerAcre: 10,
    tips: 'जिंक और DAP को कभी एक साथ मिलाकर न डालें, रासायनिक क्रिया से असर कम हो जाता है।'
  },
  mustard: {
    name: 'सरसों (Mustard)',
    ureaBagsPerAcre: 1.5,
    dapBagsPerAcre: 0.8,
    mopBagsPerAcre: 0.3,
    zincKgPerAcre: 4,
    tips: 'सरसों में सल्फर (20-25 किलो SSP या 90% बेंटोनाइट) अवश्य दें, इससे तेल की मात्रा 3-4% बढ़ती है।'
  },
  sugarcane: {
    name: 'गन्ना (Sugarcane)',
    ureaBagsPerAcre: 5,
    dapBagsPerAcre: 2,
    mopBagsPerAcre: 1.5,
    zincKgPerAcre: 10,
    tips: 'बुवाई के समय फास्फोरस व पोटाश दें। यूरिया को 3-4 बार में मिट्टी चढ़ाते समय तक पूरा करें।'
  },
  potato: {
    name: 'आलू (Potato)',
    ureaBagsPerAcre: 3.5,
    dapBagsPerAcre: 2,
    mopBagsPerAcre: 2,
    zincKgPerAcre: 5,
    tips: 'पोटाश (MOP) आलू के कंदों की चमक और साइज बढ़ाने में अत्यंत महत्वपूर्ण है।'
  }
};

export function calculateFertilizerRequirement(
  cropKey: string,
  area: number,
  unit: 'acre' | 'bigha' | 'hectare' = 'acre'
) {
  const config = FERTILIZER_RECOMMENDATIONS[cropKey] || FERTILIZER_RECOMMENDATIONS.wheat;
  const cleanArea = sanitizePositiveNumber(area, 0);
  const areaInAcres =
    unit === 'acre'
      ? cleanArea
      : unit === 'bigha'
      ? cleanArea / 2.5
      : cleanArea * 2.47105;

  const ureaBags = Number((config.ureaBagsPerAcre * areaInAcres).toFixed(1));
  const dapBags = Number((config.dapBagsPerAcre * areaInAcres).toFixed(1));
  const mopBags = Number((config.mopBagsPerAcre * areaInAcres).toFixed(1));
  const zincKg = Number((config.zincKgPerAcre * areaInAcres).toFixed(1));

  return {
    config,
    areaInAcres: Number(areaInAcres.toFixed(2)),
    ureaBags,
    ureaKg: Math.round(ureaBags * 45),
    dapBags,
    dapKg: Math.round(dapBags * 50),
    mopBags,
    mopKg: Math.round(mopBags * 50),
    zincKg
  };
}

export const SEED_RATES_PER_ACRE: Record<string, { name: string; kgPerAcre: number; tip: string }> = {
  wheat: {
    name: 'गेहूं (Wheat)',
    kgPerAcre: 40,
    tip: 'समय पर बुवाई (नवंबर 1-20): 40 किग्रा/एकड़। पछेती बुवाई: 50 किग्रा/एकड़।'
  },
  mustard: {
    name: 'सरसों (Mustard)',
    kgPerAcre: 1.5,
    tip: 'संकर (हाइब्रिड) बीज: 1.5 किलो/एकड़। देसी किस्में: 2 किलो/एकड़।'
  },
  paddy_dsm: {
    name: 'धान (DSR सीधी बुवाई)',
    kgPerAcre: 8,
    tip: 'सीधी बिजाई (DSR) में 8-10 किलो/एकड़, नर्सरी के लिए 5-6 किलो।'
  },
  chana: {
    name: 'चना (Gram)',
    kgPerAcre: 30,
    tip: 'काबुली चना 35-40 किलो, देसी चना 25-30 किलो प्रति एकड़।'
  },
  cotton: {
    name: 'कपास (Bt Cotton)',
    kgPerAcre: 1.8,
    tip: '2 पैकेट (लगभग 900 ग्राम प्रति पैकेट) प्रति एकड़।'
  }
};

export function calculateSeedRequirement(
  cropKey: string,
  area: number,
  pricePerKg: number,
  unit: 'acre' | 'bigha' | 'hectare' = 'acre'
) {
  const config = SEED_RATES_PER_ACRE[cropKey] || SEED_RATES_PER_ACRE.wheat;
  const cleanArea = sanitizePositiveNumber(area, 0);
  const cleanPrice = sanitizePositiveNumber(pricePerKg, 0);
  const areaInAcres =
    unit === 'acre'
      ? cleanArea
      : unit === 'bigha'
      ? cleanArea / 2.5
      : cleanArea * 2.47105;

  const totalSeedRequiredKg = Number((config.kgPerAcre * areaInAcres).toFixed(1));
  const totalSeedCost = Math.round(totalSeedRequiredKg * cleanPrice);

  return {
    config,
    areaInAcres: Number(areaInAcres.toFixed(2)),
    totalSeedRequiredKg,
    totalSeedCost
  };
}

export function calculateDieselIrrigationCost(
  runHours: number,
  litersPerHour: number,
  pricePerLiter: number,
  irrigatedAcres: number
) {
  const cleanHours = sanitizePositiveNumber(runHours, 0);
  const cleanLph = sanitizePositiveNumber(litersPerHour, 0);
  const cleanPrice = sanitizePositiveNumber(pricePerLiter, 0);
  const cleanAcres = sanitizePositiveNumber(irrigatedAcres, 0);

  const totalDieselLiters = Number((cleanHours * cleanLph).toFixed(1));
  const totalDieselCost = Math.round(totalDieselLiters * cleanPrice);
  const costPerAcre = cleanAcres > 0 ? Math.round(totalDieselCost / cleanAcres) : 0;

  return {
    totalDieselLiters,
    totalDieselCost,
    costPerAcre
  };
}


`;export{n as default};
