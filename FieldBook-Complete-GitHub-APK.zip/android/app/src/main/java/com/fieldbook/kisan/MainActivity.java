package com.fieldbook.kisan;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends BridgeActivity {
    private WebView printWebView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.parseColor("#064e3b"));
        window.setNavigationBarColor(Color.parseColor("#090d0b"));
        window.getDecorView().setBackgroundColor(Color.parseColor("#064e3b"));

        // Ensure crisp white status bar icons on deep emerald status bar
        WindowInsetsControllerCompat controller =
            WindowCompat.getInsetsController(window, window.getDecorView());
        if (controller != null) {
            controller.setAppearanceLightStatusBars(false);
            controller.setAppearanceLightNavigationBars(false);
        }

        // Handle system window insets explicitly so the WebView never overlaps the status bar,
        // camera cutout, or navigation bar on any Android version (including Android 15 / API 35)
        WindowCompat.setDecorFitsSystemWindows(window, false);

        View contentView = findViewById(android.R.id.content);
        if (contentView != null) {
            int fallbackStatusBarHeight = getStatusBarHeight();
            ViewCompat.setOnApplyWindowInsetsListener(contentView, (v, windowInsets) -> {
                Insets bars = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout()
                );
                int topInset = bars.top > 0 ? bars.top : fallbackStatusBarHeight;
                v.setPadding(bars.left, topInset, bars.right, bars.bottom);
                return WindowInsetsCompat.CONSUMED;
            });
            // Apply initial fallback padding immediately before first inset pass
            contentView.setPadding(0, fallbackStatusBarHeight, 0, 0);
        }

        // Register native Android bridge and lock WebView textZoom to 100% so APK layout & font sizes
        // match the web preview pixel-for-pixel regardless of phone system font scaling
        if (getBridge() != null && getBridge().getWebView() != null) {
            WebView webView = getBridge().getWebView();
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            android.webkit.WebSettings webSettings = webView.getSettings();
            webSettings.setTextZoom(100);
            webSettings.setDomStorageEnabled(true);
            webSettings.setDatabaseEnabled(true);
            webSettings.setAllowFileAccess(true);
            webSettings.setAllowContentAccess(true);
            webView.addJavascriptInterface(new AndroidNativeBridge(this), "AndroidBridge");
        }
    }

    private int getStatusBarHeight() {
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        if (result <= 0) {
            result = Math.round(24 * getResources().getDisplayMetrics().density);
        }
        return result;
    }

    public class AndroidNativeBridge {
        private final Context context;

        AndroidNativeBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void printHtml(final String htmlContent, final String jobName) {
            runOnUiThread(() -> {
                try {
                    WebView webView = new WebView(context);
                    webView.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(WebView view, String url) {
                            createWebPrintJob(view, jobName != null && !jobName.isEmpty() ? jobName : "FieldBook_Statement");
                            printWebView = null;
                        }
                    });
                    webView.loadDataWithBaseURL(null, htmlContent, "text/HTML", "UTF-8", null);
                    printWebView = webView;
                } catch (Exception e) {
                    Toast.makeText(context, "PDF Print Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        private void createWebPrintJob(WebView webView, String jobName) {
            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            if (printManager != null) {
                PrintDocumentAdapter printAdapter = webView.createPrintDocumentAdapter(jobName);
                printManager.print(jobName, printAdapter, new PrintAttributes.Builder().build());
            }
        }

        @JavascriptInterface
        public boolean saveFileToDownloads(final String content, final String fileName, final String mimeType) {
            try {
                byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
                return writeBytesToDownloads(bytes, fileName, mimeType);
            } catch (Exception e) {
                shareText(content, fileName);
            }
            return false;
        }

        @JavascriptInterface
        public boolean saveBase64FileToDownloads(final String base64Data, final String fileName, final String mimeType) {
            try {
                String cleanBase64 = base64Data;
                if (cleanBase64.contains(",")) {
                    cleanBase64 = cleanBase64.substring(cleanBase64.indexOf(",") + 1);
                }
                byte[] bytes = Base64.decode(cleanBase64, Base64.DEFAULT);
                return writeBytesToDownloads(bytes, fileName, mimeType != null ? mimeType : "application/pdf");
            } catch (Exception e) {
                runOnUiThread(() ->
                    Toast.makeText(context, "PDF Save Error: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
            }
            return false;
        }

        private boolean writeBytesToDownloads(final byte[] bytes, final String fileName, final String mimeType) throws Exception {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, mimeType != null ? mimeType : "application/octet-stream");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                ContentResolver resolver = context.getContentResolver();
                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    try (OutputStream out = resolver.openOutputStream(uri)) {
                        if (out != null) {
                            out.write(bytes);
                            out.flush();
                        }
                    }
                    runOnUiThread(() ->
                        Toast.makeText(context, "Downloads में सेव हो गया: " + fileName, Toast.LENGTH_LONG).show()
                    );
                    return true;
                }
            } else {
                File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloadsDir.exists()) {
                    downloadsDir.mkdirs();
                }
                File outFile = new File(downloadsDir, fileName);
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(bytes);
                    fos.flush();
                }
                runOnUiThread(() ->
                    Toast.makeText(context, "Downloads में सेव हो गया: " + fileName, Toast.LENGTH_LONG).show()
                );
                return true;
            }
            return false;
        }

        @JavascriptInterface
        public void shareText(final String text, final String title) {
            runOnUiThread(() -> {
                try {
                    Intent sendIntent = new Intent(Intent.ACTION_SEND);
                    sendIntent.setType("text/plain");
                    sendIntent.putExtra(Intent.EXTRA_SUBJECT, title != null ? title : "FieldBook Report");
                    sendIntent.putExtra(Intent.EXTRA_TEXT, text);
                    Intent shareIntent = Intent.createChooser(sendIntent, title != null ? title : "Share via");
                    shareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(shareIntent);
                } catch (Exception e) {
                    Toast.makeText(context, "Share Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
