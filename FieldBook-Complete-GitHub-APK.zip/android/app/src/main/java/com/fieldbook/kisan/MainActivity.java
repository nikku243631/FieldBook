package com.fieldbook.kisan;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
